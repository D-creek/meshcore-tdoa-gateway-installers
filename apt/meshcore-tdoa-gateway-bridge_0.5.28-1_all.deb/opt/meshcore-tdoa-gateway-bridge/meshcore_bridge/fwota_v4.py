"""Remote firmware OTA for Heltec WiFi LoRa 32 v4 receivers (KAN-168).

The bridge is the only host with USB-CDC reach to a V4 receiver, so
remote firmware upgrades funnel through here: the API server queues a
job, the bridge downloads the artifact, then this module hands the
binary off to ``esptool`` over the receiver's CDC port and verifies the
chip re-enumerates with a valid bootloader.

Hardware specifics encoded below:

* Heltec WiFi LoRa 32 v4 — ESP32-S3-WROOM-1, 16 MB flash, 2 MB PSRAM.
* Runtime CDC descriptor::

      usb-Espressif_Systems_heltec_wifi_lora_32_v4__16_MB_FLASH__2_MB_PSRAM_*

* Bootloader (post-reset) CDC descriptor::

      usb-Espressif_USB_JTAG_serial_debug_unit_*

  When ``esptool`` issues its ``usb-reset`` sequence over the
  USB-Serial-JTAG peripheral, the ESP32-S3 ROM bootloader engages
  automatically — we don't need an out-of-band reboot. After the write,
  ``--after watchdog-reset`` re-samples GPIO0 so the chip boots the new
  firmware and the runtime descriptor reappears under
  ``/dev/serial/by-id/``.

* Flash command we use::

      esptool --chip esp32s3 --port <jtag-port> --baud 460800 \\
              --connect-attempts 5 \\
              --before usb-reset --after watchdog-reset \\
              write-flash 0x10000 <fw.bin>

  ``--before usb-reset`` is the documented reset sequence for the
  USB-Serial-JTAG peripheral (the ESP32-S3 native-USB face) — the
  RTS-line ``default-reset``/``hard-reset`` does NOT exist on native USB,
  so it never engaged the ROM bootloader and produced
  "No serial data received". ``--after watchdog-reset`` triggers a FULL
  system reset that re-samples GPIO0 (the USB-Serial-JTAG core-reset
  alone leaves the chip stuck in download mode), so the chip leaves
  download mode and boots the freshly-flashed image; the runtime
  descriptor then reappears under ``/dev/serial/by-id/``.

The function is async-first so the caller (a per-job task spawned by
the bridge's HTTP handler) can ``await`` flash progress without
blocking the supervisor thread that owns USB rescans.

The caller is responsible for stopping the serial reader on the port
BEFORE calling :func:`flash_v4` — esptool needs exclusive access to
the CDC node and a concurrent ``serial.Serial.read`` will fight it.
This module never mutates :class:`~meshcore_bridge.serial_reader.SerialReader`
state directly so its responsibility boundary stays narrow and testable.
"""

from __future__ import annotations

import asyncio
import glob
import re
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Literal

import serial
import structlog

from . import usb_recovery

log = structlog.get_logger(__name__)

#: Async post-flash version probe (STEP 5). Same shape as
#: ``fwota_techo.HeartbeatProbe`` — ``(port, within_seconds) -> bool`` — so the
#: dispatcher hands the SAME version-aware collaborator to both flashers.
#: Returns True only when the device came back reporting the TARGET version.
HeartbeatProbe = Callable[[str, float], Awaitable[bool]]


#: Re-enumeration glob for the V4's RUNTIME (post-flash) CDC descriptor.
#: The trailing ``*`` matches the per-MAC suffix udev appends; one V4 plugged
#: in shows exactly one match. When two V4s share a bridge the caller passes
#: a more specific glob via :attr:`FlashOptions.runtime_glob`.
DEFAULT_RUNTIME_GLOB = (
    "/dev/serial/by-id/"
    "usb-Espressif_Systems_heltec_wifi_lora_32_v4__16_MB_FLASH__2_MB_PSRAM_*"
)

#: Default upper bound for re-enumeration polling. The V4 typically reboots
#: + re-enumerates in 4-8 s on a clean USB hub; 90 s leaves headroom for a
#: cold-cache udev fire and a slow Pi-side ``by-id`` symlink refresh.
DEFAULT_REENUM_TIMEOUT_S = 90.0

#: Polling interval for the re-enumeration loop. Slow enough that we don't
#: burn the bridge CPU, fast enough that a healthy reboot is detected within
#: ~1 s of the symlink appearing.
_REENUM_POLL_INTERVAL_S = 0.5

#: Pre-flash wait-for-port poll (0.5.24). Before launching esptool on a native-
#: USB ESP32-S3 we poll the resolved by-id node until it exists (udev settle),
#: to ride out the CDC->ROM re-enumeration race that produces "Could not
#: configure port (5)". Short interval + short ceiling: a present node returns
#: immediately, a missing node is given a couple of seconds before we let
#: esptool's own --connect-attempts take over.
_PORT_WAIT_POLL_INTERVAL_S = 0.25
_PORT_WAIT_TIMEOUT_S = 5.0

#: How long to wait for esptool's subprocess to finish a write. The 660 KB
#: artifact flashes in <30 s on a clean USB hub at 460800 baud; 5 min covers
#: a degraded link or a UART-glitch retry without escaping into "the job
#: hung forever" territory.
DEFAULT_FLASH_TIMEOUT_S = 300.0

#: Verification step's timeout — a ``flash-id`` query that just asks the
#: bootloader to identify itself. Usually completes in <5 s; 30 s covers a
#: slow USB hub or a transient enumeration glitch.
DEFAULT_VERIFY_TIMEOUT_S = 30.0

#: Default flashing baud rate. 460800 is the speed we've used successfully
#: against the V4's ROM bootloader on the OPi One bridge. Higher rates work
#: on shorter cables but degrade reliability on a long bus run.
DEFAULT_FLASH_BAUD = 460800

#: Offset of the V4's primary application partition within the SPI flash.
#: 0x10000 (64 KiB) is the PlatformIO default for the
#: ``heltec_v4_companion_radio_usb_tdoa_rx`` env (and for every ESP-IDF
#: project that uses the stock partition table).
DEFAULT_FLASH_OFFSET = "0x10000"


FlashState = Literal[
    "success",
    "rolled_back_to_previous",
    "failed_verify",
    "failed_flash",
    "failed_no_reenum",
    "failed_timeout",
    "failed_boot_loop",
    # STEP 5: flash wrote + chip re-enumerated + booted stably, but the
    # version-aware probe never saw a TARGET-version 0x94 frame within the
    # window (old firmware still running / cold-GPS too slow). RETRIABLE —
    # _map_flash_state folds it into the collector's retriable ``failed_flash``.
    "failed_post_flash_no_heartbeat",
]

#: How long to wait after the runtime CDC descriptor reappears before
#: declaring the flash a success. A bad firmware enumerates briefly
#: (the bootloader hands off, USB-CDC comes up) then crashes back into
#: the JTAG ROM bootloader within ~4 s — see the V4 tdoa-1.8.5 incident
#: on 2026-05-13 where every flash succeeded at bytes-on-disk but the
#: firmware faulted within 4 s of boot. 8 s gives ~2x headroom over
#: that observed boot-loop interval; a healthy firmware is still
#: enumerated continuously for the entire window.
BOOT_STABILITY_WAIT_S = 8.0

#: Baud rate for the JTAG-bootloader recovery path. The JTAG ROM
#: bootloader is less tolerant of high baud rates than the application
#: serial path, especially on long USB cables / hubs. 115_200 is the
#: ESP32-S3 ROM default and works reliably; the 460_800 we use for
#: normal application flashing intermittently fails on the JTAG path
#: which is exactly the failure pattern that bricked the V4 on
#: 2026-05-13. Belt-and-braces: also bump --connect-attempts.
JTAG_RETRY_BAUD = 115_200

#: Initial sleep before the JTAG retry attempt. The runtime-port flash
#: that failed will have dropped the chip into JTAG bootloader; the OS
#: needs ~1-2 s to enumerate the new descriptor and stabilise its
#: udev symlink. 5 s gives generous headroom — but if the chip is slow
#: to transition, see JTAG_DETECT_TOTAL_S for the upper bound.
JTAG_RETRY_WAIT_S = 5.0

#: Upper bound on the JTAG-descriptor polling loop. If the chip is
#: still in runtime mode 5 s after the failed handshake (the previous
#: behaviour gave up here), some chips need an extra few seconds to
#: actually transition. Poll every JTAG_DETECT_POLL_S until the
#: JTAG descriptor appears or this deadline elapses. Verified on V4
#: job 12 on 2026-05-13: the chip transitioned to JTAG ~7 s after
#: esptool exit, well past the previous single-shot glob window.
JTAG_DETECT_TOTAL_S = 20.0
JTAG_DETECT_POLL_S = 1.0

#: --connect-attempts passed to the JTAG retry esptool invocation.
#: esptool's default is 7 internally but our prior code didn't pass
#: it explicitly. Setting it high is cheap (only affects the failure
#: path) and makes the retry succeed across more flaky USB hubs.
JTAG_CONNECT_ATTEMPTS = 7

#: --connect-attempts for the FIRST (application-port) attempt on a native-USB
#: ESP32-S3 (STEP 4 / 0.5.24). The Heltec V4 runs ESP-IDF5 native USB-CDC; a
#: single usb-reset can race the host re-enumerating the CDC node, so several
#: attempts smooth over the transient before the soft-EIO ladder kicks in.
#: 5 is the documented esptool value for riding out the CDC->ROM re-enumeration
#: race on native USB (esptool's internal default is 7; we pass it explicitly so
#: the PRIMARY attempt is as robust as the JTAG retry, which already sets 7).
NATIVE_USB_CONNECT_ATTEMPTS = 5

#: ``--after`` reset mode for every ESP32-S3 native-USB write-flash (0.5.24).
#: DOCUMENTED: over USB-Serial-JTAG the peripheral can only trigger a CORE reset,
#: which does NOT re-sample the GPIO0 boot-strapping pin, so the chip can stay
#: wedged in download mode after the write. ``watchdog-reset`` forces a FULL
#: system reset that re-samples GPIO0 and lets normal boot proceed; the legacy
#: ``hard-reset`` drives the RTS line, which does not exist on native USB and so
#: did nothing. (Espressif advanced-options: watchdog-reset is the after-mode to
#: use "when the RTS control line is not available, especially in the USB-OTG and
#: USB-Serial/JTAG modes".)
AFTER_RESET_MODE = "watchdog-reset"

#: Baud for the 1200-bps "touch" that drops an APP-RUNNING Heltec V4 into
#: download mode (KAN-149-endorsed). The V4 build is Arduino USB-OTG
#: (ARDUINO_USB_MODE=0, ARDUINO_USB_CDC_ON_BOOT=1, use_1200bps_touch=true);
#: arduino-esp32's USBCDC honours a 1200-baud open (with DTR/RTS deasserted) by
#: calling usb_persist_restart(RESTART_BOOTLOADER) → on the S3 this is a CLEAN
#: PHY hand-off (persist-magic + FORCE_DOWNLOAD_BOOT + esp_restart) and the chip
#: re-enumerates as the USB-Serial-JTAG descriptor. This lives in the arduino
#: core (host-side), so it works on EXISTING field firmware with no firmware
#: change. (The bare KAN-149 register write — no persist magic / no PHY switch —
#: is what bricked; we are NOT doing that.)
_TOUCH_BAUD: int = 1200

#: Brief settle after the 1200-touch open before closing the port — gives the
#: USB host time to register the SET_CONTROL_LINE_STATE (DTR/RTS=0) that the
#: arduino core latches to decide a touch-reset. Kept tiny; the JTAG-detect poll
#: below provides the real re-enumeration wait.
_TOUCH_SETTLE_S: float = 0.25

#: Upper bound on the post-1200-touch poll for the USB-Serial-JTAG descriptor to
#: appear. The S3 PHY hand-off + host re-enumeration completes in ~2-6 s on a
#: clean hub; 30 s leaves generous headroom for a slow Pi-side by-id symlink
#: refresh on a heavily-contended host (this fleet runs at load 8-14) while
#: staying well inside the job timeout. Matched-or-exceeded by JTAG_DETECT_TOTAL_S.
#: Poll every _DOWNLOAD_MODE_POLL_S.
_DOWNLOAD_MODE_DETECT_TOTAL_S: float = 30.0
_DOWNLOAD_MODE_POLL_S: float = 0.5

#: BRICK-SAFETY: how long the reset-only escape waits for the USB-Serial-JTAG
#: descriptor to (re)appear when it is invoked WITHOUT a pre-resolved port — i.e.
#: a 1200-touch latched the chip into download mode but the by-id symlink hadn't
#: materialised by the time the flow bailed. If the chip really is in download
#: mode the symlink WILL appear; if the touch was a no-op (chip still on the app)
#: it never does and the escape safely no-ops. Kept SHORT (the 30s detect poll has
#: ALREADY run before this — see _DOWNLOAD_MODE_DETECT_TOTAL_S — so this is only
#: the extra safety margin for a symlink lagging PAST that window, not the primary
#: wait). Short so the genuine no-op-touch failure path terminates promptly rather
#: than always paying a second 30s.
_ESCAPE_PORT_WAIT_S: float = 10.0

#: STEP 4 — esptool reset-mode fallback LADDER for an ESP32-S3 native-USB chip.
#: The ``usb-reset`` mode (esptool >= 4.6) drives the reset over the native
#: USB-CDC's CDC-ACM break/SET_CONTROL_LINE_STATE rather than the DTR/RTS toggle
#: ``default-reset`` uses — the DTR/RTS dance is what reliably wedged the
#: ESP32-S3 USB-CDC stack and bounced the chip into the JTAG ROM bootloader
#: (2026-05-13). But ``usb-reset`` is hardware-UNVERIFIED on this exact OPi +
#: V4 combination, so we keep a ladder: try usb-reset, then usb-reset with the
#: stub loader disabled (``--no-stub`` — the stub upload itself can fail to sync
#: over the wedged CDC), then fall all the way back to the legacy default-reset.
#: Each entry is (before_reset_mode, no_stub).
_NATIVE_USB_RESET_LADDER: tuple[tuple[str, bool], ...] = (
    ("usb-reset", False),
    ("usb-reset", True),
    ("default-reset", False),
)

#: Runtime + bootloader descriptor markers that mean "this is an ESP32-S3
#: native-USB port" (STEP 4 classification). The JTAG ROM bootloader descriptor
#: is the unambiguous one; the V4 application descriptor is the other native-USB
#: face of the SAME chip. A port carrying either is driven over native USB-CDC,
#: so it gets the usb-reset ladder instead of the DTR/RTS default-reset.
_NATIVE_USB_DESCRIPTOR_MARKERS: tuple[str, ...] = (
    "Espressif_USB_JTAG_serial_debug_unit",  # ESP32-S3 ROM JTAG bootloader
    "heltec_wifi_lora_32_v4",                 # IDF5 V4 application descriptor
)

#: The unambiguous ESP32-S3 USB-Serial-JTAG (USJ) descriptor marker — the
#: download-mode face of the chip. esptool MUST be handed THIS descriptor, not
#: the V4 application CDC, which is a firmware TinyUSB endpoint with no ROM
#: bootloader behind it. Used by :func:`_is_usb_jtag_descriptor` to tell the two
#: native-USB faces apart so the 1200-touch download-mode trigger only fires on
#: the application CDC (and is skipped when we're already handed a USJ port).
_USB_JTAG_DESCRIPTOR_MARKER: str = "Espressif_USB_JTAG_serial_debug_unit"

#: Glob for the ESP32-S3 USB-Serial-JTAG (download-mode) descriptor. The chip is
#: the only one parked in download mode at a time, so the broad ``*`` match is
#: safe; it pairs with the MAC-suffixed descriptor the dispatcher's
#: ``find_jtag_recovery_port`` builds. Defined once so the 1200-touch JTAG-detect
#: poll and the existing failure-path JTAG retry glob the same pattern.
_JTAG_GLOB = "/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_*"

#: Marker esptool prints when the host can't open / configure the native-USB
#: CDC port — the transient that a usb-reset is racing on the FIRST attempt.
#: Seen as ``Could not configure port: (5, 'Input/output error')`` (errno 5 =
#: EIO). We treat a FIRST-attempt failure carrying this as a SOFT failure and
#: fall through to the bootloader-descriptor retry rather than declaring
#: failed_flash (STEP 4).
_EIO_MARKERS: tuple[str, ...] = (
    "could not configure port",
    "could not open port",
    "(5,",
    "errno 5",
    "input/output error",
)


def is_native_usb_descriptor(path: str) -> bool:
    """True when ``path`` is an ESP32-S3 native-USB CDC descriptor (STEP 4).

    Used to pick the usb-reset esptool ladder over the legacy DTR/RTS
    default-reset, which wedges the ESP32-S3 USB-CDC stack. Matches either the
    JTAG ROM-bootloader descriptor or the V4 IDF5 application descriptor (the
    two native-USB faces of the same chip).
    """
    return any(marker in path for marker in _NATIVE_USB_DESCRIPTOR_MARKERS)


def _is_usb_jtag_descriptor(path: str) -> bool:
    """True when ``path`` is the ESP32-S3 USB-Serial-JTAG (download-mode) face.

    The 1200-touch download-mode trigger only applies to the Heltec V4
    application (OTG-CDC) descriptor; a port that is ALREADY the USJ descriptor
    is a chip already in download mode (stuck-chip recovery, or a dispatcher
    JTAG-swap), so the touch is skipped and we flash it directly.
    """
    return _USB_JTAG_DESCRIPTOR_MARKER in path


def _is_eio_failure(log_lines: list[str]) -> bool:
    """True when the esptool output carries an EIO port-open/configure error.

    Scanned to decide whether a FIRST-attempt failure is the soft USB-CDC
    transient (proceed to the bootloader retry) rather than a hard flash error.
    """
    blob = "\n".join(log_lines).lower()
    return any(marker in blob for marker in _EIO_MARKERS)


ProgressCallback = Callable[[str], None]


@dataclass(frozen=True)
class FlashOptions:
    """Tunables for :func:`flash_v4`. All defaults work for production V4s.

    Surfaced as a dataclass so the bridge's HTTP handler can override
    timeouts for slow USB hubs (Pi 3 + powered hub on a long cable) without
    re-passing eight kwargs. Frozen so tests can share one instance across
    multiple flash attempts without worrying about accidental mutation.
    """

    esptool_path: str = "esptool"
    chip: str = "esp32s3"
    baud: int = DEFAULT_FLASH_BAUD
    flash_offset: str = DEFAULT_FLASH_OFFSET
    runtime_glob: str = DEFAULT_RUNTIME_GLOB
    flash_timeout_s: float = DEFAULT_FLASH_TIMEOUT_S
    reenum_timeout_s: float = DEFAULT_REENUM_TIMEOUT_S
    verify_timeout_s: float = DEFAULT_VERIFY_TIMEOUT_S


@dataclass
class FlashResult:
    """Outcome of a single :func:`flash_v4` invocation.

    Always populated regardless of ``state`` — even on a hard failure the
    caller gets the partial log and the elapsed wall time so the API can
    surface "we tried for 6 s before esptool died".

    ``new_port`` is the post-reenum CDC path the chip came back on (used by
    the supervisor to restart its serial reader on the same logical
    receiver). ``None`` when re-enumeration never completed.
    """

    state: FlashState
    elapsed_s: float
    log: list[str] = field(default_factory=list)
    new_port: str | None = None
    error: str | None = None


def _now() -> float:
    """Wall-clock seconds; pulled out so tests can patch it deterministically."""
    return time.monotonic()


async def _stream_lines(
    stream: asyncio.StreamReader | None,
    log_lines: list[str],
    on_progress: ProgressCallback | None,
) -> None:
    """Drain ``stream`` line-by-line into ``log_lines`` and (optionally) ``on_progress``.

    ESP32 ``esptool`` interleaves progress lines on stdout (percentage bar)
    with status on stderr (errors, sync retries); we tee both streams through
    the same callback so the caller's UI sees a chronological view. Lines are
    decoded with ``errors="replace"`` so a stray non-UTF-8 byte from the
    JTAG-CDC serial path doesn't crash the drain task.
    """
    if stream is None:
        return
    while True:
        chunk = await stream.readline()
        if not chunk:
            return
        line = chunk.decode("utf-8", errors="replace").rstrip("\r\n")
        log_lines.append(line)
        if on_progress is not None:
            try:
                on_progress(line)
            except Exception as exc:  # noqa: BLE001 - callback must not kill the drain
                # Log but don't propagate; a misbehaving progress callback
                # should never abort an in-progress flash.
                log.warning(
                    "fwota.progress_callback_error",
                    error=str(exc),
                    error_type=type(exc).__name__,
                )


async def _await_reenum(
    glob_pattern: str,
    *,
    timeout_s: float,
    deadline_start: float,
    glob_fn: Callable[[str], list[str]] = glob.glob,
    sleep_fn: Callable[[float], asyncio.Future[None]] | None = None,
) -> str | None:
    """Poll ``glob_pattern`` until at least one path appears, or ``timeout_s`` elapses.

    Returns the first matching path (sorted, for determinism when two V4s
    share a hub) or ``None`` on timeout. Tests inject ``glob_fn`` to drive
    a synthetic re-enumeration without touching ``/dev``.
    """
    deadline = deadline_start + timeout_s
    while _now() < deadline:
        matches = sorted(glob_fn(glob_pattern))
        if matches:
            return matches[0]
        if sleep_fn is not None:
            await sleep_fn(_REENUM_POLL_INTERVAL_S)
        else:
            await asyncio.sleep(_REENUM_POLL_INTERVAL_S)
    return None


async def _wait_for_port(
    port: str,
    *,
    timeout_s: float,
    glob_fn: Callable[[str], list[str]] = glob.glob,
    sleep_fn: Callable[[float], asyncio.Future[None]] | None = None,
) -> bool:
    """Poll for ``port`` to exist (by-id node settled) before launching esptool.

    0.5.24 — the native-USB CDC node re-enumerates on reset (the app CDC vanishes
    and the ROM USB-Serial-JTAG node re-appears); handing esptool a momentarily-
    absent descriptor is what produces ``Could not configure port: (5, Input/
    output error)``. We poll the resolved by-id ``port`` (never ``/dev/ttyACMx``,
    which renumbers) until it appears or ``timeout_s`` elapses, the documented
    "wait for the correct node by descriptor" mitigation for the re-enumeration
    race. ``glob_fn`` is the test seam: in production it globs the literal path
    (a no-op pattern), so an already-present node returns True on the first poll.

    Returns True once the node is present, False on timeout. A False is advisory
    only — esptool still runs with ``--connect-attempts`` to ride out any residual
    race — so this never aborts a flash; it just removes the first-shot EIO.
    """
    deadline = _now() + timeout_s
    while True:
        # glob the literal path so the test seam can drive presence/absence; a
        # literal path with no wildcard globs to [path] iff it exists.
        if glob_fn(port):
            return True
        if _now() >= deadline:
            return False
        if sleep_fn is not None:
            await sleep_fn(_PORT_WAIT_POLL_INTERVAL_S)
        else:
            await asyncio.sleep(_PORT_WAIT_POLL_INTERVAL_S)


def _send_1200_touch(
    port: str,
    serial_factory: Callable[..., serial.Serial] | None,
) -> None:
    """Open ``port`` at 1200 bps with DTR/RTS deasserted, settle, close.

    The host-side trigger that drops an APP-RUNNING Heltec V4 (Arduino USB-OTG,
    ``use_1200bps_touch=true``) into download mode: arduino-esp32's USBCDC
    latches a 1200-baud open whose control lines are deasserted and calls
    ``usb_persist_restart(RESTART_BOOTLOADER)`` → a clean S3 PHY hand-off into
    the USB-Serial-JTAG ROM stub. Mirrors ``fwota_techo._send_1200_touch`` (the
    nRF52 primitive): synchronous + fast — the JTAG-detect poll provides the
    re-enumeration wait. Best-effort DTR/RTS: not every adapter exposes the
    lines, so failures to toggle them are swallowed (the open at 1200 bps is the
    load-bearing part). The brief settle gives the host time to emit the
    SET_CONTROL_LINE_STATE the core reads before we close.
    """
    factory = serial_factory or serial.Serial
    ser = factory(port, _TOUCH_BAUD, timeout=1.0)
    try:
        try:
            ser.dtr = False
            ser.rts = False
        except Exception:  # noqa: BLE001 - not all adapters expose DTR/RTS
            pass
        # Synchronous settle (sub-tick) so the control-line state registers
        # before close; this is fast enough not to warrant offloading.
        time.sleep(_TOUCH_SETTLE_S)
    finally:
        try:
            ser.close()
        except Exception:  # noqa: BLE001 - best-effort
            pass


async def _await_download_mode_port(
    *,
    timeout_s: float,
    glob_fn: Callable[[str], list[str]] = glob.glob,
    sleep_fn: Callable[[float], asyncio.Future[None]] | None = None,
) -> str | None:
    """Poll for the USB-Serial-JTAG (download-mode) descriptor to appear.

    Run right after a 1200-touch: the V4 re-enumerates from its application
    OTG-CDC descriptor to the USB-Serial-JTAG ROM descriptor in ~2-6 s. Globs
    :data:`_JTAG_GLOB` (the chip is the only one in download mode) every
    :data:`_DOWNLOAD_MODE_POLL_S` until it appears or ``timeout_s`` elapses.
    Returns the first matching path (sorted, for determinism), else ``None``.
    """
    deadline = _now() + timeout_s
    while True:
        matches = sorted(glob_fn(_JTAG_GLOB))
        if matches:
            return matches[0]
        if _now() >= deadline:
            return None
        if sleep_fn is not None:
            await sleep_fn(_DOWNLOAD_MODE_POLL_S)
        else:
            await asyncio.sleep(_DOWNLOAD_MODE_POLL_S)


async def _reset_only_escape(
    jtag_port: str | None,
    *,
    opts: FlashOptions,
    log_lines: list[str],
    on_progress: ProgressCallback | None,
    subprocess_factory: (
        Callable[..., asyncio.Future[asyncio.subprocess.Process]] | None
    ),
    plog: object,
    glob_fn: Callable[[str], list[str]] = glob.glob,
    sleep_fn: Callable[[float], asyncio.Future[None]] | None = None,
) -> None:
    """Brick-safety: issue a reset-only ``--after watchdog-reset`` over the USJ port.

    THE INVARIANT: once a 1200-touch (or a handed-in USJ port) puts the chip in
    download mode, it STAYS there until a full ``--after watchdog-reset`` — over
    native USB the DTR/RTS hard-reset does nothing and the USB-Serial-JTAG
    core-reset alone leaves the chip wedged in download mode. A button-less remote
    V4 must never be parked there. So on every exit path that would otherwise
    leave it in download mode without a successful watchdog-reset write, we run a
    NO-WRITE esptool invocation whose ``--after watchdog-reset`` does a POR-class
    reset: re-samples the straps + clears the download-mode latch → boots the
    INTACT old firmware. ``flash-id`` is the benign identify we attach the reset
    to (esptool always resets ``--after`` regardless of the operation).

    ``jtag_port`` may be ``None`` when the chip was latched into download mode by
    a 1200-touch but the USB-Serial-JTAG by-id symlink hadn't materialised by the
    time the flow bailed (a slow udev refresh on a contended Pi). In that case we
    POLL :func:`_await_download_mode_port` up to :data:`_ESCAPE_PORT_WAIT_S` for
    the descriptor to appear — if the chip really is in download mode the symlink
    WILL show up and we reset it; if the touch was a no-op (chip still running the
    app) the descriptor never appears and we safely no-op (nothing to recover).
    Without this poll, a symlink-lag window leaves the escape with no ``--port``
    to aim at and a remote V4 stuck in download mode — the single residual brick
    path this closes.

    Best-effort + idempotent: NEVER raises and NEVER changes the caller's
    FlashResult — the flash already terminated; this only stops it leaving the
    device unbootable. Re-uses the JTAG-recovery baud + connect-attempts.
    """
    if jtag_port is None:
        plog.info("fwota.flash.v4_reset_escape.awaiting_jtag_descriptor")  # type: ignore[attr-defined]
        jtag_port = await _await_download_mode_port(
            timeout_s=_ESCAPE_PORT_WAIT_S,
            glob_fn=glob_fn,
            sleep_fn=sleep_fn,
        )
        if jtag_port is None:
            # No USB-Serial-JTAG descriptor ever appeared: the chip is not in
            # download mode (the touch was a no-op / chip still on the app), so
            # there is nothing to reset and nothing to recover. Safe no-op.
            plog.info(  # type: ignore[attr-defined]
                "fwota.flash.v4_reset_escape.no_jtag_descriptor_presumed_running",
                waited_s=_ESCAPE_PORT_WAIT_S,
            )
            return
    reset_argv = [
        opts.esptool_path,
        "--chip", opts.chip,
        "--port", jtag_port,
        "--baud", str(JTAG_RETRY_BAUD),
        "--connect-attempts", str(JTAG_CONNECT_ATTEMPTS),
        "--before", "usb-reset",
        "--after", AFTER_RESET_MODE,
        "--no-stub",
        "flash-id",
    ]
    plog.info("fwota.flash.v4_reset_escape", jtag_port=jtag_port)  # type: ignore[attr-defined]
    try:
        rc, timed_out = await _run_esptool(
            reset_argv,
            log_lines=log_lines,
            on_progress=on_progress,
            timeout_s=opts.verify_timeout_s,
            subprocess_factory=subprocess_factory,
        )
        if not timed_out and rc == 0:
            plog.info("fwota.flash.v4_reset_escape.ok", jtag_port=jtag_port)  # type: ignore[attr-defined]
        else:
            plog.warning(  # type: ignore[attr-defined]
                "fwota.flash.v4_reset_escape.nonzero",
                jtag_port=jtag_port, returncode=rc, timed_out=timed_out,
            )
    except FileNotFoundError as exc:
        plog.warning(  # type: ignore[attr-defined]
            "fwota.flash.v4_reset_escape.esptool_missing", error=str(exc)
        )
    except Exception as exc:  # noqa: BLE001 - reset escape must never raise
        plog.warning(  # type: ignore[attr-defined]
            "fwota.flash.v4_reset_escape.error", error=str(exc)
        )


async def _run_esptool(
    argv: list[str],
    *,
    log_lines: list[str],
    on_progress: ProgressCallback | None,
    timeout_s: float,
    subprocess_factory: (
        Callable[..., asyncio.Future[asyncio.subprocess.Process]] | None
    ) = None,
) -> tuple[int, bool]:
    """Spawn esptool, stream its output, return ``(returncode, timed_out)``.

    The factory indirection exists so the test suite can swap in a fake
    ``Process`` object without monkeypatching the ``asyncio`` module
    itself — leaner test isolation, less risk of cross-test bleed.

    A ``timed_out=True`` indicates we hit ``timeout_s`` and killed the
    subprocess; the returncode in that case is whatever
    ``Process.wait()`` reports after ``kill()`` (-9 on POSIX, 1 on
    Windows). The caller treats either signal as ``failed_timeout``.
    """
    create = subprocess_factory or asyncio.create_subprocess_exec
    log_lines.append(f"$ {' '.join(argv)}")
    if on_progress is not None:
        try:
            on_progress(f"$ {' '.join(argv)}")
        except Exception:  # noqa: BLE001
            pass
    proc = await create(
        *argv,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    drain_stdout = asyncio.create_task(
        _stream_lines(proc.stdout, log_lines, on_progress)
    )
    drain_stderr = asyncio.create_task(
        _stream_lines(proc.stderr, log_lines, on_progress)
    )
    timed_out = False
    try:
        await asyncio.wait_for(proc.wait(), timeout=timeout_s)
    except TimeoutError:
        timed_out = True
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        # Give the killed process a moment to release its pipes so the
        # drain tasks can finish naturally rather than getting cancelled
        # mid-readline.
        try:
            await asyncio.wait_for(proc.wait(), timeout=5.0)
        except TimeoutError:
            pass
    # Make sure both stream-drain tasks finish (or get cancelled) before
    # returning — otherwise their output gets attributed to the wrong
    # invocation when the caller chains a verify call afterwards.
    #
    # When the process exited cleanly we give the drains a short grace
    # period to finish reading whatever buffered output the kernel still
    # has queued (esptool can emit its last "Hash of data verified" line
    # AFTER its return code goes through the pipe on some kernels). On a
    # timeout-kill path the kernel has already torn the pipes down so the
    # drains finish near-instantly anyway.
    drain_grace_s = 2.0 if not timed_out else 0.5
    try:
        await asyncio.wait_for(
            asyncio.gather(drain_stdout, drain_stderr, return_exceptions=True),
            timeout=drain_grace_s,
        )
    except TimeoutError:
        # Drains still going — cancel them and absorb the CancelledError so
        # the caller never sees a leaked task.
        for task in (drain_stdout, drain_stderr):
            if not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):  # noqa: BLE001
                    pass
    returncode = proc.returncode if proc.returncode is not None else 1
    return returncode, timed_out


def _build_write_argv(
    *,
    esptool_path: str,
    chip: str,
    port: str,
    baud: int,
    flash_offset: str,
    payload_path: str,
    before_reset: str,
    no_stub: bool,
    connect_attempts: int | None,
    after_reset: str = AFTER_RESET_MODE,
) -> list[str]:
    """Assemble an esptool ``write-flash`` argv for one reset-ladder step.

    ``before_reset`` is the ``--before`` mode (``usb-reset`` for an ESP32-S3
    native-USB chip, ``default-reset`` for the DTR/RTS fallback). ``after_reset``
    is the ``--after`` mode — defaults to ``watchdog-reset``, the documented
    after-mode for native USB: the USB-Serial-JTAG peripheral can only trigger a
    core reset that does NOT re-sample GPIO0, so ``hard-reset`` (an RTS toggle
    that doesn't exist on native USB) leaves the chip stuck in download mode,
    whereas ``watchdog-reset`` forces a full system reset that re-samples the
    strapping pin and boots the app. ``no_stub`` appends ``--no-stub`` so a
    wedged CDC doesn't have to survive the stub upload (the default stub loader
    is preferred — it is faster and not a requirement to drop on native USB).
    ``connect_attempts`` (when not None) adds ``--connect-attempts``. The global
    esptool flags (``--before``/``--after``/``--no-stub``/``--connect-attempts``)
    precede the ``write-flash`` subcommand, matching esptool's argument grammar.
    """
    argv = [esptool_path, "--chip", chip, "--port", port, "--baud", str(baud)]
    if connect_attempts is not None:
        argv += ["--connect-attempts", str(connect_attempts)]
    argv += ["--before", before_reset, "--after", after_reset]
    if no_stub:
        argv.append("--no-stub")
    argv += ["write-flash", flash_offset, payload_path]
    return argv


async def _run_native_usb_ladder(
    *,
    port: str,
    payload_path: str,
    opts: FlashOptions,
    baud: int,
    connect_attempts: int | None,
    label: str,
    log_lines: list[str],
    on_progress: ProgressCallback | None,
    subprocess_factory: (
        Callable[..., asyncio.Future[asyncio.subprocess.Process]] | None
    ),
    plog: object,
) -> tuple[int, bool]:
    """Run the STEP-4 usb-reset → usb-reset+no-stub → default-reset ladder.

    Walks :data:`_NATIVE_USB_RESET_LADDER` until an esptool invocation exits 0
    (success) or the ladder is exhausted. ``usb-reset`` is hardware-UNVERIFIED
    on this OPi+V4 combo, so the ladder must remain: a usb-reset that the ROM
    doesn't honour just fails fast and we drop to the legacy default-reset.

    A TIMEOUT stops the ladder immediately — esptool hung (not a reset-mode
    mismatch), so retrying with ``--no-stub`` / ``default-reset`` would only
    burn another full ``flash_timeout_s`` per step for no gain. A clean non-zero
    exit advances to the next step. Returns ``(returncode, timed_out)`` of the
    LAST attempt — the caller maps a non-zero/timed-out tail into the existing
    JTAG-retry / rollback flow.
    """
    rc, timed_out = 1, False
    for i, (before_reset, no_stub) in enumerate(_NATIVE_USB_RESET_LADDER):
        argv = _build_write_argv(
            esptool_path=opts.esptool_path,
            chip=opts.chip,
            port=port,
            baud=baud,
            flash_offset=opts.flash_offset,
            payload_path=payload_path,
            before_reset=before_reset,
            no_stub=no_stub,
            connect_attempts=connect_attempts,
        )
        plog.info(  # type: ignore[attr-defined]
            "fwota.flash.native_usb_ladder_step",
            label=label, step=i, before=before_reset, no_stub=no_stub,
        )
        rc, timed_out = await _run_esptool(
            argv,
            log_lines=log_lines,
            on_progress=on_progress,
            timeout_s=opts.flash_timeout_s,
            subprocess_factory=subprocess_factory,
        )
        if rc == 0 or timed_out:
            return rc, timed_out
    return rc, timed_out


async def _await_version_heartbeat(
    *,
    port: str,
    probe: HeartbeatProbe,
    budget_seconds: float,
    sleep_fn: Callable[[float], Awaitable[None]] | None,
) -> bool:
    """Poll ``probe`` until it confirms the target version or the budget runs out.

    STEP 5 collaborator for ``flash_v4``: returns True the instant a
    target-version 0x94 frame is seen, else False after ``budget_seconds`` (the
    caller then returns the retriable failed_post_flash_no_heartbeat). Mirrors
    ``fwota_techo._await_heartbeat`` so the two flashers behave identically.
    """
    deadline = _now() + budget_seconds
    while True:
        if await probe(port, budget_seconds):
            return True
        if _now() >= deadline:
            return False
        if sleep_fn is None:
            await asyncio.sleep(1.0)
        else:
            await sleep_fn(1.0)


#: STEP 8 — serial extractor for the guaranteed-boot fallback. Pulls the
#: bare-hex serial out of a JTAG/by-id descriptor so usb_recovery can re-enumerate
#: that one device. Matches the colon/plain forms (kept loose; usb_recovery
#: substring-matches the device's sysfs ``serial``).
_BOOT_SERIAL_RE = re.compile(r"([0-9A-Fa-f]{12,16})")


async def _guarantee_runnable_boot(
    jtag_port: str | None,
    *,
    opts: FlashOptions,
    log_lines: list[str],
    on_progress: ProgressCallback | None,
    subprocess_factory: (
        Callable[..., asyncio.Future[asyncio.subprocess.Process]] | None
    ),
    plog: object,
    reenumerate: Callable[[str], bool] = usb_recovery.reenumerate_by_serial,
) -> bool:
    """Best-effort: hard-reset an ESP32-S3 out of ROM bootloader (STEP 8).

    Called on the terminal-failure paths where the chip is most likely stranded
    in the JTAG ROM bootloader (requested flash + JTAG retry + rollback all
    failed). Without this the chip is left DARK in ROM — no app running, no
    receptions — until a human power-cycles it. We try, in order:

      1. an esptool ``--before usb-reset --after watchdog-reset --no-stub
         flash-id`` against the JTAG port: ``flash-id`` is a benign identify
         whose ``--after watchdog-reset`` re-samples GPIO0 to boot the chip out
         of ROM into whatever app is still in flash (a failed write usually left
         the previous app intact). ``hard-reset``'s RTS line does NOT exist on
         the ESP32-S3 native-USB face, so it would leave the chip in ROM;
      2. a single-device sysfs re-enumeration (``usb_recovery``) keyed on the
         serial — a fallback when esptool is missing / the JTAG port is gone.

    NEVER raises and NEVER changes the caller's FlashResult — the job already
    FAILED; this only stops it leaving the device unbootable. ``reenumerate`` is
    injected for unit tests.

    Returns ``True`` iff it PROVABLY issued a reset (esptool rc==0) or a
    successful sysfs re-enumeration; ``False`` when neither could run (esptool
    missing / non-zero / timed out AND the reenum fallback failed or was
    unavailable). The caller gates ``download_mode_resolved`` on this so a SILENT
    failure here does NOT suppress the finally reset-only escape — the chip gets
    a second reset attempt rather than being left parked in download mode.
    """
    if jtag_port:
        boot_argv = [
            opts.esptool_path,
            "--chip", opts.chip,
            "--port", jtag_port,
            "--baud", str(JTAG_RETRY_BAUD),
            "--before", "usb-reset",
            "--after", "watchdog-reset",
            "--no-stub",
            "flash-id",
        ]
        plog.info("fwota.flash.guarantee_boot.esptool", jtag_port=jtag_port)  # type: ignore[attr-defined]
        try:
            rc, timed_out = await _run_esptool(
                boot_argv,
                log_lines=log_lines,
                on_progress=on_progress,
                timeout_s=opts.verify_timeout_s,
                subprocess_factory=subprocess_factory,
            )
            if not timed_out and rc == 0:
                plog.info("fwota.flash.guarantee_boot.ok")  # type: ignore[attr-defined]
                return True
        except FileNotFoundError as exc:
            plog.warning(  # type: ignore[attr-defined]
                "fwota.flash.guarantee_boot.esptool_missing", error=str(exc)
            )
        except Exception as exc:  # noqa: BLE001 - guaranteed-boot must never raise
            plog.warning(  # type: ignore[attr-defined]
                "fwota.flash.guarantee_boot.esptool_error", error=str(exc)
            )

    # Fallback: re-enumerate the one device via sysfs so it at least re-runs
    # SET_CONFIGURATION (re-binds its CDC node) — a last resort when the esptool
    # hard-reset couldn't run. Strip colons first so a colon-grouped MAC serial
    # (ESP32-S3 native-USB JTAG: ``..._8C:FD:49:B7:0A:30-if00``) matches the
    # bare-hex pattern — its longest contiguous hex run is only 2 chars otherwise.
    m = _BOOT_SERIAL_RE.search((jtag_port or "").replace(":", ""))
    if m is not None:
        try:
            if reenumerate(m.group(1)):
                plog.info("fwota.flash.guarantee_boot.reenum_ok")  # type: ignore[attr-defined]
                return True
        except Exception as exc:  # noqa: BLE001
            plog.warning(  # type: ignore[attr-defined]
                "fwota.flash.guarantee_boot.reenum_error", error=str(exc)
            )
    plog.warning("fwota.flash.guarantee_boot.unavailable", jtag_port=jtag_port)  # type: ignore[attr-defined]
    return False


async def flash_v4(
    port: str,
    fw_bin_path: str,
    *,
    on_progress: ProgressCallback | None = None,
    options: FlashOptions | None = None,
    glob_fn: Callable[[str], list[str]] = glob.glob,
    subprocess_factory: (
        Callable[..., asyncio.Future[asyncio.subprocess.Process]] | None
    ) = None,
    sleep_fn: Callable[[float], asyncio.Future[None]] | None = None,
    rollback_fw_bin_path: str | None = None,
    # 1200-touch seam (default: real pyserial). Tests pass a fake so the
    # download-mode trigger doesn't open a real /dev node.
    serial_factory: Callable[..., serial.Serial] | None = None,
    # Pre-flash USB recovery seam (default: real single-device re-enumeration).
    # Tests pass a no-op to avoid touching the host's /sys/bus/usb.
    ensure_port: Callable[[str], bool] | None = None,
    # STEP 5 — version-aware post-flash probe. When supplied, SUCCESS is gated on
    # the device coming back reporting the TARGET version in a 0x94 frame within
    # ``post_flash_heartbeat_seconds``; a non-matching/absent frame returns the
    # RETRIABLE ``failed_post_flash_no_heartbeat`` instead of a false success.
    # None (the default) preserves the prior boot-stability-only behaviour.
    heartbeat_probe: HeartbeatProbe | None = None,
    post_flash_heartbeat_seconds: float = 360.0,
    # Called ONCE after the write + reenum + boot-stability check, BEFORE the
    # version-verify probe. The dispatcher uses this to RESUME the supervisor's
    # serial reader + lift the flashing gate so the rebooted chip's 0x94 frames
    # populate the publisher version cache the probe reads. Without it the reader
    # stays paused for the whole probe window → the probe never sees the new
    # version → spurious failed_post_flash_no_heartbeat + retries. None = no-op.
    on_programmed: Callable[[], None] | None = None,
) -> FlashResult:
    """Flash ``fw_bin_path`` onto the Heltec V4 currently reachable at ``port``.

    The caller must have STOPPED any serial reader holding ``port`` before
    calling this — esptool needs exclusive USB-CDC access. This function
    never touches the bridge's :class:`SerialReader` registry directly so
    the responsibility boundary stays narrow.

    Flow:

    0. If ``port`` is the APP-RUNNING Heltec V4 OTG-CDC descriptor (native-USB
       but NOT yet the USB-Serial-JTAG face), do a 1200-baud touch to drop the
       chip into download mode (arduino-esp32's host-side ``use_1200bps_touch``
       → ``usb_persist_restart(RESTART_BOOTLOADER)`` → clean S3 PHY hand-off),
       then poll for the USB-Serial-JTAG descriptor and flash THAT. If we are
       handed a USJ port already (stuck-chip recovery / dispatcher swap), skip
       the touch.
    1. For a native-USB ESP32-S3, wait for the by-id node to settle, then spawn
       ``esptool --before usb-reset --after watchdog-reset --connect-attempts 5
       write-flash``. ``usb-reset`` engages the ROM bootloader over the
       USB-Serial-JTAG peripheral; ``watchdog-reset`` re-samples GPIO0 so the
       chip boots the new app (the RTS-line ``default-reset``/``hard-reset``
       doesn't exist on native USB). Output streams through ``on_progress``.
    2. If esptool exits non-zero (or times out) — return ``failed_flash`` /
       ``failed_timeout``.
    3. Wait up to ``options.reenum_timeout_s`` for the runtime CDC glob to
       reappear (by /dev/serial/by-id, never /dev/ttyACMx). Some other
       ``Espressif_Systems_heltec*`` symlink → we have a healthy chip back.
       None → ``failed_no_reenum``.
    4. Wait ``BOOT_STABILITY_WAIT_S`` and re-confirm the runtime descriptor is
       still present (a boot-looping image has crashed back to the JTAG ROM
       bootloader by then). Gone → ``failed_boot_loop``.
    5. ``success`` — log elapsed time and return.

    BRICK-SAFETY INVARIANT: once the chip is in download mode (after the
    1200-touch, or because we were handed a USJ port), it STAYS there until a
    full ``--after watchdog-reset``. So on EVERY exit path that would otherwise
    leave it parked in download mode without a successful watchdog-reset write —
    every failure return, timeout, exception, AND the ``finally`` — a final
    reset-only ``--after watchdog-reset`` (no write) is issued against the USJ
    port so an aborted flash boots the device back to its INTACT old firmware
    with no physical access. Best-effort + idempotent: it is NOT issued after a
    write that already re-sampled the straps (success / rollback re-enum).

    The returned :class:`FlashResult` always carries the full streamed log,
    even on failure, so the API server can persist it to the job row.

    ``glob_fn`` / ``subprocess_factory`` / ``sleep_fn`` / ``serial_factory`` are
    test seams — the production caller never sets them.
    """
    opts = options or FlashOptions()
    started = _now()
    log_lines: list[str] = []

    plog = log.bind(port=port, fw=fw_bin_path, opts=opts)
    plog.info("fwota.flash.start")

    # Pre-flash USB recovery: esptool is about to drive the reset on `port`. If
    # that port vanished (device on the bus but no ttyACM — failed
    # SET_CONFIGURATION / "descriptor read -110"), re-enumerate THIS device only
    # (sysfs `authorized` toggle — never a hub reset, so sibling receivers stay
    # up) and wait for the port. Best-effort + a no-op when the port is present.
    if not (ensure_port or usb_recovery.ensure_serial_enumerated)(port):
        plog.warning("fwota.usb_recovery.port_still_absent_continuing")

    # STEP 4 — ESP32-S3 native-USB chips (V4 application descriptor or the JTAG
    # ROM bootloader) are driven over native USB-CDC, where the legacy
    # ``--before default-reset`` DTR/RTS toggle reliably wedges the USB-CDC stack
    # and bounces the chip into the JTAG bootloader. Use the usb-reset ladder
    # (usb-reset → usb-reset+no-stub → default-reset) with --connect-attempts on
    # the FIRST attempt and ``--after watchdog-reset`` so the chip leaves
    # download mode. usb-reset is hardware-UNVERIFIED on this OPi+V4 combo, which
    # is why the ladder ends in the legacy default-reset before-mode.
    native_usb = is_native_usb_descriptor(port)

    # BRICK-SAFETY tracking. ``in_download_mode`` flips True the instant the chip
    # is (or is handed to us) in download mode: once True, an aborted flash MUST
    # finish with a ``--after watchdog-reset`` (the reset-only escape) or the
    # button-less remote V4 is parked in download mode forever.
    # ``download_mode_resolved`` flips True once a watchdog-reset has provably
    # booted the chip out of download mode (a successful write re-enumerated the
    # runtime descriptor / a rollback re-enum) so the escape is NOT double-issued.
    # ``escape_jtag_port`` is the USJ descriptor the escape resets against.
    in_download_mode = False
    download_mode_resolved = False
    escape_jtag_port: str | None = None
    if _is_usb_jtag_descriptor(port):
        # Handed a USB-Serial-JTAG descriptor directly (stuck-chip recovery or a
        # dispatcher JTAG-swap): the chip is ALREADY in download mode, so skip
        # the touch but arm the brick-safety escape on this port.
        in_download_mode = True
        escape_jtag_port = port

    async def _attempt() -> FlashResult:
        # The full flash body. Mutations to the brick-safety tracking vars
        # (escape_jtag_port / download_mode_resolved / port) must reach the
        # enclosing finally, so they are nonlocal.
        nonlocal in_download_mode, escape_jtag_port, download_mode_resolved
        nonlocal port, plog
        try:
            if native_usb:
                # STEP 0 — APP-RUNNING V4 download-mode trigger. When the port is the
                # Heltec OTG-CDC descriptor (native-USB but not yet the USJ face), do
                # a 1200-baud touch: arduino-esp32's host-side use_1200bps_touch makes
                # the runtime firmware usb_persist_restart(RESTART_BOOTLOADER) into a
                # clean S3 PHY hand-off to the USB-Serial-JTAG ROM stub. Then poll for
                # the USJ descriptor and flash THAT. Skipped when already on a USJ
                # port (in_download_mode already set above) so a stuck-chip recovery
                # doesn't double-touch.
                if not _is_usb_jtag_descriptor(port):
                    plog.info("fwota.flash.v4_1200_touch", cdc_port=port)
                    try:
                        _send_1200_touch(port, serial_factory)
                    except (serial.SerialException, OSError) as exc:
                        # A successful touch RESETS the chip, so the OTG-CDC port may
                        # vanish mid-open — that means the touch already took effect.
                        # Either way the chip is now (re)entering download mode, so
                        # ARM the escape and proceed to poll for the USJ descriptor.
                        plog.warning(
                            "fwota.flash.v4_1200_touch.port_error_continuing",
                            error=str(exc),
                            error_type=type(exc).__name__,
                        )
                    # Whether or not the touch's open raised, the chip is transitioning
                    # into download mode — arm the brick-safety escape NOW so an
                    # exception before the USJ descriptor resolves still gets a reset.
                    in_download_mode = True
                    jtag_port_found = await _await_download_mode_port(
                        timeout_s=_DOWNLOAD_MODE_DETECT_TOTAL_S,
                        glob_fn=glob_fn,
                        sleep_fn=sleep_fn,
                    )
                    if jtag_port_found is None:
                        # The USJ descriptor didn't appear in the detect window.
                        # in_download_mode is already True, so the finally guard
                        # still runs the reset-only escape (it re-polls for the
                        # descriptor) — a wedged chip whose symlink merely lagged
                        # is recovered; a chip that never left the app no-ops.
                        plog.warning(
                            "fwota.flash.v4_1200_touch.no_jtag_descriptor",
                            timeout_s=_DOWNLOAD_MODE_DETECT_TOTAL_S,
                        )
                        return FlashResult(
                            state="failed_flash",
                            elapsed_s=_now() - started,
                            log=log_lines,
                            error=(
                                "1200-touch issued but the USB-Serial-JTAG descriptor "
                                f"never appeared within {_DOWNLOAD_MODE_DETECT_TOTAL_S}s"
                            ),
                        )
                    plog.info(
                        "fwota.flash.v4_1200_touch.jtag_detected",
                        cdc_port=port,
                        jtag_port=jtag_port_found,
                    )
                    port = jtag_port_found
                    escape_jtag_port = jtag_port_found
                    plog = plog.bind(port=port)
                # 0.5.24 — ride out the CDC->ROM re-enumeration race: wait for the
                # resolved by-id node to settle before launching esptool, so the
                # first attempt doesn't hit "Could not configure port (5)" against a
                # momentarily-absent descriptor. Advisory only — esptool's
                # --connect-attempts covers any residual race — so a timeout here
                # just logs and proceeds rather than failing the flash.
                if not await _wait_for_port(
                    port,
                    timeout_s=_PORT_WAIT_TIMEOUT_S,
                    glob_fn=glob_fn,
                    sleep_fn=sleep_fn,
                ):
                    plog.warning(
                        "fwota.flash.port_wait_timeout",
                        port=port,
                        timeout_s=_PORT_WAIT_TIMEOUT_S,
                    )
                rc, timed_out = await _run_native_usb_ladder(
                    port=port,
                    payload_path=fw_bin_path,
                    opts=opts,
                    baud=opts.baud,
                    connect_attempts=NATIVE_USB_CONNECT_ATTEMPTS,
                    label="primary",
                    log_lines=log_lines,
                    on_progress=on_progress,
                    subprocess_factory=subprocess_factory,
                    plog=plog,
                )
            else:
                # NON-native-USB path (external UART bridge — e.g. Wio-E5 / CP2102).
                # These DO carry real DTR/RTS lines, so the legacy default-reset +
                # hard-reset RTS dance is correct here; watchdog-reset only applies
                # to native-USB ESP32-S3. (In practice flash_v4 is only routed an
                # ESP32-S3, so this branch is the descriptor-classification escape
                # hatch — keep the legacy after-mode for it.)
                write_argv = _build_write_argv(
                    esptool_path=opts.esptool_path,
                    chip=opts.chip,
                    port=port,
                    baud=opts.baud,
                    flash_offset=opts.flash_offset,
                    payload_path=fw_bin_path,
                    before_reset="default-reset",
                    after_reset="hard-reset",
                    no_stub=False,
                    connect_attempts=None,
                )
                rc, timed_out = await _run_esptool(
                    write_argv,
                    log_lines=log_lines,
                    on_progress=on_progress,
                    timeout_s=opts.flash_timeout_s,
                    subprocess_factory=subprocess_factory,
                )
        except FileNotFoundError as exc:
            plog.error("fwota.flash.esptool_missing", error=str(exc))
            return FlashResult(
                state="failed_flash",
                elapsed_s=_now() - started,
                log=log_lines,
                error=f"esptool not found: {exc}",
            )

        if timed_out:
            plog.warning("fwota.flash.timeout", elapsed_s=_now() - started)
            return FlashResult(
                state="failed_timeout",
                elapsed_s=_now() - started,
                log=log_lines,
                error=f"esptool exceeded {opts.flash_timeout_s}s",
            )
        if rc != 0:
            # STEP 4 — a FIRST-attempt EIO ("Could not configure port (5,…)") is a
            # SOFT failure: the host couldn't open the native-USB CDC node (the chip
            # is mid-reset / re-enumerating), NOT a corrupt image. Log it as soft and
            # fall through to the bootloader-descriptor retry below (which itself
            # uses usb-reset/--no-stub), rather than treating it as a hard
            # failed_flash. Non-EIO non-zero exits also fall through to the retry —
            # the soft-EIO log line just makes the transient diagnosable.
            if _is_eio_failure(log_lines):
                plog.warning(
                    "fwota.flash.first_attempt_eio_soft",
                    returncode=rc,
                    msg="EIO opening native-USB CDC; proceeding to bootloader retry",
                )
            plog.warning("fwota.flash.nonzero_exit", returncode=rc)
            # Real-world V4 behaviour: the first ``--before default-reset``
            # attempt often fails because the chip is mid-`micros()` and
            # esptool's DTR/RTS toggle can't sync. The failure ALSO drops
            # the chip into the USB-JTAG ROM bootloader (descriptor flips
            # to ``Espressif_USB_JTAG_serial_debug_unit_*``). Detect that
            # and retry against the new port — this is exactly the manual
            # recovery dance we have done on the bench.
            # Poll for the JTAG descriptor — chip can take ~5-15 s after a
            # failed esptool handshake to actually transition into the ROM
            # JTAG bootloader and re-enumerate. A one-shot glob after only
            # 5 s misses this window on slower chips (V4 job 12 transitioned
            # at ~7 s post-fail). Initial wait then poll every JTAG_DETECT_POLL_S
            # up to JTAG_DETECT_TOTAL_S.
            if sleep_fn is None:
                await asyncio.sleep(JTAG_RETRY_WAIT_S)
            else:
                await sleep_fn(JTAG_RETRY_WAIT_S)
            jtag_glob = "/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_*"
            jtag_deadline = _now() + (JTAG_DETECT_TOTAL_S - JTAG_RETRY_WAIT_S)
            jtag_ports: list[str] = sorted(glob_fn(jtag_glob))
            while not jtag_ports and _now() < jtag_deadline:
                if sleep_fn is None:
                    await asyncio.sleep(JTAG_DETECT_POLL_S)
                else:
                    await sleep_fn(JTAG_DETECT_POLL_S)
                jtag_ports = sorted(glob_fn(jtag_glob))
            if not jtag_ports:
                return FlashResult(
                    state="failed_flash",
                    elapsed_s=_now() - started,
                    log=log_lines,
                    error=(
                        f"esptool exited with code {rc}; no JTAG-bootloader "
                        f"descriptor appeared within {JTAG_DETECT_TOTAL_S}s"
                    ),
                )
            jtag_port = jtag_ports[0]
            plog.info(
                "fwota.flash.jtag_descriptor_detected",
                jtag_port=jtag_port,
                wait_elapsed_s=_now() - started,
            )

            async def _retry_via_jtag(payload_path: str, *, label: str) -> tuple[int, bool]:
                """Helper to run the esptool ladder against the JTAG port.

                Encapsulated so the rollback path below can reuse the
                slower-baud / more-connect-attempts settings without
                duplicating the argv construction. STEP 4: the JTAG ROM
                bootloader is also native USB-CDC, so it walks the same
                usb-reset → usb-reset+no-stub → default-reset ladder.
                """
                plog.info(
                    "fwota.flash.retry_via_jtag_bootloader",
                    jtag_port=jtag_port,
                    label=label,
                    baud=JTAG_RETRY_BAUD,
                    connect_attempts=JTAG_CONNECT_ATTEMPTS,
                )
                # Slower JTAG_RETRY_BAUD is more tolerant of flaky USB hubs on the
                # JTAG path; application-side flashes still use opts.baud.
                return await _run_native_usb_ladder(
                    port=jtag_port,
                    payload_path=payload_path,
                    opts=opts,
                    baud=JTAG_RETRY_BAUD,
                    connect_attempts=JTAG_CONNECT_ATTEMPTS,
                    label=f"jtag-{label}",
                    log_lines=log_lines,
                    on_progress=on_progress,
                    subprocess_factory=subprocess_factory,
                    plog=plog,
                )

            try:
                rc2, timed_out2 = await _retry_via_jtag(fw_bin_path, label="primary")
            except FileNotFoundError as exc:
                return FlashResult(
                    state="failed_flash",
                    elapsed_s=_now() - started,
                    log=log_lines,
                    error=f"esptool not found on retry: {exc}",
                )
            if timed_out2:
                return FlashResult(
                    state="failed_timeout",
                    elapsed_s=_now() - started,
                    log=log_lines,
                    error=f"esptool retry exceeded {opts.flash_timeout_s}s",
                )
            if rc2 != 0:
                # Last-chance recovery: the requested firmware can't be
                # flashed (corrupt image, hardware regression, etc.) AND
                # the chip is stuck in JTAG bootloader. If the caller has
                # supplied a known-good rollback binary, flash THAT so the
                # chip comes back to a runnable state. Without this path
                # the chip stays bricked in bootloader mode until the
                # operator manually intervenes — which is exactly the
                # 2026-05-13 V4 incident we are hardening against.
                if rollback_fw_bin_path is not None:
                    plog.warning(
                        "fwota.flash.rolling_back",
                        rc=rc2,
                        rollback_fw=rollback_fw_bin_path,
                    )
                    try:
                        rc3, timed_out3 = await _retry_via_jtag(
                            rollback_fw_bin_path, label="rollback"
                        )
                    except FileNotFoundError as exc:
                        return FlashResult(
                            state="failed_flash",
                            elapsed_s=_now() - started,
                            log=log_lines,
                            error=f"esptool not found on rollback: {exc}",
                        )
                    if not timed_out3 and rc3 == 0:
                        plog.info("fwota.flash.rollback_succeeded")
                        # Wait for runtime descriptor + verify so the
                        # caller sees a real success of the rollback path.
                        new_port_rb = await _await_reenum(
                            opts.runtime_glob,
                            timeout_s=opts.reenum_timeout_s,
                            deadline_start=_now(),
                            glob_fn=glob_fn,
                            sleep_fn=sleep_fn,
                        )
                        # The rollback write did --after watchdog-reset and the
                        # chip is back on its app — no reset-only escape needed.
                        download_mode_resolved = True
                        return FlashResult(
                            state="rolled_back_to_previous",
                            elapsed_s=_now() - started,
                            log=log_lines,
                            new_port=new_port_rb,
                            error=(
                                f"requested version failed (rc={rc2}); "
                                f"rolled back to previous via JTAG"
                            ),
                        )
                # STEP 8 — the requested flash + JTAG retry (+ rollback if any) all
                # failed; the chip is sitting in the JTAG ROM bootloader, DARK. Hard-
                # reset it out of ROM so it boots whatever app is still in flash
                # rather than leaving it unbootable until a human power-cycles it.
                # Mark resolved ONLY if STEP 8 PROVABLY reset the chip. If it
                # could not (esptool missing/non-zero/timed-out AND the sysfs
                # reenum fallback failed), leave resolved False so the finally
                # escape fires a second reset attempt rather than suppressing it.
                download_mode_resolved = await _guarantee_runnable_boot(
                    jtag_port,
                    opts=opts,
                    log_lines=log_lines,
                    on_progress=on_progress,
                    subprocess_factory=subprocess_factory,
                    plog=plog,
                )
                return FlashResult(
                    state="failed_flash",
                    elapsed_s=_now() - started,
                    log=log_lines,
                    error=f"esptool retry exited with code {rc2}",
                )
            # JTAG-path retry succeeded; fall through to the reenum loop.

        # The write ladder returned rc==0 — its ``--after watchdog-reset`` has
        # already issued a POR-class reset that boots the chip out of download
        # mode. So the chip is NO LONGER in download mode regardless of whether
        # we go on to OBSERVE the runtime descriptor. Mark resolved here (not
        # after the reenum poll) so a ``failed_no_reenum`` return — a DETECTION
        # failure, not a stuck chip — does not fire a doomed reset-only escape
        # against a JTAG port the now-booted chip no longer exposes.
        download_mode_resolved = True
        plog.info("fwota.flash.write_complete", awaiting_reenum_s=opts.reenum_timeout_s)
        new_port = await _await_reenum(
            opts.runtime_glob,
            timeout_s=opts.reenum_timeout_s,
            deadline_start=_now(),
            glob_fn=glob_fn,
            sleep_fn=sleep_fn,
        )
        if new_port is None:
            plog.warning("fwota.flash.no_reenum", glob=opts.runtime_glob)
            return FlashResult(
                state="failed_no_reenum",
                elapsed_s=_now() - started,
                log=log_lines,
                error=f"runtime CDC descriptor never reappeared at {opts.runtime_glob}",
            )

        # The runtime CDC descriptor reappeared — independent confirmation the
        # write's --after watchdog-reset booted the app out of download mode
        # (download_mode_resolved was already set True at write-success above).
        plog.info("fwota.flash.reenum_seen", new_port=new_port)

        # Boot-stability check, replacing the destabilising esptool flash-id
        # verify step. The previous post-flash ``flash-id`` query issued its
        # own ``--before default-reset`` DTR/RTS dance, and the ESP32-S3
        # USB-CDC stack reliably mishandled the reset — every flash that
        # wrote successfully also "failed verify" and ended with the chip
        # bricked in JTAG bootloader. Replacing it with a passive
        # re-enumeration-still-present check: wait BOOT_STABILITY_WAIT_S
        # after reenum, then confirm the runtime descriptor is still present.
        # A boot-looping firmware will have crashed back into the JTAG
        # bootloader by then; a healthy firmware will still be enumerated.
        if sleep_fn is None:
            await asyncio.sleep(BOOT_STABILITY_WAIT_S)
        else:
            await sleep_fn(BOOT_STABILITY_WAIT_S)
        post_check_matches = sorted(glob_fn(opts.runtime_glob))
        if not post_check_matches:
            plog.warning(
                "fwota.flash.boot_unstable",
                new_port=new_port,
                stability_wait_s=BOOT_STABILITY_WAIT_S,
            )
            # The chip crashed back into the JTAG ROM bootloader — it is in
            # download mode AGAIN, so the write-success resolved flag above is now
            # stale. Re-arm the brick-safety obligation; the rollback-success and
            # STEP 8 paths below each re-confirm it from their own reset.
            download_mode_resolved = False
            # Boot-loop: chip enumerated briefly then crashed back to
            # bootloader. If the caller supplied a rollback target, flash
            # it via the same JTAG path the dispatcher walked in on; the
            # ESP32-S3 should be in JTAG bootloader by now.
            if rollback_fw_bin_path is not None:
                jtag_glob = "/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_*"
                jtag_matches = sorted(glob_fn(jtag_glob))
                if jtag_matches:
                    jtag_port = jtag_matches[0]
                    plog.warning(
                        "fwota.flash.rolling_back_after_boot_loop",
                        rollback_fw=rollback_fw_bin_path,
                        jtag_port=jtag_port,
                    )
                    try:
                        # STEP 4 — rollback via the native-USB usb-reset ladder too.
                        rb_rc, rb_timed_out = await _run_native_usb_ladder(
                            port=jtag_port,
                            payload_path=rollback_fw_bin_path,
                            opts=opts,
                            baud=JTAG_RETRY_BAUD,
                            connect_attempts=JTAG_CONNECT_ATTEMPTS,
                            label="boot-loop-rollback",
                            log_lines=log_lines,
                            on_progress=on_progress,
                            subprocess_factory=subprocess_factory,
                            plog=plog,
                        )
                        if not rb_timed_out and rb_rc == 0:
                            plog.info("fwota.flash.rollback_succeeded")
                            rb_port = await _await_reenum(
                                opts.runtime_glob,
                                timeout_s=opts.reenum_timeout_s,
                                deadline_start=_now(),
                                glob_fn=glob_fn,
                                sleep_fn=sleep_fn,
                            )
                            # The rollback write's --after watchdog-reset booted
                            # the chip out of download mode; mark resolved
                            # explicitly so this return is self-contained (no
                            # reliance on a non-local flag) and the finally escape
                            # does not double-reset.
                            download_mode_resolved = True
                            return FlashResult(
                                state="rolled_back_to_previous",
                                elapsed_s=_now() - started,
                                log=log_lines,
                                new_port=rb_port,
                                error="requested firmware boot-looped; rolled back",
                            )
                    except FileNotFoundError as exc:
                        plog.error("fwota.flash.rollback_esptool_missing", error=str(exc))
            # STEP 8 — the firmware boot-looped and the rollback (if any) didn't
            # recover it; the chip is in the JTAG ROM bootloader, DARK. Re-find the
            # JTAG descriptor and hard-reset it out of ROM so it boots whatever app
            # is still in flash, rather than leaving it unbootable.
            boot_loop_jtag = sorted(
                glob_fn("/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_*")
            )
            # Resolve ONLY if STEP 8 provably reset the chip; otherwise leave it
            # False so the finally escape gets a second attempt. The escape's
            # no-port re-poll covers the case where the JTAG glob above came up
            # empty (boot_loop_jtag falsy → guarantee_boot can't esptool).
            download_mode_resolved = await _guarantee_runnable_boot(
                boot_loop_jtag[0] if boot_loop_jtag else None,
                opts=opts,
                log_lines=log_lines,
                on_progress=on_progress,
                subprocess_factory=subprocess_factory,
                plog=plog,
            )
            return FlashResult(
                state="failed_boot_loop",
                elapsed_s=_now() - started,
                log=log_lines,
                new_port=new_port,
                error=(
                    f"runtime CDC descriptor gone {BOOT_STABILITY_WAIT_S}s "
                    "after reenum — firmware boot-looped"
                ),
            )
        plog.info("fwota.flash.boot_stable", new_port=new_port)

        # Resume the reader BEFORE the version probe: the write is done and the chip
        # is booted, so let the supervisor reader re-open the runtime port NOW to
        # capture the device's 0x94 frames into the publisher version cache the probe
        # reads (the probe never opens the port, so no contention). Without this the
        # reader stays paused for the whole probe window and the probe never sees the
        # new version.
        if on_programmed is not None:
            try:
                on_programmed()
                plog.info("fwota.flash.reader_resumed_for_verify")
            except Exception as exc:  # noqa: BLE001 - never fail a good flash on this
                plog.warning("fwota.flash.reader_resume_error", error=str(exc))

        # STEP 5 — version-aware post-flash gate. Boot-stability proves the chip is
        # enumerated + not crash-looping, but NOT that it's running the firmware we
        # flashed (a no-op flash or the OLD image would also stay enumerated). When a
        # probe is supplied, only declare SUCCESS once a TARGET-version 0x94 frame is
        # seen; absent/non-matching within the window → RETRIABLE
        # failed_post_flash_no_heartbeat (never a false success on the old firmware).
        if heartbeat_probe is not None:
            plog.info(
                "fwota.flash.version_probe.wait",
                window_s=post_flash_heartbeat_seconds,
                probe_port=new_port,
            )
            matched = await _await_version_heartbeat(
                port=new_port,
                probe=heartbeat_probe,
                budget_seconds=post_flash_heartbeat_seconds,
                sleep_fn=sleep_fn,
            )
            if not matched:
                plog.warning(
                    "fwota.flash.version_probe.no_match",
                    window_s=post_flash_heartbeat_seconds,
                    new_port=new_port,
                )
                return FlashResult(
                    state="failed_post_flash_no_heartbeat",
                    elapsed_s=_now() - started,
                    log=log_lines,
                    new_port=new_port,
                    error=(
                        "no target-version 0x94 frame within "
                        f"{post_flash_heartbeat_seconds:.0f}s of flash"
                    ),
                )
            plog.info("fwota.flash.version_probe.match", new_port=new_port)

        elapsed = _now() - started
        plog.info("fwota.flash.success", elapsed_s=elapsed, new_port=new_port)
        return FlashResult(
            state="success",
            elapsed_s=elapsed,
            log=log_lines,
            new_port=new_port,
        )

    # BRICK-SAFETY: run the flow, but GUARANTEE that if the chip was put into
    # (or handed to us in) download mode and we never confirmed it booted back
    # out via a watchdog-reset, we issue the reset-only escape on the way out —
    # success, every failure return, timeout, AND any exception.
    try:
        return await _attempt()
    finally:
        # Fire the escape whenever the chip is (believed to be) in download mode
        # and we never confirmed a watchdog-reset booted it out — REGARDLESS of
        # whether escape_jtag_port resolved. When it is None (1200-touch latched
        # the chip but the by-id symlink lagged), _reset_only_escape polls for the
        # USJ descriptor itself; a no-op if it never appears. Dropping the old
        # `and escape_jtag_port` requirement closes the symlink-lag brick path.
        if in_download_mode and not download_mode_resolved:
            await _reset_only_escape(
                escape_jtag_port,
                opts=opts,
                log_lines=log_lines,
                on_progress=on_progress,
                subprocess_factory=subprocess_factory,
                plog=plog,
                glob_fn=glob_fn,
                sleep_fn=sleep_fn,
            )
