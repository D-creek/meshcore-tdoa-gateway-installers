"""KAN-167: bridge-side FW-OTA job dispatcher.

Listens on ``gateway/+/cmd/fw-upgrade`` MQTT topic; when a job message
arrives the dispatcher:

  1. Resolves the target USB port from the topic's sanitized-port path.
  2. Downloads the firmware artifact to a local cache (verifying sha256).
  3. Calls the right per-platform flash function (fwota_v4.flash_v4 for
     ESP32-S3 boards, fwota_techo.flash_techo for nRF52840 boards
     including T-Echo + RAK4631).
  4. Publishes a series of status messages on
     ``gateway/{port}/cmd/fw-upgrade/status`` so the collector + API
     can show live progress in the frontend.

Job payload shape (published by the API on POST /admin/.../firmware-upgrade):

    {
      "job_id":       <int>,
      "release_id":   <int>,
      "target_board": "heltec_v4_companion_radio_usb_tdoa_rx" | "LilyGo_T-Echo_..." | ...,
      "download_url": "https://<firmware-host>/firmware/blobs/<sha>",
      "sha256":       "<64-hex>",
      "version":      "tdoa-1.8.5"
    }

Status payload shape (published back on .../status):

    {"job_id": <int>, "state": "pending"|"downloading"|"flashing"|"done"|"failed_*",
     "log_chunk": "..."}

The dispatcher is intentionally a separate MQTT client from the
publisher so we don't tangle pub + sub state. Wired into ``__main__.py``
alongside the publisher.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass

import paho.mqtt.client as mqtt
import structlog

from .config import MQTTConfig
from .fwota_h743 import flash_h743
from .fwota_stm32wl import FlashResult, flash_stm32wl
from .fwota_t114 import flash_t114
from .fwota_techo import flash_techo
from .fwota_v4 import flash_v4

log = structlog.get_logger(__name__)

#: Matches an HTTP Authorization bearer/basic credential that a urllib error
#: string may carry (e.g. when it echoes the failed request's headers). The
#: firmware download attaches ``Authorization: Bearer <github_token>``, so an
#: unsanitised ``str(exc)`` could leak the PAT into the root-readable journal
#: (security fix 2026-06-06). We also catch a bare ``ghp_``/``github_pat_``.
_CRED_RE = re.compile(
    r"(Authorization|Bearer|Basic)\s*[:=]?\s*\S+|ghp_\w+|github_pat_\w+",
    re.IGNORECASE,
)


def _safe_err(exc: BaseException) -> str:
    """A log-safe one-line description of ``exc`` with any credential redacted.

    Prefer the structured ``code``/``reason`` of a urllib/OS error (which never
    carry the request headers) and scrub the fallback string so a leaked
    ``Authorization: Bearer <PAT>`` can't reach the journal."""
    code = getattr(exc, "code", None)
    reason = getattr(exc, "reason", None)
    if code is not None or reason is not None:
        _code = code if code is not None else ""
        _reason = reason if reason is not None else ""
        base = f"{type(exc).__name__}: {_code} {_reason}".strip()
    else:
        base = f"{type(exc).__name__}: {exc}"
    return _CRED_RE.sub("<redacted>", base)


#: Where flashing artifacts get cached on the bridge host. Each is named
#: by sha256 so re-downloads are idempotent and a corrupted artifact
#: can be re-downloaded by deleting the file.
#:
#: Resolved from systemd's ``$STATE_DIRECTORY`` (set by the unit's
#: ``StateDirectory=``). Both the deb unit (``meshcore-tdoa-gateway-bridge``)
#: and the legacy image unit run ``ProtectSystem=strict``, so the ONLY writable
#: ``/var/lib`` path is whatever ``StateDirectory`` grants. The old hard-coded
#: ``/var/lib/meshcore-bridge`` did NOT match the deb's
#: ``/var/lib/meshcore-tdoa-gateway-bridge`` StateDirectory, so every flash
#: failed at download with ``OSError [Errno 30] Read-only file system`` under
#: the sandbox. ``$STATE_DIRECTORY`` may be colon-separated → take the first;
#: fall back to the deb path for non-systemd / test contexts.
_STATE_DIR = (os.environ.get("STATE_DIRECTORY") or "").split(":")[0].strip()
DEFAULT_FW_CACHE_DIR = os.path.join(
    _STATE_DIR or "/var/lib/meshcore-tdoa-gateway-bridge", "fw-cache"
)

#: Topic patterns. The dispatcher subscribes to the wildcard variant
#: and parses the sanitized-port out of the second level.
TOPIC_CMD_SUB = "gateway/+/cmd/fw-upgrade"
TOPIC_STATUS_TEMPLATE = "gateway/{sanitized}/cmd/fw-upgrade/status"

#: When the topic looks like ``gateway/abc/cmd/fw-upgrade`` we extract
#: ``abc`` as the sanitized port. The sanitize_port helper in
#: mqtt_publisher applies the same scheme so this is reversible.
_TOPIC_PORT_RE = re.compile(r"^gateway/([^/]+)/cmd/fw-upgrade$")


@dataclass(frozen=True)
class JobPayload:
    """Parsed inbound job message.

    Optional ``previous_*`` fields carry the known-good firmware the
    flash should roll back to if BOTH the requested-version flash AND
    the JTAG-bootloader retry fail. Without them a corrupt or
    incompatible build leaves the chip stuck in bootloader mode (the
    2026-05-13 V4 incident); with them the bridge auto-recovers to
    the last-running firmware.
    """

    job_id: int
    release_id: int
    target_board: str
    download_url: str
    sha256: str
    version: str
    previous_release_id: int | None = None
    previous_download_url: str | None = None
    previous_sha256: str | None = None
    previous_version: str | None = None


def parse_job(payload: bytes) -> JobPayload | None:
    """Decode the JSON job payload; return ``None`` on any structural error."""
    try:
        doc = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(doc, dict):
        return None
    try:
        previous = doc.get("previous") if isinstance(doc.get("previous"), dict) else None
        return JobPayload(
            job_id=int(doc["job_id"]),
            release_id=int(doc["release_id"]),
            target_board=str(doc["target_board"]),
            download_url=str(doc["download_url"]),
            sha256=str(doc["sha256"]).lower(),
            version=str(doc["version"]),
            previous_release_id=(
                int(previous["release_id"])
                if previous and "release_id" in previous
                else None
            ),
            previous_download_url=(
                str(previous["download_url"])
                if previous and "download_url" in previous
                else None
            ),
            previous_sha256=(
                str(previous["sha256"]).lower()
                if previous and "sha256" in previous
                else None
            ),
            previous_version=(
                str(previous["version"])
                if previous and "version" in previous
                else None
            ),
        )
    except (KeyError, TypeError, ValueError):
        return None


def is_esp32_target(target_board: str) -> bool:
    """Heuristic: the V4 + future Heltec ESP32 envs name themselves
    ``heltec_v4_*`` / ``heltec_v3_*``; everything else (LilyGo, RAK,
    Wio, STM32, Heltec T114) stays on the nRF/STM path. Cheap
    classification — refine if we ever ship an ESP32-named env that
    should not use esptool."""
    tb = target_board.lower()
    return tb.startswith("heltec_v") or tb.startswith("esp32")


def is_h743_target(target_board: str) -> bool:
    """Heuristic: STM32H743 receiver envs name themselves
    ``stm32h743_*`` (mirrors the in-tree variant directory). These flash
    via the STM32 ROM USB-DFU bootloader (dfu-util) rather than the
    Adafruit nRF52 path used by T-Echo / T114."""
    tb = target_board.lower()
    return tb.startswith("stm32h743") or tb.startswith("h743")


def is_t114_target(target_board: str) -> bool:
    """Heuristic: Heltec T114 v2 receiver envs match ``heltec_t114_*``.

    The T114 v2 uses the Adafruit nRF52 bootloader, identical to T-Echo;
    classification here is purely for runtime-descriptor routing so the
    bridge picks the right per-chip USB glob (Heltec_T114_* vs
    Nordic_NRF52_DK_*). The actual flash code path is fwota_t114 →
    fwota_techo internally."""
    tb = target_board.lower()
    return tb.startswith("heltec_t114") or tb.startswith("t114")


def is_stm32wl_target(target_board: str) -> bool:
    """Heuristic: STM32WL (Wio-E5 mini / LoRa-E5) receiver envs match
    ``wio_e5_*`` / ``wio-e5-*`` / ``lora_e5_*`` / ``*stm32wl*``.

    These flash over serial via stm32flash → ST Open Bootloader (OpenBL),
    NOT the ROM bootloader: the WLE5 ROM bootloader's USART1 is on
    PA9/PA10 which the CP2102 (PB6/PB7) can't reach, and BOOT0 isn't
    bonded out. OpenBL — flashed once over SWD into a write-protected
    region, USART retargeted to PB6/PB7 — gives the AN3155 protocol on
    the CP2102 so stm32flash works. See fwota_stm32wl.flash_stm32wl."""
    tb = target_board.lower()
    return (
        tb.startswith("wio_e5")
        or tb.startswith("wio-e5")
        or tb.startswith("lora_e5")
        or "stm32wl" in tb
    )


def is_stm32wl_openbl_target(target_board: str) -> bool:
    """A STM32WL target that is the OpenBootloader-prepped build — the ONLY
    image safe to serial-flash on a Wio-E5.

    OpenBL writes the application at the app base (0x08008000). Only the
    ``*_openbl`` env is linked there (with VECT_TAB_OFFSET=0x8000); a normal
    0x08000000-based image written at 0x08008000 has the wrong vector table
    and absolute addresses and bricks the node. So the OTA path accepts the
    prepped build only. The matching firmware env is
    ``wio_e5_..._tdoa_rx_openbl``."""
    return is_stm32wl_target(target_board) and "_openbl" in target_board.lower()


def download_to_cache(
    url: str,
    expected_sha256: str,
    *,
    cache_dir: str = DEFAULT_FW_CACHE_DIR,
    opener: Callable[[str], object] = urllib.request.urlopen,
    github_token: str = "",
) -> str:
    """Download ``url`` into ``cache_dir`` keyed by ``expected_sha256``.

    Returns the local filesystem path. Verifies sha256 after download
    and raises ValueError on mismatch (caller marks the job
    ``failed_verify``). If the file already exists with the right hash
    we skip the download entirely.

    2026-05-31: when ``url`` matches the GitHub release-asset API form
    (``https://api.github.com/repos/<owner>/<repo>/releases/assets/<id>``)
    we attach ``Authorization: Bearer <github_token>`` + ``Accept:
    application/octet-stream``. This lets the bridge fetch firmware
    blobs directly from a private repo's Release without proxying
    through the prod host. Anonymous fallback still works for public
    repos / mirrors when ``github_token`` is empty.
    """
    os.makedirs(cache_dir, exist_ok=True)
    dest = os.path.join(cache_dir, expected_sha256)
    if os.path.exists(dest) and _file_sha256(dest) == expected_sha256:
        return dest

    # Build a Request when we need to attach headers (private-repo GH
    # API URL + a token to authenticate with). Anonymous public URLs
    # pass-through as bare strings — keeps the test stub (``opener``
    # default = ``urllib.request.urlopen``) working with both forms.
    is_gh_api_asset = url.startswith("https://api.github.com/repos/") and "/releases/assets/" in url
    if is_gh_api_asset and github_token:
        request: object = urllib.request.Request(
            url,
            headers={
                "Authorization": f"Bearer {github_token}",
                "Accept": "application/octet-stream",
                "User-Agent": "meshcore-bridge-fwota/1",
            },
        )
    else:
        request = url

    # urlopen is intentionally injected so tests can substitute.
    with opener(request) as resp:  # type: ignore[operator,arg-type]
        data = resp.read()  # type: ignore[attr-defined]
    actual = hashlib.sha256(data).hexdigest()
    if actual != expected_sha256:
        raise ValueError(
            f"sha256 mismatch: expected {expected_sha256}, got {actual}"
        )
    # Write atomically so a half-downloaded blob can't poison a future
    # cache hit.
    tmp = dest + ".part"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, dest)
    return dest


def _map_flash_state(raw_state: str) -> str:
    """Translate a FlashResult.state literal into the API's state vocab.

    The flasher returns lower-case literals defined in fwota_v4.FlashState
    (e.g. "success", "rolled_back_to_previous", "failed_flash"); the API
    schema uses slightly different terminology ("done" instead of
    "success") and treats a rollback as a non-terminal outcome that the
    collector + frontend surface distinctly.
    """
    s = raw_state.lower()
    if s in {"success"} or s.endswith("success"):
        return "done"
    if "rolled_back" in s or "rollback" in s:
        return "rolled_back_to_previous"
    if "boot_loop" in s:
        return "failed_boot_loop"
    if "no_reenum" in s:
        return "failed_no_reenum"
    if "verify" in s:
        return "failed_verify"
    if "timeout" in s:
        return "failed_timeout"
    return "failed_flash"


#: Regex that extracts the hex chip-ID suffix from a runtime descriptor
#: slug. Two flavours show up in the field:
#:   - Heltec V4 ESP32-S3: 12-hex-digit MAC (``...PSRAM__441BF661E624-if00``)
#:   - LilyGo T-Echo nRF52: 16-hex-digit chip ID
#:     (``...Nordic_NRF52_DK_62444E784607AE64-if00``)
#: Used by find_jtag_recovery_port / find_techo_dfu_port to build the
#: matching bootloader descriptor when the supervisor (correctly)
#: doesn't track those ports as gateways.
_RUNTIME_MAC_RE = re.compile(r"_([0-9A-Fa-f]{12,16})-if")


def find_jtag_recovery_port(
    sanitized: str,
    *,
    glob_fn: Callable[[str], list[str]] | None = None,
) -> str | None:
    """Locate the JTAG-bootloader descriptor that pairs with ``sanitized``.

    When a Heltec V4 OTA fails, the chip drops into the ESP32-S3 ROM
    USB-JTAG bootloader. The supervisor's port sweep deliberately
    filters those descriptors out so the OTA dispatcher's retry doesn't
    race a SerialReader for the port — but the dispatcher then has to
    find the JTAG descriptor itself to recover the chip. The MAC suffix
    is the same on both descriptors (just colon-formatted on JTAG side).

    Returns the first matching JTAG path, or ``None`` if the sanitized
    slug doesn't carry a recognisable MAC or no JTAG descriptor exists.
    """
    import glob as _glob

    g = glob_fn or _glob.glob
    m = _RUNTIME_MAC_RE.search(sanitized)
    if m is None:
        return None
    mac = m.group(1)
    colon_mac = ":".join(mac[i : i + 2] for i in range(0, 12, 2))
    # ESP32-S3 — the descriptor format the bridge has seen on the V4.
    pattern = (
        f"/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_"
        f"{colon_mac}-if00"
    )
    matches = sorted(g(pattern))
    return matches[0] if matches else None


def find_techo_dfu_port(
    sanitized: str,
    *,
    glob_fn: Callable[[str], list[str]] | None = None,
) -> str | None:
    """Locate the LilyGo T-Echo Adafruit-DFU descriptor for ``sanitized``.

    Adafruit nRF52 bootloader on T-Echo exposes a USB-CDC descriptor
    with a different product name (``LilyGo_T-Echo_v1_*``) than the
    runtime (``Nordic_NRF52_DK_*``). Same MAC suffix. When a previous
    OTA left the chip stuck in DFU, the dispatcher needs to find the
    DFU port so flash_techo can drop the .uf2 onto the bootloader's
    mass-storage device — same MAC-based lookup as V4's JTAG path.
    """
    import glob as _glob

    g = glob_fn or _glob.glob
    m = _RUNTIME_MAC_RE.search(sanitized)
    if m is None:
        return None
    mac = m.group(1)
    pattern = f"/dev/serial/by-id/usb-LilyGo_T-Echo_v1_{mac}-if00"
    matches = sorted(g(pattern))
    return matches[0] if matches else None


def _file_sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class FwOtaDispatcher:
    """Subscribes to fw-upgrade commands and orchestrates per-port flashes.

    The dispatcher needs a way to resolve a sanitized-port back to a
    full ``/dev/serial/by-id/...`` path; ``port_resolver`` is injected
    so tests can stub it and the supervisor can pass the live mapping.

    ``pause_port`` is called BEFORE flashing (so the serial reader
    releases the USB-CDC port) and ``resume_port`` is called AFTER
    flashing succeeds / fails (so the reader reattaches and starts
    seeing the new firmware's heartbeats). Both are no-ops when the
    supervisor doesn't have the matching port.
    """

    def __init__(
        self,
        cfg: MQTTConfig,
        *,
        port_resolver: Callable[[str], str | None],
        pause_port: Callable[[str], None] | None = None,
        resume_port: Callable[[str], None] | None = None,
        update_health: Callable[[str, str, str], None] | None = None,
        cache_dir: str = DEFAULT_FW_CACHE_DIR,
        github_token: str = "",
        client_factory: Callable[[], mqtt.Client] | None = None,
        own_ports_provider: Callable[[], list[str]] | None = None,
    ) -> None:
        self._cfg = cfg
        self._port_resolver = port_resolver
        # Returns THIS Pi's sanitized port names so the dispatcher subscribes
        # only to its own ``gateway/<sanitized>/cmd/fw-upgrade`` topics. The
        # per-Pi MQTT ACL grants only the Pi's own port subtree, so the legacy
        # wildcard subscribe (gateway/+/...) is rejected as "Not authorized"
        # on a scoped broker. None / empty → fall back to the wildcard (dev /
        # god-user brokers, which DO allow it). See test_fwota_dispatcher_subscribe.
        self._own_ports_provider = own_ports_provider
        self._pause_port = pause_port or (lambda _p: None)
        self._resume_port = resume_port or (lambda _p: None)
        # Set a port's status.json health (sanitized, kind, detail). Used to
        # mark a port "flashing" for the duration of an OTA so the portal shows
        # "fw update in progress" instead of the down/serial_error it would
        # otherwise read while the reader is paused. No-op by default.
        self._update_health = update_health or (lambda _p, _k, _d: None)
        self._cache_dir = cache_dir
        self._github_token = github_token
        if client_factory is None:
            # Honour MQTTConfig.transport so the dispatcher follows the
            # bridge's own broker connection model. A CF-fronted prod broker
            # is WSS+TLS on 443 — without `transport="websockets"` the
            # plain-TCP client connect against that port silently fails and
            # the dispatcher never subscribes
            # (zero `fwota.dispatcher.subscribed` log line, zero packets
            # routed). Was broken on every WSS bridge from the moment the
            # WSS migration shipped (no Layer-1 OTA ever succeeded on the
            # fleet until 2026-05-31).
            transport = (getattr(cfg, "transport", "tcp") or "tcp")
            client_factory = lambda: mqtt.Client(  # noqa: E731
                client_id=f"{cfg.client_id}-fwota",
                callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
                transport=transport,
            )
        self._client = client_factory()
        self._client.on_message = self._on_message
        self._client.on_connect = self._on_connect
        self._client.on_disconnect = self._on_disconnect
        self._log = log.bind(component="fwota-dispatcher")
        self._stop = threading.Event()

    def connect(self) -> None:
        """Open the connection + start the paho loop thread.

        Mirrors the bridge's main-publisher TLS handling — if
        ``cfg.tls_enabled`` is true we call ``client.tls_set()`` before
        ``connect()`` so paho negotiates a TLS handshake on the
        underlying socket (whether that socket carries raw MQTT or WSS,
        depending on transport). Without this the dispatcher was
        attempting plain-TCP on whatever port ``cfg.port`` advertised —
        works on port 1883, silently fails on the home-prod WSS:443
        endpoint.
        """
        if self._cfg.username:
            self._client.username_pw_set(self._cfg.username, self._cfg.password)
        if getattr(self._cfg, "tls_enabled", False):
            import ssl
            cert_reqs = (
                ssl.CERT_NONE
                if getattr(self._cfg, "tls_insecure", False)
                else ssl.CERT_REQUIRED
            )
            self._client.tls_set(cert_reqs=cert_reqs)
            if getattr(self._cfg, "tls_insecure", False):
                self._client.tls_insecure_set(True)
        self._client.connect(self._cfg.host, self._cfg.port, keepalive=60)
        self._client.loop_start()

    def stop(self) -> None:
        self._stop.set()
        try:
            self._client.loop_stop()
        finally:
            try:
                self._client.disconnect()
            except (OSError, RuntimeError):
                pass

    def _on_connect(
        self, _client: mqtt.Client, _ud: object, _flags: object,
        rc: int, _props: object | None = None,
    ) -> None:
        if rc != 0:
            self._log.warning("fwota.dispatcher.connect_fail", rc=rc)
            return
        # Subscribe to THIS Pi's own port topics so a scoped per-Pi ACL
        # doesn't reject us ("Not authorized" on the wildcard). Fall back to
        # the wildcard only when we don't know our ports (dev / god-user).
        own = []
        if self._own_ports_provider is not None:
            try:
                own = [p for p in (self._own_ports_provider() or []) if p]
            except Exception as exc:  # noqa: BLE001
                self._log.warning("fwota.dispatcher.own_ports_error", error=str(exc))
                own = []
        if own:
            topics = [f"gateway/{s}/cmd/fw-upgrade" for s in own]
        else:
            topics = [TOPIC_CMD_SUB]
        # paho drops subscriptions across reconnects (clean_session), so we MUST
        # re-subscribe on every connect — but only LOG at INFO when the topic set
        # actually CHANGES. A reconnect that re-subscribes the same set logs at
        # DEBUG, so a flapping broker connection no longer spams INFO every few
        # seconds (#4). Real connection FAILURES stay visible (connect_fail rc!=0
        # above, and _on_disconnect rc below).
        for topic in topics:
            self._client.subscribe(topic, qos=1)
        new = set(topics)
        if new != getattr(self, "_subscribed_topics", set()):
            self._log.info(
                "fwota.dispatcher.subscribed", topics=topics,
                scoped=bool(own), reconnect=hasattr(self, "_subscribed_topics"),
            )
            self._subscribed_topics = new
        else:
            self._log.debug("fwota.dispatcher.resubscribed", topics=topics)

    def _on_disconnect(
        self, _client: mqtt.Client, _ud: object, _flags: object,
        rc: int = 0, _props: object | None = None,
    ) -> None:
        # An UNEXPECTED disconnect (rc != 0) is the real churn cause — network
        # blip, broker eviction, or a client_id collision (another "-fwota"
        # client). Surface it at WARNING so a flapping connection is diagnosable
        # even though the per-connect subscribe log is now quiet (#4).
        if rc:
            self._log.warning("fwota.dispatcher.disconnected", rc=rc)
        else:
            self._log.debug("fwota.dispatcher.disconnected_clean")

    def _on_message(self, _client: mqtt.Client, _ud: object, msg: mqtt.MQTTMessage) -> None:
        m = _TOPIC_PORT_RE.match(msg.topic)
        if not m:
            return
        sanitized = m.group(1)
        job = parse_job(msg.payload)
        if job is None:
            self._log.warning(
                "fwota.dispatcher.bad_payload",
                topic=msg.topic, bytes=len(msg.payload),
            )
            return
        # Run the flash in a worker thread so the paho loop stays
        # responsive (paho callbacks are NOT thread-pooled).
        threading.Thread(
            target=self._run_job,
            args=(sanitized, job),
            name=f"fwota-{sanitized}-{job.job_id}",
            daemon=True,
        ).start()

    def _publish_status(self, sanitized: str, job_id: int, state: str, log_chunk: str = "") -> None:
        payload = json.dumps({"job_id": job_id, "state": state, "log_chunk": log_chunk}).encode()
        self._client.publish(
            TOPIC_STATUS_TEMPLATE.format(sanitized=sanitized),
            payload=payload,
            qos=1,
            retain=False,
        )

    def _run_job(self, sanitized: str, job: JobPayload) -> None:
        """Run one flash attempt for a job.

        Hardening note: the entire body is wrapped in a try/except so
        that ANY exception (network blip during download, asyncio
        runner crash, subprocess oddity) still results in a final
        terminal status being published to MQTT. Without this safety
        net the collector would see the job stuck at ``flashing``
        forever and the 3-strike retry policy would never advance.
        """
        bound = self._log.bind(sanitized=sanitized, job_id=job.job_id, version=job.version)
        try:
            self._run_job_inner(sanitized, job, bound)
        except Exception as exc:  # noqa: BLE001
            bound.exception("fwota.dispatcher.job.crashed", error=_safe_err(exc))
            try:
                self._publish_status(
                    sanitized, job.job_id, "failed_flash",
                    # _safe_err: this catch-all also catches exceptions that
                    # AREN'T OSError/URLError (e.g. http.client.HTTPException),
                    # which bypass the typed handlers above and could carry the
                    # download's Authorization: Bearer <PAT> header to the MQTT
                    # broker. Redact before publishing.
                    f"dispatcher exception: {_safe_err(exc)}",
                )
            except Exception:  # noqa: BLE001 - never let cleanup crash
                pass

    def _run_job_inner(
        self, sanitized: str, job: JobPayload, bound: object
    ) -> None:
        bound.info("fwota.dispatcher.job.start", target_board=job.target_board)
        port = self._port_resolver(sanitized)
        if port is None:
            # Stuck-chip recovery. When the supervisor has no runtime
            # descriptor matching the slug, the chip is likely in a
            # bootloader after a previous failed flash. Look up the
            # matching bootloader descriptor by MAC suffix:
            #   - ESP32-S3 → USB_JTAG_serial_debug_unit_*
            #   - nRF52 (T-Echo) → LilyGo_T-Echo_v1_*
            # The supervisor filters both out so the dispatcher's
            # retry doesn't race a SerialReader; we find them here
            # and hand them to flash_v4 / flash_techo directly.
            jtag_port = find_jtag_recovery_port(sanitized)
            if jtag_port is not None:
                bound.warning(
                    "fwota.dispatcher.using_jtag_recovery_port",
                    jtag_port=jtag_port,
                )
                port = jtag_port
            else:
                techo_dfu_port = find_techo_dfu_port(sanitized)
                if techo_dfu_port is not None:
                    bound.warning(
                        "fwota.dispatcher.using_techo_dfu_port",
                        dfu_port=techo_dfu_port,
                    )
                    port = techo_dfu_port
        if port is None:
            self._publish_status(
                sanitized, job.job_id, "failed_flash",
                f"port resolve failed for {sanitized}",
            )
            bound.warning("fwota.dispatcher.port_unresolved")
            return

        self._publish_status(sanitized, job.job_id, "downloading")
        try:
            local_path = download_to_cache(
                job.download_url,
                job.sha256,
                cache_dir=self._cache_dir,
                github_token=self._github_token,
            )
        except ValueError as exc:
            self._publish_status(sanitized, job.job_id, "failed_verify", _safe_err(exc))
            bound.warning("fwota.dispatcher.verify_fail", error=_safe_err(exc))
            return
        except (OSError, urllib.error.URLError) as exc:  # type: ignore[attr-defined]
            self._publish_status(sanitized, job.job_id, "failed_download", _safe_err(exc))
            bound.warning("fwota.dispatcher.download_fail", error=_safe_err(exc))
            return

        # Pre-download the rollback firmware so it's available when we
        # need it. Failures here are non-fatal — the primary flash may
        # still succeed and never trigger the rollback path. If the
        # primary fails AND we have no rollback, the chip stays stuck
        # in JTAG mode (same as before this hardening); with one it
        # auto-recovers.
        rollback_path: str | None = None
        if job.previous_download_url and job.previous_sha256:
            try:
                rollback_path = download_to_cache(
                    job.previous_download_url,
                    job.previous_sha256,
                    cache_dir=self._cache_dir,
                    github_token=self._github_token,
                )
                bound.info(
                    "fwota.dispatcher.rollback_armed",
                    previous_version=job.previous_version,
                    previous_sha=job.previous_sha256,
                )
            except (ValueError, OSError, urllib.error.URLError) as exc:  # type: ignore[attr-defined]
                # Roll-forward without a rollback target — log loud so
                # the operator knows the safety net is missing for this
                # job, but don't fail the primary attempt over it.
                bound.warning(
                    "fwota.dispatcher.rollback_prepare_fail",
                    error=_safe_err(exc),
                    previous_version=job.previous_version,
                )

        # Pause the serial reader so the flashing subprocess can take
        # the USB-CDC port; resume on the way out regardless of
        # success/failure.
        self._pause_port(sanitized)
        # Mark the port "flashing" so the portal shows "fw update in progress"
        # instead of the down/serial_error it would otherwise read while the
        # reader is paused for the flash. Set AFTER pause so the (now-stopped)
        # reader can't immediately overwrite it.
        self._update_health(sanitized, "flashing", "firmware update in progress")
        self._publish_status(sanitized, job.job_id, "flashing")
        result = None
        try:
            log_lines: list[str] = []
            def on_progress(line: str) -> None:
                log_lines.append(line)
                self._publish_status(sanitized, job.job_id, "flashing", line)

            # Async fwota_* functions are run synchronously here on the
            # worker thread via asyncio.run() — simpler than threading
            # in an asyncio.Runner. The flash takes 5-15s typically.
            import asyncio

            if is_esp32_target(job.target_board):
                result = asyncio.run(
                    flash_v4(
                        port,
                        local_path,
                        on_progress=on_progress,
                        rollback_fw_bin_path=rollback_path,
                    )
                )
            elif is_h743_target(job.target_board):
                # STM32H743 path uses dfu-util against the H7 ROM
                # bootloader at 0x1FF09800. The H7 family doesn't have
                # a separate JTAG bootloader, so the rollback path is
                # "retry against rollback binary while still in DFU"
                # rather than "retry on a different descriptor" — see
                # fwota_h743.flash_h743 for the details.
                result = asyncio.run(
                    flash_h743(
                        port,
                        local_path,
                        on_progress=on_progress,
                        rollback_fw_bin_path=rollback_path,
                    )
                )
            elif is_t114_target(job.target_board):
                # Heltec T114 v2 uses the Adafruit nRF52 bootloader,
                # identical to T-Echo at the flash-protocol level. The
                # wrapper exists so we can diverge later (e.g. if v3
                # ships with a different bootloader pin map) without
                # touching the T-Echo flash flow.
                result = asyncio.run(
                    flash_t114(port, local_path, on_progress=on_progress)
                )
            elif is_stm32wl_target(job.target_board):
                # SAFETY: only the OpenBootloader-prepped build (_openbl,
                # linked at 0x08008000) may be serial-flashed. OpenBL writes
                # the app at 0x08008000; a normal 0x08000000-based image lands
                # there with the wrong vector table + absolute addresses and
                # bricks the node. So refuse anything that isn't the prepped
                # TDOA build for the Wio. See is_stm32wl_openbl_target.
                if not is_stm32wl_openbl_target(job.target_board):
                    bound.warning(
                        "fwota.dispatcher.stm32wl.refused_non_openbl",
                        target_board=job.target_board,
                    )
                    result = FlashResult(
                        state="failed_bad_input",
                        port=port,
                        fw_bin_path=local_path,
                        duration_seconds=0.0,
                        error=(
                            "Wio-E5 serial OTA requires the OpenBL-prepped "
                            f"build (*_openbl); refusing {job.target_board} "
                            "to avoid a brick"
                        ),
                    )
                else:
                    # Wio-E5 mini / LoRa-E5 (STM32WLE5). Serial flash over the
                    # CP2102 (PB6/PB7) via stm32flash → ST Open Bootloader. The
                    # ROM bootloader is unreachable (PA9/PA10, BOOT0 not bonded)
                    # so OpenBL must already be resident (one-time SWD install,
                    # write-protected region) and the app must have self-jumped
                    # into it (startOTAUpdate sets the RTC backup flag + reset)
                    # before this runs. local_path is the raw firmware.bin; it's
                    # written at the app base past the OpenBL region. See
                    # fwota_stm32wl.flash_stm32wl.
                    result = asyncio.run(
                        flash_stm32wl(
                            port,
                            local_path,
                            on_progress=on_progress,
                            rollback_fw_bin_path=rollback_path,
                        )
                    )
            else:
                # T-Echo / RAK4631 / Wio fall-through path. Doesn't yet
                # support rollback; the DFU bootloader behaves
                # differently from ESP32-S3 and a generic rollback shim
                # risks bricking a healthy chip. Tracked separately.
                result = asyncio.run(flash_techo(port, local_path, on_progress=on_progress))

            raw_state = str(getattr(result, "state", "failed_flash"))
            final_state = _map_flash_state(raw_state)
            self._publish_status(sanitized, job.job_id, final_state)
            bound.info("fwota.dispatcher.job.complete", final_state=final_state)
        finally:
            # Clear the transient "flashing" marker. On a successful flash the
            # device re-enumerates and the serial reader sets the real health
            # ("ok") from live frames once the port resumes; only force a
            # terminal "serial_error" when the flash clearly did NOT succeed so
            # a failed/aborted flash never stays stuck showing "flashing".
            _raw = str(getattr(result, "state", "")) if result is not None else ""
            if (not _raw) or any(
                t in _raw for t in ("fail", "timeout", "error", "refused", "bad_input")
            ):
                self._update_health(
                    sanitized, "serial_error", _raw or "firmware flash did not complete"
                )
            self._resume_port(sanitized)
