#!/bin/bash
# MeshCore TDOA gateway auto-update. Fires every 6h from
# meshcore-tdoa-auto-update.timer.
#
# HARDENED 2026-06-07 to actually VERIFY the update took effect instead of
# declaring "ok" on a no-op or a half-failed upgrade — the recurring
# "stale bridge" class. The old script only ever reported the PORTAL version,
# never recovered from a failed postinst, and never checked that the RUNNING
# bridge matched the INSTALLED deb, so a box could sit on an old bridge for
# days while the status said "ok". This version:
#   * reports BOTH portal + bridge (installed / candidate / running)
#   * forces a fresh index each run (defeats a stale mirror Release / apt cache)
#   * recovers from a broken/half-configured upgrade
#     (dpkg --configure -a + apt-get -f install + one retry)
#   * verifies the RUNNING bridge == the INSTALLED bridge and restarts to
#     converge (catches old code still running after a deb upgrade)
#   * classifies each package: upgraded / up-to-date / failed / running_stale
#
# Best-effort: always exits 0 so the 6h timer keeps retrying. Logs to journald
# (StandardOutput=journal) AND /var/log/meshcore-tdoa-auto-update.log.
set -u

export DEBIAN_FRONTEND=noninteractive
PKGS=(meshcore-tdoa-gateway-portal meshcore-tdoa-gateway-bridge)
STATUS_DIR=/run/meshcore-tdoa
STATUS_FILE=$STATUS_DIR/auto-update.json
LOG=/var/log/meshcore-tdoa-auto-update.log
BRIDGE_STATUS=/run/meshcore-tdoa-gateway-bridge/status.json
BRIDGE_SVC=meshcore-tdoa-gateway-bridge.service

mkdir -p "$STATUS_DIR"
: > "$LOG" 2>/dev/null || true
log() { printf '%s %s\n' "$(date -u +%FT%TZ)" "$*" >> "$LOG" 2>/dev/null || true; }

# install.sh writes meshcore-tdoa-gateway.list; an older bootstrap used
# meshcore-tdoa.list. Accept either so pre-rename fleet Pis keep updating.
LIST=""
for candidate in /etc/apt/sources.list.d/meshcore-tdoa-gateway.list \
                  /etc/apt/sources.list.d/meshcore-tdoa.list; do
  [ -f "$candidate" ] && { LIST="$candidate"; break; }
done

# --- helpers ---------------------------------------------------------------
installed_ver() { dpkg-query -W -f='${Version}' "$1" 2>/dev/null || true; }
is_installed()  { dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"; }
candidate_ver() {
  apt-cache policy "$1" 2>/dev/null | awk '/Candidate:/{print $2; exit}'
}
# The bridge self-reports the version it's ACTUALLY running into status.json
# (read once at process import). Comparing this to the installed deb catches a
# service still executing old/shadowed code after a successful deb upgrade.
bridge_running_ver() {
  [ -f "$BRIDGE_STATUS" ] || return 0
  python3 - "$BRIDGE_STATUS" <<'PY' 2>/dev/null || true
import json, sys
try:
    print((json.load(open(sys.argv[1])).get("bridge_version") or ""))
except Exception:
    pass
PY
}
json_str() { printf '%s' "${1:-}" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'; }

# write_status STATE MSG
# Emits the back-compat top-level {state,at,msg,installed=portal} PLUS a rich
# per-package block so the portal/fleet-health can see bridge staleness too.
write_status() {
  local state=$1 msg=$2
  local p_inst p_cand b_inst b_cand b_run
  p_inst=$(installed_ver meshcore-tdoa-gateway-portal)
  p_cand=$(candidate_ver meshcore-tdoa-gateway-portal)
  b_inst=$(installed_ver meshcore-tdoa-gateway-bridge)
  b_cand=$(candidate_ver meshcore-tdoa-gateway-bridge)
  b_run=$(bridge_running_ver)
  python3 - <<PY > "$STATUS_FILE.tmp" 2>/dev/null && mv "$STATUS_FILE.tmp" "$STATUS_FILE"
import json
print(json.dumps({
  "state": "$state",
  "at": "$(date -u +%FT%TZ)",
  "msg": $(json_str "$msg"),
  "installed": "${p_inst}",
  "packages": {
    "portal": {"installed": "${p_inst}", "candidate": "${p_cand}"},
    "bridge": {"installed": "${b_inst}", "candidate": "${b_cand}", "running": "${b_run}"},
  },
}))
PY
}

# --- toggle ----------------------------------------------------------------
if [ -f /etc/meshcore-tdoa-gateway-portal/portal.env ]; then
  # shellcheck disable=SC1091
  source /etc/meshcore-tdoa-gateway-portal/portal.env 2>/dev/null || true
fi
if [ "${AUTO_UPDATE:-on}" = "off" ]; then
  write_status disabled "AUTO_UPDATE=off in portal.env; skipping. Re-enable via the portal UI or unset the var."
  exit 0
fi

if [ -z "$LIST" ]; then
  write_status not_bootstrapped "no apt source list under /etc/apt/sources.list.d/ — run install.sh first"
  exit 0
fi

# --- 1. fresh index (defeat a stale mirror Release / apt list cache) --------
# A weakly-cached mirror (e.g. an http.server that 304s an updated flat repo, or
# a Release whose hash wasn't regenerated) makes apt keep the OLD candidate, so
# --only-upgrade silently does nothing. Drop OUR mirror's cached lists first so
# every run re-fetches the index. Host is parsed from the deb line; only files
# matching that host are removed.
MIRROR_HOST=$(awk '/^deb /{for(i=1;i<=NF;i++) if($i ~ /^https?:\/\//){sub(/^https?:\/\//,"",$i); sub(/\/.*/,"",$i); sub(/:.*/,"",$i); print $i; exit}}' "$LIST")
if [ -n "${MIRROR_HOST:-}" ]; then
  log "clearing cached lists for mirror host: $MIRROR_HOST"
  find /var/lib/apt/lists -maxdepth 1 -type f -name "*${MIRROR_HOST}*" -delete 2>/dev/null || true
fi

if ! apt-get update \
     -o Dir::Etc::sourcelist="$LIST" \
     -o Dir::Etc::sourceparts="-" \
     -o APT::Get::List-Cleanup="0" >>"$LOG" 2>&1; then
  write_status apt_update_failed "$(tail -c 2000 "$LOG")"
  exit 0
fi

# --- 2. classify packages: upgrade / install-new / skip ---------------------
UPGRADE=(); INSTALL_NEW=()
for p in "${PKGS[@]}"; do
  cand=$(candidate_ver "$p")
  [ -z "$cand" ] || [ "$cand" = "(none)" ] && continue   # unknown to apt
  if is_installed "$p"; then
    UPGRADE+=("$p")
  else
    INSTALL_NEW+=("$p")
  fi
done

if [ "${#UPGRADE[@]}" -eq 0 ] && [ "${#INSTALL_NEW[@]}" -eq 0 ]; then
  write_status no_candidate "none of the configured packages have an apt candidate (${PKGS[*]})"
  exit 0
fi

# --- 3. apply, with recovery on a broken/half-configured dpkg ----------------
# A failed postinst leaves dpkg half-configured and keeps the OLD version; the
# next plain retry fails the same way. So on failure: configure pending, fix
# broken deps, then retry the transaction ONCE before giving up.
apply() {
  local rc=0
  if [ "${#UPGRADE[@]}" -gt 0 ]; then
    apt-get install --only-upgrade -y "${UPGRADE[@]}" >>"$LOG" 2>&1 || rc=$?
  fi
  if [ "$rc" -eq 0 ] && [ "${#INSTALL_NEW[@]}" -gt 0 ]; then
    apt-get install -y "${INSTALL_NEW[@]}" >>"$LOG" 2>&1 || rc=$?
  fi
  return "$rc"
}

if ! apply; then
  log "apply failed; attempting recovery (dpkg --configure -a + apt-get -f install)"
  dpkg --configure -a >>"$LOG" 2>&1 || true
  apt-get -f install -y >>"$LOG" 2>&1 || true
  if ! apply; then
    write_status install_failed "$(tail -c 2000 "$LOG")"
    exit 0
  fi
  log "recovery succeeded on retry"
fi

# --- 4. verify each package reached its candidate ---------------------------
STALE=()
for p in "${PKGS[@]}"; do
  cand=$(candidate_ver "$p"); inst=$(installed_ver "$p")
  [ -z "$cand" ] || [ "$cand" = "(none)" ] && continue
  if [ "$inst" != "$cand" ]; then
    STALE+=("$p (installed $inst, candidate $cand)")
  fi
done

# --- 5. converge the RUNNING bridge to the INSTALLED bridge ------------------
# After a successful deb upgrade the bridge's running process should report the
# installed version. If it doesn't (old/shadowed code still resident), restart
# once and re-check. 0.5.2's postinst auto-heal removes the legacy shadow; this
# is the belt-and-braces runtime check.
RUNNING_STALE=""
b_inst=$(installed_ver meshcore-tdoa-gateway-bridge)
if [ -n "$b_inst" ] && systemctl is-active --quiet "$BRIDGE_SVC" 2>/dev/null; then
  b_run=$(bridge_running_ver)
  if [ -n "$b_run" ] && [ "$b_run" != "$b_inst" ]; then
    log "running bridge ($b_run) != installed ($b_inst); restarting to converge"
    systemctl restart "$BRIDGE_SVC" >>"$LOG" 2>&1 || true
    sleep 8
    b_run=$(bridge_running_ver)
    [ -n "$b_run" ] && [ "$b_run" != "$b_inst" ] && RUNNING_STALE="$b_run vs installed $b_inst"
  fi
fi

# --- 6. final status --------------------------------------------------------
if [ "${#STALE[@]}" -gt 0 ]; then
  write_status install_failed "package(s) did not reach candidate after recovery: ${STALE[*]}"
elif [ -n "$RUNNING_STALE" ]; then
  write_status running_stale "bridge installed OK but still running old code ($RUNNING_STALE) — shadowed install; see auto-heal"
else
  write_status ok ""
fi
exit 0
