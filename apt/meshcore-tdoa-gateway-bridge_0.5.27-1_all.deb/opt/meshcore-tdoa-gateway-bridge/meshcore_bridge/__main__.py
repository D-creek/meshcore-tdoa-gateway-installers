"""``meshcore-bridge`` entry point.

Parses CLI args, loads YAML config, wires the MQTT publisher to the
port supervisor, and blocks on SIGINT/SIGTERM. Designed to be invoked
by systemd via ``ExecStart=/usr/bin/meshcore-bridge --config /etc/...``.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import signal
import sys
import threading
from pathlib import Path

import structlog

from .config import BridgeConfig, load_config
from .discovery import PortSupervisor, join_forever
from .frame import (
    DeviceTelemetryFrame,
    GatewayInfoFrame,
    GatewayPositionFrame,
    GpsQualityFrame,
    TdoaAdvertAuxFrame,
    TDOAFrame,
)
from .mqtt_publisher import MQTTPublisher

# notify_ready is imported at module top (not function-local like the watchdog
# helpers) because the not-yet-registered early-return path below must signal
# systemd READY=1 before the normal startup reaches it — otherwise a Type=notify
# unit times out the start on a fresh, unregistered install (Meshtest2 2026-06-15).
from .sd_notify import notify_ready

log = structlog.get_logger(__name__)

# How long the bridge pauses before exiting when it isn't registered yet (empty
# mqtt.host). Keeps Restart=always/RestartSec=2 from tight-looping the wait.
_NOT_REGISTERED_WAIT_SECONDS = 30


class _TeePublisher:
    """Thin fan-out wrapper around N :class:`MQTTPublisher` instances.

    Mirrors the ``publish_*`` surface of a single MQTTPublisher so the
    rest of ``__main__`` (the ``on_frame`` callback) is broker-count
    agnostic. The primary publisher's exceptions propagate; secondary
    publishers' exceptions are caught + logged so a dead secondary
    broker never disrupts the primary publish.

    Order: primary first, then secondaries. If the primary raises
    (e.g. broker disconnect), the secondaries don't run for that
    method call — the bridge's existing primary-failure recovery
    handles the disconnect + reconnect via paho's loop_start. A
    secondary failure logs at WARN and skips that one broker; other
    secondaries still receive the publish.

    Why not inside :class:`MQTTPublisher` itself: the publisher class
    owns one paho client + per-port caches keyed off ``self``. Adding
    multi-client inside would require threading the per-client state
    through every internal helper. The Tee at this level keeps the
    publisher class single-broker (which matches its caches) and the
    fan-out trivially correct (each publisher has its own caches).
    """

    def __init__(
        self,
        primary: MQTTPublisher,
        secondaries: list[MQTTPublisher],
    ) -> None:
        self._primary = primary
        self._secondaries = secondaries

    def _fan_out(self, method_name: str, *args, **kwargs) -> None:
        getattr(self._primary, method_name)(*args, **kwargs)
        for sec in self._secondaries:
            try:
                getattr(sec, method_name)(*args, **kwargs)
            except Exception as exc:  # noqa: BLE001
                log.warning(
                    "bridge.secondary_publish.failed",
                    method=method_name,
                    error=str(exc),
                )

    # ------------------------------------------------------------------
    # Mirror MQTTPublisher's public API. Each method delegates to the
    # primary, then fans out to every secondary best-effort.
    # ------------------------------------------------------------------
    def publish_aux(self, *args, **kwargs) -> None:
        self._fan_out("publish_aux", *args, **kwargs)

    def publish_frame(self, *args, **kwargs) -> None:
        self._fan_out("publish_frame", *args, **kwargs)

    def publish_position(self, *args, **kwargs) -> None:
        self._fan_out("publish_position", *args, **kwargs)

    def publish_info(self, *args, **kwargs) -> None:
        self._fan_out("publish_info", *args, **kwargs)

    def publish_telemetry(self, *args, **kwargs) -> None:
        self._fan_out("publish_telemetry", *args, **kwargs)

    def publish_gps_quality(self, *args, **kwargs) -> None:
        self._fan_out("publish_gps_quality", *args, **kwargs)

    def disconnect(self) -> None:
        # On shutdown, disconnect everyone. Secondaries first so the
        # primary disconnect's final-LWT is the one the broker sees
        # latest. Errors swallowed — best-effort shutdown.
        for sec in self._secondaries:
            try:
                sec.disconnect()
            except Exception:  # noqa: BLE001
                pass
        try:
            self._primary.disconnect()
        except Exception:  # noqa: BLE001
            pass

# Per-port friendly-name map maintained by the config portal at
# /etc/meshcore-bridge/port-names.json. The bridge re-reads it on each
# resolve so admin saves take effect on the very next published frame
# without needing a service restart.
_NAMES_PATH = Path(
    os.environ.get(
        "MESHCORE_BRIDGE_NAMES_FILE", "/etc/meshcore-bridge/port-names.json"
    )
)


_PORTAL_DEVICES_DIR = Path(
    os.environ.get(
        "MESHCORE_PORTAL_DEVICES_DIR", "/etc/meshcore-tdoa-gateway/devices"
    )
)


def _name_from_legacy_file(sanitized_port: str) -> str | None:
    """First resolver path: ``/etc/meshcore-bridge/port-names.json``."""
    try:
        if not _NAMES_PATH.exists():
            return None
        with _NAMES_PATH.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    for key, val in data.items():
        if not isinstance(val, str) or not val.strip():
            continue
        if key == sanitized_port or key.split("/")[-1] == sanitized_port:
            return val.strip()
    return None


def _normalize_id(s: str) -> str:
    """Collapse ``[-_]`` and lowercase — the portal's slug-derivation and
    our sanitize_port use different conventions for the same underlying
    by-id string. Normalising both to lower-no-separators lets us match
    them without re-implementing the portal's slugify rules."""
    out = []
    for ch in s.lower():
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


def _portal_meta_matches(meta: dict[str, object], sanitized_port: str, slug: str) -> bool:
    """True iff this portal meta block belongs to ``sanitized_port``.

    sanitize_port keeps dashes (regex ``[^A-Za-z0-9_-]+`` → ``_``), so
    ``usb-RAKwireless_WisCore_RAK4631_...-if00`` survives the sanitize
    pass unchanged. The portal stores by_id with the SAME dash form when
    the field is present, so a direct equality check works there.

    The portal's CURRENT meta.json schema also drops by_id_name/tty and
    keeps only ``slug`` (which is a lowercased dashes-only fingerprint
    derived from the by-id with the variable serial-number tail
    collapsed). For those entries we fall back to a normalize-and-
    contains match: strip every non-alphanumeric from both strings,
    lowercase, then check the slug-form is a substring of the port-form.
    """
    by_id = str(meta.get("by_id_name") or "")
    tty = str(meta.get("tty") or "")
    if by_id and sanitized_port == by_id:
        return True
    if tty and sanitized_port == tty.split("/")[-1]:
        return True
    norm_port = _normalize_id(sanitized_port)
    norm_slug = _normalize_id(slug)
    # Substring rather than endswith — the slug omits the trailing
    # USB serial-number hex, so the port string carries extra bytes
    # AFTER the slug content. Containment captures both cases.
    return bool(norm_slug) and norm_slug in norm_port


def _name_from_portal_meta(sanitized_port: str) -> str | None:
    """Second resolver path: scan portal device dirs for a matching meta.json."""
    try:
        if not _PORTAL_DEVICES_DIR.is_dir():
            return None
        entries = list(_PORTAL_DEVICES_DIR.iterdir())
    except OSError:
        return None
    for entry in entries:
        if not entry.is_dir():
            continue
        meta_path = entry / "meta.json"
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(meta, dict):
            continue
        name = meta.get("gateway_name")
        if not isinstance(name, str) or not name.strip():
            continue
        if _portal_meta_matches(meta, sanitized_port, entry.name):
            return name.strip()
    return None


def _resolve_display_name(sanitized_port: str) -> str | None:
    """Return the user-set name for a port, or None.

    Resolution order (portal first — the portal is the operator-facing
    source of truth now; legacy file is a fallback for installs that
    never adopted the portal):

    1. ``/etc/meshcore-tdoa-gateway/devices/<slug>/meta.json`` —
       portal-managed gateway_name (operator edits via /devices UI).
    2. ``/etc/meshcore-bridge/port-names.json`` — legacy direct-bridge
       configurator file. Kept as a fallback so existing deployments
       that haven't migrated to the portal still work, but the portal
       wins when both are present.
    """
    return _name_from_portal_meta(sanitized_port) or _name_from_legacy_file(sanitized_port)


# Minimum satellites in view for a position frame to be considered
# trustworthy enough to forward downstream. 4 is the threshold for a
# 3D fix. Honoured only when the firmware actually populates sat_count
# — see ``position_frame_has_real_fix`` for the workaround that covers
# firmwares that hardcode the field to zero.
GPS_FIX_MIN_SAT_COUNT = 4


def position_frame_has_real_fix(frame: GatewayPositionFrame) -> bool:
    """Return True iff the position frame is backed by an actual fix.

    Decision tree:

    1. ``position_valid`` must be set. Firmwares with healthy GPS-loss
       handling clear this bit when the chip drops its fix; trusting
       the rest of the payload without this bit set would let stale
       coords through.
    2. If ``sat_count > 0`` the firmware is populating it — require
       ``>= GPS_FIX_MIN_SAT_COUNT`` (4) for a real 3D fix.
    3. If ``sat_count == 0`` the firmware is either reporting "no fix"
       OR hardcoding zero (TDOA-1.3.0 on T-Echo + Heltec V4 — verified
       by raw-frame capture 2026-05-10: lat_e7=509381280 with sat_count=0
       was a real fix all along). The firmware guards 0x92 emission on
       ``node_lat != 0 || node_lon != 0``, so a position_valid frame
       with non-zero coordinates IS a real fix on those firmwares.
       Accept it.

    Trade-off for case (3): if a firmware fails to clear position_valid
    when GPS loses lock, we'll briefly persist the last-known coords
    until KAN-156 (collector clears location on valid=false) fires.
    The proper fix is in firmware — wire ``nmea.getNumSatellites()``
    into ``MyMesh::sendGatewayPosition()`` so case (2) takes over.
    """
    if not frame.position_valid:
        return False
    if frame.sat_count > 0:
        return frame.sat_count >= GPS_FIX_MIN_SAT_COUNT
    return frame.lat_e7 != 0 or frame.lon_e7 != 0


def _configure_logging(level: str) -> None:
    """JSON-on-stdout structlog config sized for systemd's journal.

    Levels mirror Python ``logging`` (debug/info/warning/error). systemd
    will tag each line with the unit name and route to the journal —
    we just need parseable JSON.
    """
    log_level = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=log_level,
    )
    structlog.configure(
        processors=[
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(log_level),
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="meshcore-bridge",
        description="MeshCore TDOA Pi bridge: USB serial → MQTT relay.",
    )
    p.add_argument(
        "--config",
        default="/etc/meshcore-bridge/config.yaml",
        help="Path to YAML config (default: %(default)s).",
    )
    return p.parse_args(argv)


def run(cfg: BridgeConfig) -> int:
    """Run the bridge until a stop signal arrives. Returns process exit code."""
    # ── Not-yet-registered guard ────────────────────────────────────────
    # Until the gateway has registered, bridge.yaml ships with an EMPTY
    # mqtt.host (the secrets template). Calling paho connect("") raises
    # ValueError: Invalid host → the unit hard-crashes and systemd crash-loops
    # (Erik 2026-06-06). That's an expected pre-onboarding state, not a fault:
    # exit cleanly with a clear message so the operator sees a "waiting for
    # registration" state and the register timer drives convergence. The unit's
    # RestartSec backoff keeps this from tight-looping.
    if not (cfg.mqtt.host or "").strip():
        log.warning(
            "bridge.not_registered",
            msg="mqtt.host is empty — this gateway hasn't registered yet. "
                "Waiting for the register service to write credentials into "
                "bridge.yaml; the bridge will start once mqtt.host is set.",
        )
        # Type=notify: signal READY=1 BEFORE parking in the wait. An
        # unregistered gateway is a valid pre-onboarding state, not a fault —
        # but if we exit 0 without ever sending READY, systemd never sees the
        # start complete, times out after TimeoutStartSec, and marks the unit
        # *failed* on a fresh install (Meshtest2 2026-06-15: "did not take the
        # steps required by its unit configuration"). Reporting ready here lets
        # the unit go active (idle, awaiting registration); the register timer
        # writes mqtt.host and the next Restart=always cycle reaches the normal
        # path. No-op when not under systemd (NOTIFY_SOCKET unset).
        notify_ready()
        # Restart=always (RestartSec=2) would otherwise tight-loop this exit
        # every 2s while we wait for onboarding. Pause so the effective cadence
        # is calm (~30s) without slowing recovery from a REAL crash. Interruptible
        # so a SIGTERM during the wait still stops promptly.
        threading.Event().wait(_NOT_REGISTERED_WAIT_SECONDS)
        return 0
    # Pass lora=None: the bridge MUST NOT fabricate radio params from a
    # YAML/env-derived default. Per-packet RF metadata comes exclusively
    # from each receiver's 0x94 GATEWAY_INFO heartbeat (cached per-port
    # in MQTTPublisher). When the cache is empty for a given port —
    # e.g. immediately post-restart, before the first 0x94 has arrived
    # — the bridge omits freq/bw/sf/cr from that port's envelopes
    # rather than reporting a default value that may not match the
    # receiver's actual tune. The cfg.lora struct is still used by the
    # boot-log line below so operators can see the YAML-configured
    # defaults; it just doesn't feed the wildcard cache.
    primary_publisher = MQTTPublisher(
        cfg.mqtt,
        name_resolver=_resolve_display_name,
        lora=None,
        # Timing-campaign Phase 1: operator-supplied hardware ground-
        # truth per USB-port glob. Loaded from ``config.yaml`` ``hardware:``
        # block (empty dict when missing). MQTTPublisher looks up the
        # matching glob at /info publish time and attaches the matching
        # fields under ``hardware.operator`` in the envelope. Collector
        # COALESCEs them onto the gateway row.
        hardware=cfg.hardware,
    )
    primary_publisher.connect()

    # 2026-05-28: secondary brokers — every publish_* call is fanned
    # out to these in PARALLEL with the primary (config.secondary_
    # mqtt_brokers in YAML). Use case: mirror the packet stream to a
    # second environment without routing through the primary broker.
    # Secondaries are best-effort — a failed connect or publish on a
    # secondary is logged but never disrupts the primary publish path.
    secondary_publishers: list[MQTTPublisher] = []
    for sec_cfg in cfg.secondary_mqtt_brokers:
        try:
            sp = MQTTPublisher(
                sec_cfg,
                name_resolver=_resolve_display_name,
                lora=None,
                hardware=cfg.hardware,
            )
            sp.connect()
            secondary_publishers.append(sp)
            log.info(
                "bridge.secondary_broker.connected",
                host=sec_cfg.host,
                port=sec_cfg.port,
                transport=sec_cfg.transport,
            )
        except Exception as exc:  # noqa: BLE001
            log.warning(
                "bridge.secondary_broker.connect_failed",
                host=sec_cfg.host,
                port=sec_cfg.port,
                error=str(exc),
            )

    if secondary_publishers:
        publisher = _TeePublisher(primary_publisher, secondary_publishers)
    else:
        publisher = primary_publisher

    def on_frame(
        port: str,
        frame: TDOAFrame
        | GatewayPositionFrame
        | GatewayInfoFrame
        | DeviceTelemetryFrame
        | TdoaAdvertAuxFrame
        | GpsQualityFrame,
    ) -> None:
        if isinstance(frame, TdoaAdvertAuxFrame):
            # tdoa-1.8.0: cache the aux fields by packet_hash; the next
            # matching 0x90 frame will pop and merge into its envelope.
            # No MQTT publish here — the data rides on the 0x90.
            publisher.publish_aux(port, frame)
            log.info(
                "bridge.aux.cached",
                port=port,
                packet_hash=frame.packet_hash.hex(),
                has_latlon=frame.tx_lat_e6 is not None,
                raw_bytes=len(frame.raw_packet) if frame.raw_packet else 0,
            )
            return
        if isinstance(frame, TDOAFrame):
            publisher.publish_frame(port, frame)
            # INFO so the portal's journal-tail-based frame counter can
            # see this without journald debug-routing tweaks (Pi /etc
            # default skips debug). pps_locked + gps_3d_fix included so
            # the portal can render per-port lock status without
            # waiting on a 0x92 position broadcast (which only fires
            # every 60 s).
            log.info(
                "bridge.frame.published",
                port=port,
                node_id=frame.node_id.hex(),
                embedded_hash=frame.embedded_packet_hash.hex(),
                rssi=frame.rssi,
                snr=frame.snr,
                pps_locked=frame.pps_locked,
                gps_3d_fix=frame.gps_3d_fix,
            )
        elif isinstance(frame, GatewayPositionFrame):
            # See module-level docstring on ``position_frame_has_real_fix``
            # for the rationale on why both the firmware's valid bit
            # and a satellite-count threshold are required.
            if position_frame_has_real_fix(frame):
                publisher.publish_position(port, frame)
                log.info(
                    "bridge.position.published",
                    port=port,
                    node_id=frame.node_id.hex(),
                    lat=frame.lat,
                    lon=frame.lon,
                    sat_count=frame.sat_count,
                    position_valid=frame.position_valid,
                )
            else:
                log.info(
                    "bridge.position.dropped",
                    port=port,
                    node_id=frame.node_id.hex(),
                    sat_count=frame.sat_count,
                    position_valid=frame.position_valid,
                    reason=(
                        "no_fix_yet"
                        if frame.sat_count < GPS_FIX_MIN_SAT_COUNT
                        else "position_valid_bit_clear"
                    ),
                )
        elif isinstance(frame, GatewayInfoFrame):
            publisher.publish_info(port, frame)
            log.info(
                "bridge.info.published",
                port=port,
                node_id=frame.node_id.hex(),
                board=frame.board_name,
                fw=frame.fw_version,
                mcu=frame.mcu_chip,
                lora=frame.lora_chip,
                has_gps=frame.has_gps,
                has_pps=frame.has_pps,
                is_tdoa_rx=frame.is_tdoa_rx,
                # tdoa 2026-05-29 PM — probe-detected GPS chip identity.
                # Visible in journald so the operator can see whether
                # the firmware's GpsChipProbe actually found the chip
                # without having to subscribe to MQTT.
                gps_chip_family=frame.gps_chip_family,
                gps_chip_model=frame.gps_chip_model,
                gps_sw=frame.gps_chip_sw_version,
                gps_ack=frame.gps_bootstrap_ack,
                gps_gnss=frame.gps_enabled_gnss_mask,
            )
        elif isinstance(frame, DeviceTelemetryFrame):  # KAN-101
            publisher.publish_telemetry(port, frame)
            log.info(
                "bridge.telemetry.published",
                port=port,
                node_id=frame.node_id.hex(),
                uptime_s=frame.uptime_s,
                boot_count=frame.boot_count,
                mcu_temp_c=frame.mcu_temp_c,
                vbat_mv=frame.vbat_mv,
                gps_sats=frame.gps_sats,
                pps_jitter_us=frame.pps_jitter_us,
            )
        elif isinstance(frame, GpsQualityFrame):
            publisher.publish_gps_quality(port, frame)
            log.info(
                "bridge.gps_quality.published",
                port=port,
                node_id=frame.node_id.hex(),
                hdop=frame.hdop,
                pdop=frame.pdop,
                vdop=frame.vdop,
                sat_total=frame.sat_total,
                fix_quality=frame.fix_quality,
            )

    # Hardware map is forwarded so the supervisor can match each USB
    # port against the ``hardware:`` block and spawn a TCP-passthrough
    # listener for ports configured with ``tcp_passthrough_port``.
    # See tcp_passthrough.py for the Option-B design.
    def on_health(port: str, kind: str, detail: str) -> None:
        # Erik #3: route per-port health into status.json so the portal can
        # render a precise badge (serial_error / quarantined / unavailable /
        # ok) explaining why a port produces no frames, instead of a generic
        # "no data". The publisher owns status.json; merge the two fields in.
        try:
            primary_publisher.update_port_health(port, kind, detail)
        except Exception as exc:  # noqa: BLE001
            log.warning("bridge.on_health.status_write_failed", port=port, error=str(exc))

    supervisor = PortSupervisor(
        cfg.serial, on_frame, hardware=cfg.hardware, on_health=on_health
    )
    supervisor.start()

    # KAN-167: FW-OTA job dispatcher subscribes to
    # ``gateway/+/cmd/fw-upgrade`` and orchestrates per-port flashes.
    # Lives in its own paho client so subscription state stays cleanly
    # separated from the publisher. ``pause_port`` / ``resume_port`` on
    # the supervisor let the dispatcher hand the USB-CDC port to the
    # flashing subprocess (esptool / nrfutil) without leaking SerialReader
    # threads.
    from .fwota_dispatcher import FwOtaDispatcher, make_version_heartbeat_probe
    from .serial_locks import PortSerialLocks

    # One shared per-port serial-access lock, used by BOTH the FW-OTA dispatcher
    # and the auth-token minter so a flash and a token-mint never open the same
    # USB-CDC port at the same time (see serial_locks.PortSerialLocks).
    serial_locks = PortSerialLocks()

    fwota = FwOtaDispatcher(
        cfg.mqtt,
        port_resolver=supervisor.resolve_port,
        pause_port=supervisor.pause_port,
        resume_port=supervisor.resume_port,
        # Serial-keyed flash gate: keeps the sweep off the device across the
        # WisCore↔WisBlock / app↔JTAG descriptor swap a flash causes (the
        # slug-keyed pause_port alone misses the re-enumerated bootloader
        # descriptor). Keyed on the stable bare-hex serial.
        mark_flashing=supervisor.mark_flashing,
        clear_flashing=supervisor.clear_flashing,
        serial_locks=serial_locks,
        # Mark the port "flashing" in status.json for the OTA duration so the
        # portal shows "fw update in progress" instead of down/serial_error
        # while the reader is paused. Same status writer on_health uses.
        update_health=primary_publisher.update_port_health,
        github_token=cfg.firmware_github_token,
        # Subscribe only to THIS Pi's own port topics so a scoped per-Pi MQTT
        # ACL doesn't reject the subscription as "Not authorized" (the legacy
        # wildcard gateway/+/cmd/fw-upgrade did). See fwota_dispatcher.
        own_ports_provider=supervisor.own_sanitized_ports,
        # Lets the T-Echo/RAK flasher pick the DFU-enter method: the magic
        # CMD_ENTER_USB_DFU frame for TDOA firmware, the 1200-baud touch for
        # stock firmware that lacks the command.
        is_tdoa_fw_probe=primary_publisher.is_tdoa_fw,
        # STEP 5 — version-aware post-flash probe. Builds, per flash, a probe
        # that re-finds the device by its stable serial symlink (contract #4)
        # and only reports success once the device's cached 0x94-reported version
        # EXACTLY matches the target (contract #3). Closes over the publisher's
        # cached per-port version string.
        heartbeat_probe_factory=lambda sanitized, version: make_version_heartbeat_probe(
            version, primary_publisher.tdoa_firmware_version_by_serial
        ),
    )
    try:
        fwota.connect()
        log.info("bridge.fwota.dispatcher.started")
    except Exception as exc:  # noqa: BLE001
        log.warning("bridge.fwota.dispatcher.connect_failed", error=str(exc))

    # On-node auth-token minter: for any device with a token-auth broker, ask the
    # node to sign a fresh JWT over serial (CMD_SIGN) and write it to /run for the
    # mesh-relay. Pauses each port briefly (~1 s) per refresh cycle. No-op when no
    # token brokers are configured (the common case).
    from .auth_token_minter import AuthTokenMinter

    minter = AuthTokenMinter(
        # active_ports is a @property (returns a list), so wrap it in a lambda —
        # the minter expects a callable.
        active_ports=lambda: supervisor.active_ports,
        pause_port=supervisor.pause_port,
        resume_port=supervisor.resume_port,
        serial_locks=serial_locks,
    )
    minter.start()
    log.info("bridge.auth_token_minter.started")

    # WS3: systemd watchdog integration.
    # ⚠️ Must be validated on testOPI before prod — missing READY=1 fails
    # service start fleet-wide (Type=notify service stays in "activating"
    # until TimeoutStartSec, then systemd marks it failed and won't restart).
    # notify_ready is imported at module top (it's also needed on the
    # not-registered early-return path). The watchdog helpers stay local —
    # they're only used here on the registered/running path.
    from .sd_notify import (
        SWEEP_STALE_THRESHOLD,
        WATCHDOG_PING_INTERVAL,
        notify_watchdog,
    )

    # Signal systemd that the bridge has fully initialised: supervisor
    # running, primary broker connected, fwota dispatcher wired. For a
    # Type=simple service this is a no-op; for Type=notify it unblocks
    # the start timeout and transitions the unit to "active".
    notify_ready()

    # Bind the stop event BEFORE starting the pinger thread (and before the
    # signal handlers below): _watchdog_pinger closes over `stop_evt`, so if it
    # were assigned after .start() the thread can execute its first
    # `stop_evt.wait()` before the binding exists and die with
    # "NameError: cannot access free variable 'stop_evt'". That race lost on
    # skypi4 (multi-core, thread scheduled first) → no WATCHDOG=1 ever sent →
    # systemd watchdog-killed the bridge every WatchdogSec. Assign it here.
    stop_evt = threading.Event()

    def _watchdog_pinger() -> None:
        """Daemon thread: ping systemd's watchdog every WATCHDOG_PING_INTERVAL
        seconds, BUT only while the port supervisor is producing fresh sweeps.

        A hung or deadlocked supervisor stops updating supervisor.last_sweep_
        monotonic; after SWEEP_STALE_THRESHOLD seconds without an update,
        this thread stops sending WATCHDOG=1 and lets systemd's WatchdogSec
        timer fire, which restarts the bridge. This ensures a "looks alive
        but isn't doing sweeps" bridge is recovered automatically without a
        manual Pi reboot.
        """
        import time as _time
        while not stop_evt.wait(WATCHDOG_PING_INTERVAL):
            age = _time.monotonic() - supervisor.last_sweep_monotonic
            if supervisor.last_sweep_monotonic > 0.0 and age < SWEEP_STALE_THRESHOLD:
                notify_watchdog()
            else:
                log.warning(
                    "bridge.watchdog.sweep_stale",
                    age_s=round(age, 1),
                    threshold_s=SWEEP_STALE_THRESHOLD,
                    msg="Skipping watchdog ping — supervisor sweep is stale; "
                        "systemd WatchdogSec will fire and restart the bridge",
                )

    threading.Thread(
        target=_watchdog_pinger,
        name="sd-watchdog-pinger",
        daemon=True,
    ).start()

    def _handle_signal(signum: int, _frame: object) -> None:
        log.info("bridge.signal.received", signal=signum)
        stop_evt.set()

    signal.signal(signal.SIGINT, _handle_signal)
    signal.signal(signal.SIGTERM, _handle_signal)

    log.info(
        "bridge.started",
        mqtt_host=cfg.mqtt.host,
        mqtt_port=cfg.mqtt.port,
        # KAN-134: surface the bridge-level LoRa RF profile at boot so
        # an operator tail-following the journal can confirm the env-var
        # / YAML overrides took effect without parsing an envelope.
        lora_freq_hz=cfg.lora.freq_hz,
        lora_bandwidth_hz=cfg.lora.bandwidth_hz,
        lora_spread_factor=cfg.lora.spread_factor,
        lora_coderate=cfg.lora.coderate,
    )
    try:
        join_forever(stop_evt)
    finally:
        log.info("bridge.shutdown.start")
        try:
            try:
                minter.stop(timeout=3.0)
            except Exception as exc:  # noqa: BLE001
                log.warning("bridge.auth_token_minter.stop_error", error=str(exc))
            try:
                fwota.stop()
            except Exception as exc:  # noqa: BLE001
                log.warning("bridge.fwota.dispatcher.stop_error", error=str(exc))
            supervisor.stop(timeout=5.0)
        finally:
            publisher.disconnect()
        log.info("bridge.shutdown.complete")
    return 0


#: Pre-rename config path. The current unit loads --config
#: /etc/meshcore-tdoa-gateway/bridge.yaml; a leftover file here is IGNORED, but
#: operators edit it expecting effect (the 2026-06-11 meshcore-observer
#: confusion — serial.port_globs edits there did nothing). Warn loudly so the
#: dead file is obvious in the journal.
_LEGACY_CONFIG_PATH = "/etc/meshcore-bridge/config.yaml"


def _warn_if_legacy_config(active_config: str) -> None:
    """Log a warning if the ignored legacy config file is present."""
    try:
        legacy = Path(_LEGACY_CONFIG_PATH)
        if legacy.is_file() and legacy.resolve() != Path(active_config).resolve():
            log.warning(
                "config.legacy_ignored",
                legacy=_LEGACY_CONFIG_PATH,
                active=active_config,
                msg=(
                    f"Ignoring legacy config {_LEGACY_CONFIG_PATH}; this service "
                    f"uses {active_config}. Edits to the legacy file have NO "
                    f"effect — move any settings (e.g. serial.port_globs) into "
                    f"{active_config}."
                ),
            )
    except Exception:  # noqa: BLE001 — diagnostics must never crash startup
        pass


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    cfg = load_config(args.config)
    _configure_logging(cfg.log.level)
    _warn_if_legacy_config(args.config)
    return run(cfg)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
