#!/usr/bin/env python3
"""Per-minute sampler — records two rolling time series:

1. **broker exported-packet counter** — per-broker publish_ok delta
   sampled from /run/meshcore-mesh-relay/status.json. Cumulative
   counters are differenced against the previous sample; resets
   (counter decreases — happens on relay restart) record delta=0.

2. **per-port GPS state** — last-known gps_3d_fix + sat_count for
   each USB-attached serial port, sourced from the bridge's
   bridge.telemetry.published / bridge.frame.published events in
   journalctl. The sampler tracks both the most recent fix-true
   timestamp AND the count of fix-false → fix-true transitions in
   the last 24h.

Both series are appended to JSONL files under
/var/lib/meshcore-tdoa-gateway-portal/. The portal HTTP API reads
these on demand and serves time-binned views to the frontend.

Designed to be fired by a systemd .timer every 60s; runs in <1s
typical, won't fight the bridge for the serial port.
"""

from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

STATE_DIR = Path("/var/lib/meshcore-tdoa-gateway-portal/sampler")
BROKER_LOG = STATE_DIR / "broker_samples.jsonl"
BROKER_STATE = STATE_DIR / "broker_last.json"
GPS_LOG = STATE_DIR / "gps_samples.jsonl"
GPS_STATE = STATE_DIR / "gps_last.json"

RELAY_STATUS_PATH = Path("/run/meshcore-mesh-relay/status.json")
# Bridge status.json carries homeprod_published_count (cumulative uplink frames
# published to the TDOA/homeprod broker). We diff it into a "TDOA export" broker
# row so the portal renders its 24h sparkline like any relay broker. The name
# MUST match the portal's synthetic read-only TDOA-export row.
BRIDGE_STATUS_PATH = Path("/run/meshcore-tdoa-gateway-bridge/status.json")
TDOA_EXPORT_STATE = STATE_DIR / "tdoa_export_last.json"
TDOA_EXPORT_NAME = "TDOA export"
JOURNAL_LOOKBACK_S = 120  # how far back to scan journal for the latest events

# Bounded log size so a long-running Pi doesn't fill the SD card.
# 7 days × 1440 min × ~6 brokers ≈ 60K lines — well under 10 MB.
# Rotate at 1 MB to keep the read fast.
MAX_LOG_BYTES = 1_000_000


# ---------------------------------------------------------------------------


def _ts() -> int:
    return int(time.time())


def _read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _write_json_atomic(path: Path, doc: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(doc), encoding="utf-8")
    tmp.replace(path)


def _append_jsonl(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # Rotate when too large — keep last half.
    try:
        if path.exists() and path.stat().st_size > MAX_LOG_BYTES:
            data = path.read_text(encoding="utf-8").splitlines()
            keep = data[len(data) // 2:]
            path.write_text("\n".join(keep) + "\n", encoding="utf-8")
    except OSError:
        pass
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row) + "\n")


# ---------------------------------------------------------------------------
# Broker sampler — diff publish_ok against the last snapshot.
# ---------------------------------------------------------------------------


def sample_brokers() -> None:
    """Sample one delta per broker.

    Primary source: the mesh-relay's /run status.json (publish_ok counter
    per broker, diffed against the last snapshot).

    Fallback (when no relay is running, OR the relay is present but
    degenerate — e.g. testopi where the relay accidentally got re-enabled
    after a deb upgrade but its input MQTT auth keeps failing rc=5, so
    forwarded=0 forever): count bridge published events from journalctl
    and attribute the count to every enabled broker in the device
    config.toml(s) — the bridge fan-outs to all of them per packet.

    Detecting "degenerate relay": relay reports brokers BUT has never
    forwarded a packet AND none of the brokers have ever published. In
    that state the relay is just an observer reporting connect-state,
    and the truth lives in the bridge's own publish journal.
    """
    # The bridge->homeprod TDOA export is independent of the relay; always
    # sample it so the portal's TDOA-export row gets a 24h sparkline.
    _sample_tdoa_export()
    cur = _read_json(RELAY_STATUS_PATH)
    brokers = cur.get("brokers") or []
    forwarded = int(cur.get("forwarded") or 0)
    relay_degenerate = bool(brokers) and forwarded == 0 and all(
        int(b.get("publish_ok") or 0) == 0 for b in brokers
    )
    if not brokers or relay_degenerate:
        _sample_brokers_from_bridge_journal()
        return
    prev = _read_json(BROKER_STATE)
    now = _ts()
    new_state: dict[str, dict[str, Any]] = {}
    relay_names: set[str] = set()
    for b in brokers:
        name = b.get("name")
        if not name:
            continue
        relay_names.add(name)
        cur_ok = int(b.get("publish_ok") or 0)
        cur_fail = int(b.get("publish_fail") or 0)
        prev_ok = int((prev.get(name) or {}).get("publish_ok") or 0)
        prev_fail = int((prev.get(name) or {}).get("publish_fail") or 0)
        # Counter reset (e.g. relay restart) → counter goes DOWN. Record
        # delta=0 for this tick so the chart shows a quiet minute rather
        # than a fake spike of the entire prior cumulative count.
        delta_ok = max(0, cur_ok - prev_ok) if cur_ok >= prev_ok else 0
        delta_fail = max(0, cur_fail - prev_fail) if cur_fail >= prev_fail else 0
        _append_jsonl(BROKER_LOG, {
            "ts": now,
            "name": name,
            "delta_ok": delta_ok,
            "delta_fail": delta_fail,
            "connected": bool(b.get("connected")),
        })
        new_state[name] = {"publish_ok": cur_ok, "publish_fail": cur_fail}
    _write_json_atomic(BROKER_STATE, new_state)
    # ALSO write bridge-direct rows for any enabled per-device broker
    # the relay does NOT cover. Real case: skypi4's relay is bound to
    # FeedCafe's config + a topic filter that scopes to FeedCafe only,
    # so D_Creek's enabled brokers (e.g. on8ar) never appear in the
    # relay's status. The bridge IS publishing those directly per
    # device config; this gives the portal something to render
    # instead of a stuck "idle" pill on a broker that is in fact live.
    bridge_only = [n for n in _enabled_brokers_from_device_configs() if n not in relay_names]
    if bridge_only:
        _sample_bridge_direct_for(bridge_only)


def _sample_tdoa_export() -> None:
    """Sample the bridge's cumulative homeprod publish count into a
    "TDOA export" broker row (reset-safe delta, like the relay path), so the
    portal's 24h sparkline renders the bridge-direct TDOA export the same way
    as the relay brokers. No-op until the bridge writes status.json."""
    st = _read_json(BRIDGE_STATUS_PATH)
    if not st:
        return
    cur = int(st.get("homeprod_published_count") or 0)
    prev = int(_read_json(TDOA_EXPORT_STATE).get("count") or 0)
    # Counter reset (bridge restart) → count goes down → record delta=0.
    delta_ok = max(0, cur - prev) if cur >= prev else 0
    _append_jsonl(BROKER_LOG, {
        "ts": _ts(),
        "name": TDOA_EXPORT_NAME,
        "delta_ok": delta_ok,
        "delta_fail": 0,
        "connected": str(st.get("mqtt") or "").strip().lower() == "connected",
    })
    _write_json_atomic(TDOA_EXPORT_STATE, {"count": cur})


_DEVICE_CONFIG_GLOB = Path("/etc/meshcore-tdoa-gateway/devices")


def _enabled_brokers_from_device_configs() -> list[str]:
    """Read every per-device config.toml under /etc/.../devices and
    return the set of broker names with ``enabled = true``.

    Matches the GUI's broker list — those are the brokers the bridge
    actually publishes to. Hand-rolled TOML parse (no tomllib dep on
    older system pythons): we only need ``name = "..."`` + ``enabled =
    true|false`` pairs inside ``[[brokers]]``-style blocks. The
    bridge config format puts both on consecutive lines so we walk
    in pairs.

    Default-enabled: a broker block without an explicit ``enabled =
    ...`` line is treated as enabled. This mirrors the bridge's own
    default (an absent flag means publish). Seed brokers added by the
    portal (e.g. on8ar baked-in creds) often omit the flag.
    """
    names: list[str] = []
    if not _DEVICE_CONFIG_GLOB.exists():
        return names
    for cfg in _DEVICE_CONFIG_GLOB.glob("*/config.toml"):
        try:
            text = cfg.read_text(encoding="utf-8")
        except OSError:
            continue
        current_name: str | None = None
        current_enabled: bool | None = None
        current_section: str | None = None
        for raw in text.splitlines():
            line = raw.strip()
            if line.startswith("[[broker"):
                # New broker block boundary — flush the previous one.
                if current_name is not None and (current_enabled is None or current_enabled):
                    names.append(current_name)
                current_name = None
                current_enabled = None
                current_section = "broker"
                continue
            if line.startswith("[broker."):
                # Sub-section of the current broker (auth, tls). Don't
                # flush; keep accumulating into current_name.
                current_section = "broker.sub"
                continue
            if line.startswith("["):
                # Unrelated top-level section (e.g. [general]) closes
                # any in-flight broker.
                if current_name is not None and (current_enabled is None or current_enabled):
                    names.append(current_name)
                current_name = None
                current_enabled = None
                current_section = None
                continue
            if current_section != "broker":
                # Only read name/enabled from the broker block itself,
                # not from broker.auth (which has its own "name" key).
                continue
            if line.startswith("name"):
                m = line.split("=", 1)
                if len(m) == 2:
                    current_name = m[1].strip().strip('"').strip("'")
            elif line.startswith("enabled"):
                m = line.split("=", 1)
                if len(m) == 2:
                    current_enabled = m[1].strip().lower() == "true"
        if current_name is not None and (current_enabled is None or current_enabled):
            names.append(current_name)
    # Dedupe but preserve order so the same broker shared across two
    # devices doesn't double-count.
    seen: set[str] = set()
    out: list[str] = []
    for n in names:
        if n not in seen:
            seen.add(n)
            out.append(n)
    return out


def _sample_bridge_direct_for(names: list[str]) -> None:
    """Write bridge-direct delta_ok rows for the given broker names.

    Shared body between the relay-absent path
    (``_sample_brokers_from_bridge_journal``) and the
    relay-present-but-incomplete supplement (called from
    ``sample_brokers`` for brokers the relay doesn't cover).
    """
    if not names:
        return
    # 60s window matches the sampler timer cadence — counts each event
    # once. The 120s JOURNAL_LOOKBACK_S used for GPS state would
    # double-count here. Small ±drift either way is fine for an
    # hourly-aggregated chart.
    BRIDGE_PUB_LOOKBACK_S = 60
    # Pick whichever bridge unit is running on this host.
    lines: list[str] = []
    for unit in ("meshcore-bridge.service", "meshcore-tdoa-gateway-bridge.service"):
        new_lines = _journal_lines(unit, BRIDGE_PUB_LOOKBACK_S)
        if new_lines:
            lines = new_lines
            break
    delta_ok = sum(
        1 for ln in lines
        if "bridge.frame.published" in ln or "bridge.position.published" in ln
    )
    now = _ts()
    for name in names:
        _append_jsonl(BROKER_LOG, {
            "ts": now,
            "name": name,
            "delta_ok": delta_ok,
            "delta_fail": 0,
            "connected": delta_ok > 0,
            "source": "bridge-direct",
        })


def _sample_brokers_from_bridge_journal() -> None:
    """Bridge-direct mode: count ``bridge.frame.published`` events since
    the last sample and attribute the count to every enabled broker.

    Used when no mesh-relay is present (testopi). The bridge fan-outs
    each successful RX to every enabled broker in its config, so the
    per-broker count is the same as the total RX count — slightly
    optimistic (treats per-broker publish failures as success) but the
    bridge has no per-broker counter exposed.
    """
    _sample_bridge_direct_for(_enabled_brokers_from_device_configs())


# ---------------------------------------------------------------------------
# GPS sampler — read latest bridge.telemetry.published per port.
# ---------------------------------------------------------------------------


def _journal_lines(unit: str, lookback_s: int) -> list[str]:
    try:
        proc = subprocess.run(
            [
                "journalctl",
                "-u", unit,
                "--since", f"-{lookback_s}s",
                "-o", "cat",
                "--no-pager",
            ],
            capture_output=True, text=True, timeout=10,
        )
        return proc.stdout.splitlines()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return []


def sample_gps() -> None:
    """For each USB port the bridge reports, persist:
        - the most recent timestamp where gps_3d_fix was true
        - a counter of fix-true → fix-false transitions in the last 24h

    Two bridge units may be present (legacy meshcore-bridge OR the
    portal-managed meshcore-tdoa-gateway-bridge); we read whichever
    is active.
    """
    state = _read_json(GPS_STATE)
    if "ports" not in state:
        state["ports"] = {}
    if "transitions" not in state:
        state["transitions"] = []   # list of {"ts","port","from","to"}
    ports: dict[str, Any] = state["ports"]
    transitions: list[dict[str, Any]] = state["transitions"]
    now = _ts()

    # Walk both candidate units; later wins on overlap.
    for unit in ("meshcore-bridge.service", "meshcore-tdoa-gateway-bridge.service"):
        for line in _journal_lines(unit, JOURNAL_LOOKBACK_S):
            if "bridge.telemetry.published" not in line and "bridge.frame.published" not in line:
                continue
            try:
                idx = line.find("{")
                if idx < 0:
                    continue
                d = json.loads(line[idx:])
            except (ValueError, TypeError):
                continue
            port = d.get("port")
            if not port:
                continue
            # gps_3d_fix is in frame events; telemetry has gps_sats
            fix = d.get("gps_3d_fix")
            sats = d.get("gps_sats")
            ts = now  # approximate — exact event ts would need re-parse
            prev = ports.get(port) or {}
            prev_fix = prev.get("gps_3d_fix")
            if fix is not None:
                if fix is True:
                    prev["last_fix_at"] = ts
                # Detect transition for lost-counter
                if prev_fix is not None and prev_fix != fix:
                    transitions.append({"ts": ts, "port": port, "from": prev_fix, "to": fix})
                prev["gps_3d_fix"] = fix
            if sats is not None:
                prev["gps_sats"] = int(sats)
            ports[port] = prev

    # Prune transitions older than 24h.
    cutoff = now - 86_400
    state["transitions"] = [t for t in transitions if t.get("ts", 0) >= cutoff]
    _write_json_atomic(GPS_STATE, state)

    # Also append the per-port snapshot to the rolling log so the chart
    # can show gps_sats over time. One row per port per tick.
    for port, info in ports.items():
        _append_jsonl(GPS_LOG, {
            "ts": now,
            "port": port,
            "gps_3d_fix": info.get("gps_3d_fix"),
            "gps_sats": info.get("gps_sats"),
        })


# ---------------------------------------------------------------------------


def main() -> int:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        sample_brokers()
    except Exception as exc:  # noqa: BLE001
        print(f"[sampler] broker sample FAILED: {exc}", file=sys.stderr, flush=True)
    try:
        sample_gps()
    except Exception as exc:  # noqa: BLE001
        print(f"[sampler] gps sample FAILED: {exc}", file=sys.stderr, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
