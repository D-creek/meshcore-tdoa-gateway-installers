"""Entry point: subscribe → translate → fan-out.

Usage:
    meshcore-mesh-relay \\
        --config /etc/meshcore-tdoa-gateway/devices/<slug>/config.toml \\
        --input-host tdoa.dahllie.nl --input-port 1884 \\
        --input-user internal --input-pass-env BRIDGE_MQTT_PASSWORD \\
        --input-topic 'gateway/<port_slug>/uplink'
        [--status-file /run/meshcore-mesh-relay/status.json]
        [--dry-run]

The input broker is hard-coded to the TDOA prod MQTT (where the bridge
publishes) by default — the operator can override with --input-host /
--input-port if running an integration test against a local broker.
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import signal
import socket
import sys
import time
from pathlib import Path
from typing import Any

from dataclasses import dataclass

from . import config as cfg_mod
from . import formats
from .config import RelayConfig
from .input_mqtt import (
    _RELAY_GW_KEY,
    _RELAY_KIND_KEY,
    InputBrokerSettings,
    UplinkSubscriber,
)
from .output_brokers import BrokerPool
from .state import GatewayCache


@dataclass
class DeviceEndpoint:
    """One mctomqtt-style endpoint: one device, one identity, one BrokerPool.

    Multi-device Pis (FeedCafe + D_Creek on SkyPi4) get one endpoint per
    receiver. Each endpoint:
      - opens its own broker connections (so letsmesh JWT is auth'd as
        THAT device's pubkey, not a shared "primary")
      - resolves topic templates with its own ``{PUBLIC_KEY}``
      - emits its own /status heartbeat

    This matches Cisien/meshcoretomqtt's deployment model — one process
    per radio. The relay just packs N endpoints into one process for
    operational simplicity.
    """

    slug: str
    cfg: RelayConfig
    priv_key: str | None
    pool: BrokerPool
    # Lower-case hex pubkey, used for envelope routing.
    pub_key_lower: str = ""
    # Slug-style suffix used in MQTT client_ids to avoid collisions
    # between endpoints sharing one broker.
    scope_suffix: str = ""

    @classmethod
    def build(cls, slug: str, cfg: RelayConfig, priv_key: str | None) -> "DeviceEndpoint":
        # Scope suffix = first 12 hex of pubkey (the bridge-side node_id).
        # Falls back to slug if pub_key is unknown.
        pk = (cfg.repeater_pub_key or "").lower()
        suffix = pk[:12] if pk and pk != "unknown" else slug[:24]
        pool = BrokerPool(
            cfg.brokers,
            iata=cfg.iata,
            pub_key=cfg.repeater_pub_key,
            priv_key=priv_key,
            scope_suffix=suffix,
        )
        return cls(
            slug=slug, cfg=cfg, priv_key=priv_key, pool=pool,
            pub_key_lower=pk, scope_suffix=suffix,
        )

    def matches(self, envelope_node_id_lower: str, envelope_gateway_id: str) -> bool:
        """Does this endpoint own the given envelope?

        Match by gatewayUid first — the node_id (the 6-byte / 12-hex pubkey
        prefix) that mctomqtt always carries in ``meta.node_id_hex`` /
        ``gatewayUid``. It is unique per device and survives renames. Fall
        back to gatewayId/name match for legacy envelopes.

        2026-06-10: the full ``meta.pubkey_hex`` no longer rides reception
        packets (it moved to the authenticated heartbeat), so routing keys on
        the node_id/gatewayUid, comparing it to this endpoint's pubkey prefix.
        """
        if envelope_node_id_lower and self.pub_key_lower:
            return envelope_node_id_lower == self.pub_key_lower[:12]
        if envelope_gateway_id and self.cfg.repeater_name:
            return envelope_gateway_id == self.cfg.repeater_name
        return False


logger = logging.getLogger("meshcore_mesh_relay")


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    _configure_logging(args.debug)

    cfg = cfg_mod.load(Path(args.config))
    logger.info(
        "config.loaded path=%s iata=%s repeater=%s brokers=%d",
        args.config, cfg.iata, cfg.repeater_name, len(cfg.brokers),
    )

    # 2026-05-30: per-device endpoints (mctomqtt-faithful model).
    #
    # Each device on this Pi gets its OWN BrokerPool, configured from
    # its own ``/etc/meshcore-tdoa-gateway/devices/<slug>/config.toml``.
    # That gives every receiver:
    #   - its own letsmesh JWT (auth'd as that device's pubkey, not the
    #     primary's — fixes the rc=16 flap caused by JWT/origin_id
    #     mismatch)
    #   - its own topic-template ``{PUBLIC_KEY}`` substitution so
    #     /packets land under the right node path
    #   - its own /status heartbeat
    #   - honor for its own enable/disable broker config (D_Creek's TOML
    #     keeps letsmesh disabled and we no longer leak D_Creek packets
    #     out via FeedCafe's letsmesh connection)
    #
    # The ``--config`` arg still names a "primary" device — its config
    # is used as the routing fall-back when the input envelope doesn't
    # carry a pubkey we recognise (legacy bridges, synthetic frames).
    devices_root = Path(args.config).parent.parent
    device_cfgs = cfg_mod.load_all_devices(devices_root)
    # Pick the PRIMARY endpoint — the routing fall-back for envelopes whose pubkey
    # we don't recognise. Prefer the real device whose pubkey matches --config;
    # else alias the FIRST loaded device. Only when NO per-device configs exist at
    # all do we fall back to a synthetic "primary" from --config — so a working
    # multi-device Pi never gets a duplicate "primary" endpoint in /status (#3).
    primary_slug: str | None = None
    if cfg.repeater_pub_key and cfg.repeater_pub_key != "UNKNOWN":
        primary_slug = next(
            (
                slug for slug, c in device_cfgs.items()
                if (c.repeater_pub_key or "").upper() == cfg.repeater_pub_key.upper()
            ),
            None,
        )
    if primary_slug is None:
        primary_slug = next(iter(device_cfgs), None)
    if primary_slug is None:
        # No per-device configs — single-device Pi via --config only.
        primary_slug = "primary"
        device_cfgs[primary_slug] = cfg

    primary_priv_key = os.environ.get("BRIDGE_REPEATER_PRIV_KEY") or None
    if primary_priv_key:
        logger.info(
            "repeater.priv_key.loaded len=%d (sourced from BRIDGE_REPEATER_PRIV_KEY for primary slug=%s)",
            len(primary_priv_key), primary_slug,
        )

    def _priv_key_for(slug: str, dev_cfg: RelayConfig) -> str | None:
        """Resolve the priv_key for a device, in order of preference.

        1. ``BRIDGE_REPEATER_PRIV_KEY_<NODE_ID_12>`` — per-device env var,
           where ``<NODE_ID_12>`` is the upper-case first 12 hex of the
           pubkey (the bridge-side node_id). Operators add one of these
           per device that needs token-auth (typically letsmesh).
        2. ``BRIDGE_REPEATER_PRIV_KEY`` — the legacy single-env-var,
           applied only to the slug matching ``--config`` (the primary).
           Backwards-compat for single-device Pis.
        3. ``None`` — device has no priv_key; any token-auth broker on
           it gets skipped (BrokerClient logs a warning).
        """
        pk12 = (dev_cfg.repeater_pub_key or "")[:12].upper()
        if pk12 and pk12 != "UNKNOWN"[:12]:
            per_dev = os.environ.get(f"BRIDGE_REPEATER_PRIV_KEY_{pk12}")
            if per_dev:
                return per_dev
        if slug == primary_slug:
            return primary_priv_key
        return None

    endpoints: dict[str, DeviceEndpoint] = {}
    for slug, dev_cfg in device_cfgs.items():
        priv = _priv_key_for(slug, dev_cfg)
        ep = DeviceEndpoint.build(slug, dev_cfg, priv)
        endpoints[slug] = ep
        logger.info(
            "endpoint.built slug=%s repeater=%s pub_key_prefix=%s brokers=%d priv_key=%s",
            slug, dev_cfg.repeater_name, ep.pub_key_lower[:12] or "?",
            ep.pool.client_count, "yes" if priv else "no",
        )

    if args.dry_run:
        logger.info("dry_run.enabled — no output broker connections will be opened")
    else:
        for ep in endpoints.values():
            ep.pool.start()

    input_pw = os.environ.get(args.input_pass_env, "") if args.input_pass_env else None
    # When the operator narrows --input-topic to a specific gateway slug we
    # mirror that narrowing on /info and /telemetry too so all three topics
    # cover the same fleet subset. Wildcard ("+") topics stay untouched.
    info_filter = _sibling_topic(args.input_topic, "info")
    tele_filter = _sibling_topic(args.input_topic, "telemetry")
    # Sanitize hostname into a stable client-id suffix — strips dots
    # and clamps to 23 chars (MQTT 3.1 client-id limit) so brokers
    # that still enforce the old limit don't refuse the connection.
    host_suffix = "".join(c for c in socket.gethostname() if c.isalnum() or c in "-_")[:16]
    client_id = args.input_client_id or f"meshcore-mesh-relay-in-{host_suffix}"
    sub = UplinkSubscriber(
        InputBrokerSettings(
            host=args.input_host,
            port=args.input_port,
            username=args.input_user,
            password=input_pw,
            tls=args.input_tls,
            topic_filter=args.input_topic,
            info_topic_filter=info_filter,
            telemetry_topic_filter=tele_filter,
            client_id=client_id,
            transport=args.input_transport,
        )
    )
    sub.start()

    gw_cache = GatewayCache()
    # gateway_id (topic-slug) -> DeviceEndpoint, populated lazily as
    # uplinks arrive so subsequent /info, /telemetry, and /status emits
    # for that gateway hit the right endpoint.
    gw_to_endpoint: dict[str, DeviceEndpoint] = {}
    # Reference to a designated primary endpoint, used when an envelope
    # doesn't match any endpoint by pubkey or gatewayId.
    primary_endpoint = endpoints.get(primary_slug) or next(iter(endpoints.values()))

    def _route_envelope(envelope: dict[str, Any], gateway_id: str) -> DeviceEndpoint:
        """Pick the right endpoint for an inbound envelope.

        Match priority:
          1. Cached: we've already routed this gateway_id (topic-slug).
          2. By gatewayUid (envelope.meta.node_id_hex / envelope.gatewayUid)
             against each endpoint's pubkey prefix.
          3. By envelope.gatewayId / displayName against endpoint.cfg.repeater_name.
          4. Fall back to the primary endpoint (preserves old behaviour
             when no endpoint can claim the envelope).

        2026-06-10: keyed on the node_id/gatewayUid (mctomqtt always carries
        it) instead of meta.pubkey_hex, which no longer rides packets.
        """
        cached = gw_to_endpoint.get(gateway_id)
        if cached is not None:
            return cached
        meta = envelope.get("meta") or {}
        env_node_id = str(
            meta.get("node_id_hex") or envelope.get("gatewayUid") or ""
        ).strip().lower()
        env_gw_id = str(envelope.get("gatewayId") or envelope.get("displayName") or "").strip()
        for ep in endpoints.values():
            if ep.matches(env_node_id, env_gw_id):
                gw_to_endpoint[gateway_id] = ep
                logger.info(
                    "uplink.routed gateway_id=%s -> endpoint slug=%s name=%s",
                    gateway_id, ep.slug, ep.cfg.repeater_name,
                )
                return ep
        # Fall back — note it once so the operator can see unmatched
        # devices in the log.
        if gateway_id and gateway_id not in gw_to_endpoint:
            logger.warning(
                "uplink.unmatched gateway_id=%s env_node_id=%s env_gw=%s "
                "-> falling back to primary endpoint (%s)",
                gateway_id, env_node_id or "?", env_gw_id or "?",
                primary_endpoint.cfg.repeater_name,
            )
            gw_to_endpoint[gateway_id] = primary_endpoint
        return primary_endpoint

    # Signal handling — flip a shutdown flag, let the main loop drain.
    _shutdown_evt = {"stop": False}
    def _on_signal(signum: int, _frame: Any) -> None:
        logger.info("signal.received signum=%s shutting_down", signum)
        _shutdown_evt["stop"] = True
    signal.signal(signal.SIGINT, _on_signal)
    signal.signal(signal.SIGTERM, _on_signal)

    status_path = Path(args.status_file) if args.status_file else None
    if status_path is not None:
        status_path.parent.mkdir(parents=True, exist_ok=True)

    last_status_write = 0.0
    last_status_backstop_check = 0.0
    forwarded = 0
    dropped = 0
    try:
        while not _shutdown_evt["stop"]:
            now_mono = time.monotonic()
            if now_mono - last_status_backstop_check >= 1.0:
                _emit_due_statuses(
                    endpoints=endpoints,
                    gw_to_endpoint=gw_to_endpoint,
                    gw_cache=gw_cache,
                    dry_run=args.dry_run,
                )
                last_status_backstop_check = now_mono

            envelope = sub.next_envelope(timeout=1.0)
            if envelope is None:
                if status_path is not None and time.time() - last_status_write > 5:
                    _write_status(status_path, endpoints, forwarded=forwarded, dropped=dropped)
                    last_status_write = time.time()
                continue

            kind = envelope.pop(_RELAY_KIND_KEY, "uplink")
            gateway_id = envelope.pop(_RELAY_GW_KEY, "") or envelope.get("gatewayId") or ""

            if kind == "info":
                hardware = envelope.get("hardware") or {}
                display = envelope.get("gatewayId") or envelope.get("displayName")
                gw_cache.update_hardware(gateway_id, hardware, display_name=display)
                # Pre-route on /info so the first /status heartbeat has
                # an endpoint to use even if no uplink has arrived yet.
                _route_envelope(envelope, gateway_id)
                continue

            if kind == "telemetry":
                telemetry = envelope.get("telemetry") or {}
                gw_cache.update_telemetry(gateway_id, telemetry)
                continue

            # ----- uplink path -----
            ep = _route_envelope(envelope, gateway_id)
            rx = (envelope.get("rxInfo") or [{}])[0]
            gw_cache.note_packet(
                gateway_id,
                rssi=rx.get("rssi"),
                snr=rx.get("snr"),
                display_name=ep.cfg.repeater_name,
                pubkey_hex=ep.cfg.repeater_pub_key,
            )

            mesh_payload = formats.envelope_to_mesh_subset(
                envelope,
                repeater_name=ep.cfg.repeater_name,
                repeater_pub_key=ep.cfg.repeater_pub_key,
            )
            mesh_bytes = formats.serialise(mesh_payload)

            on8ar_payload = formats.envelope_to_on8ar_packet(
                envelope,
                repeater_name=ep.cfg.repeater_name,
                repeater_pub_key=ep.cfg.repeater_pub_key,
            )
            on8ar_bytes = formats.serialise(on8ar_payload)

            tdoa_bytes = formats.serialise(envelope)

            if args.dry_run:
                logger.info(
                    "dry_run.would_publish endpoint=%s mesh=%s on8ar=%s",
                    ep.cfg.repeater_name,
                    mesh_bytes[:200].decode("utf-8", errors="replace"),
                    on8ar_bytes[:200].decode("utf-8", errors="replace"),
                )
                forwarded += 1
                continue

            # mctomqtt-faithful fan-out: route through THIS device's pool
            # only. letsmesh JWT was minted with THIS device's pubkey;
            # the topic template substitutes THIS device's pubkey; the
            # /packets path lands under the right node identity.
            results = ep.pool.publish_per_broker(
                {
                    "emqx-public": on8ar_bytes,
                    "meshrank": on8ar_bytes,
                    "letsmesh": on8ar_bytes,
                },
                default_payload=mesh_bytes,
                tdoa_payload=tdoa_bytes,
            )
            forwarded += 1
            failed = [n for n, ok in results.items() if not ok]
            if failed:
                logger.debug(
                    "forward.partial endpoint=%s brokers_failed=%s",
                    ep.cfg.repeater_name, failed,
                )

            if status_path is not None and time.time() - last_status_write > 5:
                _write_status(status_path, endpoints, forwarded=forwarded, dropped=dropped)
                last_status_write = time.time()
    finally:
        logger.info("shutdown.cleanup forwarded=%d dropped=%d", forwarded, dropped)
        sub.stop()
        if not args.dry_run:
            for ep in endpoints.values():
                ep.pool.stop()
        if status_path is not None:
            _write_status(status_path, endpoints, forwarded=forwarded, dropped=dropped, shutdown=True)

    return 0


def _sibling_topic(uplink_topic: str, suffix: str) -> str | None:
    """Derive ``gateway/<slug>/<suffix>`` from a `gateway/<slug>/uplink` filter.

    Used to keep /info and /telemetry subscriptions scoped to the same
    gateway subset as the operator-supplied --input-topic. Returns None
    when the topic doesn't end in ``/uplink`` (operator has set something
    custom — don't override their intent).
    """
    if not uplink_topic.endswith("/uplink"):
        return None
    return uplink_topic[: -len("uplink")] + suffix


# /status heartbeat cadence per gateway. mctomqtt defaults to 60s, but
# we publish one envelope per tracked gateway and the SkyPi4 hosts ~3
# of them — at 60s that's a status burst every minute on the broker.
# 300s (5 min) keeps the cadence operator-readable without losing the
# online/offline signal (offline_after_secs is still 10 min).
_STATUS_HEARTBEAT_SECS = 300.0
# Treat a gateway as offline (skip status emit) when we've heard nothing
# from any of its topics for this long.
_STATUS_OFFLINE_AFTER_SECS = 10 * 60.0


def _emit_due_statuses(
    *,
    endpoints: dict[str, "DeviceEndpoint"],
    gw_to_endpoint: dict[str, "DeviceEndpoint"],
    gw_cache: GatewayCache,
    dry_run: bool,
) -> None:
    """Publish one /status per due gateway via THAT gateway's own pool.

    Called every ~1 s from the main loop. The cache is the throttle —
    once a gateway is published its ``last_status_pub_at`` is fresher
    than the heartbeat so this is a cheap no-op until the next window.

    Per-endpoint routing: each due gateway publishes through its own
    endpoint's pool (not a shared primary). That gives mctomqtt-style
    per-node /status with the right JWT identity on letsmesh and the
    right ``{PUBLIC_KEY}`` topic resolution everywhere else.
    """
    due = gw_cache.gateways_due_for_status(
        heartbeat_secs=_STATUS_HEARTBEAT_SECS,
        offline_after_secs=_STATUS_OFFLINE_AFTER_SECS,
    )
    if not due:
        return
    seen_endpoints: set[str] = set()
    for gid in due:
        snap = gw_cache.snapshot(gid)
        if snap is None:
            continue
        ep = gw_to_endpoint.get(gid)
        if ep is None:
            # No uplink/info routed this gateway yet — skip status for
            # now. Will route on the next /info or /uplink arrival.
            continue
        if ep.slug in seen_endpoints:
            # An endpoint already heartbeat'd this cycle; no need to
            # double-publish the same identity even if two gateway_ids
            # map to it (shouldn't happen with pubkey routing, but
            # defensive).
            continue
        seen_endpoints.add(ep.slug)
        status_payload = formats.gateway_state_to_on8ar_status(
            snap,
            repeater_name=ep.cfg.repeater_name,
            repeater_pub_key=ep.cfg.repeater_pub_key,
        )
        status_bytes = formats.serialise(status_payload)
        if dry_run:
            logger.info(
                "dry_run.status.would_publish gw=%s endpoint=%s origin=%s payload=%s",
                gid, ep.slug, ep.cfg.repeater_name,
                status_bytes[:200].decode("utf-8", errors="replace"),
            )
        else:
            # Publish only via this endpoint's pool so the JWT identity
            # and topic templating match the per-packet origin.
            ep.pool.publish_status_to_kind("emqx-public", status_bytes)
            ep.pool.publish_status_to_kind("meshrank", status_bytes)
            ep.pool.publish_status_to_kind("letsmesh", status_bytes)
    # Mark every due gateway as published — including dedup'd ones, so
    # they don't re-trigger on the next 1 s tick.
    for gid in due:
        gw_cache.mark_status_published(gid)


def _write_status(path: Path, endpoints: dict[str, "DeviceEndpoint"],
                  *, forwarded: int, dropped: int, shutdown: bool = False) -> None:
    """Dump a JSON status file the portal can read.

    Schema 2 (2026-05-30): adds an ``endpoints`` array so the portal
    can render per-device broker state on multi-device Pis. The legacy
    flat ``brokers`` array is kept for back-compat — its contents are
    the union of every endpoint's broker snapshots, with each entry's
    ``name`` field prefixed by ``<endpoint_slug>/`` when there is more
    than one endpoint (so two ``home-prod-wss`` entries from different
    endpoints don't collide in the portal's UI).
    """
    endpoint_snaps: list[dict[str, Any]] = []
    flat_brokers: list[dict[str, Any]] = []
    # Snapshot each endpoint's brokers once; only REPORT endpoints that actually
    # have output brokers. A device whose brokers are all disabled / homeprod-
    # skipped, or a quarantined non-LoRa device, has nothing to fan out — listing
    # it just clutters the portal with broker-less / UNKNOWN-pubkey rows (#3). The
    # endpoints still exist internally for routing; we just don't surface the
    # empty ones.
    snaps = [(slug, ep, ep.pool.snapshot()) for slug, ep in endpoints.items()]
    reported = [(slug, ep, bs) for slug, ep, bs in snaps if bs]
    multi = len(reported) > 1
    for slug, ep, broker_snap in reported:
        endpoint_snaps.append({
            "slug": slug,
            "repeater_name": ep.cfg.repeater_name,
            "pub_key": ep.cfg.repeater_pub_key,
            "iata": ep.cfg.iata,
            "brokers": broker_snap,
        })
        for entry in broker_snap:
            if multi:
                entry = dict(entry)
                # Prefix by the unique endpoint SLUG (not repeater_name, which can
                # duplicate across endpoints) so flat broker names stay unique and
                # traceable to a physical device (#3).
                entry["name"] = f"{slug}/{entry['name']}"
            flat_brokers.append(entry)
    snapshot = {
        "schema": 2,
        "timestamp": time.time(),
        "forwarded": forwarded,
        "dropped": dropped,
        "shutdown": shutdown,
        "endpoints": endpoint_snaps,
        "brokers": flat_brokers,
    }
    try:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(snapshot, indent=2))
        tmp.replace(path)
    except OSError as exc:
        logger.warning("status.write_failed path=%s error=%s", path, exc)


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="meshcore-mesh-relay")
    p.add_argument(
        "--config",
        required=True,
        help="path to the mctomqtt-format device config.toml "
             "(usually /etc/meshcore-tdoa-gateway/devices/<slug>/config.toml)",
    )
    p.add_argument("--input-host", default="tdoa.dahllie.nl",
                   help="upstream MQTT host (TDOA bridge publishes here)")
    p.add_argument("--input-port", type=int, default=1884)
    p.add_argument("--input-user", default="internal")
    p.add_argument("--input-pass-env", default="BRIDGE_MQTT_PASSWORD",
                   help="env var name carrying the input-broker password")
    p.add_argument("--input-tls", action="store_true",
                   help="enable TLS on the input broker connection")
    p.add_argument("--input-transport", default="tcp",
                   choices=("tcp", "websockets"),
                   help="paho transport — websockets needed for "
                        "mqtt.dahllie.nl:443 (CF-fronted WSS+TLS)")
    p.add_argument(
        "--input-topic",
        default="gateway/+/uplink",
        help="MQTT topic filter — defaults to all gateways; narrow to a "
             "specific port_slug to limit forwarding to this Pi's node",
    )
    p.add_argument("--status-file", default="/run/meshcore-mesh-relay/status.json")
    p.add_argument("--dry-run", action="store_true",
                   help="log what would be published, don't connect output brokers")
    p.add_argument("--debug", action="store_true")
    # Default derives from hostname so two Pi's (skypi4 + testopi) running the
    # same relay don't share an MQTT client-id and kick each other off the
    # input broker at ~1 Hz. Operator may override for predictable session
    # naming if running multiple relays on one host.
    p.add_argument(
        "--input-client-id",
        default=None,
        help="MQTT client-id for the input subscriber (default: "
             "'meshcore-mesh-relay-in-<hostname>')",
    )
    return p.parse_args(argv)


def _configure_logging(debug: bool) -> None:
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        stream=sys.stderr,
    )


if __name__ == "__main__":
    sys.exit(main())
