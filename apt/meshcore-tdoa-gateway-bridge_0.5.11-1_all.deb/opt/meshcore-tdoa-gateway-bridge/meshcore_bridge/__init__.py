"""MeshCore Pi bridge: USB serial → MQTT relay.

Public re-exports for tests and downstream callers.
"""

from .config import BridgeConfig, MQTTConfig, SerialConfig, load_config
from .frame import (
    DEVICE_TELEMETRY_LEN,
    DEVICE_TELEMETRY_TYPE_BYTE,
    FLAG_GPS_3D_FIX,
    FLAG_PPS_LOCKED,
    TDOA_RECEPTION_LEN,
    TDOA_TYPE_BYTE,
    DeviceTelemetryFrame,
    FrameExtractor,
    TDOAFrame,
    parse_device_telemetry_frame,
    parse_tdoa_frame,
)
from .mqtt_publisher import (
    MQTTPublisher,
    build_telemetry_envelope,
    build_uplink_envelope,
    sanitize_port,
)

__all__ = [
    "BridgeConfig",
    "MQTTConfig",
    "SerialConfig",
    "load_config",
    "FrameExtractor",
    "TDOAFrame",
    "DeviceTelemetryFrame",
    "parse_tdoa_frame",
    "parse_device_telemetry_frame",
    "FLAG_PPS_LOCKED",
    "FLAG_GPS_3D_FIX",
    "TDOA_RECEPTION_LEN",
    "TDOA_TYPE_BYTE",
    "DEVICE_TELEMETRY_LEN",
    "DEVICE_TELEMETRY_TYPE_BYTE",
    "MQTTPublisher",
    "build_uplink_envelope",
    "build_telemetry_envelope",
    "sanitize_port",
]
