"""Per-port UART arbiter — one master, no interleaves.

Background
==========

The bridge speaks to one USB-attached LoRa transceiver per port. Multiple
code paths inside the process need to write to that UART concurrently:

* :class:`SerialReader` runs continuously, parsing the binary companion
  protocol off ``/dev/ttyACM*`` and emitting frames to MQTT.
* :class:`TCPPassthrough` forwards bytes from any connected chat / CLI
  client to the same UART, and tees inbound bytes to all clients.
* The fwota dispatcher issues a one-shot DFU-trigger frame before an
  external flasher takes over the port.
* The portal's ``probe-role`` endpoint briefly opens the passthrough
  socket to issue ``get role`` / ``get repeat`` CLI commands.
* The chat publisher (in some bridge revs) writes user messages.

The May 2026 race-fix (``tcp_passthrough._serial_lock``) wrapped each
``ser.write(data)`` call so two TCP clients couldn't interleave bytes
*inside a single ``recv()`` chunk*. That stopped the most-obvious
collision, but it does NOT stop:

* multi-step CLI transactions (write ``get role\\r`` → read response →
  write ``get repeat\\r``; another writer can sneak between the read
  and the next write),
* two TCP clients each sending a complete command back-to-back where
  the firmware's CLI parser sees them blend at a buffer-flush boundary,
* the SerialReader thread reading USB bytes while a CLI session is
  expected to be exclusive (the reader's buffer can swallow the CLI
  reply we wanted to parse).

Three production incidents (2026-05-29, 2026-05-31 × 2) trace back to
this gap. The most-recent one corrupted the firmware NVS ``node_name``
to ``"NL-MST-RP03-D_Creek h+s"`` and required out-of-band serial
recovery. See:

* ``feedback_no_auto_passthrough_writes.md``
* ``feedback_firmware_node_name_authoritative.md``
* ``project_tcp_passthrough_serial_write_race_2026_05_29.md``

Design
======

One :class:`UartArbiter` per port. The arbiter owns the
:class:`serial.Serial` handle (or its proxy when reads come from a
dedicated reader thread). Every consumer that needs to write must
acquire a **session** for the lifetime of the entire transaction. Only
one session can be active at a time per port; additional requesters
wait FIFO or raise :class:`UartBusy` after their timeout elapses.

Four session modes::

  mode='binary'   normal companion-protocol reads; the SerialReader
                  thread holds this and can be **preempted** by a
                  higher-priority mode entering (CLI / DFU / exclusive)
  mode='cli'      operator-driven text CLI; reader is suspended for
                  the session window. Buffered binary frames are
                  flushed at session end (best-effort).
  mode='dfu'      one-shot DFU-trigger; reader suspended; external
                  flasher takes over the device after the session
                  releases (the OS device may even disappear).
  mode='exclusive' read+write owned by the session; useful for
                  probing without involving the binary path at all.

The arbiter does NOT enforce a particular write API — sessions expose
the underlying :class:`serial.Serial` so existing pyserial-based code
ports cleanly. It DOES guarantee that only one session can hold the
device at a time, and provides helpers for the common "write a CLI
line, read until prompt or timeout" pattern.

Preemption
==========

The binary mode is special: the SerialReader runs forever in its own
thread holding a binary session. When a CLI (or DFU) session is
requested, the arbiter signals the binary holder to release
("preempt"). The binary holder cooperates by checking
:meth:`UartSession.should_yield` between read chunks and exiting its
``with`` block when set. After the higher-priority session releases,
the SerialReader re-acquires binary mode and resumes.

Cross-process exclusion
=======================

To stop external processes (``cu``, ``screen``, ``picocom``, another
``meshcore-bridge`` instance) from competing on the same device, the
arbiter sets ``TIOCEXCL`` on the opened fd and takes an exclusive
``flock(2)`` on it. Both are advisory but enforced by the kernel for
well-behaved daemons and by most TTY-using tools. See
``Documentation/tty/`` in the Linux source for ``TIOCEXCL`` semantics.

Thread safety
=============

The arbiter is designed for threaded daemons (pyserial is blocking).
The internal lock is a :class:`threading.Condition`; ``session()`` and
``release_requested`` are safe to call from any thread.

Public API
==========

The two interesting names are :class:`UartArbiter` and
:func:`UartArbiter.session`. Everything else is implementation detail
exposed for tests.
"""

from __future__ import annotations

import contextlib
import threading
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from typing import Literal

import serial
import structlog

# ``fcntl`` is POSIX-only. The arbiter runs on Linux in production
# (Raspberry Pi) but we want the module + tests to import cleanly on
# Windows / macOS dev machines too. ``enable_kernel_locks=False`` (the
# test default) skips every fcntl call, so the missing module is only
# a problem if production were to disable the guard, which it never
# does. The wrapper below lets call sites use ``fcntl.ioctl(...)``
# unconditionally; on a system without fcntl the calls quietly skip.
try:
    import fcntl as _fcntl  # type: ignore[import-not-found]
    fcntl: object | None = _fcntl
except ImportError:  # pragma: no cover - executed on non-POSIX dev hosts
    fcntl = None

log = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

Mode = Literal["binary", "cli", "dfu", "exclusive"]
"""The four session modes the arbiter recognises.

Priority order, highest first: ``dfu`` > ``exclusive`` > ``cli`` >
``binary``. A higher-priority request preempts a lower-priority holder
by setting its ``release_requested`` flag and waiting for the holder to
exit its ``with`` block. Same-priority requests queue FIFO.
"""

_MODE_PRIORITY: dict[Mode, int] = {
    "binary": 0,
    "cli": 10,
    "exclusive": 20,
    "dfu": 30,
}


class UartBusy(RuntimeError):
    """Raised when ``session()`` couldn't acquire within its timeout.

    The exception message names the current holder's ``reason`` and
    ``mode`` so the caller can log something actionable.
    """


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------


@dataclass
class _Holder:
    """In-memory record of who currently holds the arbiter."""
    mode: Mode
    reason: str
    since: float
    thread_ident: int
    release_requested: bool = False
    # Set when the holder has finished its critical section and dropped
    # the device — used by waiters to know when to attempt re-acquire.
    released: threading.Event = field(default_factory=threading.Event)


class UartSession:
    """Handle returned by :func:`UartArbiter.session`.

    Exposes the underlying :class:`serial.Serial` plus a few helpers
    for the common transaction patterns. Methods are safe to call only
    from inside the ``with`` block and only from the thread that
    acquired the session — the arbiter does not police this in
    production code but tests assert it.
    """

    def __init__(
        self,
        arbiter: UartArbiter,
        holder: _Holder,
        serial_handle: serial.Serial | None,
    ) -> None:
        self._arbiter = arbiter
        self._holder = holder
        self._serial = serial_handle

    # -- accessors ---------------------------------------------------------

    @property
    def mode(self) -> Mode:
        return self._holder.mode

    @property
    def reason(self) -> str:
        return self._holder.reason

    @property
    def serial(self) -> serial.Serial:
        """The underlying pyserial handle.

        Raises :class:`RuntimeError` if no handle is attached — that
        happens for ``mode='dfu'`` sessions when the caller asked the
        arbiter to close the device before the flasher takes over.
        """
        if self._serial is None:
            raise RuntimeError(
                "UartSession.serial accessed but no handle attached "
                f"(mode={self._holder.mode}, reason={self._holder.reason})"
            )
        return self._serial

    def should_yield(self) -> bool:
        """True when a higher-priority requester is waiting.

        The binary-mode session holder MUST poll this between read
        chunks. Other modes can ignore it (they hold for a bounded
        duration and don't need to be preempted).
        """
        return self._holder.release_requested

    # -- write/read helpers ------------------------------------------------

    def write_bytes(self, data: bytes) -> int:
        """Atomically write the given bytes. Returns count written.

        Wraps ``ser.write(data)`` — kept as a helper so future Phase-B
        broker work can intercept here without touching call sites.
        """
        return self.serial.write(data)

    def write_line(self, line: str, *, eol: bytes = b"\r") -> int:
        """Write a text line followed by ``eol`` (default CR).

        Useful for CLI mode where commands are terminated by ``\\r``.
        """
        encoded = line.encode("ascii") + eol
        return self.write_bytes(encoded)

    def read_until(
        self,
        terminator: bytes,
        *,
        timeout: float,
        max_bytes: int = 4096,
    ) -> bytes:
        """Read bytes until ``terminator`` is seen or ``timeout`` elapses.

        Returns the accumulated bytes (including the terminator if
        seen). Returns whatever was read so far if the timeout fires —
        callers should check whether the terminator is present in the
        result. Does NOT raise on timeout (CLI parsers commonly want
        the partial response to log diagnostically).
        """
        deadline = time.monotonic() + timeout
        buf = bytearray()
        ser = self.serial
        previous_timeout = ser.timeout
        try:
            ser.timeout = 0.05  # short read so we can poll the deadline
            while time.monotonic() < deadline and len(buf) < max_bytes:
                chunk = ser.read(max_bytes - len(buf))
                if chunk:
                    buf.extend(chunk)
                    if terminator in buf:
                        break
        finally:
            ser.timeout = previous_timeout
        return bytes(buf)


# ---------------------------------------------------------------------------
# Arbiter
# ---------------------------------------------------------------------------


SerialFactory = Callable[..., serial.Serial]


class UartArbiter:
    """One-master arbiter for a single ``/dev/tty*`` port.

    Lifecycle:

    1. Construct with the port path + a ``serial_factory`` (defaults to
       :class:`serial.Serial`). The arbiter does NOT open the device on
       construction; the first ``session()`` call does.
    2. Consumers acquire sessions via the ``session(mode=..., reason=...)``
       context manager. Only one session is active at a time. Higher-
       priority modes preempt the binary holder; same-or-lower-priority
       requests wait FIFO.
    3. The arbiter owns the open ``serial.Serial`` instance across
       sessions of compatible modes (e.g., a CLI session inherits the
       binary holder's open handle), and closes it across DFU
       boundaries where the device file may disappear.

    The arbiter is NOT bound to a single thread; methods are safe from
    any thread. Each session must be entered and exited by the same
    thread, however (a hard pyserial requirement).
    """

    def __init__(
        self,
        port_path: str,
        *,
        baud: int = 115200,
        read_timeout_seconds: float = 0.5,
        serial_factory: SerialFactory | None = None,
        enable_kernel_locks: bool = True,
    ) -> None:
        self._port_path = port_path
        self._baud = baud
        self._read_timeout = read_timeout_seconds
        self._factory: SerialFactory = serial_factory or serial.Serial
        self._enable_kernel_locks = enable_kernel_locks
        # Condition guarding _holder, _waiters, _serial.
        self._cond = threading.Condition()
        self._holder: _Holder | None = None
        # FIFO of (priority, mode, reason, ack_event) — waiters add
        # themselves to the back; the head wakes when _holder clears or
        # when the head's priority outranks the holder.
        self._waiters: list[_Waiter] = []
        # The open serial handle. None until first session.
        self._serial: serial.Serial | None = None
        self._plog = log.bind(component="uart_arbiter", port=port_path)

    # -- introspection (for tests + logging) -------------------------------

    @property
    def port_path(self) -> str:
        return self._port_path

    def current_holder(self) -> _Holder | None:
        """Return a snapshot of the current holder, or None if free."""
        with self._cond:
            return self._holder

    # -- session acquire ---------------------------------------------------

    @contextlib.contextmanager
    def session(
        self,
        *,
        mode: Mode,
        reason: str,
        timeout: float = 15.0,
    ) -> Iterator[UartSession]:
        """Acquire exclusive UART access for the lifetime of the block.

        :param mode: which session mode to acquire — see module docstring.
        :param reason: short human-readable string for diagnostics
            (logged + reported to other waiters that timeout).
        :param timeout: how long to wait for the lock to become
            available. Raises :class:`UartBusy` on timeout.

        The returned :class:`UartSession` exposes the live
        :class:`serial.Serial` handle (or None for DFU sessions where
        the caller asked for the device to be closed). Exiting the
        ``with`` block releases the session and wakes the next waiter.
        """
        holder = self._acquire(mode=mode, reason=reason, timeout=timeout)
        try:
            handle = self._open_or_reuse_handle()
            session_obj = UartSession(self, holder, handle)
            try:
                yield session_obj
            finally:
                # If this session is DFU and the device file may have
                # gone away (flasher took over), drop our handle so the
                # next binary-mode acquire reopens fresh.
                if mode == "dfu":
                    self._close_handle_safely()
        finally:
            self._release(holder)

    # -- private acquire/release plumbing ---------------------------------

    def _acquire(self, *, mode: Mode, reason: str, timeout: float) -> _Holder:
        deadline = time.monotonic() + timeout
        priority = _MODE_PRIORITY[mode]
        new_holder = _Holder(
            mode=mode,
            reason=reason,
            since=time.monotonic(),
            thread_ident=threading.get_ident(),
        )
        waiter = _Waiter(priority=priority, holder=new_holder)
        with self._cond:
            self._waiters.append(waiter)
            self._maybe_request_preemption_locked(priority)
            while True:
                # Are we the next slot-able waiter? Slot-able means
                # (a) no current holder, OR (b) we strictly outrank
                # the current holder AND they've acknowledged the
                # preempt by leaving their critical section. We sort
                # waiters by (priority desc, arrival asc) implicitly via
                # the priority check below; equal-priority waiters are
                # served FIFO because we walk the list in arrival order.
                head = self._highest_priority_waiter_locked()
                if head is waiter and self._holder is None:
                    self._waiters.remove(waiter)
                    self._holder = new_holder
                    self._plog.info(
                        "uart.acquire", mode=mode, reason=reason,
                    )
                    return new_holder
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    # Timed out — back out of the queue and raise.
                    try:
                        self._waiters.remove(waiter)
                    except ValueError:
                        pass
                    holder_repr = (
                        f"mode={self._holder.mode!r} reason={self._holder.reason!r}"
                        if self._holder is not None
                        else "no holder"
                    )
                    raise UartBusy(
                        f"could not acquire {mode!r} session for {reason!r} "
                        f"within {timeout:.1f}s (current: {holder_repr})"
                    )
                self._cond.wait(timeout=remaining)

    def _highest_priority_waiter_locked(self) -> _Waiter | None:
        """Return the waiter that should run next, or None if queue empty.

        Higher priority wins; equal priority is FIFO. Must be called
        with ``self._cond`` held.
        """
        if not self._waiters:
            return None
        best = self._waiters[0]
        for w in self._waiters[1:]:
            if w.priority > best.priority:
                best = w
        return best

    def _maybe_request_preemption_locked(self, new_priority: int) -> None:
        """If the current holder is lower-priority, request release.

        Sets the holder's ``release_requested`` flag so cooperative
        holders (the binary-mode SerialReader) yield. Higher-priority
        sessions effectively cut the queue.
        """
        if self._holder is None:
            return
        holder_priority = _MODE_PRIORITY[self._holder.mode]
        if new_priority > holder_priority:
            self._holder.release_requested = True
            self._plog.info(
                "uart.preempt.request",
                holder_mode=self._holder.mode,
                holder_reason=self._holder.reason,
                new_priority=new_priority,
            )

    def _release(self, holder: _Holder) -> None:
        with self._cond:
            if self._holder is holder:
                self._holder = None
                holder.released.set()
                self._plog.info(
                    "uart.release",
                    mode=holder.mode,
                    reason=holder.reason,
                    held_seconds=time.monotonic() - holder.since,
                )
            self._cond.notify_all()

    # -- serial handle plumbing -------------------------------------------

    def _open_or_reuse_handle(self) -> serial.Serial | None:
        """Open the device if needed, or return the existing handle.

        The session context manager closes the handle on DFU exit, so
        when a DFU session enters it sees a fresh open here. Other
        modes reuse the cached handle for efficiency.
        """
        with self._cond:
            if self._serial is None:
                self._serial = self._open_locked()
            return self._serial

    def _open_locked(self) -> serial.Serial:
        ser = self._factory(
            self._port_path,
            self._baud,
            timeout=self._read_timeout,
        )
        if self._enable_kernel_locks:
            self._apply_kernel_locks(ser)
        return ser

    def _apply_kernel_locks(self, ser: serial.Serial) -> None:
        """Set TIOCEXCL + take flock(LOCK_EX|LOCK_NB) on the fd.

        Both are best-effort and only meaningful on Linux. The arbiter
        logs but does NOT raise if either fails — a non-Linux test
        environment, a tty driver that ignores TIOCEXCL (e.g., some
        USB-CDC drivers on older kernels), or a competing process
        already holding flock — none of these should crash the bridge.
        Other writers in the same process are still serialised by the
        arbiter's own lock; the kernel locks just stop external tools.
        """
        if fcntl is None:  # POSIX-only; non-Linux dev hosts skip silently
            self._plog.debug("uart.kernel_lock.fcntl_unavailable")
            return
        try:
            fd = ser.fileno()
        except Exception as exc:  # noqa: BLE001 - best-effort
            self._plog.debug(
                "uart.kernel_lock.no_fileno", error=str(exc),
            )
            return
        # TIOCEXCL (0x540C) — set exclusive mode on the tty.
        try:
            fcntl.ioctl(fd, 0x540C, 0)
        except OSError as exc:
            self._plog.debug("uart.kernel_lock.tiocexcl_failed", error=str(exc))
        # flock — refuse if another process holds it. LOCK_NB so we
        # don't block; we just log and continue (the in-process lock
        # is still doing its job).
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self._plog.warning(
                "uart.kernel_lock.flock_busy",
                error=str(exc),
                hint="another process may have the device open",
            )

    def _close_handle_safely(self) -> None:
        with self._cond:
            ser = self._serial
            self._serial = None
        if ser is not None:
            try:
                ser.close()
            except Exception as exc:  # noqa: BLE001
                self._plog.debug("uart.close.error", error=str(exc))

    # -- explicit close (for shutdown) ------------------------------------

    def shutdown(self) -> None:
        """Close the device and refuse further sessions.

        Called at bridge shutdown. Existing holders are not interrupted
        (they'll return on their own); new acquires raise
        :class:`UartBusy`. The handle is closed so the kernel locks
        release.
        """
        self._close_handle_safely()


@dataclass
class _Waiter:
    priority: int
    holder: _Holder
