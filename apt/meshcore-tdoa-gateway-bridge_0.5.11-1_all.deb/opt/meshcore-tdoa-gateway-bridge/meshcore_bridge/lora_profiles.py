"""LoRa RF profile constants for the MeshCore Pi bridge (KAN-134).

The 0x90 TDOA_RECEPTION frame the firmware emits over USB does not
currently carry the RF parameters (frequency / bandwidth / spreading
factor / code rate) the receiver was tuned to when it heard the LoRa
packet — those values are baked into the firmware build at
``platformio.ini`` time via ``LORA_FREQ`` / ``LORA_BW`` / ``LORA_SF``
macros.

KAN-133 already plumbed those four columns through the collector's
``write_reception`` and the chirpstack-v4 ingest path (where the bridge
HAL surfaces them on every uplink). For the legacy MeshCore-bridge MQTT
path to also populate the columns, we make the bridge itself attach the
RF params to every published envelope. Two pragmatic options were
considered:

* **(a)** Extend the firmware-side 0x90 envelope with four new fields.
  This requires a firmware build + reflash on every receiver — out of
  scope for KAN-134 (the ticket explicitly excludes firmware changes).
* **(b)** Hardcode the four values at the bridge level via env vars
  (``BRIDGE_LORA_FREQ_HZ`` / ``BW_HZ`` / ``SF`` / ``CR``) read once at
  startup, with sensible defaults matching the firmware's compile-time
  defaults. Each receiver running off the same firmware build sees the
  same RF profile, so a single bridge-side override is sufficient.

We pick (b). Defaults below mirror the MeshCore EU868 default profile
(see ``firmware/MeshCore/variants/*/platformio.ini``):

* frequency:        869.618 MHz
* bandwidth:        125 kHz
* spreading factor: SF8
* code rate:        4/5

2026-05-11: these defaults are now a LAST-RESORT FALLBACK. tdoa-1.6.5+
emits the real per-receiver radio config in the 0x94 GATEWAY_INFO
frame's radio tail. The bridge caches that per-port and uses the
learned values on every published uplink envelope, so these defaults
only apply to a receiver whose 0x94 heartbeat hasn't been seen yet
(very first packets after a fresh boot) — and even then only for the
specific port involved.

Operators tuning a receiver to a non-default profile (e.g. Meshtastic
LongFast EU868: 869.525 MHz / BW 250 kHz / SF 11 / CR 4/5) can override
any of the four via env var without a code change. The bridge re-reads
env on startup only — changing the profile requires a service restart,
which is fine for the deploy cadence (we don't retune mid-run).
"""

from __future__ import annotations

# MeshCore EU868 default profile. Keep these in sync with the firmware
# build's platformio.ini macros — if the firmware default changes, this
# file is the single source of truth on the bridge side.
DEFAULT_FREQ_HZ: int = 869_618_000
DEFAULT_BANDWIDTH_HZ: int = 125_000
DEFAULT_SPREAD_FACTOR: int = 8
DEFAULT_CODERATE: str = "4/5"
