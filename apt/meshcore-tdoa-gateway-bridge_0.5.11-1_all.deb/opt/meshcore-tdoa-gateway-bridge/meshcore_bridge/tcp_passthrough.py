"""Bridge-tee TCP listener: MeshCore client ↔ USB-CDC passthrough.

Option-B coexistence design (per the architecture discussion 2026-05-24):
the bridge stays the SOLE reader of the USB-CDC port — parsing TDOA
frames into MQTT as today AND fanning the raw byte stream out to any
TCP clients connected on a configured port. Writes from TCP clients
are forwarded back to the USB serial port, so a chat client gets full
bidirectional access without fighting the bridge for the file
descriptor.

Why this beats a sidecar socat proxy:

* **Zero interleave.** One reader on the USB-CDC means bytes can't be
  split between two consumers. Both the TDOA parser AND the chat client
  see the same complete stream.
* **Sub-millisecond fan-out latency.** Same thread that just read a
  chunk writes it to clients before the next ``read()`` blocks.
* **Bidirectional.** A chat client's ``CMD_SEND_TXT_MSG`` (and similar)
  reaches the USB device via the bridge's per-port write lock — no
  separate write path to wedge.

Wire-format note: we do NOT parse the bytes flowing in either direction.
The bridge's frame extractor consumes a COPY of the read chunk (already
the case in ``serial_reader.feed()``); this module is a pure byte
forwarder. Chat clients see exactly what the firmware emits — the same
companion-protocol ``<``+length frames they'd see on a direct USB
connection.

Thread model:

* One **accept thread** per :class:`TCPPassthrough` listens on the
  configured port and adds new socket clients to ``_clients``.
* One **per-client read thread** for each connected client forwards
  incoming TCP bytes to the serial port via ``self._serial.write()``.
* The **serial reader thread** (in ``serial_reader.py``) calls
  :meth:`broadcast` once per USB chunk; that walks ``_clients`` and
  writes (non-blocking, drops on dead socket).

Memory bound: per-client send buffer is the OS socket buffer (TCP_NODELAY
isn't set; we want OS-level coalescing). A stuck client gets ECONNRESET
on the next write and is dropped. No application-level queueing.
"""
from __future__ import annotations

import socket
import threading
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    import serial


log = structlog.get_logger(__name__)


class TCPPassthrough:
    """One TCP listener bound to one USB-CDC serial port.

    Lifecycle: instantiate → :meth:`set_serial` (when the port opens) →
    :meth:`start` → :meth:`broadcast` from the reader thread for every
    chunk → :meth:`stop`. Reusable across serial reopens: call
    :meth:`set_serial` again with the new ``serial.Serial`` instance
    and pending TCP clients keep working.
    """

    def __init__(self, port: int, bind_host: str = "127.0.0.1") -> None:
        # Default loopback — the TCP passthrough has no auth today, so a
        # LAN-bound listener would accept companion-protocol commands
        # from any host that can reach it. Operators on a trusted LAN
        # who want remote access can SSH-tunnel (``ssh -L 5000:127.0.0.1
        # :5000 host``) or override ``bind_host`` once we add a
        # ``tcp_passthrough_bind`` YAML field (future work).
        self._tcp_port = port
        self._bind_host = bind_host
        self._stop_evt = threading.Event()
        self._listen_sock: socket.socket | None = None
        self._accept_thread: threading.Thread | None = None
        # Connected clients + per-client read thread. Guarded by
        # _clients_lock for add/remove; broadcast() reads under the
        # lock then writes outside it (so a slow client can't block
        # other clients during fan-out).
        self._clients: list[socket.socket] = []
        self._clients_lock = threading.Lock()
        # The USB serial port we're tee'ing. Set by set_serial when the
        # SerialReader successfully opens the device. None when the
        # port is closed (reader is in backoff); broadcast() short-
        # circuits in that case.
        self._serial: serial.Serial | None = None
        self._serial_lock = threading.Lock()
        self._plog = log.bind(component="tcp_passthrough", tcp_port=port)

    @property
    def tcp_port(self) -> int:
        return self._tcp_port

    def start(self) -> None:
        """Open the listening socket and start accepting clients.

        Idempotent. Safe to call before :meth:`set_serial` — clients
        will connect but their writes go nowhere until the serial port
        opens (consistent with what a real direct-USB chat client sees
        when the cable is unplugged).
        """
        if self._accept_thread is not None:
            return
        self._stop_evt.clear()
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((self._bind_host, self._tcp_port))
            sock.listen(8)
            sock.settimeout(0.5)  # so accept() can poll _stop_evt
        except OSError as exc:
            self._plog.error("tcp.bind.failed", error=str(exc), error_type=type(exc).__name__)
            return
        self._listen_sock = sock
        self._accept_thread = threading.Thread(
            target=self._accept_loop,
            name=f"tcp-passthrough-accept-{self._tcp_port}",
            daemon=True,
        )
        self._accept_thread.start()
        self._plog.info("tcp.listening")

    def stop(self, timeout: float = 2.0) -> None:
        """Signal shutdown; close listener + all clients."""
        self._stop_evt.set()
        sock = self._listen_sock
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass
        thr = self._accept_thread
        if thr is not None:
            thr.join(timeout)
        self._accept_thread = None
        self._listen_sock = None
        with self._clients_lock:
            for c in self._clients:
                try:
                    c.close()
                except OSError:
                    pass
            self._clients.clear()

    def set_serial(self, ser: serial.Serial | None) -> None:
        """Bind/unbind the USB serial port for client→USB write forwarding."""
        with self._serial_lock:
            self._serial = ser

    def broadcast(self, chunk: bytes) -> None:
        """Fan one USB-read chunk out to every connected TCP client.

        Called from the SerialReader thread once per ``ser.read()``.
        Non-blocking per client; on a write failure (client gone /
        socket buffer full + nonblocking) we drop that client and
        continue. Other clients are unaffected.
        """
        if not chunk:
            return
        with self._clients_lock:
            clients = list(self._clients)  # snapshot for safe iteration
        if not clients:
            return
        dead: list[socket.socket] = []
        for c in clients:
            try:
                c.sendall(chunk)
            except OSError:
                dead.append(c)
        if dead:
            with self._clients_lock:
                for c in dead:
                    try:
                        self._clients.remove(c)
                    except ValueError:
                        pass
                    try:
                        c.close()
                    except OSError:
                        pass
            self._plog.info("tcp.client.dropped", dropped=len(dead))

    # ------------------------------------------------------------------
    # internals
    # ------------------------------------------------------------------

    def _accept_loop(self) -> None:
        """Accept incoming TCP connections until ``stop()`` is called."""
        self._plog.info("tcp.accept.start")
        sock = self._listen_sock
        assert sock is not None
        try:
            while not self._stop_evt.is_set():
                try:
                    client, addr = sock.accept()
                except TimeoutError:
                    continue
                except OSError as exc:
                    if self._stop_evt.is_set():
                        break
                    self._plog.warning("tcp.accept.error", error=str(exc))
                    continue
                client.settimeout(0.5)
                with self._clients_lock:
                    self._clients.append(client)
                self._plog.info("tcp.client.accepted", peer=str(addr))
                # Spawn a per-client thread that forwards TCP→USB bytes.
                threading.Thread(
                    target=self._client_read_loop,
                    name=f"tcp-passthrough-client-{addr[0]}:{addr[1]}",
                    args=(client, addr),
                    daemon=True,
                ).start()
        finally:
            self._plog.info("tcp.accept.stop")

    def _client_read_loop(self, client: socket.socket, addr: tuple) -> None:
        """Forward this client's TCP bytes to the USB serial port."""
        plog = self._plog.bind(peer=str(addr))
        try:
            while not self._stop_evt.is_set():
                try:
                    data = client.recv(4096)
                except TimeoutError:
                    continue
                except OSError:
                    break
                if not data:
                    # Clean close from the client side.
                    break
                # 2026-05-29: hold _serial_lock through the entire
                # ser.write() — pyserial does not promise write atomicity
                # across threads, and TCP recv() chunks from two
                # simultaneous chat clients can otherwise interleave on
                # the UART, producing companion frames the firmware
                # silently drops as garbage. The lock is per-port and
                # contended only when 2+ clients are actively writing,
                # which is the case that needs serialisation anyway.
                with self._serial_lock:
                    ser = self._serial
                    if ser is None:
                        # No serial port open yet; drop the bytes
                        # (matches the behaviour a direct-USB chat
                        # client would see when the cable is unplugged).
                        continue
                    try:
                        ser.write(data)
                    except Exception as exc:  # noqa: BLE001 - never crash the thread
                        plog.warning("tcp.serial.write.error", error=str(exc))
                        break
        finally:
            with self._clients_lock:
                try:
                    self._clients.remove(client)
                except ValueError:
                    pass
            try:
                client.close()
            except OSError:
                pass
            plog.info("tcp.client.closed")
