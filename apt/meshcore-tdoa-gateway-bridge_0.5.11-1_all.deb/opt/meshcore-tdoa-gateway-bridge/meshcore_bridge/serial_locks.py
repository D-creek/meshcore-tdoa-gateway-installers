"""Per-port exclusive-serial-access coordination.

Several components take exclusive control of a receiver's USB-CDC serial port
for a short transaction by pausing the :class:`SerialReader` via the
supervisor's ``pause_port`` / ``resume_port``:

  * the FW-OTA dispatcher (``fwota_dispatcher``) — for a 5-300 s flash;
  * the on-node auth-token minter (``auth_token_minter``) — for a ~1-2 s
    CMD_SIGN transaction every refresh cycle.

The supervisor's pause/resume is a plain slug set with NO reference count, so
if a flash and a mint overlap on the same port the one that finishes first
removes the slug and the other's ``resume`` becomes a no-op — leaving the reader
dark, or worse two processes opening the same ``/dev/serial/by-id`` node at once
(``Resource busy`` / interleaved writes). This module hands out ONE
:class:`threading.Lock` per sanitized port so those components serialize their
critical sections on the same port. Pass a single shared instance to every
component (see ``__main__``).
"""
from __future__ import annotations

import threading


class PortSerialLocks:
    """Vends a process-wide unique :class:`threading.Lock` per sanitized port."""

    def __init__(self) -> None:
        self._meta = threading.Lock()
        self._locks: dict[str, threading.Lock] = {}

    def get(self, sanitized_port: str) -> threading.Lock:
        """Return the lock for ``sanitized_port`` (created on first use)."""
        with self._meta:
            lock = self._locks.get(sanitized_port)
            if lock is None:
                lock = threading.Lock()
                self._locks[sanitized_port] = lock
            return lock
