"""Remote firmware OTA for Heltec T114 v2 receivers (Q2 2026 hardware).

The T114 v2 is an nRF52840-based board running the Adafruit nRF52 BSP +
bootloader — exactly the same flash path as the LilyGo T-Echo handled
by :mod:`fwota_techo`. The only thing that differs is the udev runtime
descriptor (``usb-Heltec_T114_*`` instead of ``usb-Nordic_NRF52_DK_*``).

So this module is intentionally a thin wrapper around
:func:`fwota_techo.flash_techo` that forwards every argument. The
dispatcher decides which to call based on ``target_board`` (see
:func:`fwota_dispatcher.is_t114_target`); having a separate wrapper
function rather than wiring the descriptor difference into the
dispatcher itself keeps the responsibility boundary clean and lets us
diverge later (e.g. if Heltec T114 v3 ships with a different
bootloader pin map) without disturbing the T-Echo flash flow.

Both the UF2 mass-storage path AND the ``adafruit-nrfutil`` serial-DFU
path are inherited from fwota_techo unchanged — the T114 v2's
bootloader implements both and the flash_techo code already auto-
selects between them by sniffing the firmware-file magic.

Status: hardware in procurement. The function is import-checkable and
delegates to a real, tested code path; the only thing that needs to be
verified against live hardware is whether the bootloader's UF2 mass-
storage volume is labelled differently from T-Echo's ``TECHOBOOT``.
That's a one-line patch to fwota_techo's volume-label glob when the
chips arrive.
"""

from __future__ import annotations

from .fwota_techo import flash_techo as _flash_techo

# Public re-exports — keep the imported names visible so the dispatcher
# can ``from .fwota_t114 import flash_t114`` and tests can monkey-patch
# the underlying flash_techo. The aliasing also lets us add T114-specific
# pre/post-flash steps later without changing the public name.
__all__ = ["flash_t114"]


async def flash_t114(*args, **kwargs):
    """Flash a Heltec T114 v2 — delegates to :func:`fwota_techo.flash_techo`.

    The T114 v2 uses the Adafruit nRF52 bootloader (identical to LilyGo
    T-Echo), so the DFU trigger frame, the UF2 mass-storage drag-and-
    drop path, the ``adafruit-nrfutil`` serial-DFU fallback, and the
    post-flash heartbeat check all work unchanged. The only known
    difference is the runtime CDC descriptor (the dispatcher's
    classification step routes to the right wrapper based on that).

    All arguments and the :class:`fwota_techo.FlashResult` return shape
    pass through verbatim — callers should treat ``flash_t114`` and
    ``flash_techo`` as interchangeable at the API level.
    """
    return await _flash_techo(*args, **kwargs)
