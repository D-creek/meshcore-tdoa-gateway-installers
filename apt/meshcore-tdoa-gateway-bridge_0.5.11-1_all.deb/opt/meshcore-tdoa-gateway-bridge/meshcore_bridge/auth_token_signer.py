"""On-node MeshCore auth-token (JWT) signing for token-auth output brokers.

Token brokers (LetsMesh, DutchMeshCore) authenticate with a MeshCore-signed
Ed25519 **JWT**. Instead of holding the node's private key on the gateway
(the old ``meshcore-decoder auth-token <pub> <priv>`` path), the **node signs
the token itself** over the companion serial protocol (``CMD_SIGN_*``, part of
the standard MeshCore companion firmware) — so the private key never leaves the
device. The bridge mints here; the relay reads the resulting token from ``/run``.

See ``docs/on-node-auth-token-signing.md`` for the full contract.

JWT shape (matches ``@michaelhart/meshcore-decoder``, what the brokers verify)::

    base64url(header) "." base64url(payload) "." HEX_UPPER(signature)
      header    = {"alg":"Ed25519","typ":"JWT"}
      payload   = {"publicKey":<UPPER hex>,"iat":<unix s>[,"exp":...],"aud":<host>}
      signature = Ed25519_sign( ascii( "base64url(header).base64url(payload)" ) )

The signature is over the *exact ASCII bytes* of the ``header.payload`` string,
so the bridge signs precisely what it emits and the broker verifies that string
against the pubkey in the ``v1_<PUBKEY>`` username.
"""
from __future__ import annotations

import base64
import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Protocol

logger = logging.getLogger(__name__)

# Companion-protocol framing (see frame.py / firmware ArduinoSerialInterface).
FRAME_OUT = 0x3C  # '<'  host -> device
FRAME_IN = 0x3E   # '>'  device -> host

# Companion-protocol opcodes (examples/companion_radio/MyMesh.cpp).
CMD_SIGN_START = 33
CMD_SIGN_DATA = 34
CMD_SIGN_FINISH = 35
RESP_CODE_SIGN_START = 19  # payload: [19, reserved, uint32_le max_len]
RESP_CODE_SIGNATURE = 20   # payload: [20] + 64 signature bytes

SIGNATURE_SIZE = 64
MAX_SIGN_DATA_LEN = 8 * 1024
# Conservative per-frame chunk for CMD_SIGN_DATA. The auth-token signing input
# is a few hundred bytes, so one chunk is plenty, but chunk anyway to stay well
# under the firmware's frame buffer.
_DATA_CHUNK = 240

DEFAULT_RUN_DIR = Path("/run/meshcore-tdoa-gateway-bridge")
_TOKENS_SUBDIR = "auth-tokens"


class SignTransport(Protocol):
    """A synchronous companion-serial transport for one CMD_SIGN transaction.

    Implemented over a ``UartArbiter`` session at runtime; faked in tests.
    """

    def write_bytes(self, data: bytes) -> None: ...

    def read_frame(self, timeout: float = 2.0) -> bytes:
        """Return the next device->host frame PAYLOAD (without the ``>``+LE16
        header). Raise on timeout."""
        ...


class SignError(RuntimeError):
    """On-node signing failed (no/!bad response, oversized input, etc.)."""


def _b64url(raw: bytes) -> str:
    """base64url without padding (JWT segment encoding)."""
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def build_signing_input(
    public_key_hex: str,
    audience: str,
    iat: int,
    *,
    exp: int | None = None,
    extra_claims: dict | None = None,
) -> bytes:
    """Return the ASCII bytes of ``base64url(header).base64url(payload)``.

    This is exactly what gets signed AND the first two JWT segments.
    """
    header = {"alg": "Ed25519", "typ": "JWT"}
    payload: dict = {"publicKey": public_key_hex.upper(), "iat": int(iat)}
    if exp is not None:
        payload["exp"] = int(exp)
    payload["aud"] = audience
    if extra_claims:
        # Caller-supplied claims (e.g. owner/email) — never override the core ones.
        for k, v in extra_claims.items():
            payload.setdefault(k, v)
    h = _b64url(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    p = _b64url(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    return f"{h}.{p}".encode("ascii")


def assemble_jwt(signing_input: bytes, signature: bytes) -> str:
    """Combine ``header.payload`` + the hex-UPPER signature into the JWT."""
    if len(signature) != SIGNATURE_SIZE:
        raise SignError(
            f"signature is {len(signature)} bytes, expected {SIGNATURE_SIZE}"
        )
    return f"{signing_input.decode('ascii')}.{signature.hex().upper()}"


def _encode_cmd(cmd: int, data: bytes = b"") -> bytes:
    """Encode a host->device companion frame: ``< + LE16(len) + cmd + data``."""
    payload = bytes([cmd]) + data
    return bytes([FRAME_OUT]) + len(payload).to_bytes(2, "little") + payload


def sign_via_node(transport: SignTransport, signing_input: bytes, *, timeout: float = 3.0) -> bytes:
    """Run the CMD_SIGN_START/DATA/FINISH transaction; return the 64-byte sig.

    The node signs ``signing_input`` with its own Ed25519 private key.
    """
    if len(signing_input) > MAX_SIGN_DATA_LEN:
        raise SignError(
            f"signing input {len(signing_input)} B exceeds node MAX_SIGN_DATA_LEN "
            f"{MAX_SIGN_DATA_LEN}"
        )

    # 1. START — node allocates a buffer and reports its capacity.
    transport.write_bytes(_encode_cmd(CMD_SIGN_START))
    resp = transport.read_frame(timeout)
    if not resp or resp[0] != RESP_CODE_SIGN_START:
        raise SignError(f"expected RESP_CODE_SIGN_START, got {resp[:1].hex() or 'nothing'}")
    if len(resp) >= 6:
        max_len = int.from_bytes(resp[2:6], "little")
        if max_len and len(signing_input) > max_len:
            raise SignError(
                f"signing input {len(signing_input)} B exceeds node-reported "
                f"max_len {max_len}"
            )

    # 2. DATA — stream the signing input in chunks.
    for off in range(0, len(signing_input), _DATA_CHUNK):
        chunk = signing_input[off : off + _DATA_CHUNK]
        transport.write_bytes(_encode_cmd(CMD_SIGN_DATA, chunk))
        ok = transport.read_frame(timeout)
        if not ok:
            raise SignError("no ACK frame after CMD_SIGN_DATA chunk")
        # Any non-signature response code here is a per-chunk ACK; a signature
        # code would be a protocol violation mid-stream.
        if ok[0] == RESP_CODE_SIGNATURE:
            raise SignError("node returned a signature before CMD_SIGN_FINISH")

    # 3. FINISH — node signs the accumulated bytes and returns the signature.
    transport.write_bytes(_encode_cmd(CMD_SIGN_FINISH))
    sig_frame = transport.read_frame(timeout)
    if not sig_frame or sig_frame[0] != RESP_CODE_SIGNATURE:
        raise SignError(
            f"expected RESP_CODE_SIGNATURE, got {sig_frame[:1].hex() or 'nothing'}"
        )
    sig = sig_frame[1 : 1 + SIGNATURE_SIZE]
    if len(sig) != SIGNATURE_SIZE:
        raise SignError(f"signature frame carried {len(sig)} bytes, expected {SIGNATURE_SIZE}")
    return sig


def mint(
    transport: SignTransport,
    public_key_hex: str,
    audience: str,
    iat: int,
    *,
    exp: int | None = None,
    extra_claims: dict | None = None,
    timeout: float = 3.0,
) -> str:
    """Build + on-node-sign + assemble a MeshCore auth-token JWT."""
    signing_input = build_signing_input(
        public_key_hex, audience, iat, exp=exp, extra_claims=extra_claims
    )
    signature = sign_via_node(transport, signing_input, timeout=timeout)
    return assemble_jwt(signing_input, signature)


def token_path(public_key_hex: str, audience: str, *, run_dir: Path = DEFAULT_RUN_DIR) -> Path:
    """Return the ``/run`` path the relay reads for (pubkey, audience)."""
    safe_aud = "".join(c if (c.isalnum() or c in "-._") else "_" for c in audience)
    return run_dir / _TOKENS_SUBDIR / f"{public_key_hex.upper()}_{safe_aud}.jwt"


def write_token_file(
    public_key_hex: str, audience: str, jwt: str, *, run_dir: Path = DEFAULT_RUN_DIR
) -> Path:
    """Atomically write the JWT to its ``/run`` path (temp + rename, 0640)."""
    path = token_path(public_key_hex, audience, run_dir=run_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tok-")
    try:
        with os.fdopen(fd, "w") as fh:
            fh.write(jwt)
        # World-readable: the bridge (root) writes this, but the mesh-relay runs
        # as a separate unprivileged user and must read it. It's a short-lived
        # (1 h) publish-only JWT, NOT a private key — 0644 is the right trade-off
        # (0640/root left the relay unable to read it → "no priv_key" skip).
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return path
