"""Remote firmware OTA for STM32H743VI receivers (Q2 2026 hardware).

This is the scaffolding for the upcoming STM32H743 + E22-900M22S + BN-220
TDOA receiver platform (variant ``stm32h743_e22p`` in the firmware repo).
The hardware has not yet been procured at the time of this commit; this
module is intentionally build-and-import-checkable now so the dispatcher
classification + downstream tooling can be wired against the public
interface without waiting on the receivers to land.

How the STM32H7 ROM bootloader works
------------------------------------

The H743 silicon includes a USB-DFU class device in its system-memory
ROM bootloader at flash address ``0x1FF09800``. Two ways to enter it:

  1. **Hardware**: hold BOOT0 high through a reset (manual recovery).
  2. **Software**: the firmware writes a magic value to RTC->BKP0R and
     triggers ``HAL_NVIC_SystemReset``; an early-boot stub recognises
     the magic and jumps to ``0x1FF09800`` instead of the application
     entry point. See ``variants/stm32h743_e22p/`` in the firmware repo
     for the embedded side.

Either way, once the chip is in DFU it enumerates as USB VID:PID
``0483:df11`` (STMicroelectronics "STM32 BOOTLOADER"). Host-side flashing
uses ``dfu-util``:

    dfu-util -d 0483:df11 -a 0 -s 0x08000000:leave -D <fw.bin>

  - ``-d 0483:df11`` matches the ROM bootloader's VID:PID.
  - ``-a 0`` selects DFU alt-setting 0 (internal flash, 2 MB at 0x08000000).
  - ``-s 0x08000000:leave`` writes to the application start address and
    issues a DFU detach (``leave``) at the end so the chip auto-resets
    into the new firmware. No separate ``dfu-util -e`` required.
  - ``-D <fw.bin>`` is the raw binary (no .elf, no .hex — dfu-util takes
    flat firmware).

Descriptor patterns we expect on the bridge
-------------------------------------------

The runtime application enumerates as a USB-CDC ACM with a vendor string
including ``STMicroelectronics STM32``::

    /dev/serial/by-id/usb-STMicroelectronics_STM32_*-if00

The DFU descriptor (no CDC interface; pure DFU class) appears under::

    /dev/usb/lsusb-ish/STMicroelectronics_STM32_BOOTLOADER_*

These are confirmed against the H743's published USB descriptors but
have NOT yet been verified on physical hardware on the bridge host;
update the glob constants below once we have a chip on the bench.

Async-first design mirrors fwota_v4.flash_v4: a per-job task spawned by
the bridge's MQTT dispatcher can ``await`` flash progress without
blocking the supervisor thread that owns USB rescans. The caller is
responsible for stopping the SerialReader on ``port`` BEFORE invoking
:func:`flash_h743` — dfu-util needs exclusive USB access and a
concurrent reader will fight the bootloader handshake.

Status
------

THIS MODULE IS A STUB. The function shape matches what the dispatcher
expects and the verify-by-reglob pattern is in place, but ``dfu-util``
is NOT actually invoked. When the H743 receivers arrive and the live
flash path needs to land, replace the ``_run_dfu_util_stub`` body with
the real ``asyncio.create_subprocess_exec`` call (mirroring
fwota_v4._run_esptool). The public ``flash_h743`` signature should stay
stable.
"""

from __future__ import annotations

import asyncio
import glob
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Literal

import structlog

log = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Descriptor globs
# ---------------------------------------------------------------------------

#: Runtime CDC descriptor for an H743 receiver post-reset. The trailing
#: ``*`` matches the per-chip-ID suffix udev appends (the H7's unique
#: device ID gets baked into the USB-CDC descriptor by the BSP).
#:
#: NOTE: this glob has not yet been verified against a live H743 board
#: — the receiver hardware is still in procurement (Q2 2026). Adjust
#: once we see the actual descriptor on the bridge host.
DEFAULT_RUNTIME_GLOB = (
    "/dev/serial/by-id/usb-STMicroelectronics_STM32_*-if00"
)

#: ROM-bootloader DFU descriptor. The H7 ROM exposes a pure DFU class
#: device (no CDC interface), so the descriptor format differs from the
#: runtime application; lsusb shows it as VID:PID 0483:df11 with the
#: product string "STM32 BOOTLOADER".
DEFAULT_DFU_GLOB = (
    "/dev/usb/lsusb-ish/STMicroelectronics_STM32_BOOTLOADER_*"
)


# ---------------------------------------------------------------------------
# Timing constants — mirrored from fwota_v4.py for consistency
# ---------------------------------------------------------------------------

#: Upper bound for re-enumeration polling after a successful flash.
#: The H743's USB-CDC stack takes ~3-6 s to come up post-reset; 90 s
#: leaves headroom for a cold-cache udev fire and a slow Pi-side
#: ``by-id`` symlink refresh.
DEFAULT_REENUM_TIMEOUT_S = 90.0

#: Polling interval for the re-enumeration loop.
_REENUM_POLL_INTERVAL_S = 0.5

#: Hard cap on the dfu-util subprocess. The H743's internal flash is
#: 2 MB; a typical TDOA-receiver build is well under 512 KB and writes
#: in under 30 s at DFU's default 1 MB/s throughput. 300 s covers a
#: degraded USB link or a retry without escaping into "the job hung
#: forever" territory.
DEFAULT_FLASH_TIMEOUT_S = 300.0

#: Verification step's timeout — wait for the runtime CDC descriptor
#: to reappear after the ``leave`` step. Usually completes in <10 s;
#: 30 s covers a slow USB hub or a transient enumeration glitch.
DEFAULT_VERIFY_TIMEOUT_S = 30.0

#: The fixed VID:PID of the H7 ROM bootloader.
DEFAULT_DFU_VID_PID = "0483:df11"

#: DFU alt-setting for the internal flash. The H7 ROM bootloader
#: exposes multiple alt settings (flash, OTP, option bytes) — alt 0 is
#: always the internal flash starting at 0x08000000.
DEFAULT_DFU_ALT = "0"

#: Application start address in the H7's flash map. The vector table
#: is placed here by the linker script; the ROM bootloader's ``leave``
#: step jumps to this address after the write completes.
DEFAULT_FLASH_OFFSET = "0x08000000"


# ---------------------------------------------------------------------------
# Result types — match fwota_v4.py shape
# ---------------------------------------------------------------------------


FlashState = Literal[
    "success",
    "rolled_back_to_previous",
    "failed_verify",
    "failed_flash",
    "failed_no_reenum",
    "failed_timeout",
    "failed_bad_input",
]

ProgressCallback = Callable[[str], None]


@dataclass(frozen=True)
class FlashOptions:
    """Tunables for :func:`flash_h743`. Defaults work for production H743s.

    Surfaced as a dataclass so the bridge's HTTP handler can override
    timeouts for slow USB hubs without re-passing eight kwargs. Frozen
    so tests can share one instance without worrying about accidental
    mutation.
    """

    dfu_util_path: str = "dfu-util"
    dfu_vid_pid: str = DEFAULT_DFU_VID_PID
    dfu_alt: str = DEFAULT_DFU_ALT
    flash_offset: str = DEFAULT_FLASH_OFFSET
    runtime_glob: str = DEFAULT_RUNTIME_GLOB
    dfu_glob: str = DEFAULT_DFU_GLOB
    flash_timeout_s: float = DEFAULT_FLASH_TIMEOUT_S
    reenum_timeout_s: float = DEFAULT_REENUM_TIMEOUT_S
    verify_timeout_s: float = DEFAULT_VERIFY_TIMEOUT_S


@dataclass
class FlashResult:
    """Outcome of a single :func:`flash_h743` invocation.

    Always populated regardless of ``state`` — even on a hard failure the
    caller gets the partial log and the elapsed wall time so the API can
    surface "we tried for 6 s before dfu-util died".

    ``new_port`` is the post-reenum CDC path the chip came back on (used
    by the supervisor to restart its serial reader on the same logical
    receiver). ``None`` when re-enumeration never completed.
    """

    state: FlashState
    elapsed_s: float
    log: list[str] = field(default_factory=list)
    new_port: str | None = None
    error: str | None = None


def _now() -> float:
    """Wall-clock seconds; pulled out so tests can patch it deterministically."""
    return time.monotonic()


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


async def flash_h743(
    port: str,
    fw_bin_path: str,
    *,
    on_progress: ProgressCallback | None = None,
    options: FlashOptions | None = None,
    glob_fn: Callable[[str], list[str]] = glob.glob,
    sleep_fn: Callable[[float], asyncio.Future[None]] | None = None,
    rollback_fw_bin_path: str | None = None,
) -> FlashResult:
    """Flash ``fw_bin_path`` onto the H743 currently reachable at ``port``.

    .. warning::

       STUB IMPLEMENTATION. The dfu-util invocation is not yet wired in
       — the hardware is still in procurement. The function returns the
       correct FlashResult shape for unit-test consumption, and the
       descriptor-glob plumbing is in place so the dispatcher can route
       a real job to this function without further changes once the
       receivers arrive.

    The caller must have STOPPED any serial reader holding ``port`` before
    calling this — dfu-util needs exclusive USB access. This function
    never touches the bridge's :class:`SerialReader` registry directly so
    the responsibility boundary stays narrow.

    Flow (when the dfu-util invocation lands):

    1. Send the companion-protocol DFU-enter command on ``port`` (writes
       the magic to RTC->BKP0R and triggers a system reset; the
       early-boot stub jumps to 0x1FF09800). The descriptor flips from
       the runtime CDC to the ``STM32_BOOTLOADER`` DFU descriptor.
    2. Poll ``options.dfu_glob`` for up to ``verify_timeout_s`` for the
       DFU descriptor to appear.
    3. Spawn ``dfu-util -d <vid:pid> -a <alt>
       -s <flash_offset>:leave -D <fw_bin_path>``. The ``:leave`` modifier
       tells dfu-util to issue a DFU detach at the end so the chip
       auto-resets into the new firmware. Output streams through
       ``on_progress`` line-by-line.
    4. If dfu-util exits non-zero (or times out) — return
       ``failed_flash`` / ``failed_timeout``. If ``rollback_fw_bin_path``
       is set and the primary flash failed AND the chip is still in DFU
       (re-glob), retry against the rollback binary, mirroring the V4's
       rollback-to-known-good path.
    5. Wait up to ``options.reenum_timeout_s`` for the runtime CDC glob
       to reappear. The H743's ``leave`` step typically results in a
       fresh enumeration within 5 s. ``None`` → ``failed_no_reenum``.
    6. ``success`` — log elapsed time and return.

    The returned :class:`FlashResult` always carries the full streamed log,
    even on failure, so the API server can persist it to the job row.

    ``glob_fn`` / ``sleep_fn`` are test seams — the production caller never
    sets them.
    """
    opts = options or FlashOptions()
    started = _now()
    log_lines: list[str] = []

    plog = log.bind(port=port, fw=fw_bin_path, opts=opts)
    plog.info("fwota.h743.flash.start")

    # ---- input validation ----
    # Mirrors fwota_techo's bad-input branch. The dispatcher already
    # sha256-checks the cached file, so a missing path here means the
    # caller bypassed download_to_cache — surface a clear failure.
    import os
    if not os.path.isfile(fw_bin_path):
        plog.warning("fwota.h743.flash.bad_input", reason="fw_bin_path missing")
        log_lines.append(f"firmware bin not found: {fw_bin_path}")
        return FlashResult(
            state="failed_bad_input",
            elapsed_s=_now() - started,
            log=log_lines,
            error=f"firmware bin not found: {fw_bin_path}",
        )

    # ---- STUB STEP: invoke dfu-util ----
    # When the H743 hardware arrives, replace this call with the real
    # asyncio.create_subprocess_exec invocation that mirrors
    # fwota_v4._run_esptool. The argv is documented in the module
    # docstring; the streaming pattern is the same.
    rc, timed_out = await _run_dfu_util_stub(
        opts=opts,
        fw_bin_path=fw_bin_path,
        log_lines=log_lines,
        on_progress=on_progress,
    )

    if timed_out:
        plog.warning("fwota.h743.flash.timeout", elapsed_s=_now() - started)
        return FlashResult(
            state="failed_timeout",
            elapsed_s=_now() - started,
            log=log_lines,
            error=f"dfu-util exceeded {opts.flash_timeout_s}s",
        )
    if rc != 0:
        # Rollback path mirrors fwota_v4's JTAG-retry-then-rollback dance.
        # The H7 doesn't have a separate JTAG bootloader — the failure
        # mode is "chip stuck in DFU" (the same VID:PID 0483:df11 is
        # still enumerated since dfu-util's failure doesn't issue the
        # ``:leave`` detach). We can re-attempt with the rollback binary
        # directly.
        if rollback_fw_bin_path is not None:
            plog.warning(
                "fwota.h743.flash.rolling_back",
                rc=rc,
                rollback_fw=rollback_fw_bin_path,
            )
            rc2, timed_out2 = await _run_dfu_util_stub(
                opts=opts,
                fw_bin_path=rollback_fw_bin_path,
                log_lines=log_lines,
                on_progress=on_progress,
            )
            if not timed_out2 and rc2 == 0:
                plog.info("fwota.h743.flash.rollback_succeeded")
                new_port_rb = await _await_reenum(
                    opts.runtime_glob,
                    timeout_s=opts.reenum_timeout_s,
                    deadline_start=_now(),
                    glob_fn=glob_fn,
                    sleep_fn=sleep_fn,
                )
                return FlashResult(
                    state="rolled_back_to_previous",
                    elapsed_s=_now() - started,
                    log=log_lines,
                    new_port=new_port_rb,
                    error=(
                        f"requested version failed (rc={rc}); "
                        f"rolled back to previous via DFU"
                    ),
                )
        return FlashResult(
            state="failed_flash",
            elapsed_s=_now() - started,
            log=log_lines,
            error=f"dfu-util exited with code {rc}",
        )

    plog.info(
        "fwota.h743.flash.write_complete",
        awaiting_reenum_s=opts.reenum_timeout_s,
    )

    # ---- verify by re-glob ----
    new_port = await _await_reenum(
        opts.runtime_glob,
        timeout_s=opts.reenum_timeout_s,
        deadline_start=_now(),
        glob_fn=glob_fn,
        sleep_fn=sleep_fn,
    )
    if new_port is None:
        plog.warning("fwota.h743.flash.no_reenum", glob=opts.runtime_glob)
        return FlashResult(
            state="failed_no_reenum",
            elapsed_s=_now() - started,
            log=log_lines,
            error=(
                f"runtime CDC descriptor never reappeared at "
                f"{opts.runtime_glob} after dfu-util :leave"
            ),
        )

    plog.info(
        "fwota.h743.flash.success",
        elapsed_s=_now() - started,
        new_port=new_port,
    )
    return FlashResult(
        state="success",
        elapsed_s=_now() - started,
        log=log_lines,
        new_port=new_port,
    )


# ---------------------------------------------------------------------------
# Helpers (test seams)
# ---------------------------------------------------------------------------


async def _await_reenum(
    glob_pattern: str,
    *,
    timeout_s: float,
    deadline_start: float,
    glob_fn: Callable[[str], list[str]] = glob.glob,
    sleep_fn: Callable[[float], asyncio.Future[None]] | None = None,
) -> str | None:
    """Poll ``glob_pattern`` until a path appears or ``timeout_s`` elapses.

    Returns the first matching path (sorted, for determinism when two
    H743s share a hub) or ``None`` on timeout. Tests inject ``glob_fn``
    to drive synthetic re-enumeration without touching ``/dev``.

    Identical contract to fwota_v4._await_reenum — kept as a local copy
    rather than imported so the H7 path can diverge if future hardware
    requires a different polling strategy (e.g. the H7's USB-CDC stack
    sometimes needs an extra serial-line-state poll before it's truly
    ready, which the V4's USB-CDC does not).
    """
    deadline = deadline_start + timeout_s
    while _now() < deadline:
        matches = sorted(glob_fn(glob_pattern))
        if matches:
            return matches[0]
        if sleep_fn is not None:
            await sleep_fn(_REENUM_POLL_INTERVAL_S)
        else:
            await asyncio.sleep(_REENUM_POLL_INTERVAL_S)
    return None


async def _run_dfu_util_stub(
    *,
    opts: FlashOptions,
    fw_bin_path: str,
    log_lines: list[str],
    on_progress: ProgressCallback | None,
) -> tuple[int, bool]:
    """STUB: pretend a dfu-util invocation succeeded.

    Returns ``(returncode=0, timed_out=False)`` and emits the argv we
    would have used so the per-port flash log is still useful when the
    bridge is exercised against this stub in CI / smoke tests.

    .. note::

       When the H743 receivers arrive (Q2 2026), replace this body with
       a real ``asyncio.create_subprocess_exec`` call that streams
       stdout/stderr through ``on_progress`` line-by-line. The argv is
       documented in the module docstring and rebuilt below; the
       subprocess machinery is functionally identical to
       fwota_v4._run_esptool — copy that pattern.

       The signature is intentionally kept compatible so the real
       implementation slots in without disturbing the caller.
    """
    argv = [
        opts.dfu_util_path,
        "-d", opts.dfu_vid_pid,
        "-a", opts.dfu_alt,
        "-s", f"{opts.flash_offset}:leave",
        "-D", fw_bin_path,
    ]
    stub_line = (
        f"$ {' '.join(argv)}    "
        f"# STUB — dfu-util not invoked, hardware pending"
    )
    log_lines.append(stub_line)
    if on_progress is not None:
        try:
            on_progress(stub_line)
        except Exception:  # noqa: BLE001 — never let a misbehaving cb abort us
            pass
    # Pretend success. When the real implementation lands it will
    # actually wait for the subprocess; for now we just yield once to
    # the event loop so the call is still ``await``-able in tests.
    await asyncio.sleep(0)
    return 0, False
