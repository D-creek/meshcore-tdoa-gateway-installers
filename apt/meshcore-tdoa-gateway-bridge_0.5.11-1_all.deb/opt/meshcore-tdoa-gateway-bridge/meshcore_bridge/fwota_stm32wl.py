"""STM32WL (Wio-E5 mini) serial firmware flash via ``stm32flash``.

Why this exists — the STM32WL flash path is unlike every other board:

* The STM32WLE5's ROM/system bootloader USART1 is hardwired to PA9/PA10,
  but the Wio-E5 mini's CP2102N USB-UART is wired to USART1 PB6/PB7 — so
  the ROM bootloader is unreachable over the only serial link we have.
  ``BOOT0`` is not bonded out of the LoRa-E5 module either.  See
  ``reference_wio_e5_flash_procedure`` + the deep-research writeup.
* The solution is **ST Open Bootloader (OpenBL)**, ported to WLE5 with its
  USART retargeted to PB6/PB7, flashed once over SWD into a reserved,
  write-protected region at 0x08000000.  OpenBL speaks the standard
  AN3155 protocol, so ``stm32flash`` (and STM32CubeProgrammer) drive it
  unchanged — over the existing CP2102 (``/dev/ttyUSB*``).

Flash flow (this module):

1. The MeshCore app receives the OTA request (its ``startOTAUpdate`` sets
   an RTC backup-register flag and resets).  OpenBL boots, sees the flag,
   stays in the bootloader listening on PB6/PB7.  The dispatcher waits
   ``reenum_wait_seconds`` for that.
2. ``stm32flash -b 115200 -w <fw.bin> -v -S <app_base> -g <app_base>
   <port>`` writes the application image at ``app_base`` (past the OpenBL
   region), verifies, and issues a Go to run it.
3. Non-zero / timeout / verify-fail → a ``FlashResult`` carrying the full
   streamed log so the operator sees what stm32flash actually said.

Brick semantics: a bad *app* flash is recoverable — reset re-enters OpenBL
(it lives in its own write-protected region) and we retry.  Only
corruption of the OpenBL region itself needs SWD.

NOTE: the app *image* must be the raw ``firmware.bin`` (not .elf/.hex);
the puller stores per-release blobs and the dispatcher hands us the path.
"""
from __future__ import annotations

import asyncio
import os
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Literal

# --------------------------------------------------------------------------
# Tunables
# --------------------------------------------------------------------------

#: Default UART baud for the OpenBL AN3155 handshake. OpenBL auto-bauds on
#: the 0x7F init byte; 115200 matches what the bridge already uses on the
#: CP2102 and what stm32flash defaults to for STM32.
_DEFAULT_BAUD: int = 115200

#: Application base address. OpenBL occupies the first 32 KB of flash
#: (0x08000000..0x08007FFF, write-protected); the MeshCore app is linked
#: to start here. MUST match the MeshCore STM32WL linker offset.
_DEFAULT_APP_BASE: int = 0x08008000

#: Seconds to wait after the app self-jumps (reset → OpenBL boot) before
#: stm32flash opens the port. OpenBL is up within ~100 ms but the CP2102
#: re-asserts and udev settles; be generous.
_DEFAULT_REENUM_WAIT_S: float = 2.0

#: Hard cap on the stm32flash subprocess. A full 224 KB app write+verify
#: at 115200 is ~40 s; 120 s leaves headroom without hanging the worker.
_DEFAULT_STM32FLASH_TIMEOUT_S: float = 120.0

#: stm32flash success marker. It prints "Starting execution at address
#: 0x..." after a Go, and per-block "Wrote and verified address 0x...".
_OK_MARKERS = ("Starting execution at address", "Wrote and verified address")

#: OTA-entry trigger sent to the *running MeshCore app* over the companion
#: protocol to make it jump into OpenBL. We reuse the existing
#: CMD_ENTER_USB_DFU frame (host→device: '<' + uint16_le(len) + 0x41 +
#: "dfu!"); on STM32WL the firmware's enterUsbDfu() override sets the TAMP
#: "OPEN" flag and resets, so OpenBL stays resident. Same constant as
#: fwota_techo.DFU_FRAME. Harmless if the device is already in OpenBL (it
#: waits for stm32flash's 0x7F auto-baud byte, ignoring these bytes).
_OTA_TRIGGER_FRAME = b"<\x05\x00\x41dfu!"

ProgressCallback = Callable[[str], None]

FlashState = Literal[
    "success",
    "failed_bad_input",
    "failed_stm32flash",
    "failed_timeout",
    "failed_no_verify",
]


@dataclass
class FlashResult:
    """Outcome of a flash attempt, with the full streamed log for triage."""

    state: FlashState
    port: str
    fw_bin_path: str
    duration_seconds: float
    returncode: int | None = None
    stdout_tail: str = ""
    error: str | None = None
    log_lines: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.state == "success"


def _clock() -> float:
    # Wall-clock for durations only; monotonic to avoid NTP steps mid-flash.
    import time

    return time.monotonic()


async def _sleep(seconds: float) -> None:
    await asyncio.sleep(seconds)


# --------------------------------------------------------------------------
# flash_stm32wl
# --------------------------------------------------------------------------


async def flash_stm32wl(
    port: str,
    fw_bin_path: str,
    *,
    on_progress: ProgressCallback | None = None,
    rollback_fw_bin_path: str | None = None,
    app_base: int = _DEFAULT_APP_BASE,
    baud: int = _DEFAULT_BAUD,
    reenum_wait_seconds: float = _DEFAULT_REENUM_WAIT_S,
    stm32flash_path: str = "stm32flash",
    stm32flash_timeout_seconds: float = _DEFAULT_STM32FLASH_TIMEOUT_S,
    subprocess_factory: Callable[..., Awaitable] | None = None,
    trigger_ota: bool = True,
    serial_factory: Callable[..., object] | None = None,
) -> FlashResult:
    """Flash a raw app binary to an STM32WL running OpenBL on ``port``.

    Assumes the running firmware has ALREADY self-jumped into OpenBL (the
    MeshCore ``startOTAUpdate`` command handler does this before the
    dispatcher calls us — set the RTC backup flag + reset). We wait
    ``reenum_wait_seconds`` for OpenBL to come up, then drive stm32flash.

    ``rollback_fw_bin_path`` mirrors the other fwota_* signatures; on a
    verify/flash failure we retry once against the rollback image if one
    is supplied (OpenBL stays resident, so a retry is safe).
    """
    started = _clock()
    log_lines: list[str] = []

    def progress(msg: str) -> None:
        log_lines.append(msg)
        if on_progress is not None:
            on_progress(msg)

    if not os.path.isfile(fw_bin_path):
        progress(f"firmware bin not found: {fw_bin_path}")
        return FlashResult(
            state="failed_bad_input",
            port=port,
            fw_bin_path=fw_bin_path,
            duration_seconds=_clock() - started,
            error=f"firmware bin not found: {fw_bin_path}",
            log_lines=log_lines,
        )

    # ---- step 0: trigger the running app into OpenBL, HOLDING the port open
    # The Wio-E5 has no remote reset wiring. Opening the port for the trigger
    # and then letting stm32flash open it again re-pulses DTR (an open on a
    # closed tty asserts DTR) which, combined with OpenBL clearing its entry
    # flag on first boot, drops the device back to the app. So we open ONE fd
    # (DTR/RTS deasserted), send the companion CMD_ENTER_USB_DFU frame (the
    # STM32WL enterUsbDfu() override sets the TAMP "OPEN" flag + resets), and
    # HOLD that fd open across the stm32flash subprocess — a second open on an
    # already-open tty does not re-pulse DTR, so the device stays in OpenBL.
    # Proven on a test gateway. Best-effort: a failed trigger is non-fatal.
    held = _open_and_trigger(port, baud, serial_factory, progress) if trigger_ota else None
    try:
        # ---- step 1: wait for OpenBL to boot on PB6/PB7 after the self-jump
        progress(f"fwota.stm32wl.reenum.wait seconds={reenum_wait_seconds:.1f}")
        await _sleep(reenum_wait_seconds)

        # ---- step 2: stm32flash write + verify + go ----------------------
        addr = f"0x{app_base:08X}"
        result = await _run_stm32flash(
            stm32flash_path=stm32flash_path,
            port=port,
            fw_bin=fw_bin_path,
            app_base_hex=addr,
            baud=baud,
            timeout_seconds=stm32flash_timeout_seconds,
            progress=progress,
            subprocess_factory=subprocess_factory,
        )

        if result.state == "success":
            progress("fwota.stm32wl.ok")
            result.duration_seconds = _clock() - started
            result.log_lines = log_lines
            return result

        # ---- step 3: one rollback retry (OpenBL is still resident) -------
        if rollback_fw_bin_path and os.path.isfile(rollback_fw_bin_path):
            progress(f"fwota.stm32wl.rollback.retry img={rollback_fw_bin_path}")
            await _sleep(reenum_wait_seconds)
            rb = await _run_stm32flash(
                stm32flash_path=stm32flash_path,
                port=port,
                fw_bin=rollback_fw_bin_path,
                app_base_hex=addr,
                baud=baud,
                timeout_seconds=stm32flash_timeout_seconds,
                progress=progress,
                subprocess_factory=subprocess_factory,
            )
            rb.duration_seconds = _clock() - started
            rb.log_lines = log_lines
            return rb

        result.duration_seconds = _clock() - started
        result.log_lines = log_lines
        return result
    finally:
        if held is not None:
            try:
                held.close()
            except Exception:  # noqa: BLE001 - best-effort cleanup
                pass


def _open_and_trigger(
    port: str,
    baud: int,
    serial_factory: Callable[..., object] | None,
    progress: ProgressCallback,
) -> object | None:
    """Open ``port``, send the companion CMD_ENTER_USB_DFU frame, and RETURN
    the still-open serial handle so the caller can hold it open across the
    stm32flash subprocess (see flash_stm32wl step 0 — holding the fd open keeps
    the device in OpenBL by avoiding a second DTR pulse).

    DTR/RTS are deasserted so simply holding the port open doesn't toggle them.
    Non-fatal by design: returns ``None`` if the port can't be opened or the
    write fails (the device may already be in OpenBL) — stm32flash's 0x7F
    auto-baud init re-syncs regardless.
    """
    progress("fwota.stm32wl.ota_trigger.send")
    try:
        if serial_factory is not None:
            ser = serial_factory(port, baud)
        else:
            import serial  # lazy: only needed on a real gateway

            ser = serial.Serial(port, baud, timeout=2.0)
    except Exception as exc:  # noqa: BLE001 - trigger is best-effort
        progress(f"fwota.stm32wl.ota_trigger.skip(open): {exc}")
        return None
    try:
        # Keep DTR/RTS low so holding the fd open doesn't pulse a reset line.
        for attr in ("dtr", "rts"):
            try:
                setattr(ser, attr, False)
            except Exception:  # noqa: BLE001 - some fakes/ports lack these
                pass
        ser.write(_OTA_TRIGGER_FRAME)
        ser.flush()
        progress("fwota.stm32wl.ota_trigger.sent (holding port open)")
        return ser
    except Exception as exc:  # noqa: BLE001 - trigger is best-effort
        progress(f"fwota.stm32wl.ota_trigger.skip(write): {exc}")
        try:
            ser.close()
        except Exception:  # noqa: BLE001
            pass
        return None


async def _run_stm32flash(
    *,
    stm32flash_path: str,
    port: str,
    fw_bin: str,
    app_base_hex: str,
    baud: int,
    timeout_seconds: float,
    progress: ProgressCallback,
    subprocess_factory: Callable[..., Awaitable] | None,
) -> FlashResult:
    """One ``stm32flash`` invocation: write + verify + go at ``app_base``."""
    argv = [
        stm32flash_path,
        "-b", str(baud),
        "-w", fw_bin,            # write
        "-v",                    # verify
        "-S", app_base_hex,      # start address (app base, past OpenBL)
        "-g", app_base_hex,      # go (run the app) after flashing
        port,
    ]
    progress("fwota.stm32flash.start: " + " ".join(argv))

    spawn = subprocess_factory or asyncio.create_subprocess_exec
    try:
        proc = await spawn(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
    except FileNotFoundError:
        return FlashResult(
            state="failed_bad_input",
            port=port,
            fw_bin_path=fw_bin,
            duration_seconds=0.0,
            error=f"{stm32flash_path} not installed on this host",
        )

    try:
        stdout_b, _ = await asyncio.wait_for(
            proc.communicate(), timeout=timeout_seconds
        )
    except TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        return FlashResult(
            state="failed_timeout",
            port=port,
            fw_bin_path=fw_bin,
            duration_seconds=0.0,
            error=f"stm32flash hung past {timeout_seconds:.0f}s",
        )

    out = (stdout_b or b"").decode("utf-8", errors="replace")
    for line in out.splitlines():
        progress(line)
    rc = proc.returncode

    if rc != 0:
        return FlashResult(
            state="failed_stm32flash",
            port=port,
            fw_bin_path=fw_bin,
            duration_seconds=0.0,
            returncode=rc,
            stdout_tail=out[-512:],
            error=f"stm32flash exited {rc}",
        )

    # rc==0 but confirm a verify + go marker actually printed — stm32flash
    # can exit 0 on a no-op if the port opened but nothing was written.
    if not any(m in out for m in _OK_MARKERS):
        return FlashResult(
            state="failed_no_verify",
            port=port,
            fw_bin_path=fw_bin,
            duration_seconds=0.0,
            returncode=rc,
            stdout_tail=out[-512:],
            error="stm32flash exited 0 but no write/verify/go marker seen",
        )

    return FlashResult(
        state="success",
        port=port,
        fw_bin_path=fw_bin,
        duration_seconds=0.0,
        returncode=rc,
        stdout_tail=out[-512:],
    )
