#!/bin/bash
# /usr/share/meshcore-tdoa-gateway-portal/scripts/mount-uf2-bootloader.sh
#
# Privileged helper for the portal's firmware-flash endpoint. On Pis
# that don't have usbmount / udisks2 configured (e.g. testopi's
# Armbian-minimal image), the nRF52 bootloader's USB-MSC volume
# appears as /dev/disk/by-label/<TECHOBOOT|RAK4631|FTHRBOOT> but
# nobody auto-mounts it. The portal calls this script via sudo to
# mount + unmount that volume into a fixed temp path; the portal
# then drops the .uf2 onto the mountpoint.
#
# Locked-down by:
#  - sudoers entry restricting invocation to this exact binary path,
#    via /etc/sudoers.d/meshcore-tdoa-gateway-portal-restart-bridge
#  - label whitelist (only TECHOBOOT / RAK4631 / FTHRBOOT)
#  - mountpoint hardcoded under /tmp/portal-uf2-<label> so an attacker
#    controlling the LABEL arg can't pivot to mounting over arbitrary
#    paths
#
# Usage: mount-uf2-bootloader.sh mount|umount <LABEL>
# Exit 0 on success; mount also echoes the mountpoint on stdout so
# the caller can pick it up.

set -e
action="$1"
label="$2"

case "$label" in
  TECHOBOOT|RAK4631|FTHRBOOT) ;;
  *) echo "Bad label (TECHOBOOT/RAK4631/FTHRBOOT only)" >&2; exit 1 ;;
esac

mountpoint="/tmp/portal-uf2-$(echo "$label" | tr '[:upper:]' '[:lower:]')"

case "$action" in
  mount)
    # Security (2026-06-06): the mountpoint lives under world-writable /tmp, so
    # an attacker could pre-plant a SYMLINK at "$mountpoint" and (since mkdir -p
    # follows an existing symlink) redirect where the bootloader MSC volume gets
    # mounted, then tamper the .uf2 before flash. Refuse if the path exists and
    # is NOT a plain directory; only create a fresh dir otherwise.
    if [ -L "$mountpoint" ] || { [ -e "$mountpoint" ] && [ ! -d "$mountpoint" ]; }; then
      echo "Refusing: $mountpoint exists and is not a plain directory" >&2
      exit 1
    fi
    [ -d "$mountpoint" ] || mkdir "$mountpoint"
    # mountpoint already in use? unmount it cleanly first — stale state
    # from a previous failed flash would otherwise block the new mount.
    if mountpoint -q "$mountpoint"; then
      umount "$mountpoint" || true
    fi
    mount -L "$label" "$mountpoint" -o rw
    echo "$mountpoint"
    ;;
  umount)
    if mountpoint -q "$mountpoint"; then
      umount "$mountpoint"
    fi
    rmdir "$mountpoint" 2>/dev/null || true
    ;;
  *)
    echo "Bad action (mount|umount only)" >&2
    exit 1
    ;;
esac
