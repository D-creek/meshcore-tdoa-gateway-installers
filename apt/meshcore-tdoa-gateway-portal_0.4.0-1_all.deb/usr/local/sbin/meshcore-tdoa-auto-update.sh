#!/bin/bash
# MeshCore TDOA gateway-portal auto-update. Fires every 6h from
# meshcore-tdoa-auto-update.timer. Best-effort:
#  - Other repos (chirpstack, armbian) failing does NOT abort our
#    package upgrade — we apt-get update ONLY our sources.list.d entry.
#  - Acts on meshcore-tdoa-gateway-portal (+ -bridge if it later
#    splits out as its own deb). System-wide unattended-upgrades
#    stays untouched.
#  - Status (last-run state + installed version + error excerpt) is
#    written to /run/meshcore-tdoa/auto-update.json so the portal
#    can surface it later.
#  - Exit code is always 0 on a transient apt failure so the timer
#    keeps retrying every 6 h. Logs go to journald (StandardOutput=
#    journal in the .service unit) AND to /var/log/meshcore-tdoa-
#    auto-update.log for a stable on-disk artefact.
set -u

export DEBIAN_FRONTEND=noninteractive
PKGS=(meshcore-tdoa-gateway-portal meshcore-tdoa-gateway-bridge)
# install.sh writes meshcore-tdoa-gateway.list; an older bootstrap path
# used meshcore-tdoa.list. Accept either so fleet Pis bootstrapped
# before the rename keep auto-updating.
LIST=""
for candidate in /etc/apt/sources.list.d/meshcore-tdoa-gateway.list \
                  /etc/apt/sources.list.d/meshcore-tdoa.list; do
  if [ -f "$candidate" ]; then
    LIST="$candidate"
    break
  fi
done
STATUS_DIR=/run/meshcore-tdoa
STATUS_FILE=$STATUS_DIR/auto-update.json
LOG=/var/log/meshcore-tdoa-auto-update.log

mkdir -p "$STATUS_DIR"

# 0.3.20: respect the operator's portal-side toggle. The portal
# writes AUTO_UPDATE=on|off to portal.env via POST /api/auto-update/
# toggle. If set to "off" we exit cleanly without touching apt — the
# 6h timer keeps firing but does nothing until the operator flips it
# back. Default (unset / empty / any other value) is treated as "on"
# so existing fleets without the env var keep upgrading.
if [ -f /etc/meshcore-tdoa-gateway-portal/portal.env ]; then
  # shellcheck disable=SC1091
  source /etc/meshcore-tdoa-gateway-portal/portal.env 2>/dev/null || true
fi
if [ "${AUTO_UPDATE:-on}" = "off" ]; then
  write_status() {
    local state=$1 msg=$2
    local installed
    installed=$(dpkg-query -W -f='${Version}' meshcore-tdoa-gateway-portal 2>/dev/null || echo unknown)
    printf '{"state":"%s","at":"%s","msg":%s,"installed":"%s"}\n' \
      "$state" "$(date -u +%FT%TZ)" \
      "$(printf '%s' "$msg" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')" \
      "$installed" \
      > "$STATUS_FILE.tmp" && mv "$STATUS_FILE.tmp" "$STATUS_FILE"
  }
  write_status disabled "AUTO_UPDATE=off in portal.env; skipping. Re-enable via the portal UI or unset the var."
  exit 0
fi

write_status() {
  local state=$1 msg=$2
  local installed
  installed=$(dpkg-query -W -f='${Version}' meshcore-tdoa-gateway-portal 2>/dev/null || echo unknown)
  # Quote msg as a JSON string. python3 is a runtime dep of the portal
  # deb (postinst creates the venv with it), so always available here.
  printf '{"state":"%s","at":"%s","msg":%s,"installed":"%s"}\n' \
    "$state" "$(date -u +%FT%TZ)" \
    "$(printf '%s' "$msg" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')" \
    "$installed" \
    > "$STATUS_FILE.tmp" && mv "$STATUS_FILE.tmp" "$STATUS_FILE"
}

if [ -z "$LIST" ] || [ ! -f "$LIST" ]; then
  # ConditionPathExists in the .timer should prevent us from getting
  # here, but defend against a manual systemctl start without bootstrap.
  write_status not_bootstrapped "no apt source list under /etc/apt/sources.list.d/ — run install.sh first"
  exit 0
fi

# Targeted apt-get update — only refresh our sources.list.d entry.
# -o Dir::Etc::sourcelist + sourceparts=- isolates apt to JUST our list;
# unrelated repos (chirpstack, armbian) can be 404 / down without
# blocking our package upgrade.
if ! apt-get update \
     -o Dir::Etc::sourcelist="$LIST" \
     -o Dir::Etc::sourceparts="-" \
     -o APT::Get::List-Cleanup="0" >"$LOG" 2>&1; then
  write_status apt_update_failed "$(tail -c 2000 "$LOG")"
  exit 0
fi

# Filter PKGS to those actually known to apt — apt-get install -y aborts
# the whole transaction if ANY listed package is unknown, so a future
# split (e.g. meshcore-tdoa-gateway-bridge as its own deb) currently
# blocks the upgrade of the package that DOES exist. apt-cache policy
# prints `Candidate: (none)` for unknown packages; we keep only those
# with a real candidate.
INSTALLABLE=()
for p in "${PKGS[@]}"; do
  if apt-cache policy "$p" 2>/dev/null | grep -qE '^\s*Candidate:\s+[0-9]'; then
    INSTALLABLE+=("$p")
  fi
done

if [ "${#INSTALLABLE[@]}" -eq 0 ]; then
  write_status no_candidate "none of the configured packages have an apt candidate (${PKGS[*]})"
  exit 0
fi

# 0.3.101: split installed-vs-not. `--only-upgrade` upgrades what's already on
# the box but will NOT install a brand-new package (e.g. the bridge once it
# split out of the image-only era). So: upgrade installed ones, and plain-
# `install` any candidate that ISN'T installed yet — that's how an existing
# fleet node AUTO-MIGRATES to the new bridge package on the 6h tick. The
# bridge deb's own postinst then performs the bridge.yaml config-split.
UPGRADE=()
INSTALL_NEW=()
for p in "${INSTALLABLE[@]}"; do
  if dpkg-query -W -f='${Status}' "$p" 2>/dev/null | grep -q "install ok installed"; then
    UPGRADE+=("$p")
  else
    INSTALL_NEW+=("$p")
  fi
done

if [ "${#UPGRADE[@]}" -gt 0 ]; then
  if ! apt-get install --only-upgrade -y "${UPGRADE[@]}" >>"$LOG" 2>&1; then
    write_status install_failed "$(tail -c 2000 "$LOG")"
    exit 0
  fi
fi
if [ "${#INSTALL_NEW[@]}" -gt 0 ]; then
  if ! apt-get install -y "${INSTALL_NEW[@]}" >>"$LOG" 2>&1; then
    write_status install_failed "$(tail -c 2000 "$LOG")"
    exit 0
  fi
fi

write_status ok ""
