"""Per-port serial reader thread.

One :class:`SerialReader` instance owns one ``/dev/tty*`` port. It runs
in its own daemon thread, draining bytes through a :class:`FrameExtractor`
and handing every parsed :class:`TDOAFrame` off to a callback (the
publisher in production, a list-appender in tests).

Reconnect strategy mirrors ``services/collector/src/collector/usb.py``:
exponential backoff 1s → 30s with reset on every successful open. On
``stop()`` the thread joins within one read-timeout cycle.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable

import serial
import structlog

from .frame import AnyFrame, FrameExtractor, TDOAFrame  # noqa: F401
from .tcp_passthrough import TCPPassthrough

log = structlog.get_logger(__name__)

#: Read-chunk size handed to ``serial.Serial.read``. Sized for headroom
#: above a single 23-byte 0x90 frame plus adjacent log frames.
_READ_CHUNK_SIZE = 256

#: Reconnect backoff bounds (seconds).
_BACKOFF_INITIAL = 1.0
_BACKOFF_MAX = 30.0


FrameCallback = Callable[[str, AnyFrame], None]

#: Reported to the optional ``on_error`` callback as ``(port, kind, detail)``.
#: ``kind`` is one of the coarse health classes the portal renders as a
#: per-port badge (Erik #3): ``serial_error`` (open/read failed — incl. the
#: EPERM device-policy block), ``unavailable`` (unexpected reader fault), or
#: ``ok`` (a successful open cleared a prior error). The supervisor maps these
#: into status.json so the portal can explain *why* a device isn't producing.
ErrorCallback = Callable[[str, str, str], None]

#: errno → True when it's a permission/policy denial worth a remediation hint.
_EPERM = 1
_EACCES = 13


class SerialReader:
    """Owns one serial port and emits frames to a callback.

    Thread-safe to ``start()``/``stop()`` from any thread. The callback
    is invoked from the reader's own thread; production callers pass a
    paho-publish wrapper which is itself thread-safe.
    """

    def __init__(
        self,
        port: str,
        baud: int,
        on_frame: FrameCallback,
        *,
        read_timeout_seconds: float = 0.5,
        serial_factory: Callable[..., serial.Serial] | None = None,
        passthrough: TCPPassthrough | None = None,
        on_error: ErrorCallback | None = None,
    ) -> None:
        self._port = port
        self._baud = baud
        self._on_frame = on_frame
        self._on_error = on_error
        self._timeout = read_timeout_seconds
        self._serial_factory = serial_factory or serial.Serial
        self._stop_evt = threading.Event()
        self._thread: threading.Thread | None = None
        self._extractor = FrameExtractor()
        self._plog = log.bind(port=port, baud=baud)
        # Optional TCP-passthrough tee: when set, every chunk read off
        # the USB serial port is fanned out to any connected TCP
        # clients, AND the passthrough is bound to the live serial
        # handle so client-side writes get forwarded back to USB. The
        # SerialReader stays the sole owner of the serial port — no
        # interleave possible. See tcp_passthrough.py for design.
        self._passthrough = passthrough

    @property
    def port(self) -> str:
        return self._port

    @property
    def is_alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop_evt.clear()
        self._thread = threading.Thread(
            target=self._run,
            name=f"serial-reader-{self._port}",
            daemon=True,
        )
        self._thread.start()

    def stop(self, timeout: float = 2.0) -> None:
        self._stop_evt.set()
        thr = self._thread
        if thr is not None:
            thr.join(timeout)
        self._thread = None

    # ------------------------------------------------------------------
    # internals
    # ------------------------------------------------------------------

    def _report(self, kind: str, detail: str = "") -> None:
        """Best-effort per-port health report to the supervisor. A bad
        callback must never disturb the reader loop."""
        if self._on_error is None:
            return
        try:
            self._on_error(self._port, kind, detail)
        except Exception as exc:  # noqa: BLE001
            self._plog.warning("serial.on_error.callback_error", error=str(exc))

    def _run(self) -> None:
        backoff = _BACKOFF_INITIAL
        self._plog.info("serial.reader.start")
        try:
            while not self._stop_evt.is_set():
                try:
                    self._read_until_eof_or_error()
                    backoff = _BACKOFF_INITIAL
                except (serial.SerialException, OSError) as exc:
                    self._plog.warning(
                        "serial.error",
                        error=str(exc),
                        error_type=type(exc).__name__,
                        retry_in_seconds=backoff,
                    )
                    # Classify so the portal can show *why* this port has no
                    # frames. EPERM/EACCES (PermissionError, or OSError with
                    # those errnos) is the Erik-class device-policy block —
                    # the supportable case warranting a remediation hint.
                    errno = getattr(exc, "errno", None)
                    is_perm = isinstance(exc, PermissionError) or errno in (
                        _EPERM,
                        _EACCES,
                    )
                    detail = f"{type(exc).__name__}: {exc}"
                    self._report(
                        "serial_error",
                        ("permission denied — " + detail) if is_perm else detail,
                    )
                    if self._stop_evt.wait(backoff):
                        break
                    backoff = min(backoff * 2.0, _BACKOFF_MAX)
                except Exception as exc:  # noqa: BLE001 - never crash thread
                    self._plog.error(
                        "serial.unexpected.error",
                        error=str(exc),
                        error_type=type(exc).__name__,
                        retry_in_seconds=backoff,
                    )
                    self._report("unavailable", f"{type(exc).__name__}: {exc}")
                    if self._stop_evt.wait(backoff):
                        break
                    backoff = min(backoff * 2.0, _BACKOFF_MAX)
        finally:
            self._plog.info("serial.reader.stop")

    def _read_until_eof_or_error(self) -> None:
        """Open the port and drain it until EOF or an exception is raised."""
        # dsrdtr=False: do not assert DTR on open. On ESP32-S3 IDF5 native-USB
        # ports (USB JTAG/serial debug unit), a DTR assertion triggers a chip
        # reset into ROM download mode; suppressing it keeps the app running.
        ser = self._serial_factory(
            self._port, self._baud, timeout=self._timeout, dsrdtr=False
        )
        self._plog.info("serial.opened")
        # A successful open clears any prior serial_error for this port —
        # the portal badge flips back from "serial error" to healthy.
        self._report("ok", "")
        if self._passthrough is not None:
            # Bind the live serial handle so TCP clients can write back
            # to the USB device. set_serial(None) on close below.
            self._passthrough.set_serial(ser)
        try:
            while not self._stop_evt.is_set():
                chunk = ser.read(_READ_CHUNK_SIZE)
                if not chunk:
                    # No data within timeout — that's fine, just loop. We
                    # rely on read_timeout_seconds being short enough that
                    # ``stop()`` is responsive.
                    continue
                # Tee every USB chunk to any connected TCP clients
                # BEFORE feeding the extractor — fan-out latency is
                # then bounded by the chunk read cadence (sub-ms in
                # practice) rather than the frame extractor's work.
                if self._passthrough is not None:
                    self._passthrough.broadcast(chunk)
                frames = self._extractor.feed(chunk)
                for frame in frames:
                    try:
                        self._on_frame(self._port, frame)
                    except Exception as exc:  # noqa: BLE001
                        # Callback misbehaving must not kill the reader.
                        self._plog.error(
                            "frame.callback.error",
                            error=str(exc),
                            error_type=type(exc).__name__,
                        )

                # Quick sleep to avoid tight-spinning if the OS keeps
                # returning very small chunks. Sub-millisecond pause; not
                # observable to the upstream packet rate (max ~50 fps).
                if len(chunk) < 4:
                    time.sleep(0.001)
        finally:
            if self._passthrough is not None:
                self._passthrough.set_serial(None)
            try:
                ser.close()
            except Exception:  # noqa: BLE001 - best-effort cleanup
                pass
