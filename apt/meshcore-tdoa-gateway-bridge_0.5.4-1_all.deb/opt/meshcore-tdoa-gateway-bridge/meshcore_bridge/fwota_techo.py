"""Remote firmware-OTA flow for LilyGo T-Echo (nRF52840) receivers.

KAN-169. The T-Echo runs the Adafruit nRF52 BSP + bootloader; the runtime
application accepts a 5-byte companion-protocol command (CMD_ENTER_USB_DFU
followed by the ASCII token "dfu!") which sets ``GPREGRET=0x57`` and
resets into the bootloader. Once in the bootloader the same VID/PID is
re-enumerated by the host (the USB-CDC descriptor does NOT change between
app and bootloader on Adafruit nRF52 boards) so we cannot tell from the
descriptor alone whether the device is ready for nrfutil; we just kick
``adafruit-nrfutil dfu serial`` and let it own the bootloader-handshake.

Firmware-side decoder (verified against
``MeshCore/examples/companion_radio/MyMesh.cpp`` lines 2549-2550)::

    cmd_frame[0] == CMD_ENTER_USB_DFU      // = 65 = 0x41
    && len >= 5
    && memcmp(&cmd_frame[1], "dfu!", 4) == 0

The serial framing layer (``ArduinoSerialInterface.cpp``) consumes
``<`` + uint16_le length + payload for host→device frames, so the
bytes we send on the wire are::

    b"<" + b"\\x05\\x00" + b"\\x41" + b"dfu!"   ==  b"<\\x05\\x00\\x41dfu!"

Quirks handled:

* OPi USB-host occasionally falls into "device descriptor read/64,
  error -110" after a DFU and needs a host reboot to recover. We can't
  fix the kernel from here, but we cap nrfutil at 120 s and surface a
  ``failed_timeout`` result so the caller can alert / reboot instead of
  hanging forever.
* Adafruit nRF52 bootloader re-uses the runtime VID/PID, so descriptor
  matching is useless for "is bootloader yet?" — we just wait 5 s after
  the DFU trigger for re-enumeration and let nrfutil's own retry loop
  do the rest.
"""

from __future__ import annotations

import asyncio
import glob
import os
import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path

import serial
import structlog

log = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Wire-format constants
# ---------------------------------------------------------------------------

#: Companion-protocol command byte for "enter USB DFU mode". Matches
#: ``CMD_ENTER_USB_DFU`` in ``MeshCore/examples/companion_radio/MyMesh.cpp``.
CMD_ENTER_USB_DFU: int = 0x41

#: 4-byte ASCII confirmation token, defensive against stray writes.
DFU_CONFIRM_TOKEN: bytes = b"dfu!"

#: 5-byte payload: cmd + token.
DFU_PAYLOAD: bytes = bytes([CMD_ENTER_USB_DFU]) + DFU_CONFIRM_TOKEN

#: Full host→device frame: '<' + uint16_le(len) + payload. Compare against
#: ``ArduinoSerialInterface::checkRecvFrame`` for the decoder.
DFU_FRAME: bytes = b"<" + len(DFU_PAYLOAD).to_bytes(2, "little") + DFU_PAYLOAD

# Sanity check (cheap at import time — file is tiny and we want to catch any
# accidental constant drift before we ship a broken DFU frame to a device).
assert DFU_FRAME == b"<\x05\x00\x41dfu!", (
    f"DFU_FRAME constant drift: got {DFU_FRAME!r}"
)


# ---------------------------------------------------------------------------
# Result types — match fwota_v4.py shape (sibling task in flight)
# ---------------------------------------------------------------------------


class FlashState(StrEnum):
    """Terminal states for a flash attempt.

    The ``failed_*`` variants are intentionally fine-grained so the caller
    (or a Jira-bot follow-up) can distinguish "the device never accepted
    DFU" from "nrfutil chewed up the firmware" from "the USB stack hung".
    """

    SUCCESS = "success"
    FAILED_DFU_TRIGGER = "failed_dfu_trigger"
    FAILED_NRFUTIL = "failed_nrfutil"
    FAILED_TIMEOUT = "failed_timeout"
    FAILED_POST_FLASH_NO_HEARTBEAT = "failed_post_flash_no_heartbeat"
    FAILED_BAD_INPUT = "failed_bad_input"


@dataclass(slots=True)
class FlashResult:
    """Result of a single flash attempt.

    Mirrors the shape we expect from ``fwota_v4.py`` (sibling KAN ticket).
    If the sibling lands with a different field set, reconcile here — the
    public ``FlashResult`` name should remain so callers don't fork.
    """

    state: FlashState
    port: str
    fw_zip_path: str
    duration_seconds: float
    nrfutil_returncode: int | None = None
    nrfutil_stdout_tail: str = ""
    error: str | None = None
    log_lines: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.state is FlashState.SUCCESS


# ---------------------------------------------------------------------------
# Callback / collaborator types
# ---------------------------------------------------------------------------

#: Progress callback. The flasher calls this with human-readable status
#: lines; the caller typically routes them into a structlog field or a
#: Jira-comment buffer.
ProgressCallback = Callable[[str], None]

#: Async "has the port emitted a frame in the last N seconds?" predicate
#: — wired into the existing SerialReader by the caller. Returns True
#: when the receiver has produced any companion frame (0x90/0x92/0x94…)
#: more recently than ``within_seconds`` ago.
HeartbeatProbe = Callable[[str, float], Awaitable[bool]]


# ---------------------------------------------------------------------------
# Tuning constants (override via kwargs in tests)
# ---------------------------------------------------------------------------

#: How long to wait after sending the DFU trigger before invoking nrfutil.
#: 5 s gives the Adafruit bootloader time to enumerate.
_DEFAULT_REENUM_WAIT_S: float = 5.0

#: Hard cap on the nrfutil subprocess. Anything longer than this almost
#: certainly means the OPi USB-host has wedged (the descriptor-read -110
#: loop). Kill the process and surface ``failed_timeout``.
_DEFAULT_NRFUTIL_TIMEOUT_S: float = 120.0

#: Post-flash window during which we expect the freshly-booted firmware
#: to emit at least one companion frame (0x94 GATEWAY_INFO or a 0x90
#: RX). If nothing arrives in this window we still consider the flash
#: itself "completed" but flag it for human follow-up.
_DEFAULT_POST_FLASH_HEARTBEAT_S: float = 30.0

#: Bytes of nrfutil stdout to keep in the result. The Adafruit tool's
#: per-block progress chatter runs ~10 KB; we keep the tail so failure
#: diagnostics survive in the log without bloating MQTT/Jira payloads.
_NRFUTIL_STDOUT_TAIL_BYTES: int = 4096

#: Markers nrfutil prints when its DFU upload fails despite the CLI
#: exiting 0 — the Adafruit-nrfutil top-level catches NordicSemiException
#: (e.g. "Serial port could not be opened" when the bootloader port
#: disappeared during re-enumeration), prints a traceback, and returns
#: cleanly. We have to look at stdout content to distinguish actual
#: success from "Python exception swallowed by CLI". Bisect 2026-05-18
#: showed multiple "done" jobs that never actually flashed because of
#: this. If ANY of these substrings appears in the captured stdout tail
#: we treat the run as a failure regardless of returncode.
_NRFUTIL_FAILURE_MARKERS: tuple[str, ...] = (
    "Failed to upgrade target",
    "Serial port could not be opened",
    "NordicSemiException",
    "Target is not in DFU mode",
)

#: Marker nrfutil prints on a successful DFU transfer. If returncode is 0
#: AND none of the failure markers appear AND this marker IS present, we
#: trust the flash. If returncode is 0 but this marker is missing, we
#: fail-safe (the device probably stayed on the old firmware).
_NRFUTIL_SUCCESS_MARKER: str = "Device programmed"

#: Default DFU baud — the Adafruit nrfutil tool defaults to 115200 and
#: the firmware-side ArduinoSerialInterface doesn't care about baud over
#: USB-CDC anyway.
_DEFAULT_BAUD: int = 115200

#: Where the bridge mounts the Adafruit nRF52 bootloader's UF2 mass-
#: storage device. The bootloader auto-detects a freshly-written
#: ``.uf2`` file in this directory, validates the embedded family-id
#: + block headers, writes the firmware, and resets the chip — same
#: drag-and-drop flow a human would do from a desktop GUI.
_UF2_MASS_STORAGE_MOUNT: str = "/mnt/techoboot"

#: How long to wait after the DFU trigger for the TECHOBOOT mass-
#: storage device to enumerate. ~5 s is the typical window on the OPi
#: bridge; 30 s gives generous headroom for a slow USB host.
_UF2_DEVICE_DETECT_TOTAL_S: float = 30.0
_UF2_DEVICE_DETECT_POLL_S: float = 1.0

#: First 4 bytes of every UF2 file. UF2 magic ``0x0A324655`` is "UF2\n"
#: in little-endian order, which on disk is the ASCII bytes ``UF2\n``.
_UF2_MAGIC: bytes = b"UF2\n"


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


async def flash_techo(
    port: str,
    fw_zip_path: str,
    *,
    on_progress: ProgressCallback | None = None,
    heartbeat_probe: HeartbeatProbe | None = None,
    nrfutil_path: str = "adafruit-nrfutil",
    baud: int = _DEFAULT_BAUD,
    reenum_wait_seconds: float = _DEFAULT_REENUM_WAIT_S,
    nrfutil_timeout_seconds: float = _DEFAULT_NRFUTIL_TIMEOUT_S,
    post_flash_heartbeat_seconds: float = _DEFAULT_POST_FLASH_HEARTBEAT_S,
    serial_factory: Callable[..., serial.Serial] | None = None,
    subprocess_factory: Callable[..., Awaitable[asyncio.subprocess.Process]] | None = None,
    sleep: Callable[[float], Awaitable[None]] | None = None,
    clock: Callable[[], float] | None = None,
) -> FlashResult:
    """Flash a LilyGo T-Echo over USB-CDC + Adafruit nRF52 DFU.

    Steps:

    1. Open ``port`` (115200 baud by default), send the 8-byte DFU frame,
       close the port. The firmware sets ``GPREGRET=0x57`` and resets;
       the bootloader re-enumerates on the same VID/PID.
    2. Sleep ``reenum_wait_seconds`` (default 5 s) to give the kernel
       time to re-bind the CDC node.
    3. Invoke ``adafruit-nrfutil dfu serial -pkg <fw_zip_path> -p <port>
       -b <baud>`` as an asyncio subprocess; stream stdout through
       ``on_progress`` line-by-line.
    4. If nrfutil exits non-zero → ``FAILED_NRFUTIL``.
       If nrfutil never exits within ``nrfutil_timeout_seconds``
       → ``FAILED_TIMEOUT`` (and we kill the process). This catches
       the OPi descriptor-read -110 wedge.
    5. On success, optionally poll ``heartbeat_probe`` for up to
       ``post_flash_heartbeat_seconds`` to confirm the new firmware is
       emitting frames. Absence of a heartbeat is reported but the
       flash itself is still considered done; we return
       ``FAILED_POST_FLASH_NO_HEARTBEAT`` so the caller can decide
       whether to retry.
    """

    plog = log.bind(port=port, fw_zip=fw_zip_path, component="fwota_techo")
    log_lines: list[str] = []
    progress = _make_progress(plog, on_progress, log_lines)

    _sleep = sleep or asyncio.sleep
    _clock = clock or asyncio.get_event_loop().time

    started = _clock()

    # ---- input validation ----
    fw_path = Path(fw_zip_path)
    if not fw_path.is_file():
        progress(f"firmware zip not found: {fw_zip_path}")
        return FlashResult(
            state=FlashState.FAILED_BAD_INPUT,
            port=port,
            fw_zip_path=fw_zip_path,
            duration_seconds=_clock() - started,
            error=f"firmware zip not found: {fw_zip_path}",
            log_lines=log_lines,
        )

    # ---- step 1: send DFU trigger (skipped when chip is already in DFU) ----
    # If the Adafruit bootloader's TECHOBOOT mass-storage device is
    # already present, the chip is already in DFU — either because a
    # previous OTA left it there or because the dispatcher handed us
    # the bootloader's USB-CDC descriptor directly via
    # find_techo_dfu_port. The runtime-side DFU command handler is NOT
    # in the bootloader, so writing the trigger frame would fail with
    # a SerialException. Detect + skip.
    already_in_dfu = bool(glob.glob("/dev/disk/by-label/TECHOBOOT"))
    if already_in_dfu:
        progress("fwota.dfu.trigger.skipped_already_in_dfu")
    else:
        progress("fwota.dfu.trigger.start")
        try:
            _send_dfu_trigger(port, baud, serial_factory)
        except (serial.SerialException, OSError) as exc:
            plog.warning(
                "fwota.dfu.trigger.failed",
                error=str(exc),
                error_type=type(exc).__name__,
            )
            progress(f"fwota.dfu.trigger.failed: {exc}")
            return FlashResult(
                state=FlashState.FAILED_DFU_TRIGGER,
                port=port,
                fw_zip_path=fw_zip_path,
                duration_seconds=_clock() - started,
                error=str(exc),
                log_lines=log_lines,
            )
        progress("fwota.dfu.trigger.ok")

        # ---- step 2: wait for re-enumeration ----
        progress(f"fwota.reenum.wait seconds={reenum_wait_seconds:.1f}")
        await _sleep(reenum_wait_seconds)

    # ---- step 2b: descriptor-swap fix-up ----
    # 2026-05-29 / 2026-05-30: Some Adafruit nRF52 boards keep the same
    # USB VID/PID across runtime+bootloader, but several T-Echos
    # and RAK4631 variants flip the product
    # name. Observed pairs:
    #   - runtime ``usb-Nordic_NRF52_DK_<MAC>-if00``
    #     ↔ bootloader ``usb-LilyGo_T-Echo_v1_<MAC>-if00``
    #   - runtime ``usb-RAKwireless_WisCore_RAK4631_*_<HEX>-if00``
    #     ↔ different bootloader descriptor
    #
    # On those boards, the original ``port`` arg may no longer exist
    # after the DFU trigger and nrfutil fails to open it (silent rc=0
    # because adafruit-nrfutil catches the FileNotFoundError and prints
    # a traceback but exits clean).
    #
    # Self-heal by extracting the hwserial token from the input ``port``
    # and trying — in order of preference — the udev-shipped stable
    # symlink, the known LilyGo bootloader candidate, then a wildcard
    # scan of /dev/serial/by-id/. The stable hwserial symlink
    # (``/dev/meshcore/serial-<HEX>-if00``, shipped by
    # gateway-portal deb 0.3.21+) is preferred because it survives both
    # descriptors transparently; callers passing it benefit from the
    # ``Path(port).exists()`` early-out below.
    resolved_port = _resolve_post_dfu_port(port, progress)
    if resolved_port != port:
        port = resolved_port

    # ---- step 3: flash via the format-matching path ----
    # Auto-detect the firmware format. Adafruit nRF52 has TWO flash paths
    # exposed by the same bootloader:
    #   1. UF2 mass-storage: bootloader exposes a USB mass-storage device
    #      labelled TECHOBOOT; drop a .uf2 file in and it auto-flashes.
    #      This is the format the release script produces by default
    #      (``pio run -t create_uf2``) and what a human drag-and-drops
    #      from a desktop GUI.
    #   2. Serial DFU: ``adafruit-nrfutil dfu serial -pkg <zip>``. Needs
    #      a Nordic-style signed DFU zip (built via
    #      ``adafruit-nrfutil dfu genpkg`` from a .hex).
    # The dispatcher hands us whatever the puller stored — we sniff the
    # file magic and pick the right path.
    if _is_uf2_file(fw_path):
        progress("fwota.uf2.start")
        ok, err = await _flash_via_uf2_mass_storage(
            fw_path=fw_path,
            progress=progress,
            sleep=_sleep,
            clock=_clock,
        )
        if not ok:
            plog.error("fwota.uf2.failed", error=err)
            return FlashResult(
                state=FlashState.FAILED_NRFUTIL,
                port=port,
                fw_zip_path=fw_zip_path,
                duration_seconds=_clock() - started,
                error=err,
                log_lines=log_lines,
            )
        progress("fwota.uf2.ok")
        nrfutil_rc, nrfutil_tail, nrfutil_err = 0, "", None
    else:
        progress("fwota.nrfutil.start")
        nrfutil_rc, nrfutil_tail, nrfutil_err = await _run_nrfutil(
            nrfutil_path=nrfutil_path,
            port=port,
            fw_zip=fw_zip_path,
            baud=baud,
            timeout_seconds=nrfutil_timeout_seconds,
            progress=progress,
            subprocess_factory=subprocess_factory,
        )

    if nrfutil_err == "timeout":
        plog.error(
            "fwota.nrfutil.timeout",
            timeout_seconds=nrfutil_timeout_seconds,
        )
        return FlashResult(
            state=FlashState.FAILED_TIMEOUT,
            port=port,
            fw_zip_path=fw_zip_path,
            duration_seconds=_clock() - started,
            nrfutil_returncode=nrfutil_rc,
            nrfutil_stdout_tail=nrfutil_tail,
            error=f"adafruit-nrfutil hung past {nrfutil_timeout_seconds:.0f}s",
            log_lines=log_lines,
        )

    if nrfutil_rc != 0:
        plog.error(
            "fwota.nrfutil.nonzero",
            returncode=nrfutil_rc,
            stdout_tail=nrfutil_tail[-512:],
        )
        return FlashResult(
            state=FlashState.FAILED_NRFUTIL,
            port=port,
            fw_zip_path=fw_zip_path,
            duration_seconds=_clock() - started,
            nrfutil_returncode=nrfutil_rc,
            nrfutil_stdout_tail=nrfutil_tail,
            error=nrfutil_err or f"adafruit-nrfutil exited with {nrfutil_rc}",
            log_lines=log_lines,
        )

    silent_fail = _build_silent_fail_result(
        nrfutil_tail=nrfutil_tail,
        nrfutil_rc=nrfutil_rc,
        port=port,
        fw_zip_path=fw_zip_path,
        duration_seconds=_clock() - started,
        log_lines=log_lines,
        progress=progress,
        plog=plog,
    )
    if silent_fail is not None:
        return silent_fail

    progress("fwota.nrfutil.ok")

    # ---- step 4: post-flash heartbeat check ----
    if heartbeat_probe is None:
        # No probe wired — caller doesn't care about the heartbeat check
        # (e.g. unit tests / CI). Treat as success.
        plog.info("fwota.success.no_heartbeat_probe")
        return FlashResult(
            state=FlashState.SUCCESS,
            port=port,
            fw_zip_path=fw_zip_path,
            duration_seconds=_clock() - started,
            nrfutil_returncode=0,
            nrfutil_stdout_tail=nrfutil_tail,
            log_lines=log_lines,
        )

    progress(
        f"fwota.heartbeat.wait seconds={post_flash_heartbeat_seconds:.0f}"
    )
    heartbeat_ok = await _await_heartbeat(
        port=port,
        probe=heartbeat_probe,
        budget_seconds=post_flash_heartbeat_seconds,
        sleep=_sleep,
        clock=_clock,
    )

    if not heartbeat_ok:
        plog.warning(
            "fwota.heartbeat.missing",
            window_seconds=post_flash_heartbeat_seconds,
        )
        progress("fwota.heartbeat.missing")
        return FlashResult(
            state=FlashState.FAILED_POST_FLASH_NO_HEARTBEAT,
            port=port,
            fw_zip_path=fw_zip_path,
            duration_seconds=_clock() - started,
            nrfutil_returncode=0,
            nrfutil_stdout_tail=nrfutil_tail,
            error=(
                f"no companion frame seen within "
                f"{post_flash_heartbeat_seconds:.0f}s of nrfutil success"
            ),
            log_lines=log_lines,
        )

    progress("fwota.heartbeat.ok")
    plog.info("fwota.success", duration_seconds=_clock() - started)
    return FlashResult(
        state=FlashState.SUCCESS,
        port=port,
        fw_zip_path=fw_zip_path,
        duration_seconds=_clock() - started,
        nrfutil_returncode=0,
        nrfutil_stdout_tail=nrfutil_tail,
        log_lines=log_lines,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


#: Hex serial-token extractor. Matches the trailing ``_<HEX>-if<N>`` suffix
#: that every udev-renamed USB-CDC node has, whether the descriptor is
#: ``Nordic_NRF52_DK_62444E784607AE64-if00``,
#: ``LilyGo_T-Echo_v1_62444E784607AE64-if00``,
#: ``RAKwireless_WisCore_RAK4631_*_<HEX>-if00``, or the stable
#: ``/dev/meshcore/serial-62444E784607AE64-if00`` symlink the gateway-portal
#: deb ships. 12-16 hex char window matches both ESP32-S3 (12) and
#: nRF52840 chip-id (16) — kept consistent with fwota_dispatcher's
#: ``_RUNTIME_MAC_RE``.
_PORT_SERIAL_TOKEN_RE = re.compile(r"([0-9A-Fa-f]{12,16})-if\d+$")


def _resolve_post_dfu_port(port: str, progress: ProgressCallback) -> str:
    """Find the device node to hand to nrfutil after the DFU re-enum.

    On boards that keep the same USB descriptor across runtime+bootloader
    (most Adafruit nRF52), the original ``port`` still resolves and we
    return it unchanged. On boards that swap (T-Echo: Nordic_NRF52_DK
    ↔ LilyGo_T-Echo_v1; RAK4631 variants), the runtime by-id symlink is
    gone after the trigger and we have to look up the bootloader-side
    descriptor by hwserial token.

    Resolution order:

    1. If ``Path(port).exists()`` → return ``port``. Covers the stable
       hwserial path (``/dev/meshcore/serial-<HEX>-if00``) plus any
       same-descriptor board where the by-id symlink is still live.
    2. Extract the hwserial token from ``port``. If none, return
       ``port`` unchanged (let the existing error path fire).
    3. Try the stable hwserial symlink ``/dev/meshcore/serial-<TOKEN>-if00``
       — the gateway-portal deb 0.3.21+ ships a udev rule that creates
       this symlink for BOTH descriptor variants, so it survives the
       swap on every board the bridge has been deployed to.
    4. Try the known LilyGo bootloader descriptor
       ``/dev/serial/by-id/usb-LilyGo_T-Echo_v1_<TOKEN>-if00``.
    5. Wildcard scan ``/dev/serial/by-id/usb-*-if00`` for any node whose
       name contains the same hwserial token. Picks the first match
       (sorted for determinism) — covers RAK4631 + future variants
       without enumerating each descriptor pattern here.

    Falls through to the existing nrfutil error path if nothing matches.
    """
    if Path(port).exists():
        return port

    token_match = _PORT_SERIAL_TOKEN_RE.search(port)
    if token_match is None:
        progress(
            f"fwota.port_resolve.no_token port={port} "
            "(cannot self-heal descriptor swap)"
        )
        return port
    token = token_match.group(1)

    stable_symlink = f"/dev/meshcore/serial-{token}-if00"
    if Path(stable_symlink).exists():
        progress(
            f"fwota.port_resolve.stable_symlink runtime_gone={port} "
            f"resolved={stable_symlink}"
        )
        return stable_symlink

    lilygo_dfu = f"/dev/serial/by-id/usb-LilyGo_T-Echo_v1_{token}-if00"
    if Path(lilygo_dfu).exists():
        progress(
            f"fwota.port_resolve.lilygo_dfu runtime_gone={port} "
            f"resolved={lilygo_dfu}"
        )
        return lilygo_dfu

    # Last-resort wildcard scan — covers RAK4631 and any future
    # descriptor flip we haven't pattern-matched yet.
    for cand in sorted(glob.glob("/dev/serial/by-id/usb-*-if00")):
        if token in cand:
            progress(
                f"fwota.port_resolve.wildcard runtime_gone={port} "
                f"resolved={cand}"
            )
            return cand

    progress(
        f"fwota.port_resolve.no_match runtime_gone={port} token={token} "
        "(falling through to nrfutil error path)"
    )
    return port


def _make_progress(
    plog: structlog.stdlib.BoundLogger,
    on_progress: ProgressCallback | None,
    log_lines: list[str],
) -> ProgressCallback:
    """Wrap the user-supplied callback so every line is also logged."""

    def emit(line: str) -> None:
        log_lines.append(line)
        plog.info("fwota.progress", line=line)
        if on_progress is not None:
            try:
                on_progress(line)
            except Exception as exc:  # noqa: BLE001 - never let cb crash flow
                plog.warning(
                    "fwota.progress.callback.error",
                    error=str(exc),
                    error_type=type(exc).__name__,
                )

    return emit


def _send_dfu_trigger(
    port: str,
    baud: int,
    serial_factory: Callable[..., serial.Serial] | None,
) -> None:
    """Open the port, write :data:`DFU_FRAME`, flush, close.

    Synchronous — the open/write/close pair is fast (<50 ms in practice)
    and pyserial has no asyncio binding. We call this from the async
    flow without offloading because it's well under one event-loop tick.
    """
    factory = serial_factory or serial.Serial
    ser = factory(port, baud, timeout=1.0)
    try:
        written = ser.write(DFU_FRAME)
        if written != len(DFU_FRAME):
            raise OSError(
                f"short write to {port}: wrote {written} of {len(DFU_FRAME)} bytes"
            )
        try:
            ser.flush()
        except Exception:  # noqa: BLE001 - best-effort; close drains too
            pass
    finally:
        try:
            ser.close()
        except Exception:  # noqa: BLE001 - best-effort
            pass


async def _run_nrfutil(
    *,
    nrfutil_path: str,
    port: str,
    fw_zip: str,
    baud: int,
    timeout_seconds: float,
    progress: ProgressCallback,
    subprocess_factory: Callable[..., Awaitable[asyncio.subprocess.Process]] | None,
) -> tuple[int | None, str, str | None]:
    """Run adafruit-nrfutil and stream stdout into ``progress``.

    Returns ``(returncode_or_None, stdout_tail, error_or_None)``. When the
    subprocess is killed for hanging past the deadline, ``error`` is the
    literal string ``"timeout"`` so the caller can distinguish it from a
    non-zero exit. ``returncode`` is ``None`` only on timeout.
    """
    factory: Callable[..., Awaitable[asyncio.subprocess.Process]]
    factory = subprocess_factory or asyncio.create_subprocess_exec

    argv = [
        nrfutil_path,
        "dfu",
        "serial",
        "-pkg",
        fw_zip,
        "-p",
        port,
        "-b",
        str(baud),
    ]
    progress(f"fwota.nrfutil.exec argv={' '.join(argv)}")

    try:
        proc = await factory(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
    except FileNotFoundError as exc:
        return None, "", f"nrfutil binary not found: {exc}"

    tail_buf: bytearray = bytearray()

    async def _drain() -> None:
        assert proc.stdout is not None
        while True:
            line = await proc.stdout.readline()
            if not line:
                return
            decoded = line.decode("utf-8", errors="replace").rstrip()
            progress(f"nrfutil: {decoded}")
            tail_buf.extend(line)
            if len(tail_buf) > _NRFUTIL_STDOUT_TAIL_BYTES * 2:
                # Keep at most ~2x the cap so the slice below stays cheap.
                del tail_buf[:-_NRFUTIL_STDOUT_TAIL_BYTES]

    drain_task = asyncio.create_task(_drain())
    try:
        rc = await asyncio.wait_for(proc.wait(), timeout=timeout_seconds)
    except TimeoutError:
        # OPi USB-host wedge or a genuine nrfutil hang. Kill & report.
        progress("fwota.nrfutil.timeout.kill")
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        # Give the kill 5 s to land then move on regardless.
        try:
            await asyncio.wait_for(proc.wait(), timeout=5.0)
        except TimeoutError:
            pass
        drain_task.cancel()
        try:
            await drain_task
        except (asyncio.CancelledError, Exception):  # noqa: BLE001
            pass
        tail = bytes(tail_buf[-_NRFUTIL_STDOUT_TAIL_BYTES:]).decode(
            "utf-8", errors="replace"
        )
        return None, tail, "timeout"

    # Process finished — let the drainer finish reading what's queued.
    try:
        await drain_task
    except Exception as exc:  # noqa: BLE001
        progress(f"fwota.nrfutil.drain.error: {exc}")

    tail = bytes(tail_buf[-_NRFUTIL_STDOUT_TAIL_BYTES:]).decode(
        "utf-8", errors="replace"
    )
    return rc, tail, None


def _detect_nrfutil_silent_fail(nrfutil_tail: str) -> str | None:
    """Inspect captured nrfutil stdout for a silent failure.

    adafruit-nrfutil's CLI catches NordicSemiException at the top level,
    prints a traceback, and exits 0. Without a stdout-content check the
    dispatcher would mark every such ghost-flash as ``done`` even though
    the device kept running the OLD firmware.

    Returns a human-readable reason string when the run looks silently-
    failed, or ``None`` when the stdout indicates a real success — or
    when the tail is empty, which means nrfutil never ran in this attempt
    (e.g. the UF2-dragdrop fallback path took over before nrfutil was
    invoked). Empty tail → no opinion → ``None`` so we don't mark a
    UF2-dragdrop success as a false-positive failure.
    """
    if not nrfutil_tail.strip():
        return None
    failure_marker = next(
        (m for m in _NRFUTIL_FAILURE_MARKERS if m in nrfutil_tail), None
    )
    if failure_marker is not None:
        return f"nrfutil exited 0 but stdout contains '{failure_marker}'"
    if _NRFUTIL_SUCCESS_MARKER not in nrfutil_tail:
        return (
            "nrfutil exited 0 but stdout did not contain the "
            f"'{_NRFUTIL_SUCCESS_MARKER}' success marker"
        )
    return None


def _build_silent_fail_result(
    *,
    nrfutil_tail: str,
    nrfutil_rc: int | None,
    port: str,
    fw_zip_path: str,
    duration_seconds: float,
    log_lines: list[str],
    progress: ProgressCallback,
    plog: structlog.stdlib.BoundLogger,
) -> FlashResult | None:
    """Return a FAILED_NRFUTIL FlashResult when nrfutil silently failed.

    Wraps :func:`_detect_nrfutil_silent_fail` with the logging + result-
    construction boilerplate so the orchestrator stays one-liner-shaped
    (cognitive complexity budget).
    """
    reason = _detect_nrfutil_silent_fail(nrfutil_tail)
    if reason is None:
        return None
    plog.error(
        "fwota.nrfutil.silent_fail",
        returncode=nrfutil_rc,
        reason=reason,
        stdout_tail=nrfutil_tail[-512:],
    )
    progress(f"fwota.nrfutil.silent_fail: {reason}")
    return FlashResult(
        state=FlashState.FAILED_NRFUTIL,
        port=port,
        fw_zip_path=fw_zip_path,
        duration_seconds=duration_seconds,
        nrfutil_returncode=nrfutil_rc,
        nrfutil_stdout_tail=nrfutil_tail,
        error=reason,
        log_lines=log_lines,
    )


def _is_uf2_file(path: Path) -> bool:
    """Detect a UF2 file by its 4-byte header magic.

    Every UF2 block starts with ``magicStart0 = 0x0A324655`` which is
    the ASCII bytes ``UF2\\n`` in little-endian order. Reading the first
    four bytes of the file is enough — even a multi-block UF2 starts
    with the same magic at offset 0.
    """
    try:
        with path.open("rb") as f:
            magic = f.read(4)
    except OSError:
        return False
    return magic == _UF2_MAGIC


async def _flash_via_uf2_mass_storage(
    *,
    fw_path: Path,
    progress: ProgressCallback,
    sleep: Callable[[float], Awaitable[None]],
    clock: Callable[[], float],
) -> tuple[bool, str]:
    """Drag-and-drop the UF2 into the Adafruit bootloader's mass-storage.

    After the DFU trigger has already set GPREGRET=0x57 and the chip
    has reset, the bootloader exposes a USB mass-storage device with
    volume label ``TECHOBOOT``. We:

      1. Poll ``/dev/disk/by-label/TECHOBOOT`` for up to ~30 s for it
         to appear (and udev to settle the symlink).
      2. Make sure the well-known mount point exists and mount the
         device there if not already mounted (idempotent).
      3. ``shutil.copyfile`` the UF2 to the mount.
      4. Best-effort ``umount`` — the bootloader auto-ejects when it
         starts writing the firmware anyway, so a busy-device return
         here is normal and silently ignored.

    Returns ``(ok, error_message)``.
    """
    deadline = clock() + _UF2_DEVICE_DETECT_TOTAL_S
    techoboot_dev: str | None = None
    while clock() < deadline:
        candidates = sorted(glob.glob("/dev/disk/by-label/TECHOBOOT"))
        if candidates:
            techoboot_dev = candidates[0]
            break
        await sleep(_UF2_DEVICE_DETECT_POLL_S)
    if techoboot_dev is None:
        return False, (
            f"TECHOBOOT mass-storage device never appeared within "
            f"{_UF2_DEVICE_DETECT_TOTAL_S:.0f}s after DFU trigger"
        )
    progress(f"fwota.uf2.device_detected dev={techoboot_dev}")

    # All filesystem + subprocess work runs in worker threads via
    # asyncio.to_thread so we don't block the event loop while the
    # kernel does mount/copy/fsync. The actual operations are short
    # (~hundreds of ms each) but the rule is the rule.
    await asyncio.to_thread(os.makedirs, _UF2_MASS_STORAGE_MOUNT, exist_ok=True)
    already_mounted = await asyncio.to_thread(os.path.ismount, _UF2_MASS_STORAGE_MOUNT)
    if not already_mounted:
        mount_proc = await asyncio.create_subprocess_exec(
            "mount", techoboot_dev, _UF2_MASS_STORAGE_MOUNT,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        m_stdout, m_stderr = await mount_proc.communicate()
        post_mount_check = await asyncio.to_thread(os.path.ismount, _UF2_MASS_STORAGE_MOUNT)
        if mount_proc.returncode != 0 and not post_mount_check:
            err = (m_stderr or m_stdout).decode("utf-8", errors="replace").strip()
            return False, (
                f"mount {techoboot_dev} → {_UF2_MASS_STORAGE_MOUNT} failed: {err}"
            )

    dest = os.path.join(_UF2_MASS_STORAGE_MOUNT, "firmware.uf2")
    # The Adafruit bootloader's virtual MSC is sensitive to chunked
    # writes — ``shutil.copyfile`` (default 64 KiB block reads + writes)
    # trips an ENOSPC after the first block on some bootloader builds
    # because the virtual FAT doesn't have a contiguous extent to
    # extend into. A single-shot read + write of the whole binary
    # mirrors the desktop drag-and-drop semantics the bootloader is
    # actually designed for, and avoids the partial-write ENOSPC.
    #
    # EIO during write/fsync is EXPECTED: the bootloader yanks the
    # USB mass-storage device the moment it sees enough of the UF2
    # stream to identify + start writing the firmware (the kernel
    # reports EIO because the device disappeared out from under it).
    # That's not a failure — it's the bootloader doing its job. Treat
    # EIO as success and let the post-flash reenum check confirm the
    # chip boots.
    def _atomic_uf2_write() -> tuple[int, bool]:
        data = fw_path.read_bytes()
        fd = os.open(dest, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o644)
        eio_seen = False
        try:
            try:
                written = os.write(fd, data)
            except OSError as exc:
                if exc.errno == 5:  # EIO — bootloader yanked the MSC
                    eio_seen = True
                    written = len(data)
                else:
                    raise
            try:
                os.fsync(fd)
            except OSError as exc:
                if exc.errno == 5:
                    eio_seen = True
                else:
                    raise
        finally:
            try:
                os.close(fd)
            except OSError:
                pass
        return written, eio_seen

    try:
        bytes_written, eio_seen = await asyncio.to_thread(_atomic_uf2_write)
    except OSError as exc:
        if exc.errno == 5:
            # EIO at os.open is rarer but same root cause — bootloader
            # already gone. Best-effort success since the bootloader
            # had time to start consuming whatever was queued.
            await _async_umount_best_effort()
            progress(f"fwota.uf2.copied dest={dest} eio_at_open=true")
            return True, ""
        await _async_umount_best_effort()
        return False, f"copy to {dest} failed: {exc}"

    progress(
        f"fwota.uf2.copied dest={dest} bytes={bytes_written}"
        f"{' eio_during_write=true' if eio_seen else ''}"
    )
    # The bootloader auto-ejects on write; umount can fail with
    # "target busy" but that's harmless — the device just goes away as
    # the chip resets into the new firmware.
    await _async_umount_best_effort()
    return True, ""


async def _async_umount_best_effort() -> None:
    """Async best-effort umount; never raises."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "umount", _UF2_MASS_STORAGE_MOUNT,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.wait()
    except OSError:
        pass


async def _await_heartbeat(
    *,
    port: str,
    probe: HeartbeatProbe,
    budget_seconds: float,
    sleep: Callable[[float], Awaitable[None]],
    clock: Callable[[], float],
) -> bool:
    """Poll ``probe`` once per second until it returns True or budget runs out."""
    deadline = clock() + budget_seconds
    # First call: ask "any frame in the last budget seconds?". The probe
    # owns the time-window semantics (the bridge keeps a last-seen ts per
    # port already; the caller wires that in).
    while True:
        if await probe(port, budget_seconds):
            return True
        if clock() >= deadline:
            return False
        await sleep(1.0)
