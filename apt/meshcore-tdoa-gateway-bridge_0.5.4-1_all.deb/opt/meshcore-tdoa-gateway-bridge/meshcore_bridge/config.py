"""Config loader for ``meshcore-bridge``.

Reads ``/etc/meshcore-bridge/config.yaml`` (path overridable via
``--config``); falls back to defaults if a key is missing. We deliberately
do NOT use pydantic here — the bridge ships on a tiny Pi image and we
want zero dependencies beyond what's strictly required (paho-mqtt,
pyserial, structlog, PyYAML).
"""

from __future__ import annotations

import os
import socket
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

import yaml

from .lora_profiles import (
    DEFAULT_BANDWIDTH_HZ,
    DEFAULT_CODERATE,
    DEFAULT_FREQ_HZ,
    DEFAULT_SPREAD_FACTOR,
)


def _default_client_id() -> str:
    """Unique-per-Pi MQTT client id.

    MQTT brokers enforce unique client ids: two bridges sharing one id kick
    each other off ("session taken over"), so fresh gateways that all used the
    old static ``meshcore-bridge`` default were in a constant connect/disconnect
    war and their uplinks never landed (2026-06-07). Derive it from the hostname
    so each Pi is distinct out of the box; an explicit ``client_id`` in
    bridge.yaml still wins. Also restores the collector's
    ``last_reported_by`` → hostname convention (it strips this exact prefix).
    """
    host = (socket.gethostname() or "").strip() or "pi"
    return f"meshcore-bridge-{host}"


@dataclass(frozen=True)
class MQTTConfig:
    host: str = "127.0.0.1"
    port: int = 1883
    username: str | None = None
    password: str | None = None
    # 2026-06-07: default is "gateway", NOT "bridge". The homeprod collector
    # ONLY subscribes ``gateway/+/uplink`` — a gateway that publishes under the
    # old "bridge" default was silently dropped (never reached the fleet). This
    # was a fleet-wide split (testopi, observer Nordic, dbblinddb Heltec all
    # defaulted to "bridge"). "gateway" is now the standard so a fresh install
    # publishes where the server listens, out of the box.
    topic_prefix: str = "gateway"
    # Unique per Pi (hostname-derived) so fresh gateways don't collide on a
    # shared client id and kick each other off the broker. Explicit YAML wins.
    client_id: str = field(default_factory=_default_client_id)
    qos: int = 0
    # 2026-05-26: WSS+TLS opt-in. The legacy plain-TCP broker was retired;
    # the current prod target is a CF-fronted WSS+TLS broker on :443
    # (configured per-deployment via the mqtt: block, not hardcoded).
    # `transport` accepts "tcp" (default — backward-compatible) or
    # "websockets". `tls_enabled` calls paho's tls_set() with system
    # CAs (ca-certificates). `tls_insecure` disables hostname-check —
    # local-dev only, never against the internet.
    transport: str = "tcp"
    tls_enabled: bool = False
    tls_insecure: bool = False


@dataclass(frozen=True)
class SerialConfig:
    baud: int = 115200
    port_globs: tuple[str, ...] = ("/dev/ttyUSB*", "/dev/ttyACM*")
    rescan_interval_seconds: float = 10.0
    read_timeout_seconds: float = 0.5


@dataclass(frozen=True)
class LogConfig:
    level: str = "info"


@dataclass(frozen=True)
class LoRaConfig:
    """RF parameters the receiver was tuned to, attached to every uplink envelope.

    KAN-134. The 0x90 frame the firmware emits today does NOT carry the
    LoRa RF profile; the values are baked into the firmware build via
    ``platformio.ini`` macros. The bridge re-publishes them on every
    envelope so the legacy MQTT ingest path can populate the
    ``packet_receptions.{freq_hz,bandwidth_hz,spread_factor,coderate}``
    columns added by KAN-133.

    Defaults match MeshCore EU868 (see :mod:`.lora_profiles`). Override
    any of the four via environment variables:

    * ``BRIDGE_LORA_FREQ_HZ`` (int Hz)
    * ``BRIDGE_LORA_BW_HZ``   (int Hz; 125000 / 250000 / 500000)
    * ``BRIDGE_LORA_SF``      (int 5..12)
    * ``BRIDGE_LORA_CR``      (str; e.g. ``"4/5"``)

    Env vars take precedence over the YAML config so a deploy can
    override the profile without re-templating ``config.yaml``. An
    invalid env override is silently ignored — we log nothing here
    because config loading runs before structlog is configured; the
    bridge just falls back to the YAML / default value.
    """

    freq_hz: int = DEFAULT_FREQ_HZ
    bandwidth_hz: int = DEFAULT_BANDWIDTH_HZ
    spread_factor: int = DEFAULT_SPREAD_FACTOR
    coderate: str = DEFAULT_CODERATE


@dataclass(frozen=True)
class HardwareMetadata:
    """Operator-supplied hardware ground-truth for a gateway.

    The firmware reports MCU + LoRa-chip + has-GPS automatically via the
    0x94 frame, but the actual GPS module model, antenna details,
    oscillator type, PCB revision, and power source aren't runtime-
    detectable. Operators describe each USB port's hardware in the
    bridge ``config.yaml`` ``hardware:`` block; the bridge ships the
    matching block on every /info envelope so the collector can persist
    it on the gateway row.

    Every field is optional. ``None`` means "operator did not specify"
    — the collector's UPSERT uses COALESCE so prior good values aren't
    clobbered by a YAML that only sets a subset of fields.
    """
    gps_module: str | None = None      # e.g. "L76K", "ATGM336H", "u-blox MAX-M10S"
    gps_antenna: str | None = None     # e.g. "external-active", "internal-passive"
    lora_antenna: str | None = None    # free text — model + dBi
    sx1262_tcxo: str | None = None     # "TCXO" | "XTAL" | "unknown"
    power_source: str | None = None    # "USB-PC" | "USB-Adapter" | "bench-PSU-5V" | "LiPo"
    pcb_revision: str | None = None    # free text — e.g. "T-Echo v1.1"
    role: str | None = None            # "reference" | "under-test" | "production"
    notes: str | None = None           # long-form free text
    # The gateway node's full 32-byte (64-hex) MeshCore pubkey. The 0x90 /
    # 0x94 / 0x96 firmware frames only carry the first 6 bytes (node_id),
    # which is enough for routing but not for on8ar/mctomqtt envelopes
    # that index by the full pubkey. Operator declares it once per port
    # in bridge.yaml; the bridge ships it under ``meta.pubkey_hex`` so
    # downstream consumers (mesh-relay /status path, on8ar) don't have
    # to zero-pad the 6-byte node_id and hope.
    pubkey: str | None = None
    # 2026-05-24 — TCP passthrough: when set, the bridge opens a TCP
    # listener on this port that mirrors the USB-CDC byte stream
    # bidirectionally. MeshCore desktop / Android clients connect there
    # to chat with the node WITHOUT giving up the USB port (the bridge
    # stays the sole reader; chunks are tee'd to TCP after extraction).
    # None = passthrough disabled. Set via the portal toggle, which
    # edits this field in ``hardware:`` and restarts the bridge.
    tcp_passthrough_port: int | None = None
    # Interface the TCP-passthrough listener binds to. None or "127.0.0.1"
    # = loopback only (safest default; reach via SSH tunnel). "0.0.0.0"
    # = LAN-accessible. The listener has no auth, so a LAN-bound
    # listener exposes companion-protocol command access to anyone on
    # the network — opt-in only.
    tcp_passthrough_bind: str | None = None


@dataclass(frozen=True)
class BridgeConfig:
    mqtt: MQTTConfig = field(default_factory=MQTTConfig)
    serial: SerialConfig = field(default_factory=SerialConfig)
    log: LogConfig = field(default_factory=LogConfig)
    lora: LoRaConfig = field(default_factory=LoRaConfig)
    # Per-port hardware metadata keyed by USB port glob (the same
    # globs that ``serial.port_globs`` matches against). Lookup is
    # done at /info publish time by ``mqtt_publisher`` matching the
    # actual serial port path against each glob in insertion order.
    # Empty dict when no ``hardware:`` block is configured.
    hardware: dict[str, HardwareMetadata] = field(default_factory=dict)
    # 2026-05-28: secondary MQTT brokers — every uplink, info,
    # position, telemetry, and aux frame is published to ALL of these
    # IN PARALLEL with the primary ``mqtt`` broker. Use case: mirror the
    # packet stream to a second environment (e.g. a dev/staging broker)
    # without routing through the primary. Broker addresses are configured
    # per-deployment in ``secondary_mqtt_brokers:``, not hardcoded.
    # Failure on a secondary broker is logged but doesn't disrupt the
    # primary publish — the bridge stays useful even if a secondary is
    # down for maintenance. Empty list = single-broker behaviour.
    secondary_mqtt_brokers: tuple[MQTTConfig, ...] = field(default_factory=tuple)
    # 2026-05-31: GitHub PAT for fetching firmware-OTA blobs directly from
    # a private firmware release-asset API. Used by
    # FwOtaDispatcher.download_to_cache when the download_url points at
    # ``https://api.github.com/repos/<owner>/<repo>/releases/assets/<id>``.
    # Empty string disables auth (works for public-repo assets / anonymous
    # mirrors). Set in ``config.yaml`` via ``firmware_github_token: <PAT>``
    # OR override at runtime via the ``FIRMWARE_GITHUB_TOKEN`` env var.
    #
    # Why this lives in the bridge (not the api): GitHub Release assets
    # are the source of truth — there's no point proxying them through
    # the prod api host (would either need a public-bypass route or a
    # CF Access service-token round-trip). The bridge fetches direct
    # over its existing internet path with a read-scoped PAT.
    firmware_github_token: str = ""


def _coerce_mqtt(raw: dict[str, Any] | None) -> MQTTConfig:
    raw = raw or {}
    transport = str(raw.get("transport", MQTTConfig.transport)).lower()
    if transport not in ("tcp", "websockets"):
        raise ValueError(
            f"mqtt.transport must be 'tcp' or 'websockets', got {transport!r}"
        )
    tls_raw = raw.get("tls") or {}
    return MQTTConfig(
        host=str(raw.get("host", MQTTConfig.host)),
        port=int(raw.get("port", MQTTConfig.port)),
        username=raw.get("username") or None,
        password=raw.get("password") or None,
        topic_prefix=str(raw.get("topic_prefix", MQTTConfig.topic_prefix)),
        # Explicit YAML client_id wins; otherwise a unique hostname-derived
        # default (NOT the old static "meshcore-bridge" that caused fleet-wide
        # session-takeover collisions). field(default_factory=...) means there's
        # no class-attribute default to reference, so compute it here.
        client_id=(str(raw["client_id"]) if raw.get("client_id") else _default_client_id()),
        qos=int(raw.get("qos", MQTTConfig.qos)),
        transport=transport,
        # Accept either flat (`tls_enabled: true`) or nested
        # (`tls: { enabled: true }`) — matches the portal-device TOML
        # schema operators already know.
        tls_enabled=bool(
            raw.get("tls_enabled", tls_raw.get("enabled", MQTTConfig.tls_enabled))
        ),
        tls_insecure=bool(
            raw.get("tls_insecure", tls_raw.get("insecure", MQTTConfig.tls_insecure))
        ),
    )


def _coerce_serial(raw: dict[str, Any] | None) -> SerialConfig:
    raw = raw or {}
    globs = raw.get("port_globs") or list(SerialConfig.port_globs)
    if isinstance(globs, str):
        globs = [globs]
    return SerialConfig(
        baud=int(raw.get("baud", SerialConfig.baud)),
        port_globs=tuple(str(g) for g in globs),
        rescan_interval_seconds=float(
            raw.get("rescan_interval_seconds", SerialConfig.rescan_interval_seconds)
        ),
        read_timeout_seconds=float(
            raw.get("read_timeout_seconds", SerialConfig.read_timeout_seconds)
        ),
    )


def _coerce_log(raw: dict[str, Any] | None) -> LogConfig:
    raw = raw or {}
    return LogConfig(level=str(raw.get("level", LogConfig.level)))


#: Single source of truth for the MQTT credentials on the gateway Pi
#: (2026-06-07). The register script writes the per-gateway username+password
#: HERE, and the bridge + portal + mesh-relay all READ it — instead of each
#: keeping its own copy (which drifted: bridge.yaml vs portal-creds vs relay
#: env). Env-tunable for tests. ``bridge.yaml`` keeps host/port/prefix; only the
#: secret lives in this one file.
_MQTT_CREDS_FILE_DEFAULT = "/etc/meshcore-tdoa-gateway/mqtt-creds.env"


def _read_creds_file() -> tuple[str | None, str | None]:
    """Return (username, password) from the shared mqtt-creds.env, or
    (None, None) when the file is absent/unreadable/blank. Best-effort — a
    missing or malformed file must never crash the bridge (it falls back to the
    YAML creds). Parses simple ``KEY=value`` lines (ignores blanks/#comments)."""
    path = os.environ.get("MESHCORE_BRIDGE_MQTT_CREDS_FILE", _MQTT_CREDS_FILE_DEFAULT)
    try:
        with open(path, encoding="utf-8") as fh:
            kv: dict[str, str] = {}
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, _, v = line.partition("=")
                kv[k.strip()] = v.strip().strip('"').strip("'")
    except OSError:
        return None, None
    return (kv.get("MQTT_USERNAME") or None, kv.get("MQTT_PASSWORD") or None)


def _apply_creds_file(mqtt: MQTTConfig) -> MQTTConfig:
    """Override the MQTT username/password from the shared creds file when it
    provides them. Single source of truth wins over the YAML's (possibly stale)
    copy. No-op when the file is absent → YAML creds stand (backward compatible)."""
    user, pw = _read_creds_file()
    if user is None and pw is None:
        return mqtt
    return replace(
        mqtt,
        username=user if user is not None else mqtt.username,
        password=pw if pw is not None else mqtt.password,
    )


def _coerce_int_env(name: str, fallback: int) -> int:
    """Read an int env var, falling back silently on missing / malformed."""
    v = os.environ.get(name)
    if v is None or not v.strip():
        return fallback
    try:
        return int(v.strip())
    except ValueError:
        return fallback


def _coerce_str_env(name: str, fallback: str) -> str:
    """Read a non-empty str env var, falling back silently when blank."""
    v = os.environ.get(name)
    if v is None or not v.strip():
        return fallback
    return v.strip()


def _coerce_lora(raw: dict[str, Any] | None) -> LoRaConfig:
    """Build a :class:`LoRaConfig` from YAML + env overrides.

    Precedence: env var > YAML > module default. We do per-field
    coercion so a single bad value (e.g. typo'd ``BRIDGE_LORA_SF``)
    falls back to the YAML/default for that field without losing the
    other three.
    """
    raw = raw or {}
    yaml_freq = int(raw.get("freq_hz", DEFAULT_FREQ_HZ))
    yaml_bw = int(raw.get("bandwidth_hz", DEFAULT_BANDWIDTH_HZ))
    yaml_sf = int(raw.get("spread_factor", DEFAULT_SPREAD_FACTOR))
    yaml_cr = str(raw.get("coderate", DEFAULT_CODERATE))
    return LoRaConfig(
        freq_hz=_coerce_int_env("BRIDGE_LORA_FREQ_HZ", yaml_freq),
        bandwidth_hz=_coerce_int_env("BRIDGE_LORA_BW_HZ", yaml_bw),
        spread_factor=_coerce_int_env("BRIDGE_LORA_SF", yaml_sf),
        coderate=_coerce_str_env("BRIDGE_LORA_CR", yaml_cr),
    )


def _resolve_passthrough_bind(raw_bind: Any, allow_lan: bool) -> str | None:
    """Resolve a ``tcp_passthrough_bind`` value to a safe bind address.

    Loopback (127.0.0.1/::1) is returned as-is. A non-loopback bind
    (0.0.0.0/::) is only honoured when ``allow_lan`` (root opt-in); otherwise
    it's CLAMPED to 127.0.0.1 so the unauthenticated passthrough can't be
    LAN-exposed by the portal. Anything unrecognised → None (TCPPassthrough
    falls back to its 127.0.0.1 default).
    """
    if not isinstance(raw_bind, str):
        return None
    stripped = raw_bind.strip()
    if stripped in ("127.0.0.1", "::1"):
        return stripped
    if stripped in ("0.0.0.0", "::"):
        return stripped if allow_lan else "127.0.0.1"
    return None


def _coerce_hardware(
    raw: dict[str, Any] | None,
    *,
    allow_lan_passthrough: bool = False,
) -> dict[str, HardwareMetadata]:
    """Build the per-port hardware-metadata map from YAML.

    Accepts a mapping ``{port_glob: {field: value, ...}}``. Every field
    is optional; missing fields stay ``None``. Returns an empty dict
    when the YAML has no ``hardware:`` block or it isn't a mapping —
    the bridge keeps running with no operator metadata in that case.

    No env-var override path here (unlike :func:`_coerce_lora`): this
    metadata is genuinely per-port and not appropriate to set globally
    via the environment.

    ``allow_lan_passthrough`` (2026-06-06 security fix): the TCP passthrough
    is an UNAUTHENTICATED raw-USB command channel. A non-loopback bind
    (0.0.0.0/::) exposes every receiver to the LAN. The portal can write
    ``tcp_passthrough_bind`` via the overrides file, so by DEFAULT we clamp any
    non-loopback bind down to 127.0.0.1 — only a ROOT edit of the base config
    setting ``tcp_passthrough_allow_lan: true`` lets a non-loopback bind through.
    This stops the (LAN-reachable, unauthenticated) portal from unilaterally
    exposing the passthrough to the network.
    """
    if not isinstance(raw, dict):
        return {}
    out: dict[str, HardwareMetadata] = {}
    for port_glob, fields in raw.items():
        if not isinstance(fields, dict):
            # Skip entries that aren't mappings — log? defer to caller.
            continue
        # Validate tcp_passthrough_port — must be a sensible TCP port
        # number, else None. We don't want a YAML typo (e.g. a string)
        # to crash the bridge on startup; quietly drop invalid values.
        raw_tcp_port = fields.get("tcp_passthrough_port")
        tcp_port: int | None
        if isinstance(raw_tcp_port, int) and 1024 <= raw_tcp_port <= 65535:
            tcp_port = raw_tcp_port
        else:
            tcp_port = None
        tcp_bind = _resolve_passthrough_bind(
            fields.get("tcp_passthrough_bind"), allow_lan_passthrough
        )
        out[str(port_glob)] = HardwareMetadata(
            gps_module=_strornone(fields.get("gps_module")),
            gps_antenna=_strornone(fields.get("gps_antenna")),
            lora_antenna=_strornone(fields.get("lora_antenna")),
            sx1262_tcxo=_strornone(fields.get("sx1262_tcxo")),
            power_source=_strornone(fields.get("power_source")),
            pcb_revision=_strornone(fields.get("pcb_revision")),
            role=_strornone(fields.get("role")),
            notes=_strornone(fields.get("notes")),
            pubkey=_coerce_pubkey(fields.get("pubkey")),
            tcp_passthrough_port=tcp_port,
            tcp_passthrough_bind=tcp_bind,
        )
    return out


def _coerce_pubkey(v: Any) -> str | None:
    """Validate operator-supplied pubkey: 64 lowercase hex chars or None.

    Invalid input (wrong length / non-hex / empty) returns None and the
    bridge keeps publishing without the pubkey_hex meta field — better
    than shipping a malformed key downstream consumers would have to
    defensively parse. Logging is deferred to the caller so config-load
    failures aggregate in one place.
    """
    if v is None:
        return None
    s = str(v).strip().lower()
    if not s:
        return None
    if len(s) != 64:
        return None
    try:
        int(s, 16)
    except ValueError:
        return None
    return s


def _strornone(v: Any) -> str | None:
    """Coerce a YAML scalar to a non-empty str or None.

    YAML can produce ``None``, numbers, or empty strings depending on
    how the operator wrote the file. We normalise everything to
    "either a meaningful string or None" so downstream code can rely
    on the shape.
    """
    if v is None:
        return None
    s = str(v).strip()
    return s if s else None


def _merge_portal_overrides(data: dict, base_path: Path) -> None:
    """Merge the portal-writable ``bridge-overrides.yaml`` into ``data`` in place.

    Privilege separation (2026-06-06 security fix): the base config
    (``bridge.yaml``) is root-only 0600 and holds SECRETS (mqtt creds,
    firmware_github_token); the unprivileged portal must NOT write it. The few
    fields the portal mutates (per-port ``role`` + ``tcp_passthrough_*``) live
    in a sibling, portal-writable ``bridge-overrides.yaml`` (0664). Only that
    file's ``hardware`` block is merged — any mqtt/secondary/
    firmware_github_token keys in it are IGNORED, so a compromised/abused
    portal can never inject broker creds or a malicious firmware token into the
    root daemon. No-op if the overrides file is absent/unreadable/empty.
    """
    overrides_path = base_path.with_name("bridge-overrides.yaml")
    if not overrides_path.exists():
        return
    try:
        with overrides_path.open("r", encoding="utf-8") as fh:
            ovr = yaml.safe_load(fh) or {}
    except (OSError, yaml.YAMLError):
        return
    if not isinstance(ovr, dict) or not isinstance(ovr.get("hardware"), dict):
        return
    base_hw = data.get("hardware")
    if not isinstance(base_hw, dict):
        base_hw = {}
    # Per-glob merge: overrides supplement/replace fields on a matching port
    # entry (and add new entries), within the hardware namespace only.
    for glob, fields in ovr["hardware"].items():
        if not isinstance(fields, dict):
            continue
        entry = base_hw.get(glob)
        if isinstance(entry, dict):
            entry.update(fields)
        else:
            base_hw[glob] = dict(fields)
    data["hardware"] = base_hw


def load_config(path: str | Path | None = None) -> BridgeConfig:
    """Load + validate config.

    Args:
        path: Optional path to a YAML file. When ``None`` (or the file
            doesn't exist) returns all-defaults. Missing keys inside an
            otherwise-present file also default — the bridge is allowed
            to start with an empty config.
    """
    if path is None:
        # Even with no YAML on disk, env-var overrides for LoRa RF
        # params still apply (see :func:`_coerce_lora`), and the shared
        # mqtt-creds.env still supplies the broker creds (single source).
        return BridgeConfig(
            mqtt=_apply_creds_file(MQTTConfig()), lora=_coerce_lora(None)
        )

    p = Path(path)
    if not p.exists():
        return BridgeConfig(
            mqtt=_apply_creds_file(MQTTConfig()), lora=_coerce_lora(None)
        )

    with p.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    if not isinstance(data, dict):
        raise ValueError(
            f"config root must be a mapping; got {type(data).__name__} from {p}"
        )

    # Privilege separation (2026-06-06 security fix): merge the portal-writable
    # overrides file's ``hardware`` block over the root-only secrets base. See
    # :func:`_merge_portal_overrides`.
    _merge_portal_overrides(data, p)

    # secondary_mqtt_brokers: list of MQTT blocks identical in shape
    # to the top-level `mqtt:` one. None / missing / [] = no secondaries.
    sec_raw = data.get("secondary_mqtt_brokers") or []
    if not isinstance(sec_raw, list):
        raise ValueError(
            "secondary_mqtt_brokers must be a list of MQTT blocks"
        )
    secondaries = tuple(_coerce_mqtt(item) for item in sec_raw)

    # firmware_github_token: prefer env var (12-factor / systemd unit
    # ``Environment=FIRMWARE_GITHUB_TOKEN=...`` or operator secret file),
    # fall back to the YAML field for a self-contained config.
    gh_token = os.environ.get(
        "FIRMWARE_GITHUB_TOKEN",
        str(data.get("firmware_github_token") or "").strip(),
    )

    return BridgeConfig(
        # Single source of truth: the shared mqtt-creds.env overrides the YAML's
        # username/password when present (one place the secret lives on the Pi).
        mqtt=_apply_creds_file(_coerce_mqtt(data.get("mqtt"))),
        serial=_coerce_serial(data.get("serial")),
        log=_coerce_log(data.get("log")),
        lora=_coerce_lora(data.get("lora")),
        # allow_lan_passthrough is a ROOT-only base-config key (overrides only
        # merge the `hardware` block, so this can't be set via the portal).
        hardware=_coerce_hardware(
            data.get("hardware"),
            allow_lan_passthrough=bool(data.get("tcp_passthrough_allow_lan", False)),
        ),
        secondary_mqtt_brokers=secondaries,
        firmware_github_token=gh_token,
    )
