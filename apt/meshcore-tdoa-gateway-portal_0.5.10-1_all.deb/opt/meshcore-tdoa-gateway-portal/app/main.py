"""MeshCore TDOA gateway portal.

Per-USB-device MQTT broker configuration + receiver-health checks.

The Pi can have multiple LoRa receivers attached over USB CDC at the
same time (e.g. Heltec V4 + RAK4631 on the SkyPi today). Each one is
an independent gateway with its own:

  * gateway_name (display label, also pushed to the firmware later)
  * brokers list (the TOML mctomqtt-style fan-out)
  * receiver-health (GPS / PPS / drift)

Config layout on disk (one subdir per device, slug = a stable USB id):

  ${DEVICES_DIR}/
      heltec-v4/
          meta.json          {gateway_name, label, port_glob, ...}
          config.toml        mctomqtt-style broker fan-out for this device
      rak4631/
          meta.json
          config.toml

Devices are discovered by:
  (a) walking ${DEVICES_DIR} for already-configured devices, and
  (b) walking /dev/serial/by-id/ for USB-CDC devices not yet configured.
The latter only fires in PRODUCTION mode; test mode uses (a) alone so
the LXC can show a fully-populated UI without real USB hardware.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import random
import re
import socket
import struct
import subprocess
import time
from pathlib import Path
from typing import Any

import tomli
import tomli_w
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

ROOT = Path(__file__).resolve().parent

DEVICES_DIR = Path(
    os.environ.get(
        "DEVICES_DIR",
        "/opt/meshcore-tdoa-gateway/test-config/devices",
    )
)
SERIAL_BY_ID = Path(
    os.environ.get("SERIAL_BY_ID", "/dev/serial/by-id")
)
# 0.3.43: stable per-chip symlinks emitted by the meshcore-tdoa-udev-symlink
# helper. Keyed on the chip's hwserial so they survive the ESP32-S3
# app↔ROM-bootloader / nRF52 app↔DFU descriptor swap mid-flash.
# Parameterized so tests can point at a fixture dir.
MESHCORE_STABLE_DIR = Path(
    os.environ.get("MESHCORE_STABLE_DIR", "/dev/meshcore")
)
PRODUCTION = os.environ.get("PRODUCTION", "false").lower() == "true"

# v0.3.5: portal deb writes its own version to this file at install time
# (see debian/rules). Read once at module load — restart the unit to
# pick up a fresh version after a deb upgrade. Falls back to "dev" so
# source-runs (not from a deb) still surface a useful chip in the topnav.
PORTAL_VERSION_PATH = Path(
    os.environ.get(
        "PORTAL_VERSION_PATH",
        "/usr/share/meshcore-tdoa-gateway-portal/version.txt",
    )
)
try:
    PORTAL_VERSION = PORTAL_VERSION_PATH.read_text().strip() or "dev"
except OSError:
    # Missing path / unreadable / FS error — all fall through to "dev".
    PORTAL_VERSION = "dev"

# The systemd EnvironmentFile. The portal unit grants
# ReadWritePaths=/etc/meshcore-tdoa-gateway-portal, so the portal can
# persist operator-entered settings (e.g. the TDOA Observer email) back
# into it. The register + heartbeat scripts `source` this same file, so
# a value written here is picked up by the next heartbeat without a
# portal restart. Overridable for dev/tests.
PORTAL_ENV_PATH = Path(
    os.environ.get(
        "PORTAL_ENV_PATH",
        "/etc/meshcore-tdoa-gateway-portal/portal.env",
    )
)

# Homeprod base the gateway page links to so an operator can jump
# straight to the cloud My-Fleet view after entering their email.
HOMEPROD_BASE_URL = os.environ.get(
    "HOMEPROD_BASE_URL", "https://homeprod.dahllie.nl"
)

# Loose email sanity check — we only need to reject obvious garbage
# before persisting; the homeprod side is the real authority (it matches
# the value against an existing username). Deliberately permissive.
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _read_portal_env() -> dict[str, str]:
    """Parse PORTAL_ENV_PATH into a dict (KEY=VALUE, ignoring comments).

    Best-effort: a missing/unreadable file yields an empty dict so the
    GET endpoint still works on a dev box without the deb installed.
    """
    out: dict[str, str] = {}
    try:
        for raw in PORTAL_ENV_PATH.read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            out[key.strip()] = val.strip()
    except OSError:
        pass
    return out


def _write_portal_env_var(name: str, value: str) -> None:
    """Set (or clear) a single KEY=VALUE in PORTAL_ENV_PATH, IN PLACE.

    Preserves all other lines/comments. Rewrites an existing assignment if
    present, otherwise appends. The register/heartbeat scripts source the
    same file, so the next heartbeat carries the value with no portal
    restart needed.

    Written in place (not via a temp+rename) on purpose: the portal user
    can write the existing portal.env (postinst makes it group 0660) but the
    config DIR is root:group 0750 — no group write — so it can't CREATE a
    sibling ``portal.env.tmp`` (that raised Errno 13). The file is tiny, so
    a truncate+write is acceptable; this matches the auto-update toggle's
    in-place write.
    """
    try:
        existing = PORTAL_ENV_PATH.read_text().splitlines()
    except OSError:
        existing = []
    new_line = f"{name}={value}"
    out_lines: list[str] = []
    replaced = False
    for line in existing:
        if line.strip().startswith(f"{name}="):
            out_lines.append(new_line)
            replaced = True
        else:
            out_lines.append(line)
    if not replaced:
        out_lines.append(new_line)
    PORTAL_ENV_PATH.write_text("\n".join(out_lines) + "\n")


def _homeprod_action_log_url() -> str:
    """Derive .../api/gateways/action-log from the same REGISTER_URL base the
    register/heartbeat scripts use (so a per-host override carries over)."""
    base = (os.environ.get("REGISTER_URL") or "").strip()
    if base.endswith("/register"):
        return base[: -len("/register")] + "/action-log"
    return f"{HOMEPROD_BASE_URL}/api/gateways/action-log"


def log_gateway_action(
    action: str,
    target: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Best-effort: forward a gateway-portal action to homeprod's central
    action_log (source='gateway'). Per-Pi HTTP-Basic (bridge.yaml creds) +
    the same CF-Access service-token headers register/heartbeat send. Fired
    on a daemon thread so it never blocks or fails the operator action that
    triggered it; silently no-ops if the Pi isn't registered yet.

    Call from any portal action, e.g.:
        log_gateway_action("firmware.flash", slug, {"image": name})
    """
    import base64 as _b64
    import json as _json
    import threading
    import urllib.error
    import urllib.request

    def _send() -> None:
        try:
            doc = yaml.safe_load(_bridge_yaml_path().read_text(encoding="utf-8")) or {}
            mqtt = doc.get("mqtt", {}) if isinstance(doc, dict) else {}
            user = str(mqtt.get("username") or "").strip()
            pw = str(mqtt.get("password") or "").strip()
            if not user or not pw:
                return  # not registered yet — nothing to authenticate with
            headers = {"Content-Type": "application/json"}
            token = _b64.b64encode(f"{user}:{pw}".encode()).decode()
            headers["Authorization"] = f"Basic {token}"
            cf_id = (os.environ.get("CF_ACCESS_CLIENT_ID") or "").strip()
            cf_secret = (os.environ.get("CF_ACCESS_CLIENT_SECRET") or "").strip()
            if cf_id and cf_secret:
                headers["CF-Access-Client-Id"] = cf_id
                headers["CF-Access-Client-Secret"] = cf_secret
            body = _json.dumps(
                {"action": action, "target": target, "metadata": metadata}
            ).encode("utf-8")
            req = urllib.request.Request(
                _homeprod_action_log_url(), data=body, headers=headers, method="POST"
            )
            with urllib.request.urlopen(req, timeout=8):
                pass
        except Exception:  # noqa: BLE001 — telemetry is best-effort
            pass

    threading.Thread(target=_send, name="gw-action-log", daemon=True).start()


# ---------------------------------------------------------------------------
# Broker type registry — same as v0.1, fed straight to the modal pulldown.
# Adding a new broker type = one entry here.
# ---------------------------------------------------------------------------

BROKER_TYPES: dict[str, dict[str, Any]] = {
    # Pre-defined "projects" lead the dropdown — each carries an explicit
    # `protocol` so the Brokers tab classifies without guessing. Generic
    # templates (tcp/wss × auth/noauth) appear after, with `protocol: None`
    # so the add-broker form forces the operator to choose `tdoa` or
    # `mctomqtt` explicitly. Dict insertion order propagates to the UI.
    "meshcore-tdoa": {
        "label": "★ MeshCore TDOA (this project's own broker)",
        "protocol": "tdoa",
        "preset": {
            "server": "tdoa.dahllie.nl", "port": 1884, "transport": "tcp",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": False},
            "auth": {"method": "password", "username": "", "password": ""},
        },
        "user_fields": [
            ("server", "TDOA broker host", "text", True),
            ("port", "Port", "number", True),
            ("auth.username", "Username", "text", True),
            ("auth.password", "Password", "password", True),
        ],
    },
    "home-prod-wss": {
        "label": "Home Prod (WSS + TLS, TDOA format)",
        "protocol": "tdoa",
        "preset": {
            "server": "mqtt.dahllie.nl", "port": 443, "transport": "websockets",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": True, "verify": True},
            "auth": {"method": "password", "username": "", "password": ""},
        },
        "user_fields": [
            ("auth.username", "Username", "text", True),
            ("auth.password", "Password", "password", True),
        ],
    },
    "on8ar": {
        "label": "on8ar.eu (TCP, mctomqtt format)",
        "protocol": "mctomqtt",
        # 2026-05-29 0.3.55: ship the shared on8ar.eu credentials baked
        # into the preset. The on8ar project publishes a public
        # username + password for any mesh gateway that wants to fan
        # mesh traffic into emqx.on8ar.eu; previously every gateway had
        # to discover + type them by hand. Operator can still override
        # in the edit modal if a private account is preferred.
        "preset": {
            "server": "emqx.on8ar.eu", "port": 1883, "transport": "tcp",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": False},
            "auth": {
                "method": "password",
                "username": "meshcore_on8ar",
                "password": "RadioActive73",
            },
        },
        "user_fields": [
            ("auth.username", "Username", "text", True),
            ("auth.password", "Password", "password", True),
        ],
    },
    "cornmeister": {
        "label": "Cornmeister (TLS, mctomqtt format)",
        "protocol": "mctomqtt",
        # 2026-06-05: shared observer credentials baked in, same pattern as
        # on8ar — operator just toggles it on. TLS on (port 8883).
        "preset": {
            "server": "mqtt.cornmeister.nl", "port": 8883, "transport": "tcp",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": True, "verify": True},
            "auth": {
                "method": "password",
                "username": "observer",
                "password": "hiermetdiedata",
            },
        },
        "user_fields": [
            ("auth.username", "Username", "text", True),
            ("auth.password", "Password", "password", True),
        ],
    },
    "letsmesh-us": {
        "label": "LetsMesh US (WSS + token)",
        "protocol": "mctomqtt",
        "preset": {
            "server": "mqtt-us-v1.letsmesh.net", "port": 443, "transport": "websockets",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": True, "verify": True},
            "auth": {"method": "token", "audience": "mqtt-us-v1.letsmesh.net",
                     "owner": "", "email": ""},
        },
        "user_fields": [
            ("auth.owner", "Owner pubkey (64 hex)", "text", True),
            ("auth.email", "Account email", "text", True),
        ],
    },
    # DutchMeshCore collectors (2026-06-10). Same auth strategy as letsmesh:
    # WSS+TLS on :443, token auth (MeshCore-signed JWT minted from the device
    # pubkey+privkey), publish-only. Two collectors for redundancy — seed both
    # (disabled); the operator enables on a device that HAS a repeater identity
    # (pub_key + BRIDGE_REPEATER_PRIV_KEY) so the relay can mint the token.
    # audience mirrors letsmesh (= the collector host) as a starting point;
    # adjust if DutchMeshCore's verifier expects a different `aud`.
    "dutchmeshcore-1": {
        "label": "DutchMeshCore collector1 (WSS + token)",
        "protocol": "mctomqtt",
        "preset": {
            "server": "collector1.dutchmeshcore.nl", "port": 443, "transport": "websockets",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": True, "verify": True},
            "auth": {"method": "token", "audience": "collector1.dutchmeshcore.nl",
                     "owner": "", "email": ""},
        },
        "user_fields": [
            ("auth.owner", "Owner pubkey (64 hex)", "text", True),
            ("auth.email", "Account email", "text", True),
        ],
    },
    "dutchmeshcore-2": {
        "label": "DutchMeshCore collector2 (WSS + token)",
        "protocol": "mctomqtt",
        "preset": {
            "server": "collector2.dutchmeshcore.nl", "port": 443, "transport": "websockets",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": True, "verify": True},
            "auth": {"method": "token", "audience": "collector2.dutchmeshcore.nl",
                     "owner": "", "email": ""},
        },
        "user_fields": [
            ("auth.owner", "Owner pubkey (64 hex)", "text", True),
            ("auth.email", "Account email", "text", True),
        ],
    },
    # Generic templates — operator picks destination + protocol + auth.
    # `protocol: None` means the add-broker form MUST present a dropdown
    # and the operator must explicitly pick `tdoa` or `mctomqtt`.
    "tcp-noauth": {
        "label": "Custom: TCP, no auth",
        "protocol": None,
        "preset": {
            "server": "", "port": 1883, "transport": "tcp",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": False},
            "auth": {"method": "none"},
        },
        "user_fields": [
            ("server", "Server hostname / IP", "text", True),
            ("port", "Port", "number", True),
        ],
    },
    "tcp-userpass": {
        "label": "Custom: TCP, username + password",
        "protocol": None,
        "preset": {
            "server": "", "port": 1883, "transport": "tcp",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": False},
            "auth": {"method": "password", "username": "", "password": ""},
        },
        "user_fields": [
            ("server", "Server hostname / IP", "text", True),
            ("port", "Port", "number", True),
            ("auth.username", "Username", "text", True),
            ("auth.password", "Password", "password", True),
        ],
    },
    "wss-userpass": {
        "label": "Custom: WSS + TLS, username + password",
        "protocol": None,
        "preset": {
            "server": "", "port": 443, "transport": "websockets",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": True, "verify": True},
            "auth": {"method": "password", "username": "", "password": ""},
        },
        "user_fields": [
            ("server", "Server hostname", "text", True),
            ("port", "Port", "number", True),
            ("auth.username", "Username", "text", True),
            ("auth.password", "Password", "password", True),
        ],
    },
    "wss-noauth": {
        "label": "Custom: WSS + TLS, no auth",
        "protocol": None,
        "preset": {
            "server": "", "port": 443, "transport": "websockets",
            "keepalive": 60, "qos": 1, "retain": False,
            "tls": {"enabled": True, "verify": True},
            "auth": {"method": "none"},
        },
        "user_fields": [
            ("server", "Server hostname", "text", True),
            ("port", "Port", "number", True),
        ],
    },
    "tcp-tls-customtopic": {
        "label": "Custom: TCP + TLS, custom topic",
        "protocol": None,
        "preset": {
            "server": "", "port": 8883, "transport": "tcp",
            "keepalive": 60, "qos": 1, "retain": False,
            "custom_topic": "{PUBLIC_KEY}/packets",
            "tls": {"enabled": True, "verify": True},
            "auth": {"method": "none"},
        },
        "user_fields": [
            ("server", "Server hostname / IP", "text", True),
            ("port", "Port", "number", True),
            ("custom_topic", "Topic template ({PUBLIC_KEY}, {IATA})", "text", True),
        ],
    },
}


# ---------------------------------------------------------------------------
# Device discovery + meta.
# ---------------------------------------------------------------------------


def _slugify(s: str) -> str:
    """Stable slug derived from a USB serial-by-id path. Used as dirname."""
    s = re.sub(r"^usb-", "", s)
    s = re.sub(r"-if\d+$", "", s)
    s = re.sub(r"[^a-zA-Z0-9]+", "-", s).strip("-").lower()
    return s[:64]


def _discover_serial_devices() -> list[dict[str, Any]]:
    """List USB-CDC devices present on /dev/serial/by-id (production only)."""
    out = []
    if not SERIAL_BY_ID.exists():
        return out
    for entry in sorted(SERIAL_BY_ID.iterdir()):
        if not entry.is_symlink() and not entry.is_block_device():
            continue
        if not entry.name.startswith("usb-"):
            continue
        out.append({
            "by_id_name": entry.name,
            "slug": _slugify(entry.name),
            "tty": str(entry.resolve()) if entry.exists() else None,
        })
    return out


def _by_id_name_for_slug(slug: str) -> str | None:
    """Reverse-lookup: walk /dev/serial/by-id and find the path whose
    slugified basename matches ``slug``.

    Needed by _latest_bridge_info on hand-bootstrapped devices whose
    meta.json doesn't yet carry ``by_id_name`` (the journal scrape
    requires SOME by-id token to grep on). Cheap — _discover_serial_devices
    already lists them; this just filters.
    """
    if not SERIAL_BY_ID.exists():
        return None
    for d in _discover_serial_devices():
        if d.get("slug") == slug:
            return d.get("by_id_name")
    return None


def _device_dir(slug: str) -> Path:
    if not re.fullmatch(r"[a-z0-9-]+", slug):
        raise HTTPException(400, f"invalid device slug: {slug}")
    return DEVICES_DIR / slug


def _load_meta(slug: str) -> dict[str, Any]:
    p = _device_dir(slug) / "meta.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def _save_meta(slug: str, meta: dict[str, Any]) -> None:
    d = _device_dir(slug)
    d.mkdir(parents=True, exist_ok=True)
    (d / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")


def _config_path(slug: str) -> Path:
    return _device_dir(slug) / "config.toml"


#: Broker types that get pre-seeded onto every device as DISABLED
#: rows on first list_brokers() call. The operator just flips them on
#: in the UI when they want to opt in to a fan-out — no need to
#: re-discover the server hostname or topic template each time.
#:
#: Order = the order they appear in the broker list.
#: NOTE (2026-06-09): homeprod is intentionally NOT seeded here. The mesh-relay's
#: brokers are its EXTERNAL/legacy fan-out (on8ar/letsmesh); the BRIDGE already
#: publishes the TDOA stream to homeprod directly with real per-gateway creds.
#: Seeding a homeprod row into the relay config made the relay ALSO try homeprod
#: (with empty creds) -> a continuous connack_fail rc=5 loop + a duplicate failing
#: broker that the portal UI conflated with the healthy bridge->homeprod status.
#: Existing rows are stripped via _DEPRECATED_BROKER_NAMES below.
_DEFAULT_SEED_BROKERS: tuple[tuple[str, str], ...] = (
    # (broker_type_id, default_name)
    ("on8ar",           "on8ar"),
    ("letsmesh-us",     "letsmesh-us"),
    # 2026-06-10: DutchMeshCore collectors (seeded disabled; enable per-device).
    ("dutchmeshcore-1", "dutchmeshcore-1"),
    ("dutchmeshcore-2", "dutchmeshcore-2"),
)

#: Broker names that should be REMOVED from per-device config.toml on
#: next load. Used to clean up deprecated projects without forcing the
#: operator to delete rows by hand. Idempotent across releases — once
#: a row is gone, the next load is a no-op.
_DEPRECATED_BROKER_NAMES: frozenset[str] = frozenset({
    # 2026-05-29 0.3.48: meshrank.net dropped from default-supported
    # projects (operator request — no longer in scope as a default
    # destination). letsmesh-eu was a never-finalised EU regional
    # fan-out that left a stale row on early-bootstrapped Pis. Anyone
    # who really wants either can re-add manually via the generic
    # tcp-userpass / wss-userpass templates.
    "meshrank",
    "letsmesh-eu",
    # 2026-06-09: homeprod must NOT be a relay output broker — the bridge
    # publishes the TDOA stream to homeprod directly. A seeded homeprod row gave
    # the relay empty creds -> connack_fail rc=5 churn + a duplicate failing
    # broker in the portal UI. Strip it from existing config.toml on next load.
    "homeprod",
    "home-prod",
    "home-prod-wss",
})


def _strip_deprecated_brokers(cfg: dict[str, Any]) -> bool:
    """Drop any per-device broker rows whose name is in the deprecated
    set. Returns True iff at least one row was removed."""
    brokers = cfg.get("broker") or []
    keep = [b for b in brokers if b.get("name", "") not in _DEPRECATED_BROKER_NAMES]
    if len(keep) == len(brokers):
        return False
    cfg["broker"] = keep
    return True


def _seed_default_brokers(cfg: dict[str, Any]) -> bool:
    """Ensure every default broker is present in cfg["broker"] (disabled).

    Two passes:
    1. Add missing default-seed rows (matched by ``name`` or by
       ``server`` so renamed rows don't get duplicated).
    2. Top up EMPTY auth fields on existing matching rows from the
       preset. This catches the case where a gateway was seeded
       BEFORE the deb baked credentials into the preset (e.g. an
       on8ar row seeded in 0.3.49 with empty username/password, then
       0.3.55 baked the shared on8ar creds in — operator shouldn't
       have to edit + save the row by hand).

    Caller is responsible for ``_save_config`` when True. Idempotent:
    returns True iff we added or topped-up at least one row.
    """
    brokers = cfg.setdefault("broker", [])
    have_names = {b.get("name", "") for b in brokers}
    have_servers = {b.get("server", "") for b in brokers}
    changed = False
    # Pre-index existing rows by name + server so we can find the row
    # to top up in pass 2 without re-scanning the list per default.
    by_name = {b.get("name", ""): b for b in brokers}
    by_server = {b.get("server", ""): b for b in brokers if b.get("server")}
    for type_id, default_name in _DEFAULT_SEED_BROKERS:
        if type_id not in BROKER_TYPES:
            continue  # spec drift safety — silently skip unknown types
        spec = BROKER_TYPES[type_id]
        preset = spec.get("preset") or {}
        preset_server = preset.get("server", "")
        existing = by_name.get(default_name) or (
            by_server.get(preset_server) if preset_server else None
        )
        if existing is None:
            # Pass 1: row missing → add it disabled.
            seeded = dict(preset)
            seeded["name"] = default_name
            seeded["type"] = type_id
            seeded["enabled"] = False  # operator opts in
            seeded["protocol"] = spec.get("protocol")
            brokers.append(seeded)
            changed = True
            continue
        # Pass 2: row present but auth might be empty (older seed
        # without baked-in creds). Top up only the empty fields so
        # we never clobber an operator-set custom value.
        preset_auth = preset.get("auth") or {}
        existing_auth = existing.setdefault("auth", {})
        for k, v in preset_auth.items():
            if k == "method":
                existing_auth.setdefault(k, v)
                continue
            if v and not existing_auth.get(k):
                existing_auth[k] = v
                changed = True
    return changed


def _load_config(slug: str) -> dict[str, Any]:
    p = _config_path(slug)
    if not p.exists():
        # Fresh device: ship with default broker set pre-seeded so the
        # operator only has to flip on the ones they want.
        cfg: dict[str, Any] = {"general": {"iata": "MST"}, "broker": []}
        _seed_default_brokers(cfg)
        return cfg
    cfg = tomli.loads(p.read_text(encoding="utf-8"))
    # Existing device — two passes:
    #  1) strip any deprecated broker rows (meshrank, letsmesh-eu)
    #  2) top up any default brokers that aren't in the config yet
    #     (gateway registered before this deb, OR a default added in a
    #     newer release).
    # Persist on first sight so the config.toml on disk accurately
    # reflects the current seed + deprecation set; subsequent loads are
    # no-ops.
    dirty = _strip_deprecated_brokers(cfg)
    if _seed_default_brokers(cfg):
        dirty = True
    if dirty:
        try:
            _save_config(slug, cfg)
        except OSError:
            # First-load is read-only on some paths (admin tools dumping
            # config); fall through with the in-memory state.
            pass
    return cfg


def _save_config(slug: str, cfg: dict[str, Any]) -> None:
    # 0.3.63: every write guarantees the ``[repeater]`` block — the
    # vendored mesh-relay's RelayConfig.load needs name + pub_key for
    # per-device endpoint matching. Legacy Pis (testopi) bootstrapped
    # before any [repeater] writer existed are migrated on next save.
    _ensure_repeater_block_in_config_dict(cfg, slug)
    d = _device_dir(slug)
    d.mkdir(parents=True, exist_ok=True)
    _config_path(slug).write_text(tomli_w.dumps(cfg), encoding="utf-8")


def _bridge_yaml_pubkey_for_by_id(by_id_name: str | None) -> str | None:
    """Extract the ``hardware:<glob>::pubkey`` matching a USB-CDC by-id name.

    Mirrors the glob-matching pattern at :func:`_by_id_pattern_for_tty`
    but returns the ``pubkey`` field instead of the matching glob key.
    Returns the upper-case 64-char hex, or None if no entry matches /
    no pubkey is set. Used to seed ``[repeater].pub_key`` for the
    mesh-relay's per-endpoint topic substitution.
    """
    if not by_id_name:
        return None
    bridge_yaml = _bridge_yaml_path()
    if not bridge_yaml.is_file():
        return None
    try:
        import yaml
        doc = yaml.safe_load(bridge_yaml.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError):
        return None
    from fnmatch import fnmatchcase
    hardware = doc.get("hardware") or {}
    candidate = f"/dev/serial/by-id/{by_id_name}"
    for pat, entry in hardware.items():
        if not isinstance(entry, dict):
            continue
        if fnmatchcase(candidate, str(pat)):
            pk = entry.get("pubkey")
            if isinstance(pk, str) and pk.strip():
                return pk.strip().upper()
    return None


def _bridge_status_pubkey_for_by_id(by_id_name: str | None) -> str | None:
    """Auto-learned pubkey: read the bridge's status.json, which carries the V210
    self-pubkey (``pubkey_hex``) the firmware emits in its 0x94 frame.

    This is the robust, zero-operator-config source for ``[repeater].pub_key``
    (#2): once a device's firmware ships a V210 self-pubkey the bridge auto-learns
    it and writes it here, so the relay can match envelopes + expand {PUBLIC_KEY}
    topics without anyone hand-editing bridge.yaml. Returns the upper-case 64-hex
    pubkey, or None if not yet cached.
    """
    if not by_id_name:
        return None
    candidate = f"/dev/serial/by-id/{by_id_name}"
    for p in (
        Path("/run/meshcore-tdoa-gateway-bridge/status.json"),
        Path("/var/lib/meshcore-tdoa-gateway-bridge/status.json"),
        Path("/run/meshcore-bridge/status.json"),
    ):
        try:
            snap = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        ports = snap.get("ports") if isinstance(snap, dict) else None
        if not isinstance(ports, dict):
            continue
        for entry in ports.values():
            if not isinstance(entry, dict):
                continue
            port = str(entry.get("port") or "")
            if by_id_name in port or port == candidate:
                pk = entry.get("pubkey_hex")
                if isinstance(pk, str) and len(pk) == 64:
                    try:
                        int(pk, 16)
                        return pk.upper()
                    except ValueError:
                        pass
    return None


def _broker_auth_owner_pubkey(cfg: dict[str, Any]) -> str | None:
    """Last-resort pubkey: scan ``[[broker]].auth.owner`` for a 64-char
    hex string. Mirrors the relay's RelayConfig.load fallback at
    ``vendor/meshcore-mesh-relay/.../config.py:152-156`` so the seeded
    ``[repeater].pub_key`` matches what the relay would derive on its
    own.
    """
    for b in cfg.get("broker") or []:
        owner = ((b.get("auth") or {}).get("owner")) or ""
        if isinstance(owner, str) and len(owner) == 64:
            try:
                int(owner, 16)
            except ValueError:
                continue
            return owner.upper()
    return None


def _ensure_repeater_block_in_config_dict(cfg: dict[str, Any], slug: str) -> bool:
    """Backfill the ``[repeater]`` block from data the portal already has:
    ``meta.gateway_name`` for ``name``; ``bridge.yaml hardware:<glob>::
    pubkey`` (falling back to ``[[broker]].auth.owner``) for ``pub_key``.

    Returns True iff ``cfg`` was modified. Idempotent — short-circuits
    when both ``repeater.name`` and ``repeater.pub_key`` are populated.

    Source priorities for ``name``:
      1. ``meta.gateway_name`` (auto-synced from firmware ``node_name``
         post-0.3.60, or operator-set on legacy Pis)
      2. ``slug`` (last-resort — produces an ugly but unique name so
         per-endpoint matching at least doesn't collide between devices)

    Without this migration, a pre-0.3.63 ``config.toml`` without
    ``[repeater]`` falls through ``RelayConfig.load`` to
    ``repeater_name = "unknown-repeater"`` and the per-device endpoint
    matching in ``__main__.py::_route_envelope`` can't find the right
    DeviceEndpoint, dropping back to the synthetic ``primary`` endpoint
    with all devices' envelopes funneled together.
    """
    repeater = cfg.setdefault("repeater", {})
    have_name = bool((repeater.get("name") or "").strip())
    current_pk = (repeater.get("pub_key") or "").strip()
    # A stale "UNKNOWN" (or empty) is NOT a valid pubkey — re-migrate it. The older
    # code locked the first written value forever, so a device that only emitted
    # its V210 self-pubkey AFTER the first save stayed "UNKNOWN" indefinitely (#2).
    have_valid_pk = bool(current_pk) and current_pk.upper() != "UNKNOWN"
    if have_name and have_valid_pk and (repeater.get("type") or "").strip():
        return False

    meta = _load_meta(slug) or {}
    changed = False

    if not have_name:
        name = (meta.get("gateway_name") or "").strip() or slug
        if name != repeater.get("name"):
            repeater["name"] = name
            changed = True

    if not (repeater.get("type") or "").strip():
        repeater["type"] = "repeater"
        changed = True

    if not have_valid_pk:
        # Robust source order: operator-declared bridge.yaml > the bridge's
        # auto-learned V210 self-pubkey (status.json) > a token-auth broker owner.
        pk = (
            _bridge_yaml_pubkey_for_by_id(meta.get("by_id_name"))
            or _bridge_status_pubkey_for_by_id(meta.get("by_id_name"))
            or _broker_auth_owner_pubkey(cfg)
        )
        if pk and pk.upper() != current_pk.upper():
            repeater["pub_key"] = pk
            changed = True
        elif not pk and current_pk.upper() == "UNKNOWN":
            logger.warning(
                "repeater.pub_key.still_unknown slug=%s — device has not emitted a "
                "0x94 V210 self-pubkey yet, and no bridge.yaml / broker-owner pubkey "
                "is set (relay can't match this device's envelopes)",
                slug,
            )

    return changed


def _ensure_repeater_block_in_config(slug: str) -> str:
    """Slug-driven migration: load → mutate → save when dirty.

    Returns one of ``"backfilled"``, ``"already_valid"``,
    ``"save_failed"``, ``"skipped"``. Used by the startup hook.
    """
    try:
        cfg = _load_config(slug)
    except (OSError, ValueError):
        return "skipped"
    if not _ensure_repeater_block_in_config_dict(cfg, slug):
        return "already_valid"
    try:
        _save_config(slug, cfg)
    except OSError:
        return "save_failed"
    return "backfilled"


_RELAY_STATUS_PATH = Path("/run/meshcore-mesh-relay/status.json")
# Candidate systemd units for the TDOA bridge. testopi still ships the
# legacy ``meshcore-bridge.service`` name from the pre-0.3.x deb; skypi4
# and newer installs use ``meshcore-tdoa-gateway-bridge.service``. Probe
# both — the first one returning ``active`` wins. Order matters only as
# a fast-path: most Pis are on the new name.
_BRIDGE_UNIT_CANDIDATES = (
    "meshcore-tdoa-gateway-bridge.service",
    "meshcore-bridge.service",
)


def _load_relay_status() -> dict[str, dict[str, Any]]:
    """Read meshcore-mesh-relay status.json and return broker_name → snapshot.

    Returns an empty dict when the file doesn't exist (relay not running)
    or can't be parsed. We do NOT raise — the portal must keep rendering
    even when the relay is down (operator needs to see config).

    Degenerate-relay guard: if the relay is running but has never
    forwarded anything AND no broker has ever published successfully
    (e.g. testopi where the relay's input MQTT auth gets rc=5 in a
    loop), return empty so the caller falls through to the bridge-
    direct snapshot path. Otherwise we'd freeze publish_ok=0 forever
    on hosts where the bridge IS publishing fine on its own.
    """
    try:
        with _RELAY_STATUS_PATH.open("r") as fh:
            doc = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return {}
    brokers = doc.get("brokers", []) or []
    forwarded = int(doc.get("forwarded") or 0)
    if brokers and forwarded == 0 and all(
        int(b.get("publish_ok") or 0) == 0 for b in brokers
    ):
        return {}
    out: dict[str, dict[str, Any]] = {}
    for b in brokers:
        name = b.get("name")
        if name:
            out[name] = b
    return out


def _bridge_status_snapshot(broker_name: str | None = None) -> dict[str, Any]:
    """Best-effort liveness snapshot for brokers handled by the bridge directly.

    Two callers:

    1. **TDOA broker fallback** (no ``broker_name``) — the mesh-relay
       deliberately skips the TDOA broker (the bridge owns that
       connection); this returns connected=True if the bridge unit is
       active, ``publish_ok=0`` (we don't have a per-broker counter
       in the bridge process itself).

    2. **No-relay hosts** (``broker_name`` given, e.g. testopi where
       the relay is masked because it's redundant) — same liveness
       probe, PLUS we sum the sampler's ``bridge-direct`` rows for
       this broker over the last hour to give the UI a real number.

    Treats ``systemctl is-active meshcore-tdoa-gateway-bridge`` as the
    connection signal: bridge running ⇒ assume MQTT is up (the bridge
    auto-reconnects on disconnect and the unit goes inactive only on
    hard failure). Not a full health check — we don't see momentary
    disconnects — but matches the operator's mental model of "is the
    bridge running" without adding an MQTT probe.
    """
    last_state = "unknown"
    connected = False
    for unit in _BRIDGE_UNIT_CANDIDATES:
        try:
            r = subprocess.run(
                ["systemctl", "is-active", unit],
                capture_output=True, text=True, timeout=3,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
            return {"connected": False, "last_error": f"systemctl probe: {exc}"}
        state = (r.stdout or "").strip()
        if state == "active":
            connected = True
            break
        last_state = state
    if not connected:
        return {
            "connected": False,
            "publish_ok": 0,
            "publish_fail": 0,
            "last_publish_ok_at": None,
            "last_error": f"bridge unit {last_state}",
        }
    # Sum sampler bridge-direct rows for this broker (last hour).
    publish_ok = 0
    last_publish_ok_at: float | None = None
    if broker_name:
        since = int(time.time()) - 3600
        for row in _read_jsonl_since(_SAMPLER_BROKER_LOG, since):
            if row.get("name") != broker_name:
                continue
            d = int(row.get("delta_ok") or 0)
            if d <= 0:
                continue
            publish_ok += d
            ts = row.get("ts")
            if isinstance(ts, (int, float)):
                if last_publish_ok_at is None or ts > last_publish_ok_at:
                    last_publish_ok_at = float(ts)
    return {
        "connected": True,
        "publish_ok": publish_ok,
        "publish_fail": 0,
        "last_publish_ok_at": last_publish_ok_at,
        "last_error": None,
    }


def _list_devices() -> list[dict[str, Any]]:
    """Merge: configured devices on disk + USB-discovered devices not yet configured."""
    seen: dict[str, dict[str, Any]] = {}

    # (a) configured-on-disk
    if DEVICES_DIR.exists():
        for entry in sorted(DEVICES_DIR.iterdir()):
            if not entry.is_dir():
                continue
            slug = entry.name
            meta = _load_meta(slug)
            # Runtime-state cache (cheap meta.json read) — drives the
            # green/amber/red device-pill dot on the page so the operator
            # sees TDOA-fw + GPS health at a glance. Probed lazily by the
            # config-modal open handler; page-load never bridge-restarts.
            cached_runtime = _runtime_state_from_meta(slug)
            # 0.3.29 — pre-compute a hardware_id + human label so the
            # frontend pill can render "Heltec V4" instead of the
            # 60-char vendor slug. hardware_id comes from cached
            # bridge.info.published board string when available; falls
            # back to slug-pattern matching when not.
            hw_id = _device_hardware_id(slug)
            hw_label = _humanize_hardware_label(hw_id, slug)
            # gateway_name = operator/firmware node_name when set. If it was
            # never genuinely named (missing, empty, or auto-seeded to the raw
            # USB slug), use the friendly hardware label ("Heltec V4") instead
            # of the giant USB slug (Erik OPI 2026-06-06). A real operator name
            # or firmware node_name still wins.
            _gw = (meta.get("gateway_name") or "").strip()
            if not _gw or _gw == slug:
                _gw = hw_label
            seen[slug] = {
                "slug": slug,
                "gateway_name": _gw,
                "label": meta.get("label", slug),
                "by_id_name": meta.get("by_id_name"),
                "tty": meta.get("tty"),
                "configured": True,
                "tcp_proxy_enabled": bool(meta.get("tcp_proxy_enabled", False)),
                "tcp_proxy_port": int(meta.get("tcp_proxy_port") or 0) or None,
                # Operator-supplied free-text metadata (gear-modal panel).
                # Surfaced so the modal can pre-fill its inputs without a
                # second round-trip. Absent → None → renders blank.
                "role": meta.get("role"),
                "notes": meta.get("notes"),
                "gps_module": meta.get("gps_module"),
                "lora_antenna": meta.get("lora_antenna"),
                "power_source": meta.get("power_source"),
                "pcb_revision": meta.get("pcb_revision"),
                "sx1262_tcxo": meta.get("sx1262_tcxo"),
                "gps_antenna": meta.get("gps_antenna"),
                # Cached runtime state (None on cold path — UI renders grey
                # "unknown" dot then). Cheap read; the live probe happens
                # lazily on config-modal open.
                "runtime_state": cached_runtime,
                "has_tdoa_fw": _has_tdoa_fw(slug),
                # 0.3.29 — hardware identity surfaced for the pill UI.
                # ``hardware_id`` is the canonical slug used everywhere
                # (firmware/available filtering, flash-modes lookup).
                # ``hardware_label`` is the operator-facing short name
                # ("Heltec V4") — much friendlier than the USB-vendor
                # slug for pills + labels.
                "hardware_id": hw_id,
                "hardware_label": hw_label,
            }

    # (b) discovered via /dev/serial/by-id (PRODUCTION only — test mode
    # leans on the on-disk fixtures so the LXC can show a populated UI)
    if PRODUCTION:
        for d in _discover_serial_devices():
            slug = d["slug"]
            if slug in seen:
                # update tty path with current value
                seen[slug]["tty"] = d["tty"]
                seen[slug]["by_id_name"] = d["by_id_name"]
                seen[slug]["_discovered"] = True  # physically present on USB now
                continue
            # Dedupe the alternate USB identity (firmware vs DFU/bootloader) of
            # the SAME chip. A flash flips the product name on the same serial
            # (e.g. usb-Nordic_NRF52_DK_<S>  <->  usb-LilyGo_T-Echo_v1_<S>), and
            # the portal would otherwise onboard a 2nd phantom device whose
            # override glob the bridge then quarantines as a ghost port (the
            # echo-on-skypi4/testopi bench, 2026-06-09). Skip THIS identity iff
            # it reports no board (cand_hw is None — i.e. it's the bootloader,
            # which never emits bridge.info) AND a CONFIGURED device with the
            # same serial already exists under a different by-id. A device that
            # IS reporting a board is never skipped, so a live node can never be
            # deduped away (safe even with a leftover stale bootloader config).
            cand_hw = _device_hardware_id(slug)
            cand_serial = _hwserial_from_by_id(d["by_id_name"])
            if cand_serial and not cand_hw and any(
                e.get("configured")
                and e.get("by_id_name") != d["by_id_name"]
                and _hwserial_from_by_id(e.get("by_id_name")) == cand_serial
                for e in seen.values()
            ):
                logger.info(
                    "device.discovery.skip_alt_identity slug=%s by_id=%s hwserial=%s",
                    slug, d["by_id_name"], cand_serial,
                )
                continue
            seen[slug] = {
                "slug": slug,
                # Leave gateway_name EMPTY for an unconfigured/USB-discovered
                # device so the frontend falls back to the friendly
                # hardware_label ("Heltec V4") instead of showing the raw USB
                # slug. Defaulting to the slug here made every fresh node read
                # "espressif-systems-heltec-wifi-lora-32-v4-..." (Erik OPI
                # 2026-06-06). The operator/firmware node_name fills this in
                # once the device is configured.
                "gateway_name": "",
                "label": d["by_id_name"],
                "by_id_name": d["by_id_name"],
                "tty": d["tty"],
                "configured": False,
                # Resolve hardware even for UNCONFIGURED USB devices so a working
                # node that enumerates under a generic USB id shows its real
                # board. CRITICAL for the LilyGo T-Echo: it presents as
                # "Nordic_NRF52_DK" over USB, but the bridge's info.published
                # reports board="LilyGo T-Echo" — _device_hardware_id reads that
                # from the journal, so the T-Echo shows correctly instead of
                # "nordic-nrf52-dk-..." with no label (testopi 2026-06-06).
                "hardware_id": (_uhw := cand_hw),
                "hardware_label": _humanize_hardware_label(_uhw, slug) if _uhw else None,
                "tcp_proxy_enabled": False,
                "tcp_proxy_port": None,
            }

    # Per-port data freshness: how long since the bridge last got a packet
    # on each device's port. Lets the page dot flag a device whose port has
    # gone silent (USB present but no frames/telemetry — a wedged reader or
    # an unplugged-but-still-enumerated board) instead of showing it green.
    # Read the bridge snapshot ONCE here; do NOT call _bridge_status_for_slug
    # (it calls back into _list_devices → recursion).
    bridge_ports = _read_bridge_status().get("ports") or {}
    if bridge_ports:
        for dev in seen.values():
            dev["data_age_s"] = _port_last_packet_age_s(
                dev.get("by_id_name"), dev.get("tty"), bridge_ports
            )
            # node_id (the firmware node's identity) — shown on the pill as the
            # node name when the operator hasn't set one (operator 2026-06-06).
            dev["node_id"] = _port_node_id(
                dev.get("by_id_name"), dev.get("tty"), bridge_ports
            )
            # Per-port health (Erik #3): serial_error / quarantined /
            # unavailable / ok — lets the pill say *why* a port is silent
            # instead of a bare "no data". None when the bridge hasn't
            # reported a health class for this port yet.
            health, health_detail = _port_health(
                dev.get("by_id_name"), dev.get("tty"), bridge_ports
            )
            dev["health"] = health
            dev["health_detail"] = health_detail

    # Drop configured devices that are NOT currently connected, so a removed
    # receiver (e.g. PocV4 unplugged) stops showing — and never shows green off
    # a stale cached snapshot. "Connected" = discovered on /dev/serial/by-id
    # right now, OR a packet within the last 10 min (grace for USB flapping on
    # flaky hosts). PRODUCTION-only: test mode keeps the on-disk fixtures so the
    # dev LXC UI stays populated. USB-discovered (unconfigured) rows are present
    # by definition and never filtered.
    if PRODUCTION:
        _FRESH_S = 600
        for slug in list(seen):
            dev = seen[slug]
            if not dev.get("configured"):
                continue
            age = dev.get("data_age_s")
            connected = bool(dev.get("_discovered")) or (
                age is not None and age < _FRESH_S
            )
            if not connected:
                logger.info(
                    "device.list.hide_disconnected slug=%s data_age_s=%s "
                    "(not on /dev/serial/by-id, no recent packet)",
                    slug, age,
                )
                del seen[slug]

    return [
        {k: v for k, v in dev.items() if not k.startswith("_")}
        for dev in seen.values()
    ]


# ---------------------------------------------------------------------------
# Helpers — TOML field set/get with dotted paths.
# ---------------------------------------------------------------------------


def _set_dotted(d: dict[str, Any], path: str, value: Any) -> None:
    parts = path.split(".")
    cur = d
    for p in parts[:-1]:
        cur = cur.setdefault(p, {})
    cur[parts[-1]] = value


# --------------------------------------------------------------------------
# Broker classification is EXPLICIT-ONLY (2026-05-25 operator directive).
#
# A broker's `type` (UI dropdown bucket) is matched against BROKER_TYPES
# by (server, transport, auth-method, tls) shape. Its `protocol` field
# (tdoa | mctomqtt) is whatever the operator wrote into the TOML block —
# pre-defined projects inherit `protocol` from BROKER_TYPES at create
# time; manual additions require the operator to pick it in the form.
#
# Auto-detect (hostname heuristics, relay observation, topic-marker
# subscribe, retained-meta probe, legacy backfill) was removed. The
# Brokers tab now reflects exactly what's in the per-device config.toml.
# --------------------------------------------------------------------------


def _classify(
    broker: dict[str, Any],
    relay_status: dict[str, dict[str, Any]] | None = None,  # kept for signature compat
) -> str:
    """Match the broker block against BROKER_TYPES.

    Walks the registry in insertion order and returns the first entry
    whose `preset` matches the broker's (server, transport, auth.method,
    tls.enabled, port) shape. Falls back to a generic transport+auth
    bucket when no pre-defined project matches. Returns "unknown" when
    the broker doesn't fit any template at all.

    `relay_status` is no longer consulted; the parameter is kept so
    existing call sites (`_classify(broker, relay)`) don't need to be
    rewritten.
    """
    server = (broker.get("server") or "").lower()
    transport = (broker.get("transport") or "tcp").lower()
    auth_method = (broker.get("auth") or {}).get("method", "none")
    tls_on = bool(broker.get("tls", {}).get("enabled"))

    # First pass — match against PRE-DEFINED projects (server pinned in preset).
    for type_id, spec in BROKER_TYPES.items():
        preset = spec.get("preset", {})
        if not preset.get("server"):
            continue  # generic template, no server to match
        if (
            (preset.get("server") or "").lower() == server
            and (preset.get("transport") or "tcp").lower() == transport
        ):
            return type_id

    # Second pass — generic transport+auth bucket.
    if "custom_topic" in broker and tls_on:
        return "tcp-tls-customtopic"
    if transport == "tcp" and auth_method == "password":
        return "tcp-userpass"
    if transport == "tcp" and auth_method == "none":
        return "tcp-noauth"
    if transport == "websockets" and auth_method == "password":
        return "wss-userpass"
    if transport == "websockets" and auth_method == "none":
        return "wss-noauth"
    return "unknown"


# ---------------------------------------------------------------------------
# Pydantic schemas.
# ---------------------------------------------------------------------------


#: Per-broker payload protocol options. "tdoa" = our own TDOA-extended
#: JSON envelope. "mctomqtt" = legacy Cisien/meshcoretomqtt shape used
#: by on8ar, letsmesh. The operator picks ONE explicitly at
#: create time (pre-defined projects bake it in via BROKER_TYPES.protocol;
#: manual additions force a dropdown). "auto" is no longer accepted —
#: 2026-05-25 operator directive removed all auto-detect.
BROKER_PROTOCOLS = ("tdoa", "mctomqtt")


def _protocol_for_broker(b: dict[str, Any]) -> str:
    """Return the broker's explicit `protocol` field.

    Pre-defined projects (meshcore-tdoa, home-prod-wss, on8ar,
    letsmesh-us) get this baked in at create time via BROKER_TYPES.
    Manual additions force the operator to pick a value. Anything that
    somehow lacks the field falls back to "mctomqtt" (the safer default
    since on8ar / public brokers are the more common manual target).
    """
    explicit = (b.get("protocol") or "").lower().strip()
    if explicit in ("tdoa", "mctomqtt"):
        return explicit
    return "mctomqtt"


class BrokerCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(..., min_length=1, max_length=64)
    type: str
    # None = "use the type's default" — TDOA-protocol presets default
    # to enabled, every other preset defaults to disabled so a fresh
    # gateway only ships uplink to our own broker until the operator
    # opts in to a public fan-out (on8ar / letsmesh).
    enabled: bool | None = None
    fields: dict[str, str | int | float | bool] = Field(default_factory=dict)
    # Operator picks tdoa | mctomqtt at create time. Optional ONLY when
    # the chosen `type` is a pre-defined project that bakes a protocol
    # into BROKER_TYPES (e.g. `meshcore-tdoa` → "tdoa"); the create
    # endpoint resolves it from the registry in that case. Generic
    # types (tcp-userpass etc.) require this field.
    protocol: str | None = None


class BrokerProtocolUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    protocol: str = Field(..., description="tdoa | mctomqtt")


class BrokerStatus(BaseModel):
    """Live publish status for one broker, sourced from meshcore-mesh-relay.

    Read fresh on every list_brokers() call (no caching — the relay
    rewrites status.json every 5 s and the file is tiny, so re-reads are
    cheap and the UI gets near-real-time numbers).
    """
    connected: bool
    publish_ok: int = 0
    publish_fail: int = 0
    last_publish_ok_at: float | None = None  # unix epoch seconds
    last_error: str | None = None


class BrokerOut(BaseModel):
    name: str
    type: str
    enabled: bool
    server: str | None = None
    port: int | None = None
    transport: str | None = None
    auth_method: str | None = None
    raw: dict[str, Any]
    # tdoa-mesh-relay status. None means the relay isn't running OR this
    # broker name isn't in its snapshot (TDOA broker is deliberately
    # skipped by the relay — handled directly by the bridge).
    status: BrokerStatus | None = None
    # Effective wire-format protocol: "tdoa" (our own envelope) or
    # "mctomqtt" (Cisien/meshcoretomqtt-shaped). Resolved via
    # _protocol_for_broker() — explicit TOML `protocol` field wins over
    # the auto-classification.
    protocol: str = "mctomqtt"
    # True iff the value above came from auto-classify (no operator
    # override). Lets the UI render a hint like "auto" next to the
    # selector.
    protocol_auto: bool = True
    # True for system-managed rows the operator must NOT edit/delete/toggle
    # — currently the bridge-owned "TDOA export" row (destination + creds are
    # set at registration in the root-only bridge.yaml). The UI renders these
    # with a 🔒 badge and no edit/delete/toggle controls.
    read_only: bool = False


class GatewayNameUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    gateway_name: str = Field(..., min_length=1, max_length=64)


class ObserverEmailUpdate(BaseModel):
    # Empty string is allowed and means "clear it" (operator wants to
    # detach their email). Non-empty is validated as a plausible email.
    # No model_config/ConfigDict — the Pi's pydantic v1.10 would leak it
    # as a field (see GatewayConfigUpdate note below).
    email: str = Field("", max_length=254)


class GatewayConfigUpdate(BaseModel):
    """Operator-editable gateway config — the gear-icon modal's payload.

    Combines the per-device meta.json fields (gateway_name + free-text
    operator metadata) into a single save call so the UI can present
    them in one panel and persist atomically. All fields are optional
    so partial updates work — only supplied keys are written, NULL or
    missing keys leave the prior value alone.

    NOTE: we deliberately omit ``model_config = ConfigDict(...)``
    because the Pi runs pydantic v1.10 where ConfigDict isn't
    recognised as a config mechanism — it becomes a regular field and
    leaks into the JSON payload + meta.json. v1's ``class Config`` is
    the alternative but the extra-field guard isn't worth the
    cross-version branch.
    """

    gateway_name: str | None = Field(None, min_length=1, max_length=64)
    role: str | None = Field(None, max_length=64)
    # node_function — structured enum gating the firmware list. Distinct
    # from the freeform ``role`` chip (which is operator-typed and may
    # carry comma-separated multi-role labels). Required before the
    # Firmware section will offer images; the UI greys the firmware
    # selector and tells the operator to set it here first.
    # Values mirror the upstream MeshCore release tags
    # (companion-v*, repeater-v*, room-server-v*) plus tdoa_rx for the
    # TDOA-specific receiver build.
    node_function: str | None = Field(
        None, pattern=r"^(companion|repeater|room_server|tdoa_rx)$"
    )
    notes: str | None = Field(None, max_length=2000)
    gps_module: str | None = Field(None, max_length=64)
    lora_antenna: str | None = Field(None, max_length=64)
    power_source: str | None = Field(None, max_length=64)
    pcb_revision: str | None = Field(None, max_length=64)
    sx1262_tcxo: str | None = Field(None, max_length=64)
    gps_antenna: str | None = Field(None, max_length=64)


# ---------------------------------------------------------------------------
# FastAPI surface.
# ---------------------------------------------------------------------------

app = FastAPI(title="MeshCore TDOA Gateway", version="0.2.0")

# Structured logger — surfaces device-onboarding / probe failures in
# `journalctl -u meshcore-tdoa-gateway-portal` so issues like "device detected
# but no bridge.yaml hardware entry" are diagnosable instead of silent.
logger = logging.getLogger("meshcore-tdoa-gateway-portal")
if not logger.handlers:
    logging.basicConfig(level=logging.INFO)


@app.on_event("startup")
def _startup_backfill_repeater_blocks() -> None:
    """One-shot per-device migration: ensure every config.toml has a
    populated ``[repeater]`` block so the per-device-isolated
    mesh-relay (shipped 0.3.62) can match each envelope to its own
    DeviceEndpoint. Legacy Pis bootstrapped before any [repeater]
    writer existed (e.g. testopi on portal v0.3.3) would otherwise
    fall back to the synthetic ``primary`` endpoint with
    ``repeater_name="unknown-repeater"`` and lose per-device topic
    isolation on emqx.on8ar.eu / letsmesh / meshrank.

    Idempotent — devices that already have a populated block (skypi4)
    are a no-op.
    """
    if not PRODUCTION:
        return
    if not DEVICES_DIR.exists():
        return
    counts = {"backfilled": 0, "already_valid": 0, "save_failed": 0, "skipped": 0}
    for entry in DEVICES_DIR.iterdir():
        if not entry.is_dir():
            continue
        slug = entry.name
        # _device_dir guard catches malformed slugs; mirror its regex
        # check so we don't crash on a stray directory.
        if not re.fullmatch(r"[a-z0-9-]+", slug):
            counts["skipped"] += 1
            continue
        result = _ensure_repeater_block_in_config(slug)
        counts[result] = counts.get(result, 0) + 1
    print(
        f"[startup] repeater-block migration: "
        f"backfilled={counts['backfilled']} "
        f"already_valid={counts['already_valid']} "
        f"save_failed={counts['save_failed']} "
        f"skipped={counts['skipped']}",
        flush=True,
    )


_SAMPLER_BROKER_LOG = Path("/var/lib/meshcore-tdoa-gateway-portal/sampler/broker_samples.jsonl")
_SAMPLER_GPS_LOG = Path("/var/lib/meshcore-tdoa-gateway-portal/sampler/gps_samples.jsonl")
_SAMPLER_GPS_STATE = Path("/var/lib/meshcore-tdoa-gateway-portal/sampler/gps_last.json")


def _read_jsonl_since(path: Path, since_ts: int) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    try:
        with path.open("r", encoding="utf-8") as fh:
            for line in fh:
                try:
                    d = json.loads(line)
                except (ValueError, TypeError):
                    continue
                if d.get("ts", 0) >= since_ts:
                    out.append(d)
    except OSError:
        pass
    return out


@app.get("/api/broker-history")
def broker_history(hours: int = 24, bucket_minutes: int = 60) -> dict[str, Any]:
    """Per-broker exported-packet count over the last ``hours`` window.

    Buckets ``delta_ok`` from the sampler's broker_samples.jsonl into
    fixed-width time bins (default 60 min / 24 h = 24 bins per broker).
    Frontend renders a small inline bar per broker row.
    """
    now = int(time.time())
    since = now - hours * 3600
    bucket_s = max(60, int(bucket_minutes) * 60)
    rows = _read_jsonl_since(_SAMPLER_BROKER_LOG, since)
    # bucket key = bucket-start epoch
    per_broker: dict[str, dict[int, dict[str, int]]] = {}
    for r in rows:
        name = r.get("name")
        ts = int(r.get("ts") or 0)
        if not name or ts == 0:
            continue
        bucket = (ts // bucket_s) * bucket_s
        b = per_broker.setdefault(name, {}).setdefault(bucket, {"ok": 0, "fail": 0})
        b["ok"] += int(r.get("delta_ok") or 0)
        b["fail"] += int(r.get("delta_fail") or 0)
    # Materialise every bucket in the window so the UI sees zeros not gaps.
    # Bucket starts MUST be bucket-aligned (same `(ts // bucket_s) * bucket_s`
    # math the sample-aggregation step uses) — otherwise the lookup below
    # never matches the keys we stored. Bug found 2026-05-26 (all rows
    # serialised as 0 even though samples were accumulating).
    n_buckets = max(1, (hours * 3600) // bucket_s)
    end_bucket = (now // bucket_s) * bucket_s
    bucket_starts = [
        end_bucket - (n_buckets - 1 - i) * bucket_s for i in range(n_buckets)
    ]
    out: dict[str, list[dict[str, int]]] = {}
    for name, buckets in per_broker.items():
        series = []
        for bs in bucket_starts:
            cell = buckets.get(bs, {"ok": 0, "fail": 0})
            series.append({"ts": bs, "ok": cell["ok"], "fail": cell["fail"]})
        out[name] = series
    return {
        "since": since,
        "until": now,
        "bucket_seconds": bucket_s,
        "brokers": out,
    }


@app.get("/api/devices/{slug}/gps-history")
def gps_history(slug: str) -> dict[str, Any]:
    """Per-port GPS state + transition timeline.

    Returns the most recent timestamps for three events the operator
    cares about — independent of one another so the UI can render
    them as three separate columns:

    * ``last_fix_at`` — last time gps_3d_fix was observed true. None
      if never seen in the sampler's window.
    * ``last_lost_at`` — last time the chip transitioned fix-true →
      fix-false (None if no such transition recorded).
    * ``last_reacquired_at`` — last time the chip transitioned
      fix-false → fix-true (None if no such transition recorded).
    * ``losses_24h`` — count of fix-true → fix-false transitions in
      the last 24h.
    """
    state = {}
    try:
        state = json.loads(_SAMPLER_GPS_STATE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    # Resolve the device's actual /dev/serial/by-id/* path. The slug
    # is the slugified form (no "usb-" prefix, dashes only); the
    # sampler keys by the firmware-reported port path which carries
    # the "usb-" prefix and underscores. Look up the device's
    # canonical by_id_name and join with SERIAL_BY_ID.
    target = ""
    for d in _list_devices():
        if d.get("slug") == slug and d.get("by_id_name"):
            target = str(SERIAL_BY_ID / d["by_id_name"])
            break
    if not target:
        target = str(SERIAL_BY_ID / slug)
    ports = state.get("ports", {})
    port_info = ports.get(target, {})
    transitions = state.get("transitions", [])
    now = int(time.time())
    cutoff = now - 86_400

    last_lost_at: int | None = None
    last_reacquired_at: int | None = None
    losses_24h = 0
    for t in transitions:
        if t.get("port") != target:
            continue
        ts = int(t.get("ts") or 0)
        if t.get("to") is False:
            if last_lost_at is None or ts > last_lost_at:
                last_lost_at = ts
            if ts >= cutoff:
                losses_24h += 1
        elif t.get("to") is True:
            if last_reacquired_at is None or ts > last_reacquired_at:
                last_reacquired_at = ts

    return {
        "slug": slug,
        "port": target,
        "last_fix_at": port_info.get("last_fix_at"),
        "last_lost_at": last_lost_at,
        "last_reacquired_at": last_reacquired_at,
        "gps_3d_fix": port_info.get("gps_3d_fix"),
        "gps_sats": port_info.get("gps_sats"),
        "losses_24h": losses_24h,
    }


@app.get("/api/info")
def info() -> dict[str, Any]:
    return {
        "hostname": socket.gethostname(),
        "production": PRODUCTION,
        "devices_dir": str(DEVICES_DIR),
        "serial_by_id": str(SERIAL_BY_ID),
        # v0.3.5: surfaced to the topnav chip so the operator can see at
        # a glance what portal deb is installed without ssh-ing to the
        # Pi. "dev" when run from source (no deb stamp).
        "portal_version": PORTAL_VERSION,
        # 0.3.100: the bridge's PROVEN RUNNING version (git short-SHA the
        # running bridge process was deployed from, read from its
        # status.json) — shown in the top bar next to the portal version.
        # null when the bridge isn't running or predates the field.
        "bridge_version": _bridge_running_version(),
        # Whether the bridge is ACTUALLY running (writes its status.json) vs
        # merely installed (version came from the deployed_version stamp). The
        # top-bar chip uses this to label "(installed)" + turn yellow when the
        # bridge package is present but the process isn't up.
        "bridge_running": bool(_read_bridge_status().get("bridge_version")),
        # Bridge→broker health (Erik #3 / dbblinddb): "connected" /
        # "unauthorized" / "connect_failed" / "connecting" — the dbblinddb
        # class is a bridge that registers over HTTP but can't AUTH to the
        # broker, so it publishes nothing and is invisible on the fleet page.
        # The top bar surfaces this so the operator (and we) catch it early.
        "bridge_mqtt": _read_bridge_status().get("mqtt"),
        # Best-effort signal whether the sidecar relay is alive. The
        # broker-status pill on the Brokers tab depends on this — if
        # false, every row will show "? unknown" by design.
        "relay_running": _RELAY_STATUS_PATH.exists(),
        # Nodes that were flashed but never re-enumerated afterwards (the
        # 2026-06-10 testOPI case: a T-Echo programmed fine but its USB hung
        # with -110 on re-enumeration, so the bridge port is stuck "flashing").
        # The top bar surfaces this with a "Restart Pi" button — a host reboot
        # re-inits the USB controller and the node comes back.
        "fw_recovery_needed": _fw_recovery_stuck_devices(),
    }


#: A port left "flashing" longer than this (with no fresher status update) means
#: the flash subprocess finished but the device never came back / re-enumerated.
#: A normal flash completes well under this and clears to "ok" the moment frames
#: resume, so this never trips on an in-progress upgrade.
_FW_STUCK_FLASHING_S = 6 * 60


def _fw_recovery_stuck_devices() -> list[dict[str, str]]:
    """Nodes that look flashed-but-not-recovered (stuck "flashing" in the bridge
    status). Returns ``[{"slug","name"}]`` — empty (the common case) when none.

    Heuristic, computed from the bridge status.json the portal already reads:
    a port whose ``health == "flashing"`` whose ``updated_at`` is older than
    :data:`_FW_STUCK_FLASHING_S`. During a real flash the device re-enumerates
    and the reader refreshes the entry to ``ok``; only a node that failed to
    come back keeps a stale "flashing" marker.
    """
    ports = _read_bridge_status().get("ports") or {}
    if not isinstance(ports, dict):
        return []
    now = time.time()
    stuck: list[dict[str, str]] = []
    for slug, st in ports.items():
        if not isinstance(st, dict) or st.get("synthetic"):
            continue
        if str(st.get("health") or "") != "flashing":
            continue
        updated = st.get("updated_at")
        if not isinstance(updated, (int, float)):
            continue
        if now - float(updated) < _FW_STUCK_FLASHING_S:
            continue
        name = (
            st.get("gateway_name")
            or st.get("node_name")
            or st.get("board_name")
            or str(slug)
        )
        stuck.append({"slug": str(slug), "name": str(name)})
    return stuck


@app.post("/api/system/reboot")
def system_reboot() -> dict[str, Any]:
    """Reboot the Pi (host). Exposed for the top-bar "Restart Pi" button shown
    when a node failed to re-enumerate after a firmware update — a host reboot
    re-inits the USB controller and the node comes back.

    Uses the ``systemctl reboot`` sudoers grant the postinst installs for the
    portal user. Best-effort: the call returns before the box goes down.
    """
    last_err = None
    for argv in (
        ["sudo", "-n", "/usr/bin/systemctl", "reboot"],
        ["sudo", "-n", "/bin/systemctl", "reboot"],
    ):
        try:
            r = subprocess.run(argv, capture_output=True, text=True, timeout=10)
            if r.returncode == 0:
                return {"ok": True, "detail": "Reboot initiated — the Pi will be back in ~1 min."}
            last_err = (r.stderr or r.stdout or "").strip() or f"rc={r.returncode}"
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
            last_err = str(exc)
    raise HTTPException(status_code=500, detail=f"reboot failed: {last_err or 'unknown'}")


# ── Internet-accessibility diagnostic (top-bar indicator) ────────────────────
# A LAYERED check so the operator sees WHERE connectivity breaks, not just a
# bare "down". Each failing layer short-circuits to one specific, actionable
# reason. Order is deliberate (no default route → raw ping → DNS → captive/HTTP
# → the TDOA server), modelled on OS captive-portal detection (the generate_204
# trick). Cached for a short TTL so the polling top bar never re-runs the
# network-bound probes on every request.
_INTERNET_STATUS_CACHE: dict[str, Any] = {}
_INTERNET_STATUS_TTL_S = 20.0


def _has_default_route() -> bool:
    """True iff a default route (gateway) is configured."""
    try:
        out = subprocess.run(
            ["ip", "route", "show", "default"],
            capture_output=True, text=True, timeout=3,
        )
        if out.stdout.strip():
            return True
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    # Fallback: /proc/net/route — the default route has destination 00000000.
    try:
        with open("/proc/net/route", encoding="utf-8") as fh:
            for line in fh.readlines()[1:]:
                fields = line.split()
                if len(fields) > 1 and fields[1] == "00000000":
                    return True
    except OSError:
        pass
    return False


def _ping_ok(host: str = "1.1.1.1", port: int = 443) -> bool:
    """Raw internet reachability WITHOUT DNS: a TCP connect to a public IP.

    Deliberately NOT ICMP ping — raw ICMP is blocked/unavailable in many
    containers (unprivileged LXC), restricted networks, and some Pi setups,
    which would give a false 'no internet'. A TCP handshake to 1.1.1.1:443
    needs no privileges and proves a real route to the internet.
    """
    try:
        with socket.create_connection((host, port), timeout=3):
            return True
    except OSError:
        return False


def _dns_ok(host: str = "cloudflare.com") -> bool:
    """Resolve a hostname via the system resolver (bounded by the subprocess
    timeout so a dead DNS server can't hang the probe)."""
    try:
        r = subprocess.run(
            ["getent", "hosts", host], capture_output=True, timeout=3,
        )
        return r.returncode == 0 and bool(r.stdout.strip())
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def _http_204_ok() -> bool:
    """Captive-portal check: a 204 from a known endpoint means real,
    un-redirected internet. A captive portal returns a redirect/200 instead."""
    import urllib.error
    import urllib.request

    try:
        req = urllib.request.Request(
            "http://cp.cloudflare.com/generate_204",
            headers={"User-Agent": "meshcore-gateway-portal"},
        )
        with urllib.request.urlopen(req, timeout=4) as resp:  # noqa: S310
            return getattr(resp, "status", resp.getcode()) == 204
    except (urllib.error.URLError, OSError, ValueError):
        return False


def _homeprod_ok() -> bool:
    """Is the TDOA server (homeprod) reachable at all? ANY HTTP response — even
    a 401/403/302 from Cloudflare Access — counts; we only care that the TCP/TLS
    connection succeeds, not the status code."""
    import urllib.error
    import urllib.request

    try:
        req = urllib.request.Request(
            HOMEPROD_BASE_URL, method="HEAD",
            headers={"User-Agent": "meshcore-gateway-portal"},
        )
        with urllib.request.urlopen(req, timeout=5):  # noqa: S310
            return True
    except urllib.error.HTTPError:
        return True  # got an HTTP response → reachable
    except (urllib.error.URLError, OSError, ValueError):
        return False


def _compute_internet_status() -> dict[str, Any]:
    checks: dict[str, bool | None] = {
        "default_route": None, "ping": None, "dns": None,
        "http": None, "homeprod": None,
    }
    checks["default_route"] = _has_default_route()
    if not checks["default_route"]:
        return {
            "ok": False, "status": "down", "reason": "No gateway",
            "detail": "No default route (gateway) found — this device has no "
            "network connection. Check the cable/Wi-Fi and the router.",
            "checks": checks,
        }
    checks["ping"] = _ping_ok()
    if not checks["ping"]:
        return {
            "ok": False, "status": "down", "reason": "No internet",
            "detail": "Cannot reach 1.1.1.1 — there is a local gateway but no "
            "route to the internet. Check the router's internet connection.",
            "checks": checks,
        }
    checks["dns"] = _dns_ok()
    if not checks["dns"]:
        return {
            "ok": False, "status": "degraded", "reason": "DNS not working",
            "detail": "Internet is reachable but DNS resolution fails — "
            "hostnames cannot be looked up. Check the DNS server (router/DHCP).",
            "checks": checks,
        }
    checks["http"] = _http_204_ok()
    if not checks["http"]:
        return {
            "ok": False, "status": "degraded",
            "reason": "Captive portal / HTTP blocked",
            "detail": "Ping and DNS work, but the HTTP check did not return 204 — "
            "likely a captive portal (login page) or a proxy/firewall blocking "
            "HTTP.",
            "checks": checks,
        }
    checks["homeprod"] = _homeprod_ok()
    if not checks["homeprod"]:
        return {
            "ok": True, "status": "degraded",
            "reason": "TDOA server unreachable",
            "detail": f"Internet works, but the TDOA server ({HOMEPROD_BASE_URL}) "
            "is unreachable — registration/heartbeat may fail temporarily "
            "(server issue or firewall).",
            "checks": checks,
        }
    return {
        "ok": True, "status": "ok", "reason": "Internet reachable",
        "detail": "All OK: gateway, internet, DNS, HTTP and the TDOA server are "
        "reachable.",
        "checks": checks,
    }


@app.get("/api/internet-status")
def internet_status() -> dict[str, Any]:
    """Layered internet-accessibility diagnostic for the top-bar indicator.

    Returns ``{ok, status: ok|degraded|down, reason, detail, checks{...}}``.
    Short-TTL cached so the top bar can poll cheaply.
    """
    now = time.monotonic()
    cached = _INTERNET_STATUS_CACHE.get("value")
    ts = _INTERNET_STATUS_CACHE.get("ts", 0.0)
    if cached is not None and (now - ts) < _INTERNET_STATUS_TTL_S:
        return cached
    result = _compute_internet_status()
    result["checked_at"] = int(time.time())
    _INTERNET_STATUS_CACHE["value"] = result
    _INTERNET_STATUS_CACHE["ts"] = now
    return result


# ── Full registration-path diagnostic (+ Telegram report) ────────────────────
# Walks the registration dependency chain in ORDER and records each step's
# pass/fail with a specific, actionable Dutch reason, so the operator (and the
# Telegram report) sees exactly WHERE it breaks: internet → CF Access token →
# device/bridge.yaml → register result → observer-email→user link.
def _compute_registration_diagnostic() -> dict[str, Any]:
    env = _read_portal_env()
    steps: list[dict[str, Any]] = []
    first_fail: dict[str, Any] | None = None

    def add(name: str, ok: bool | None, label: str, detail: str) -> None:
        nonlocal first_fail
        step = {"name": name, "ok": ok, "label": label, "detail": detail}
        steps.append(step)
        if ok is False and first_fail is None:
            first_fail = step

    # 1 — internet (reuse the layered probe).
    net = _compute_internet_status()
    add("internet", net["status"] == "ok",
        "Internet" if net["status"] == "ok" else net["reason"], net["detail"])

    # (2026-06-06) The CF Access service-token step was REMOVED: the gateway
    # bootstrap endpoints (register/heartbeat/observer-status) are now a public
    # CF Access bypass, so NO token is needed and its absence is no longer a
    # failure. Keeping the old check made a perfectly-healthy gateway show a
    # false red. registration now needs only: internet → device → register.

    # 2 — receiver added (bridge.yaml exists). Registration waits for this.
    try:
        device_ok = _bridge_yaml_path().exists()
    except Exception:  # noqa: BLE001
        device_ok = False
    add("device", device_ok,
        "LoRa receiver added" if device_ok else "No LoRa receiver added yet",
        "A LoRa receiver is connected and added to this gateway." if device_ok else
        "No receiver added yet. Plug in your LoRa receiver (USB) and add it on the "
        "Gateway & Nodes page. The gateway only starts working once a receiver is added.")

    # 3 — last register outcome (recorded by the register/heartbeat scripts).
    last: dict[str, Any] = {}
    try:
        last = json.loads(_CLOUD_STATUS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        last = {}
    pi_host_id = last.get("pi_host_id")
    code = last.get("http_code")
    action = last.get("action")
    registered = _bridge_has_creds()
    if registered:
        # Registered (creds present, or a 200 register/heartbeat proves it).
        # This is the GATEWAY↔server step — NOT the user-claim step (that's #4).
        detail = (
            "This gateway is registered on the remote management server"
            + (f" (id {pi_host_id})." if pi_host_id else ".")
        )
        add("register", True, "Gateway registered on the management server", detail)
    elif code == 403:
        add("register", False, "Gateway registration blocked (403)",
            "The management server refused this gateway with a 403. Usually a "
            "network appliance/proxy is intercepting the request, or DNS pointed "
            "the server name at the wrong host.")
    elif code == 429:
        add("register", False, "Gateway registration rate-limited (429)",
            "The management server returned 429 — this gateway registered too often "
            "(limit ~1/hour). The gateway now backs off for 30 min after a 429 instead "
            "of retrying every 5 min, so it converges on its own — just wait. "
            + str(last.get("detail") or ""))
    elif code:
        add("register", False, f"Gateway registration failed (HTTP {code})",
            str(last.get("detail") or "Unknown error from the management server."))
    else:
        add("register", None if device_ok else False, "Gateway not registered yet",
            "This gateway hasn't registered itself on the remote management server yet."
            + ("  It registers automatically within a few minutes once a receiver is"
               " added." if device_ok
               else "  Configure a LoRa receiver first (see above), then it"
                    " registers automatically."))

    # 3b — PUBLISHING to the server (the testopi/dbblinddb blind spot, operator
    # request 2026-06-07): a gateway can be REGISTERED over HTTP yet its bridge
    # fail to AUTH/connect to the MQTT broker — so it publishes NOTHING and never
    # shows on the fleet, with no other visible symptom. The bridge records its
    # broker health in status.json as ``mqtt``; surface it as a hard step so the
    # diagnostic FAILS instead of falsely passing. Only meaningful once the
    # gateway is registered (creds exist) — skip otherwise to avoid noise.
    if registered:
        bridge_status = _read_bridge_status()
        mqtt_health = bridge_status.get("mqtt")
        bridge_up = bool(bridge_status.get("bridge_version"))
        if mqtt_health == "connected":
            add("publish", True, "Publishing to the server",
                "The bridge is connected to the management broker and publishing "
                "this gateway's receptions — it will appear on the fleet/map.")
        elif mqtt_health == "unauthorized":
            add("publish", False, "Can't publish — broker rejected the gateway",
                "The bridge reached the management broker but it refused the "
                "credentials (\"not authorized\"), so NO data is being published "
                "and this gateway won't appear on the fleet. The MQTT password is "
                "wrong/stale — re-run onboarding or update the gateway so it "
                "re-registers fresh broker credentials.")
        elif mqtt_health == "connect_failed":
            add("publish", False, "Can't publish — broker unreachable",
                "The bridge can't reach the management broker, so NO data is being "
                "published and this gateway won't appear on the fleet. Check the "
                "gateway's internet connection to the broker.")
        elif not bridge_up:
            add("publish", False, "Can't publish — bridge not running",
                "The gateway is registered but the bridge process isn't running, so "
                "nothing is being published. Restart the bridge (Restart on the "
                "Gateway & Nodes page) or check its logs.")
        else:
            # connecting / unknown (older bridge without the mqtt field).
            add("publish", None, "Publishing status unknown",
                "The bridge hasn't reported its broker-connection state yet. If this "
                "persists, the bridge may be starting up or running an older version.")

    # 4 — observer-email → user CLAIM (this is the SEPARATE 'claim on the
    # frontend' step, distinct from gateway↔server registration above).
    # Clear two-state wording (operator request 2026-06-06): "registered" =
    # gateway talks to the server; "claimed" = YOU own it on the frontend by
    # registering on the website with this Observer email.
    email = (env.get("OBSERVER_EMAIL") or os.environ.get("OBSERVER_EMAIL", "")).strip()
    user_registered: bool | None = None
    if not email:
        add("email", None, "You haven't claimed this gateway yet",
            "The gateway registers itself, but to see it on YOUR account you must"
            " CLAIM it with your email. 1) Sign in / create an account on the TDOA"
            " website with your email. 2) Enter that SAME email in the Observer"
            " card on this page. They link automatically. Until you do, the gateway"
            " still works and sends data — it just won't show on your My-Fleet page.")
    else:
        user_registered = _observer_email_registered(email)
        if user_registered is True:
            add("email", True, "You claimed this gateway",
                f"{email} matches a TDOA account, so this gateway is linked to your"
                " account and shows on your My-Fleet page.")
        elif user_registered is False:
            add("email", None, "You haven't claimed this gateway yet",
                f"{email} is saved on the gateway, but there's no TDOA account with"
                f" that email yet. Sign in / create an account on the TDOA website"
                f" using {email} and the gateway links to your account"
                " automatically. (The gateway itself is working fine.)")
        else:
            add("email", None, "Claim status couldn't be checked",
                f"Couldn't reach the server to check whether {email} has an account."
                " The gateway itself is unaffected.")

    if first_fail is not None:
        # A broken link in the path-to-register (internet/device/register) is a
        # hard failure (red); anything else degraded (amber).
        status = "down" if first_fail["name"] in ("internet", "device", "register", "publish") else "degraded"
        summary, ok = first_fail["label"], False
    elif registered and user_registered is True:
        # Fully green: gateway registered AND claimed by the user.
        status, summary, ok = "ok", "Gateway registered and claimed by you", True
    elif registered:
        # Gateway registered but NOT yet claimed → AMBER: it works + sends data,
        # it just won't show on your My-Fleet until you claim it with your email.
        status, summary, ok = "degraded", (
            "Gateway registered — claim it with your email to see it on your account"
            if email
            else "Gateway registered — add your email to claim it"
        ), True
    else:
        status, summary, ok = "degraded", "Gateway not registered yet", False

    return {
        "ok": ok, "status": status, "summary": summary, "steps": steps,
        "node": {
            "hostname": socket.gethostname(),
            "pi_host_id": pi_host_id,
            "portal_version": PORTAL_VERSION,
            "observer_email": email or None,
            "user_registered": user_registered,
            "registered": registered,
        },
    }


@app.get("/api/registration/diagnostic")
def registration_diagnostic() -> dict[str, Any]:
    """Full registration-path diagnostic for the top-bar indicator + tooltip."""
    return _compute_registration_diagnostic()


def _format_diagnostic_telegram(diag: dict[str, Any]) -> str:
    n = diag.get("node", {})
    icon = {"ok": "✅", "degraded": "⚠️", "down": "❌"}.get(diag.get("status"), "•")
    lines = [
        f"{icon} MeshCore Gateway — registration diagnostic",
        f"Host: {n.get('hostname', '?')} ({n.get('portal_version', '?')})",
    ]
    if n.get("pi_host_id"):
        lines.append(f"pi_host_id: {n['pi_host_id']}")
    if n.get("observer_email"):
        link = {True: "linked", False: "no account", None: "unknown"}.get(n.get("user_registered"), "unknown")
        lines.append(f"Email: {n['observer_email']} ({link})")
    lines.append(f"Status: {diag.get('summary', '?')}")
    lines.append("")
    sym = {True: "✅", False: "❌", None: "▫️"}
    for s in diag.get("steps", []):
        lines.append(f"{sym.get(s.get('ok'), '•')} {s.get('label', '')}")
        if s.get("ok") is False:
            lines.append(f"   → {s.get('detail', '')}")
    return "\n".join(lines)


# Services whose journals go into the diagnostic log bundle.
_LOG_BUNDLE_UNITS = (
    "meshcore-tdoa-gateway-portal",
    "meshcore-tdoa-gateway-bridge",
    "meshcore-tdoa-gateway-register",
    "meshcore-tdoa-gateway-heartbeat",
    "meshcore-tdoa-gateway-sampler",
    "meshcore-mesh-relay",
    "meshcore-tdoa-auto-update",
)

# Redact anything that looks like a secret before a config/log line leaves the Pi.
_REDACT_RE = re.compile(
    r"(?i)(password|passwd|token|secret|authorization|bearer|api[_-]?key|"
    r"mqtt_password|client[_-]?secret)\s*[:=]\s*\S+"
)
_REDACT_INLINE_RE = re.compile(r"(?i)(ghp_\w+|github_pat_\w+|Bearer\s+\S+|Basic\s+\S+)")


def _redact(text: str) -> str:
    """Best-effort scrub of secret-looking key:value pairs + inline tokens."""
    text = _REDACT_RE.sub(lambda m: f"{m.group(1)}: <redacted>", text)
    text = _REDACT_INLINE_RE.sub("<redacted>", text)
    return text


def _gather_log_bundle() -> bytes:
    """Build a single redacted .log bundle: diagnostic JSON + all gateway
    service journals + config files (secrets scrubbed). Best-effort — a missing
    source becomes a note, never an error. Returns UTF-8 bytes."""
    import subprocess

    parts: list[str] = []
    host = socket.gethostname()
    parts.append(f"# MeshCore TDOA gateway log bundle")
    parts.append(f"# host: {host}")
    parts.append(f"# portal_version: {PORTAL_VERSION}")
    parts.append("")

    # 1) the diagnostic, as JSON
    try:
        diag = _compute_registration_diagnostic()
        parts.append("===== REGISTRATION DIAGNOSTIC =====")
        parts.append(json.dumps(diag, indent=2, default=str))
        parts.append("")
    except Exception as exc:  # noqa: BLE001
        parts.append(f"(diagnostic failed: {exc})\n")

    # 2) service journals (last 200 lines each)
    for unit in _LOG_BUNDLE_UNITS:
        parts.append(f"===== journalctl -u {unit} (last 200) =====")
        try:
            out = subprocess.run(
                ["journalctl", "-u", unit, "--no-pager", "-n", "200"],
                capture_output=True, text=True, timeout=15,
            )
            parts.append(_redact(out.stdout or out.stderr or "(no output)"))
        except (OSError, subprocess.SubprocessError) as exc:
            parts.append(f"(journal unavailable: {exc})")
        parts.append("")

    # 3) config files (redacted)
    cfg_files = [
        "/etc/meshcore-tdoa-gateway-portal/portal.env",
        "/etc/meshcore-tdoa-gateway/bridge-overrides.yaml",
        "/etc/meshcore-bridge/deployed_version",
        "/etc/meshcore-tdoa-gateway/gateway-id",
        str(_CLOUD_STATUS_PATH),
        str(_BRIDGE_STATUS_PATH),
    ]
    for f in cfg_files:
        parts.append(f"===== {f} (redacted) =====")
        try:
            parts.append(_redact(Path(f).read_text(encoding="utf-8", errors="replace")))
        except OSError as exc:
            parts.append(f"(unreadable: {exc})")
        parts.append("")

    # NOTE: bridge.yaml (0600 secrets) is deliberately NOT included.
    return "\n".join(parts).encode("utf-8")


@app.post("/api/registration/diagnostic/telegram")
def registration_diagnostic_telegram() -> dict[str, Any]:
    """Run the diagnostic and send the full analysis + node/user info to the
    operator's Telegram, WITH a redacted log bundle attached as a file."""
    # 2026-06-06: guard BEFORE calling Telegram. If this gateway has no operator
    # Telegram configured (no bot token / chat id), calling the API just bubbles
    # up a raw "Telegram API rejected: HTTP 404" — confusing. Return a clear,
    # actionable 503 instead so the UI can say "Telegram isn't set up here."
    if not (TELEGRAM_BOT_TOKEN and TELEGRAM_OPERATOR_CHAT_ID):
        # User-facing: don't expose operator-internal setup (env vars / setup
        # script). The contact channel simply isn't available on this gateway;
        # the diagnostic on screen is what matters. (The form is normally hidden
        # when unconfigured — this guard is the belt-and-braces for a stale tab.)
        raise HTTPException(
            503,
            "The direct-message channel isn't set up on this gateway, so the "
            "report can't be sent from here. Everything you need is on this "
            "page — share a screenshot of this diagnostic with whoever runs "
            "your gateway.",
        )
    diag = _compute_registration_diagnostic()
    # Send the human-readable summary as the message, with the FULL redacted log
    # bundle attached as a file (operator asked: failed-health click → full logs
    # in a Telegram attachment). The bundle gather is best-effort; if it fails we
    # still send the text so the operator at least gets the diagnostic.
    summary_text = _format_diagnostic_telegram(diag)
    host = socket.gethostname()
    try:
        bundle = _gather_log_bundle()
        _telegram_send_document(
            filename=f"{host}-diagnostic.log",
            content=bundle,
            caption=summary_text,
        )
    except HTTPException:
        # sendDocument failed (too big? transport?) — fall back to text-only so
        # the report still reaches the operator.
        _telegram_send(summary_text)
    return {"sent": True, "status": diag.get("status"), "summary": diag.get("summary")}


# ── Changelog / Info page ────────────────────────────────────────────────────
# Mirrors the cloud frontend's Info page: a human-readable change history. Source
# is the deb changelog Debian installs at /usr/share/doc/<pkg>/changelog.Debian.gz
# (gzipped); falls back to debian/changelog when running from source.
_CHANGELOG_GZ_PATHS = (
    "/usr/share/doc/meshcore-tdoa-gateway-portal/changelog.Debian.gz",
    "/usr/share/doc/meshcore-tdoa-gateway-portal/changelog.gz",
)


def _read_changelog_text() -> str:
    import gzip

    for p in _CHANGELOG_GZ_PATHS:
        try:
            with gzip.open(p, "rt", encoding="utf-8", errors="replace") as fh:
                return fh.read()
        except OSError:
            continue
    for p in ("debian/changelog", str(Path(__file__).resolve().parent / "debian" / "changelog")):
        try:
            return Path(p).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
    return ""


def _parse_changelog(text: str, limit: int = 50) -> list[dict[str, Any]]:
    header_re = re.compile(r"^\S+ \(([^)]+)\)")
    trailer_re = re.compile(r"^ -- .*>  (.+)$")
    entries: list[dict[str, Any]] = []
    cur: dict[str, Any] | None = None
    for line in text.splitlines():
        h = header_re.match(line)
        if h:
            if len(entries) >= limit:
                break
            cur = {"version": h.group(1), "date": "", "changes": []}
            entries.append(cur)
            continue
        if cur is None:
            continue
        t = trailer_re.match(line)
        if t:
            cur["date"] = t.group(1).strip()
            cur = None
            continue
        s = line.strip()
        if s:
            cur["changes"].append(s[1:].strip() if s.startswith("*") else s)
    return entries


@app.get("/api/changelog")
def changelog() -> dict[str, Any]:
    """Parsed deb changelog for the portal's Info / Changes page."""
    return {"current": PORTAL_VERSION, "entries": _parse_changelog(_read_changelog_text())}


@app.get("/api/observer-email")
def get_observer_email() -> dict[str, Any]:
    """Return the operator's saved TDOA Observer email + the homeprod link.

    Reads the live portal.env (not just the process env) so a value saved
    by a previous request is reflected even before the unit restarts.
    """
    env = _read_portal_env()
    email = (env.get("OBSERVER_EMAIL") or os.environ.get("OBSERVER_EMAIL", "")).strip()
    return {
        "email": email,
        "homeprod_url": HOMEPROD_BASE_URL,
        "my_fleet_url": f"{HOMEPROD_BASE_URL}/my-fleet",
    }


@app.post("/api/observer-email")
def set_observer_email(payload: ObserverEmailUpdate) -> dict[str, Any]:
    """Persist the operator's TDOA Observer email into portal.env.

    The next register/heartbeat (both source portal.env) forwards it to
    homeprod, which links this gateway to the matching user account and
    unlocks the cloud My-Fleet page — the primary email-correlation path.
    An empty string clears it.
    """
    email = (payload.email or "").strip()
    if email and not _EMAIL_RE.match(email):
        raise HTTPException(status_code=422, detail="not a valid email address")
    try:
        _write_portal_env_var("OBSERVER_EMAIL", email)
    except OSError as exc:
        raise HTTPException(
            status_code=500,
            detail=f"could not write portal.env ({PORTAL_ENV_PATH}): {exc}",
        ) from exc
    log_gateway_action("observer_email.set", metadata={"cleared": not email})
    # Does this email already have a TDOA cloud account? If not (and we
    # could actually reach homeprod to ask), the UI nudges the operator
    # to sign up so they can view this gateway + the TDOA maps online.
    # `registered` is None when the check couldn't run (gateway not yet
    # registered, homeprod unreachable) — the UI treats None like "unknown
    # → show the optional sign-up nudge" so a real new operator isn't
    # silently left without the link.
    registered = _observer_email_registered(email) if email else None
    return {
        "ok": True,
        "email": email,
        "registered": registered,
        "homeprod_url": HOMEPROD_BASE_URL,
        "signup_url": f"{HOMEPROD_BASE_URL}/my-fleet",
        "my_fleet_url": f"{HOMEPROD_BASE_URL}/my-fleet",
    }


# Single source of truth for the per-Pi MQTT creds (2026-06-07): the register
# flow writes mqtt-creds.env; the bridge + relay read the SAME file. The legacy
# portal-mqtt-creds.env name is kept as a symlink for back-compat, so try the
# canonical name first and fall back.
_MQTT_CREDS_PATHS = (
    Path("/etc/meshcore-tdoa-gateway/mqtt-creds.env"),
    Path("/etc/meshcore-tdoa-gateway/portal-mqtt-creds.env"),
)


def _portal_mqtt_creds() -> tuple[str, str]:
    """Read the per-Pi MQTT username+password from the shared creds file the
    register script writes (0640 root:meshcore-tdoa-portal) — the single source
    of truth all consumers read.

    Returns ("", "") if absent/unreadable. This exists because bridge.yaml is
    0600 root-only (secrets separation) and the portal can't read it; the
    register script writes these values to the group-readable shared file for
    the portal's read-only observer-status check.
    """
    user = pw = ""
    for path in _MQTT_CREDS_PATHS:
        try:
            for raw in path.read_text(encoding="utf-8").splitlines():
                s = raw.strip()
                if s.startswith("MQTT_USERNAME="):
                    user = s.split("=", 1)[1].strip()
                elif s.startswith("MQTT_PASSWORD="):
                    pw = s.split("=", 1)[1].strip()
        except OSError:
            continue
        if user and pw:
            return user, pw
    return user, pw


def _observer_email_registered(email: str) -> bool | None:
    """Ask homeprod whether ``email`` already has a TDOA account.

    Uses the same per-Pi HTTP-Basic creds + CF-Access service-token headers
    as register/heartbeat/action-log. Returns True/False on a clean answer,
    or None when the check couldn't run (not registered yet, no creds,
    homeprod unreachable, non-200) — callers treat None as "unknown".
    """
    import base64 as _b64
    import json as _json
    import urllib.parse
    import urllib.request

    # Resolve the per-Pi MQTT creds the observer-status call authenticates with.
    # PRIMARY source: the portal-readable creds file the (root) register script
    # writes (0640 root:meshcore-tdoa-portal) — because bridge.yaml is 0600
    # root-only and the unprivileged portal CANNOT read it (that made this check
    # always return None on a privilege-separated gateway). FALLBACK: parse
    # bridge.yaml directly (dev boxes where the portal can read it / no creds
    # file yet).
    user, pw = _portal_mqtt_creds()
    if not (user and pw):
        # Fallback: try bridge.yaml (works on dev / pre-creds-file installs).
        try:
            import yaml
        except ModuleNotFoundError:
            logger.warning("PyYAML missing + no portal creds file — observer check skipped")
            return None
        try:
            doc = yaml.safe_load(_bridge_yaml_path().read_text(encoding="utf-8")) or {}
            mqtt = doc.get("mqtt", {}) if isinstance(doc, dict) else {}
            user = str(mqtt.get("username") or "").strip()
            pw = str(mqtt.get("password") or "").strip()
        except OSError:
            return None  # 0600 root-only + no creds file → can't authenticate

    try:
        if not user or not pw:
            return None  # gateway not registered yet → can't authenticate
        headers = {
            "Authorization": "Basic "
            + _b64.b64encode(f"{user}:{pw}".encode()).decode(),
            # Cloudflare's WAF blocks the default Python-urllib UA with
            # error 1010 → observer-status silently returns None for every
            # email. A named UA clears the challenge.
            "User-Agent": "meshcore-gateway-portal",
        }
        cf_id = (os.environ.get("CF_ACCESS_CLIENT_ID") or "").strip()
        cf_secret = (os.environ.get("CF_ACCESS_CLIENT_SECRET") or "").strip()
        if cf_id and cf_secret:
            headers["CF-Access-Client-Id"] = cf_id
            headers["CF-Access-Client-Secret"] = cf_secret
        url = (
            f"{HOMEPROD_BASE_URL}/api/gateways/observer-status?"
            + urllib.parse.urlencode({"email": email})
        )
        req = urllib.request.Request(url, headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = _json.loads(resp.read().decode("utf-8"))
        return bool(data.get("registered"))
    except Exception:  # noqa: BLE001 — best-effort; unknown on any failure
        return None


@app.get("/api/broker-types")
def broker_types() -> dict[str, Any]:
    return {
        k: {
            "label": v["label"],
            "user_fields": v["user_fields"],
            # null = generic template; UI must show a protocol dropdown.
            # str = pre-defined project; UI hides the dropdown, sends this.
            "protocol": v.get("protocol"),
        }
        for k, v in BROKER_TYPES.items()
    }


@app.get("/api/devices")
def list_devices() -> list[dict[str, Any]]:
    devices = _list_devices()
    # AUTO-ONBOARD (2026-06-05): the moment a USB device is detected, make sure
    # it has a bridge.yaml hardware: entry so the bridge actually reads it (and
    # probe-role / TDOA data work) — operators no longer need to hand-edit YAML.
    # Idempotent: _ensure_bridge_hardware_entry no-ops when an entry already
    # matches, so this only writes on first sighting. Best-effort — never fail
    # the listing if seeding hits an error.
    if PRODUCTION:
        for d in devices:
            try:
                _ensure_bridge_hardware_entry(d["slug"])
            except Exception as exc:  # noqa: BLE001
                logger.warning("auto_onboard.failed slug=%s err=%s", d.get("slug"), exc)
            # One-shot: discover the firmware node_name so the MQTT gatewayId
            # matches the USB pill, without the operator setting it. Guarded to
            # fire at most once per device (no recurring passthrough). Only for
            # LoRa devices the bridge actually opens.
            try:
                if d.get("hardware_id"):
                    _oneshot_name_probe(d["slug"])
            except Exception as exc:  # noqa: BLE001
                logger.warning("oneshot_name_probe.wire_failed slug=%s err=%s", d.get("slug"), exc)
    return devices


@app.put("/api/devices/{slug}/name")
def update_name(slug: str, payload: GatewayNameUpdate) -> dict[str, Any]:
    meta = _load_meta(slug)
    if not meta:
        # initialise — first time we see this device
        meta = {"slug": slug}
    meta["gateway_name"] = payload.gateway_name
    # 2026-05-30: any operator-issued PUT pins the manual choice so
    # the next runtime-state probe doesn't overwrite it with the
    # firmware node_name. Operator can clear the pin via the unpin
    # endpoint (POST /api/devices/{slug}/name/unpin) to re-enable
    # auto-sync from firmware node_name.
    meta["gateway_name_pinned"] = True
    meta["gateway_name_source"] = "operator_manual"
    meta["gateway_name_synced_at"] = time.time()
    _save_meta(slug, meta)
    log_gateway_action("gateway.rename", slug, {"name": payload.gateway_name})
    return {"ok": True, "gateway_name": payload.gateway_name, "pinned": True}


@app.post("/api/devices/{slug}/name/unpin")
def unpin_name(slug: str) -> dict[str, Any]:
    """Clear the gateway_name pin so the next runtime-state probe auto-
    syncs the value from the firmware's ``node_name``.

    Useful when the operator initially set a manual name and now wants
    to track the firmware-side identity (e.g. after renaming the node
    via ``set node_name``). No-op when the pin was never set.
    """
    meta = _load_meta(slug) or {"slug": slug}
    was_pinned = bool(meta.get("gateway_name_pinned"))
    if was_pinned:
        meta["gateway_name_pinned"] = False
        meta["gateway_name_source"] = "auto_pending_next_probe"
        _save_meta(slug, meta)
    return {"ok": True, "was_pinned": was_pinned, "pinned": False}


@app.put("/api/devices/{slug}/config")
def update_config(slug: str, payload: GatewayConfigUpdate) -> dict[str, Any]:
    """Bulk-save the gear-icon config panel.

    Layers the supplied fields on top of the existing meta.json. Any
    field the payload leaves out is kept as-is; explicit ``None`` is
    treated the same (the field's name isn't sent — pydantic strips
    unset model fields when we dump with ``exclude_none``). Returns
    the merged meta so the UI can re-render without a follow-up GET.
    """
    meta = _load_meta(slug) or {"slug": slug}
    # Use ``.dict`` (works on both pydantic v1 and v2) since some Pis run
    # the legacy v1 lineage and v2's ``.model_dump`` isn't there. Both
    # versions accept the ``exclude_none`` kwarg with the same semantics.
    updates = payload.dict(exclude_none=True)
    if not updates:
        return {"ok": True, "meta": meta, "unchanged": True}
    meta.update(updates)
    _save_meta(slug, meta)
    return {"ok": True, "meta": meta}


@app.get("/api/devices/{slug}/brokers", response_model=list[BrokerOut])
def list_brokers(slug: str) -> list[BrokerOut]:
    cfg = _load_config(slug)
    relay = _load_relay_status()
    # The TDOA broker connection lives in the bridge process, not the
    # relay; the meshcore-tdoa row's pill is sourced from the bridge
    # (per-broker via _bridge_status_snapshot below) rather than the relay.
    out = []
    for b in cfg.get("broker", []):
        name = b.get("name", "")
        per_device_enabled = bool(b.get("enabled", True))
        # Pass the relay snapshot in so observed_protocol (MQTT-native
        # TDOA marker) can flip classification away from the hostname
        # default. _classify falls back to the protocol field /
        # tdoa_gateway topic template when the relay hasn't seen the
        # retained meta yet on a fresh broker.
        btype = _classify(b, relay)
        # 2026-05-29 0.3.50: gate the relay snap on the per-device
        # enabled flag. The relay status file is keyed by broker NAME
        # globally — a different gateway with the SAME-named broker
        # (e.g. the auto-seeded `letsmesh-us` on every device) would
        # otherwise inherit publish_ok counters from a sibling Pi
        # whose copy IS enabled, surfacing "exporting" stats on a row
        # the operator deliberately turned off. Disabled rows show
        # status=None so the UI renders the muted "—" pill.
        snap = relay.get(name) if per_device_enabled else None
        if snap is None:
            # Two fallback paths to the bridge:
            #   - relay running but skipping this broker (TDOA — bridge
            #     owns the connection)
            #   - no relay at all (testopi-style: relay is masked
            #     because it's redundant with the bridge's fan-out)
            # In both cases the bridge IS publishing; ask
            # _bridge_status_snapshot for live state + per-broker count
            # from the sampler's bridge-direct rows.
            if bool(b.get("enabled", True)):
                snap = _bridge_status_snapshot(name)
        status = (
            BrokerStatus(
                connected=bool(snap.get("connected", False)),
                publish_ok=int(snap.get("publish_ok", 0)),
                publish_fail=int(snap.get("publish_fail", 0)),
                last_publish_ok_at=snap.get("last_publish_ok_at"),
                last_error=snap.get("last_error"),
            )
            if snap is not None
            else None
        )
        protocol = _protocol_for_broker(b)
        protocol_auto = (b.get("protocol") or "").lower().strip() not in ("tdoa", "mctomqtt")
        out.append(BrokerOut(
            name=name,
            type=btype,
            enabled=bool(b.get("enabled", True)),
            server=b.get("server"),
            port=b.get("port"),
            transport=b.get("transport"),
            auth_method=(b.get("auth") or {}).get("method"),
            raw=b,
            status=status,
            protocol=protocol,
            protocol_auto=protocol_auto,
        ))
    # The bridge owns the TDOA-export connection (the relay deliberately
    # skips it — seeding it as a relay broker caused the rc=5 churn the
    # _DEPRECATED_BROKER_NAMES list now strips). It therefore never appears
    # as a config row, yet operators expect to see the export's destination
    # + health alongside the other brokers. Synthesise a read-only row from
    # the bridge's own status.json. Skip if the operator already has an
    # explicit tdoa-protocol broker configured (avoid a confusing duplicate).
    has_tdoa_cfg = any(
        _protocol_for_broker(b) == "tdoa" for b in cfg.get("broker", [])
    )
    if not has_tdoa_cfg:
        tdoa_row = _tdoa_export_row()
        if tdoa_row is not None:
            # Pin the TDOA export to the TOP of the list — it's the primary
            # output (the bridge's reason for existing); the relay fan-out
            # brokers are secondary.
            out.insert(0, tdoa_row)
    return out


def _tdoa_export_row() -> BrokerOut | None:
    """Build the synthetic read-only "TDOA export" broker row.

    Destination (host/port/transport) and live connection state come from
    the bridge's status.json (``/run/meshcore-tdoa-gateway-bridge/status.json``)
    — the portal can't read the root-only ``bridge.yaml``. Returns None when
    the bridge has never written a status file (nothing meaningful to show).

    An older bridge (pre-broker_host) still reports ``mqtt`` state, so the
    row renders with a live status pill and a "—" destination until the
    bridge is updated; the destination then fills in automatically.
    """
    st = _read_bridge_status()
    if not st or not st.get("bridge_version"):
        return None
    mqtt_state = str(st.get("mqtt") or "").strip().lower()
    connected = mqtt_state == "connected"
    raw_port = st.get("broker_port")
    port = int(raw_port) if isinstance(raw_port, (int, float)) else None
    return BrokerOut(
        name="TDOA export",
        type="meshcore-tdoa",
        enabled=True,
        server=(st.get("broker_host") or None),
        port=port,
        transport=(st.get("broker_transport") or None),
        auth_method=None,
        raw={},
        status=BrokerStatus(
            connected=connected,
            publish_ok=0,
            publish_fail=0,
            last_publish_ok_at=None,
            last_error=None if connected else (mqtt_state or "unknown"),
        ),
        protocol="tdoa",
        protocol_auto=False,
        read_only=True,
    )


@app.post("/api/devices/{slug}/brokers")
def create_broker(slug: str, payload: BrokerCreate) -> BrokerOut:
    if payload.type not in BROKER_TYPES:
        raise HTTPException(400, f"Unknown broker type: {payload.type}")
    cfg = _load_config(slug)
    brokers = cfg.setdefault("broker", [])
    if any(b.get("name") == payload.name for b in brokers):
        raise HTTPException(400, f"Broker name already exists: {payload.name}")

    type_spec = BROKER_TYPES[payload.type]

    # Resolve protocol — operator's pick wins; pre-defined projects
    # fall back to BROKER_TYPES[type].protocol; generic types REQUIRE
    # the operator to choose ("tdoa" or "mctomqtt"). No auto-detect.
    req_protocol = (payload.protocol or "").lower().strip()
    if req_protocol not in ("tdoa", "mctomqtt"):
        req_protocol = (type_spec.get("protocol") or "").lower().strip()
    if req_protocol not in ("tdoa", "mctomqtt"):
        raise HTTPException(
            400,
            f"Broker type '{payload.type}' has no default protocol; "
            "pass protocol='tdoa' or 'mctomqtt' in the request body.",
        )

    # Default-enabled policy: TDOA-protocol brokers come up enabled (we
    # always want our own broker live); every other preset (on8ar,
    # letsmesh, generic templates) comes up disabled so a
    # fresh Pi never publishes to a third-party until the operator
    # flips the toggle in the UI. payload.enabled=None means "use the
    # type default"; True/False from the operator wins.
    default_enabled = req_protocol == "tdoa"
    effective_enabled = (
        default_enabled if payload.enabled is None else bool(payload.enabled)
    )
    new_broker: dict[str, Any] = {
        "name": payload.name,
        "enabled": effective_enabled,
    }
    preset = type_spec["preset"]
    for k, v in preset.items():
        new_broker[k] = ({**v} if isinstance(v, dict) else v)
    for path, value in payload.fields.items():
        _set_dotted(new_broker, path, value)
    new_broker["protocol"] = req_protocol

    brokers.append(new_broker)
    _save_config(slug, cfg)
    return BrokerOut(
        name=new_broker["name"], type=payload.type,
        enabled=new_broker["enabled"], server=new_broker.get("server"),
        port=new_broker.get("port"), transport=new_broker.get("transport"),
        auth_method=(new_broker.get("auth") or {}).get("method"),
        raw=new_broker,
        protocol=req_protocol,
        protocol_auto=False,  # never auto anymore; kept in schema for back-compat
    )


class BrokerEdit(BaseModel):
    """Partial-update payload for an existing broker.

    The portal sends only the fields the operator changed; we merge
    them into the existing TOML block (preserving keys that weren't
    in the request). `fields` uses the same dotted-path convention
    as BrokerCreate so `auth.username` etc. land in the right place.

    For full-block override (when the preset-driven fields aren't
    enough to express what the operator wants), set ``raw_block`` to
    a parsed TOML dict — the backend REPLACES the broker's entry with
    this, preserving only the name field by default.
    """
    model_config = ConfigDict(extra="forbid")
    enabled: bool | None = None
    fields: dict[str, str | int | float | bool] = Field(default_factory=dict)
    protocol: str | None = None
    # Allow renaming via PUT — the URL holds the OLD name, payload may
    # carry a new one. Omit to keep the existing name.
    new_name: str | None = Field(default=None, min_length=1, max_length=64)
    # Full-block override. When non-empty, replaces the broker's TOML
    # entry verbatim — operator's "override anything" escape hatch.
    raw_block: dict[str, Any] | None = None


@app.put("/api/devices/{slug}/brokers/{name}")
def edit_broker(slug: str, name: str, payload: BrokerEdit) -> BrokerOut:
    """Edit an existing broker in place. Updates only the fields supplied."""
    cfg = _load_config(slug)
    brokers = cfg.get("broker", [])
    target = next((b for b in brokers if b.get("name") == name), None)
    if target is None:
        raise HTTPException(404, f"broker {name!r} not found")

    if payload.new_name and payload.new_name != name:
        if any(b.get("name") == payload.new_name for b in brokers):
            raise HTTPException(400, f"broker name already exists: {payload.new_name}")
        target["name"] = payload.new_name
    if payload.enabled is not None:
        target["enabled"] = bool(payload.enabled)
    # Full-block override happens BEFORE individual field merges so
    # the operator's specific tweaks always win.
    if payload.raw_block:
        keep_name = target.get("name", name)
        target.clear()
        target.update(payload.raw_block)
        target["name"] = keep_name  # never let raw_block change the name silently
    for path, value in payload.fields.items():
        _set_dotted(target, path, value)
    if payload.protocol is not None:
        desired = payload.protocol.lower().strip()
        if desired in ("tdoa", "mctomqtt"):
            target["protocol"] = desired
        elif desired in ("", "auto"):
            target.pop("protocol", None)
        else:
            raise HTTPException(400, f"unknown protocol: {payload.protocol!r}")

    _save_config(slug, cfg)
    relay = _load_relay_status()
    return BrokerOut(
        name=target["name"],
        type=_classify(target, relay),
        enabled=bool(target.get("enabled", True)),
        server=target.get("server"),
        port=target.get("port"),
        transport=target.get("transport"),
        auth_method=(target.get("auth") or {}).get("method"),
        raw=target,
        protocol=_protocol_for_broker(target),
        protocol_auto=(target.get("protocol") or "").lower().strip() not in ("tdoa", "mctomqtt"),
    )


@app.put("/api/devices/{slug}/brokers/{name}/protocol")
def update_broker_protocol(slug: str, name: str, payload: BrokerProtocolUpdate) -> dict[str, Any]:
    """Set the per-broker protocol explicitly.

    Operator picks `tdoa` or `mctomqtt`. The `auto` option was removed
    2026-05-25 — every broker now carries an explicit protocol.
    """
    desired = payload.protocol.lower().strip()
    if desired not in BROKER_PROTOCOLS:
        raise HTTPException(400, f"unknown protocol: {payload.protocol!r}; expected one of {BROKER_PROTOCOLS}")
    cfg = _load_config(slug)
    for b in cfg.get("broker", []):
        if b.get("name") == name:
            b["protocol"] = desired
            _save_config(slug, cfg)
            return {"ok": True, "protocol": desired, "protocol_auto": False}
    raise HTTPException(404, f"broker {name!r} not found")


@app.delete("/api/devices/{slug}/brokers/{name}")
def delete_broker(slug: str, name: str) -> dict[str, Any]:
    cfg = _load_config(slug)
    brokers = cfg.get("broker", [])
    new = [b for b in brokers if b.get("name") != name]
    if len(new) == len(brokers):
        raise HTTPException(404, f"Broker not found: {name}")
    cfg["broker"] = new
    _save_config(slug, cfg)
    return {"deleted": name}


@app.post("/api/devices/{slug}/brokers/{name}/toggle")
def toggle_broker(slug: str, name: str) -> BrokerOut:
    cfg = _load_config(slug)
    for b in cfg.get("broker", []):
        if b.get("name") == name:
            b["enabled"] = not bool(b.get("enabled", True))
            _save_config(slug, cfg)
            return BrokerOut(
                name=b["name"], type=_classify(b, _load_relay_status()),
                enabled=b["enabled"], server=b.get("server"),
                port=b.get("port"), transport=b.get("transport"),
                auth_method=(b.get("auth") or {}).get("method"),
                raw=b,
            )
    raise HTTPException(404, f"Broker not found: {name}")


class TcpProxyUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool
    # Optional port override; when omitted (or 0), the backend auto-picks
    # the next free port starting at 5000.
    port: int = Field(default=0, ge=0, le=65535)
    # Interface the bridge's TCP-passthrough listener binds to. Default
    # ``"0.0.0.0"`` = LAN-accessible (no auth on the listener — anyone
    # who can reach the IP can talk to the node; opt-in by setting this
    # toggle). ``"127.0.0.1"`` = loopback only (SSH-tunnel access).
    bind: str = Field(default="0.0.0.0")


_TCP_PROXY_UNIT_PREFIX = "meshcore-companion-tcp@"


def _ports_in_use() -> set[int]:
    """Set of TCP ports already claimed by another device's tcp-proxy.

    Reads the meta.json of every configured device — the SOURCE OF TRUTH
    for collision detection is on-disk state, not socket probing, so
    we get a consistent answer even when the proxy unit is briefly
    stopped between toggle clicks.
    """
    out: set[int] = set()
    if not DEVICES_DIR.exists():
        return out
    for entry in sorted(DEVICES_DIR.iterdir()):
        if not entry.is_dir():
            continue
        meta = _load_meta(entry.name)
        if meta.get("tcp_proxy_enabled"):
            p = int(meta.get("tcp_proxy_port") or 0)
            if p > 0:
                out.add(p)
    return out


def _port_actually_free(p: int) -> bool:
    """True iff a TCP listener can bind to 0.0.0.0:p right now.

    Catches collisions with NON-portal-managed listeners (e.g. an old
    roomserver-relay script the operator left running on 5001) — those
    won't show up in _ports_in_use() but a socat unit would fail to
    bind, so we'd rather skip them at allocation time.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("0.0.0.0", p))
        return True
    except OSError:
        return False
    finally:
        s.close()


def _pick_free_port(start: int = 5000) -> int:
    """First port ≥ start not already claimed by another device AND
    actually bindable right now."""
    used = _ports_in_use()
    p = start
    while p < 65536:
        if p not in used and _port_actually_free(p):
            return p
        p += 1
    raise HTTPException(409, "no free port in 5000..65535")


def _resolve_device_tty(slug: str) -> str | None:
    """Best-effort canonical /dev/serial/by-id/<...> path for this device.

    The companion-tcp template unit needs a stable path because /dev/ttyACM*
    enumeration order is non-deterministic across reboots.
    """
    for d in _list_devices():
        if d["slug"] == slug:
            tty = d.get("tty")
            if tty and tty.startswith("/dev/"):
                return tty
            by_id = d.get("by_id_name")
            if by_id:
                return f"{SERIAL_BY_ID}/{by_id}"
    return None


_BRIDGE_YAML_PATH_DEFAULT = Path("/etc/meshcore-tdoa-gateway/bridge.yaml")
_BRIDGE_YAML_PATH_LEGACY = Path("/etc/meshcore-bridge/config.yaml")


def _bridge_overrides_path() -> Path:
    """The portal-writable overrides file (0664) sibling to the bridge config.

    Privilege separation (2026-06-06 security fix): the bridge's main config
    (``bridge.yaml``) is root-only 0600 and holds SECRETS the portal must NOT
    write. The portal-mutable fields (per-port ``role`` + ``tcp_passthrough_*``)
    go HERE instead; the bridge merges this file's ``hardware`` block over the
    base at startup. Always sits next to whichever bridge config is in use.
    """
    return _bridge_yaml_path().with_name("bridge-overrides.yaml")


def _bridge_yaml_path() -> Path:
    """Resolve the bridge config file the running bridge service ACTUALLY reads.

    0.3.32 — discovered the hard way on testopi: the portal was writing
    to /etc/meshcore-tdoa-gateway/bridge.yaml but the bridge service's
    ExecStart points at /etc/meshcore-bridge/config.yaml. Every
    TCP-passthrough toggle silently no-op'd because the field never
    reached the bridge's parser.

    Strategy:
      1. Parse the bridge unit file's ExecStart for ``--config <path>``
         and use that. This handles BOTH installer eras and any future
         path moves without portal code changes.
      2. Fall back to the canonical path if the unit isn't reachable
         (test mode, sudoers blocking systemctl, etc).
      3. Cache the answer per process so we don't shell out on every
         toggle.
    """
    cached = getattr(_bridge_yaml_path, "_cached", None)
    if cached is not None:
        return cached
    unit = _bridge_unit_name()
    try:
        r = subprocess.run(
            ["systemctl", "cat", f"{unit}.service"],
            capture_output=True, text=True, timeout=5,
        )
        if r.returncode == 0:
            for line in r.stdout.splitlines():
                if "ExecStart=" not in line:
                    continue
                # Tokenize the ExecStart args; look for --config <path>.
                tokens = line.split()
                for i, tok in enumerate(tokens):
                    if tok == "--config" and i + 1 < len(tokens):
                        p = Path(tokens[i + 1])
                        if p.is_file():
                            _bridge_yaml_path._cached = p  # type: ignore[attr-defined]
                            return p
                    if tok.startswith("--config="):
                        p = Path(tok.split("=", 1)[1])
                        if p.is_file():
                            _bridge_yaml_path._cached = p  # type: ignore[attr-defined]
                            return p
    except (subprocess.TimeoutExpired, OSError):
        pass
    # Fallback chain: legacy bridge path first if it exists, else default.
    for candidate in (_BRIDGE_YAML_PATH_LEGACY, _BRIDGE_YAML_PATH_DEFAULT):
        if candidate.is_file():
            _bridge_yaml_path._cached = candidate  # type: ignore[attr-defined]
            return candidate
    _bridge_yaml_path._cached = _BRIDGE_YAML_PATH_DEFAULT  # type: ignore[attr-defined]
    return _BRIDGE_YAML_PATH_DEFAULT


# Compat shim — callers still reference ``_BRIDGE_YAML_PATH`` as a name.
# Property-style attribute lookup would require a metaclass; keep it as
# a function call at the use sites instead. The single-line below is for
# any reader scanning for the old name to find the migration note.
# _BRIDGE_YAML_PATH = _bridge_yaml_path()  # replaced by _bridge_yaml_path() calls below


def _by_id_pattern_for_tty(slug: str, tty: str | None, by_id_name: str | None) -> str | None:
    """Resolve to the ``/dev/serial/by-id/...`` glob the operator likely
    has in ``bridge.yaml hardware:`` keys.

    The bridge.yaml hardware block matches by ``/dev/serial/by-id/<glob>``,
    not by the resolved ``/dev/ttyACM*`` device. The portal's
    ``_resolve_device_tty`` may return either; we always try the by-id
    candidate first (constructed from the device's recorded by_id_name)
    and only fall back to the tty when no by-id form is known.

    Returns the FIRST matching glob key from the existing hardware
    block — so adding ``tcp_passthrough_port`` lands inside the
    operator's already-configured entry (with all the metadata they
    typed) instead of spawning a new lookalike key.
    """
    from fnmatch import fnmatchcase

    candidates: list[str] = []
    # Prefer a by-id-derived path because that's what the bridge's
    # port_supervisor sees as the canonical port string.
    if by_id_name:
        candidates.append(f"/dev/serial/by-id/{by_id_name}")
    if tty and tty.startswith("/dev/serial/by-id/"):
        candidates.append(tty)
    if tty and tty not in candidates:
        candidates.append(tty)

    # The bridge reads the MERGED hardware set (root base bridge.yaml +
    # portal-writable bridge-overrides.yaml), so an entry the portal seeded
    # lives in overrides. Union the glob keys from BOTH files so the
    # "already configured?" check sees portal-seeded entries too (else we'd
    # re-seed on every detection).
    import yaml
    hardware_keys: list[str] = []
    for cfg_path in (_bridge_yaml_path(), _bridge_overrides_path()):
        if not cfg_path.is_file():
            continue
        try:
            doc = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
        except (OSError, yaml.YAMLError):
            continue
        hw = doc.get("hardware") if isinstance(doc, dict) else None
        if isinstance(hw, dict):
            hardware_keys.extend(str(k) for k in hw.keys())
    for pat_str in hardware_keys:
        for cand in candidates:
            if fnmatchcase(cand, pat_str):
                return pat_str
    return None


def _set_bridge_tcp_passthrough(
    by_id_glob: str,
    tcp_port: int | None,
    bind_host: str | None = None,
) -> None:
    """Write/clear ``hardware.<glob>.tcp_passthrough_port`` (+ optional
    ``tcp_passthrough_bind``) in the portal-writable OVERRIDES file.

    Privilege separation (2026-06-06 security fix): the portal writes ONLY the
    0664 ``bridge-overrides.yaml`` — never the root-only 0600 ``bridge.yaml``
    (which holds MQTT creds + the firmware PAT). The bridge merges the
    overrides' ``hardware`` block over the base at startup, then we
    ``systemctl restart`` the bridge (portal has a sudoers entry for that).
    Note: the bridge clamps a non-loopback ``tcp_passthrough_bind`` back to
    127.0.0.1 unless the ROOT base config opts in — so writing 0.0.0.0 here
    does NOT actually LAN-expose the passthrough.

    ``bind_host`` semantics:

    * ``None``     — leave whatever's already there (don't touch the field).
    * ``""``       — clear the override (bridge falls back to its 127.0.0.1 default).
    * ``"0.0.0.0"``/ ``"127.0.0.1"`` etc — write that bind interface.
    """
    overrides = _bridge_overrides_path()
    import yaml
    # The overrides file may not exist yet (fresh install before the bridge
    # postinst seeded it, or a manual setup). Start from empty; the parent dir
    # is portal-group-writable so we can create it.
    doc: dict[str, Any] = {}
    if overrides.is_file():
        try:
            doc = yaml.safe_load(overrides.read_text(encoding="utf-8")) or {}
        except (OSError, yaml.YAMLError) as exc:
            raise HTTPException(500, f"bridge-overrides.yaml unreadable: {exc}")
    if not isinstance(doc, dict):
        doc = {}
    hardware = doc.setdefault("hardware", {})
    block = hardware.setdefault(by_id_glob, {})
    if not isinstance(block, dict):
        raise HTTPException(500, f"hardware[{by_id_glob!r}] is not a mapping")
    if tcp_port is None:
        block.pop("tcp_passthrough_port", None)
        # Disabling cascades — also clear the bind so a re-enable with
        # different intent isn't silently inheriting the old value.
        block.pop("tcp_passthrough_bind", None)
    else:
        block["tcp_passthrough_port"] = int(tcp_port)
        if bind_host == "":
            block.pop("tcp_passthrough_bind", None)
        elif bind_host is not None:
            block["tcp_passthrough_bind"] = bind_host
    try:
        overrides.write_text(
            yaml.safe_dump(doc, sort_keys=False), encoding="utf-8",
        )
    except OSError as exc:
        raise HTTPException(500, f"could not write {overrides}: {exc}")


def _by_id_glob_for_name(by_id_name: str) -> str:
    """Build the ``/dev/serial/by-id/<glob>`` a hardware: entry should use.

    Operators (and skypi4's existing config) write a glob that ends in ``*`` so
    the entry survives a DFU descriptor swap / a serial-suffix change, e.g.
    ``usb-Nordic_nRF52_DK_1FF473CE99131A16-if00`` →
    ``/dev/serial/by-id/usb-Nordic_nRF52_DK_*``. We truncate at the device's
    serial/interface tail (the first run of hex/``-if``) so the stable
    vendor+model prefix remains.
    """
    base = by_id_name
    # Drop a trailing "-ifNN" interface suffix, then a trailing "_<hexserial>".
    base = re.sub(r"-if[0-9]+$", "", base)
    base = re.sub(r"_[0-9A-Fa-f]{6,}$", "", base)
    return f"/dev/serial/by-id/{base}*"


def _ensure_bridge_hardware_entry(slug: str) -> str | None:
    """Make sure bridge.yaml has a ``hardware:`` entry matching ``slug``'s device.

    THE onboarding link that was missing: a detected USB device only gets read
    by the bridge (and becomes probe-able) once a ``hardware:<by-id-glob>`` key
    exists in bridge.yaml. The gear-icon "Save config" only wrote meta.json, so
    a fresh operator's device was detected but never wired into the bridge —
    probe-role 404'd ("add an entry first") and the bridge produced no TDOA
    data. This seeds a minimal entry (glob only) if none matches yet, so the
    bridge picks the device up on its next restart and probe works.

    Returns the matching/created glob, or None if we couldn't (no bridge.yaml,
    no by-id name). Idempotent: never overwrites an operator's existing entry.
    """
    tty = _resolve_device_tty(slug)
    by_id_name = None
    for d in _list_devices():
        if d["slug"] == slug:
            by_id_name = d.get("by_id_name")
            break
    # Already have a matching entry? Nothing to do.
    existing = _by_id_pattern_for_tty(slug, tty, by_id_name)
    if existing is not None:
        return existing
    if not by_id_name:
        logger.warning("hardware_entry.skip slug=%s reason=no_by_id_name", slug)
        return None
    # #A (2026-06-09): don't seed a managed-receiver entry for a device the bridge
    # has QUARANTINED — it opened but produced no valid MeshCore frames within the
    # grace window, so it's not a LoRa receiver (e.g. a CP2102 debug UART; CP2102
    # is ALSO used by real boards, so the discriminator is "no valid frames", not
    # the chip). The bridge sets health="quarantined"; respect it.
    try:
        _h, _hd = _port_health(by_id_name, tty, _read_bridge_status().get("ports", {}))
        if _h == "quarantined":
            logger.info("hardware_entry.skip slug=%s reason=quarantined detail=%s", slug, _hd)
            return None
    except Exception as _exc:  # never block seeding on a health-read hiccup
        logger.debug("hardware_entry.health_check_failed slug=%s err=%s", slug, _exc)
    glob = _by_id_glob_for_name(by_id_name)
    import yaml
    # 2026-06-06 security fix: seed the entry into the portal-writable OVERRIDES
    # file, not the root-only secrets bridge.yaml. The bridge merges the
    # overrides' hardware block over the base at startup, so seeding here is
    # enough for the bridge to pick up + read the device.
    overrides = _bridge_overrides_path()
    doc: dict[str, Any] = {}
    if overrides.is_file():
        try:
            doc = yaml.safe_load(overrides.read_text(encoding="utf-8")) or {}
        except (OSError, yaml.YAMLError) as exc:
            logger.warning("hardware_entry.skip slug=%s reason=yaml:%s", slug, exc)
            return None
    if not isinstance(doc, dict):
        doc = {}
    hardware = doc.setdefault("hardware", {})
    if not isinstance(hardware, dict):
        logger.warning("hardware_entry.skip slug=%s reason=hardware_not_mapping", slug)
        return None
    # Seed a minimal entry; the operator's "Save config" fields (role/GPS/etc.)
    # layer on top later via meta.json + the config writers.
    hardware.setdefault(glob, {"role": "production"})
    try:
        overrides.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8")
    except OSError as exc:
        logger.warning("hardware_entry.write_failed slug=%s err=%s", slug, exc)
        return None
    logger.info("hardware_entry.created slug=%s glob=%s by_id=%s (overrides)", slug, glob, by_id_name)
    return glob


def _bridge_unit_name() -> str:
    """Pick whichever bridge systemd unit actually exists on this Pi.

    Two-installer-era drift: legacy Pis (skypi4, testopi) ship the unit
    as ``meshcore-bridge.service``; current install.sh writes
    ``meshcore-tdoa-gateway-bridge.service``. The fleet has both. We
    prefer the new name when both exist, fall back to the legacy one.

    ``systemctl list-unit-files NAME`` exits non-zero when the unit
    doesn't exist on disk — a clean detector that doesn't require
    parsing structured output. Caches the answer in a module-level dict
    so we only shell out once per process.
    """
    cached = getattr(_bridge_unit_name, "_cached", None)
    if cached is not None:
        return cached
    for candidate in ("meshcore-tdoa-gateway-bridge", "meshcore-bridge"):
        try:
            r = subprocess.run(
                ["systemctl", "list-unit-files", f"{candidate}.service"],
                capture_output=True, text=True, timeout=5,
            )
            if r.returncode == 0 and candidate in r.stdout:
                _bridge_unit_name._cached = candidate  # type: ignore[attr-defined]
                return candidate
        except (subprocess.TimeoutExpired, OSError):
            continue
    # Fallback to the canonical new name; the sudo restart will fail
    # cleanly with a "unit not found" stderr that surfaces in the 500.
    _bridge_unit_name._cached = "meshcore-tdoa-gateway-bridge"  # type: ignore[attr-defined]
    return "meshcore-tdoa-gateway-bridge"


def _restart_bridge() -> None:
    """``systemctl restart <bridge-unit>`` via sudo (-n).

    Unit name resolved per :func:`_bridge_unit_name` so this works on
    BOTH the current installer (``meshcore-tdoa-gateway-bridge``) and
    the legacy one (``meshcore-bridge``). Sudoers must whitelist both
    names — see postinst.
    """
    unit = _bridge_unit_name()
    try:
        subprocess.run(
            ["sudo", "-n", "systemctl", "restart", unit],
            check=True, capture_output=True, text=True, timeout=15,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as exc:
        stderr = getattr(exc, "stderr", "") or str(exc)
        raise HTTPException(500, f"failed to restart bridge ({unit}): {stderr}")


@app.put("/api/devices/{slug}/tcp-proxy")
def toggle_tcp_proxy(slug: str, payload: TcpProxyUpdate) -> dict[str, Any]:
    """Toggle the bridge's TCP-passthrough for one companion device.

    Option-B coexistence (per 2026-05-24 architecture):

    * Bridge stays the sole USB-CDC reader — no interleave possible.
    * When ``enabled`` is set, we write
      ``hardware.<by-id-glob>.tcp_passthrough_port = <port>`` into
      ``/etc/meshcore-tdoa-gateway/bridge.yaml`` and restart the
      bridge. The supervisor's port-add path then spawns a
      :class:`TCPPassthrough` for that USB-CDC and the SerialReader
      tees every read chunk to connected TCP clients (plus forwards
      client writes back to USB).
    * When ``enabled`` is false, we strip the field and restart;
      bridge stops the listener cleanly.

    Replaces the earlier socat-based ``meshcore-companion-tcp@<slug>``
    systemd template — single owner of the USB-CDC means TDOA pipeline
    AND chat client coexist without fighting for the file descriptor.
    Persisted in meta.json so the bridge YAML and the portal's UI
    state always agree.
    """
    meta = _load_meta(slug) or {"slug": slug}

    tty = _resolve_device_tty(slug)
    if not tty:
        raise HTTPException(404, f"no USB-CDC device found for slug {slug!r}")
    # Look up the device's by_id_name from the live device list so we
    # can match the bridge.yaml hardware glob (operators write globs
    # against ``/dev/serial/by-id/<usb-...>``, not against the resolved
    # ``/dev/ttyACM*`` path).
    by_id_name = None
    for d in _list_devices():
        if d["slug"] == slug:
            by_id_name = d.get("by_id_name")
            break
    by_id_glob = _by_id_pattern_for_tty(slug, tty, by_id_name)
    if by_id_glob is None:
        # ONBOARDING FIX (2026-06-05): a detected device used to have NO
        # bridge.yaml hardware entry until an operator hand-edited the YAML, so
        # this 404'd ("add an entry first") with no way to comply from the UI —
        # and the bridge never read the device (no TDOA data). Auto-create a
        # minimal entry now so the device is wired into the bridge + probe works.
        logger.info(
            "tcp_proxy.no_hardware_entry slug=%s tty=%s by_id=%s — auto-creating",
            slug, tty, by_id_name,
        )
        by_id_glob = _ensure_bridge_hardware_entry(slug)
    if by_id_glob is None:
        logger.warning(
            "tcp_proxy.no_hardware_entry_unrecoverable slug=%s tty=%s by_id=%s",
            slug, tty, by_id_name,
        )
        raise HTTPException(
            404,
            f"no hardware entry could be created for device {slug!r} "
            f"(tty={tty}, by_id={by_id_name}) — is bridge.yaml present + writable?",
        )
    if payload.enabled:
        # Resolve the target port — explicit choice (if free) or auto-pick.
        used = _ports_in_use() - ({int(meta.get("tcp_proxy_port") or 0)} if meta.get("tcp_proxy_enabled") else set())
        want = payload.port or 0
        if want > 0:
            if want in used:
                raise HTTPException(409, f"port {want} already in use by another device")
            port = want
        else:
            port = _pick_free_port(5000)
        # Validate bind — allowlist matches what the bridge config
        # parser accepts. Any other value is rejected so we don't
        # write nonsense to bridge.yaml.
        bind = payload.bind.strip()
        if bind not in ("127.0.0.1", "0.0.0.0", "::1", "::"):
            raise HTTPException(400, f"unsupported bind: {payload.bind!r}; expected 127.0.0.1 or 0.0.0.0")
        meta["tcp_proxy_enabled"] = True
        meta["tcp_proxy_port"] = port
        meta["tcp_proxy_tty"] = tty
        meta["tcp_proxy_by_id_glob"] = by_id_glob
        meta["tcp_proxy_bind"] = bind
        _save_meta(slug, meta)
        if PRODUCTION:
            _set_bridge_tcp_passthrough(by_id_glob, port, bind_host=bind)
            _restart_bridge()
        return {"ok": True, "enabled": True, "port": port, "tty": tty, "by_id_glob": by_id_glob, "bind": bind, "mock": not PRODUCTION}

    # Disabling
    meta["tcp_proxy_enabled"] = False
    _save_meta(slug, meta)
    if PRODUCTION:
        _set_bridge_tcp_passthrough(by_id_glob, None)
        _restart_bridge()
    return {"ok": True, "enabled": False, "mock": not PRODUCTION}


# --------------------------------------------------------------------------
# 0.3.35 — MeshCore binary companion-protocol surface.
#
# Most production firmware variants (`*_companion_radio_usb_tdoa_rx`,
# `*_repeater_tdoa_rx`, vanilla `companion_radio`/`repeater`/`room_server`)
# speak the MeshCore binary companion-protocol — they don't have a text
# CLI. The text-CLI probe (`get role`) only works on
# `simple_repeater_tdoa_rx`. To make runtime knobs work on the actual
# fleet, we need to speak the binary protocol.
#
# Wire framing per
# c:/projects/MeshCore/TDOA/MeshCore/src/helpers/ArduinoSerialInterface.cpp:
#   host → device:  `<` (0x3C) + 2 bytes LE length + payload
#   device → host:  `>` (0x3E) + 2 bytes LE length + payload
# Bridge's TDOA frame extractor (frame.py) already parses `>` frames and
# dispatches on inner opcodes 0x90/0x92/0x94/0x96/0x9A. Companion-protocol
# response opcodes (0x00/0x01/0x05/0x0E …) don't collide with that marker
# space, so portal-level framing runs alongside the bridge's pipeline.
# --------------------------------------------------------------------------

_FRAME_TX_HDR = b"<"  # host → device (write)
_FRAME_RX_HDR = b">"  # device → host (read)

# Companion-protocol request opcodes (host → device).
# Values come from examples/companion_radio/MyMesh.cpp #defines (decimal).
# CMD_DEVICE_QEURY = 22 (decimal) = 0x16 — NOT 0x22; got bitten by hex/decimal
# confusion in 0.3.35 which made probes always RESP_ERR.
CMD_APP_START          = 0x01  # → RESP_SELF_INFO   (role + radio state + name)
                                # MUST be sent with 7-byte reserved + NUL-app_name
                                # payload (firmware requires len >= 8).
CMD_SET_RADIO_PARAMS   = 0x0B  # freq/bw/sf/cr + repeat flag → RESP_OK/ERR
CMD_SET_RADIO_TX_POWER = 0x0C  # int8 dBm                    → RESP_OK/ERR
CMD_SET_TUNING_PARAMS  = 0x15  # rx_delay + airtime          → RESP_OK/ERR
CMD_DEVICE_QUERY       = 0x16  # = decimal 22; → RESP_DEVICE_INFO. Needs 1-byte
                                # app_target_ver payload (we send 11).
CMD_SET_OTHER_PARAMS   = 0x26  # = decimal 38; manual_add_contacts/telemetry/
                                # advert_loc_policy/multi_acks bitpacked.
                                # NOTE: does NOT set GPS or advert interval —
                                # those go through CMD_SET_CUSTOM_VAR.
CMD_SET_CUSTOM_VAR     = 0x29  # = decimal 41; payload "key:value" string.
                                # GPS toggle: payload "gps:1" or "gps:0".
                                # GPS interval: "gps_interval:NNN" (seconds).
                                # Handler at MyMesh.cpp:3207-3232.

# Companion-protocol response opcodes (device → host).
# Values: decimal 0/1/5/13 per MyMesh.cpp #defines.
RESP_OK          = 0x00
RESP_ERR         = 0x01
RESP_SELF_INFO   = 0x05   # decimal 5
RESP_DEVICE_INFO = 0x0D   # decimal 13 — NOT 0x0E

# MeshCore role enum (byte 1 of RESP_SELF_INFO; matches ADV_TYPE_* in
# AdvertDataHelpers.h ll. 7-10).
MESHCORE_ROLE_NAMES: dict[int, str] = {
    0x01: "companion",
    0x02: "repeater",
    0x03: "room_server",
}


def _encode_frame(opcode: int, payload: bytes = b"") -> bytes:
    """Wrap ``opcode + payload`` in the companion-protocol TX frame.

    Frame format: ``<`` (0x3C) + uint16 LE length + payload bytes. The
    length covers opcode + payload (not the header).
    """
    body = bytes([opcode]) + payload
    return _FRAME_TX_HDR + struct.pack("<H", len(body)) + body


def _iter_frames(buf: bytes):
    """Yield ``(opcode, payload)`` for every complete ``>``-framed RX frame.

    Tolerates noise / partial frames at boundaries: scans for the ``>``
    marker, reads the 2-byte LE length, validates against remaining buffer,
    yields (opcode, payload_after_opcode). When a length runs past the
    buffer or is implausibly large (> 4096), skips a single byte and tries
    again at the next ``>``.

    Pure: callers feed in the bytes they've drained from the socket.
    """
    i = 0
    n = len(buf)
    while i < n:
        if buf[i:i+1] != _FRAME_RX_HDR:
            i += 1
            continue
        if i + 3 > n:
            return  # need 1 marker + 2 length bytes; partial at end
        length = struct.unpack("<H", buf[i+1:i+3])[0]
        if length == 0 or length > 4096:
            # implausible — skip the marker, try the next byte
            i += 1
            continue
        if i + 3 + length > n:
            return  # partial frame at end of buffer
        body = buf[i+3:i+3+length]
        opcode = body[0]
        payload = bytes(body[1:])
        yield (opcode, payload)
        i += 3 + length


def _txrx_frames(host: str, port: int, frames: list[bytes], *,
                 drain_secs: float = 2.0,
                 boot_drain_secs: float = 0.6) -> bytes:
    """Open a TCP socket, write every TX frame, return all bytes drained.

    Caller passes raw `_encode_frame()` output and slices the returned
    byte stream via :func:`_iter_frames` to find responses of interest.
    Mirrors :func:`_probe_run_cli`'s socket pattern (non-blocking +
    polling) so latency + bridge behaviour are equivalent.
    """
    s = socket.create_connection((host, port), timeout=4)
    s.setblocking(False)

    def drain(secs: float) -> bytes:
        end = time.monotonic() + secs
        buf = bytearray()
        while time.monotonic() < end:
            try:
                chunk = s.recv(4096)
                if not chunk:
                    break
                buf.extend(chunk)
            except BlockingIOError:
                time.sleep(0.05)
        return bytes(buf)

    try:
        # Clear boot-noise / bridge-tee'd telemetry that arrived before
        # our send. Same pattern as _probe_run_cli; the bridge tees all
        # USB-CDC bytes (including the firmware's TDOA frames) to every
        # TCP client.
        _ = drain(boot_drain_secs)
        for f in frames:
            s.sendall(f)
            # Small inter-frame pause so the device can dispatch one
            # request before the next byte arrives. Companion-protocol
            # handlers are single-threaded.
            time.sleep(0.05)
        return drain(drain_secs)
    finally:
        try:
            s.close()
        except OSError:
            pass


def _parse_self_info(payload: bytes) -> dict[str, Any]:
    """Parse RESP_SELF_INFO payload (0x05 after opcode).

    Wire layout per MyMesh.cpp CMD_APP_START handler (ll. 2440-2473) —
    captured live on PocV4 + decoded byte-by-byte:
        byte 0:    role enum (0x01 companion / 0x02 repeater / 0x03 room_server)
        byte 1:    tx_power_dbm (int8)
        byte 2:    MAX_LORA_TX_POWER (uint8)
        bytes 3..34:  pub_key (32 bytes)
        bytes 35..38: node_lat × 1e6 (int32 LE)
        bytes 39..42: node_lon × 1e6 (int32 LE)
        byte 43:   multi_acks
        byte 44:   advert_loc_policy
        byte 45:   telemetry mode (bitpacked: env<<4 | loc<<2 | base)
        byte 46:   manual_add_contacts
        bytes 47..50: lora_freq Hz (uint32 LE; firmware stores ×1000)
        bytes 51..54: lora_bw  Hz (uint32 LE)
        byte 55:   lora_sf
        byte 56:   lora_cr
        bytes 57..:variable — node_name (UTF-8, length = payload_len - 57)

    All fields best-effort: short payload yields None for unreached fields.
    """
    out: dict[str, Any] = {
        "role": None, "role_byte": None, "tx_dbm": None,
        "max_tx_power_dbm": None, "lora_freq_hz": None, "lora_bw_hz": None,
        "lora_sf": None, "lora_cr": None, "node_name": None,
    }
    if len(payload) >= 1:
        rb = payload[0]
        out["role_byte"] = rb
        out["role"] = MESHCORE_ROLE_NAMES.get(rb)
    if len(payload) >= 2:
        out["tx_dbm"] = struct.unpack("<b", payload[1:2])[0]
    if len(payload) >= 3:
        out["max_tx_power_dbm"] = payload[2]
    if len(payload) >= 51:
        try:
            out["lora_freq_hz"] = struct.unpack("<I", payload[47:51])[0]
        except struct.error:
            pass
    if len(payload) >= 55:
        try:
            out["lora_bw_hz"] = struct.unpack("<I", payload[51:55])[0]
        except struct.error:
            pass
    if len(payload) >= 56:
        out["lora_sf"] = payload[55]
    if len(payload) >= 57:
        out["lora_cr"] = payload[56]
    if len(payload) > 57:
        try:
            out["node_name"] = payload[57:].decode("utf-8", "replace").strip("\x00").strip()
        except Exception:  # noqa: BLE001
            pass
    return out


def _parse_device_info(payload: bytes) -> dict[str, Any]:
    """Parse RESP_DEVICE_INFO payload (0x0D after opcode).

    Wire layout per MyMesh.cpp CMD_DEVICE_QEURY handler (ll. 2412-2431) —
    captured live on PocV4 + decoded byte-by-byte:
        byte 0:    firmware_ver_code (uint8) — e.g. 11
        byte 1:    max_contacts / 2 (uint8, double for actual count)
        byte 2:    MAX_GROUP_CHANNELS (uint8)
        bytes 3..6:  ble_pin (uint32 LE)
        bytes 7..18: build date string (12 bytes UTF-8, NUL-padded)
        bytes 19..58: manufacturer / board (40 bytes UTF-8)
        bytes 59..78: firmware_version string (20 bytes UTF-8)
        byte 79:   client_repeat (uint8: 0=off, 1=on) — the runtime
                   repeater flag the operator sees
        byte 80:   path_hash_mode (uint8)

    Strings are NUL-padded; we strip trailing NULs + whitespace.
    """
    def _str(b: bytes) -> str:
        try:
            return b.split(b"\x00", 1)[0].decode("utf-8", "replace").strip()
        except Exception:  # noqa: BLE001
            return ""
    out: dict[str, Any] = {
        "firmware_ver_code": None, "max_contacts": None,
        "max_group_channels": None, "ble_pin": None,
        "build_date": None, "manufacturer": None,
        "firmware_version": None, "client_repeat": None, "path_hash_mode": None,
    }
    if len(payload) >= 1:
        out["firmware_ver_code"] = payload[0]
    if len(payload) >= 2:
        out["max_contacts"] = int(payload[1]) * 2
    if len(payload) >= 3:
        out["max_group_channels"] = payload[2]
    if len(payload) >= 7:
        try:
            out["ble_pin"] = struct.unpack("<I", payload[3:7])[0]
        except struct.error:
            pass
    if len(payload) >= 19:
        out["build_date"] = _str(payload[7:19])
    if len(payload) >= 59:
        out["manufacturer"] = _str(payload[19:59])
    if len(payload) >= 79:
        out["firmware_version"] = _str(payload[59:79])
    if len(payload) >= 80:
        out["client_repeat"] = bool(payload[79])
    if len(payload) >= 81:
        out["path_hash_mode"] = payload[80]
    return out


def _detect_firmware_protocol(host: str, port: int) -> tuple[str, dict[str, Any]]:
    """Probe the firmware to identify its protocol family.

    Returns one of:
        ("text-cli", {role})                                — text reply to ``get role``
        ("binary", {role, tx_dbm, firmware_version, ...})   — RESP_SELF_INFO seen
        ("unknown", {})                                     — nothing parseable

    Strategy (0.3.38 — order reversed + leading-CR flush):
      1. Send a leading ``\\r`` to flush any partial command in the
         firmware's input buffer, then send ``get role\\r``. Drain 1.5 s.
         Text-CLI firmware (simple_repeater_tdoa_rx and similar built
         on CommonCLI) responds with ``-> <reply>``. If we see a reply,
         classify as text-cli.
      2. Else try binary: send CMD_APP_START + CMD_DEVICE_QUERY. Drain
         2 s. If we see ANY ``>``-framed reply with opcode
         RESP_SELF_INFO or RESP_DEVICE_INFO, classify as binary and
         parse what we got.
      3. Else "unknown" — likely a firmware variant we don't support
         (or a transient bridge issue).

    Why text-first: binary probe bytes (`<\\x01\\x00\\x01...`) accumulate
    in the text firmware's command buffer (Serial.read() byte-by-byte
    until \\r), filling it with garbage that breaks the next text probe.
    Text bytes don't have the same effect on binary firmware — the
    binary parser scans for `<` markers and ignores everything else.
    """
    # Phase 1 — text-CLI probe FIRST. Leading \r flushes any partial
    # command that may have accumulated from a prior failed probe.
    try:
        replies = _probe_run_cli(host, port, ["", "get role"])
    except OSError as exc:
        return ("unknown", {"error": str(exc)})
    role_text = (replies.get("get role") or "").strip()
    if role_text:
        return ("text-cli", {"protocol": "text-cli", "role": role_text})
    # Phase 2 — binary fallback.
    # CMD_APP_START requires 7-byte reserved + NUL-terminated app_name
    # (firmware checks len >= 8 in MyMesh.cpp ll. 2432-2433; shorter
    # bodies fall through to default RESP_ERR).
    # CMD_DEVICE_QUERY requires 1-byte app_target_ver (len >= 2 check
    # at MyMesh.cpp l. 2412); we send 11 = the version this portal
    # speaks (matches FIRMWARE_VER_CODE in the firmware too).
    binary_frames = [
        _encode_frame(CMD_APP_START, b"\x00" * 7 + b"\x00"),
        _encode_frame(CMD_DEVICE_QUERY, b"\x0b"),
    ]
    try:
        raw = _txrx_frames(host, port, binary_frames, drain_secs=2.0)
    except OSError as exc:
        return ("unknown", {"error": str(exc)})
    self_info: dict[str, Any] = {}
    device_info: dict[str, Any] = {}
    for opcode, payload in _iter_frames(raw):
        if opcode == RESP_SELF_INFO and not self_info:
            self_info = _parse_self_info(payload)
        elif opcode == RESP_DEVICE_INFO and not device_info:
            device_info = _parse_device_info(payload)
    if self_info or device_info:
        merged: dict[str, Any] = {**self_info, **device_info}
        merged["protocol"] = "binary"
        return ("binary", merged)
    return ("unknown", {"protocol": "unknown"})


def _probe_run_cli(host: str, port: int, commands: list[str], *,
                   per_cmd_timeout: float = 1.5) -> dict[str, str]:
    """Send each command terminated by \\r, return ``{cmd: parsed_reply}``.

    Parsing follows the firmware contract from
    examples/simple_repeater_tdoa_rx/main.cpp: ``handleCommand`` writes
    its reply to ``Serial`` prefixed with ``  -> <reply>``. We pull the
    longest printable-ASCII run from the response window, search for
    ``-> ``, then peel any ``> `` (get-reply) lead. Replies the firmware
    writes after the ``> `` get returned without it.
    """
    s = socket.create_connection((host, port), timeout=4)
    s.setblocking(False)

    def drain(secs: float) -> bytes:
        end = time.monotonic() + secs
        buf = bytearray()
        while time.monotonic() < end:
            try:
                chunk = s.recv(4096)
                if not chunk:
                    break
                buf.extend(chunk)
            except BlockingIOError:
                time.sleep(0.05)
        return bytes(buf)

    # Clear boot-noise / advert echoes that arrive in the first ~600 ms
    _ = drain(0.6)

    out: dict[str, str] = {}
    try:
        for cmd in commands:
            s.sendall((cmd + "\r").encode("ascii"))
            time.sleep(0.05)
            got = drain(per_cmd_timeout)
            # Pull printable runs ≥ 3 chars; flatten and search for the
            # firmware's "-> " reply marker.
            printable = re.findall(rb"[\x20-\x7e]{3,}", got)
            ascii_run = " ".join(p.decode("ascii", "replace") for p in printable)
            m = re.search(r"->\s*(?:>\s*)?([^\r\n]{1,200})", ascii_run)
            if m:
                # Stop at the next "  $" or a control sequence the
                # firmware sometimes emits — keep just the reply word.
                reply = m.group(1).strip().rstrip(",")
                # Trim trailing stuff after a double-space (firmware
                # tags the next prompt's "  " separator).
                reply = reply.split("   ")[0].strip()
                out[cmd] = reply
            else:
                out[cmd] = ""
    finally:
        try:
            s.close()
        except OSError:
            pass
    return out


def _wait_tcp_listen(host: str, port: int, timeout_s: float = 8.0) -> bool:
    """Poll until the bridge's passthrough socket accepts connections."""
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        try:
            s = socket.create_connection((host, port), timeout=1)
        except OSError:
            time.sleep(0.3)
            continue
        try:
            s.close()
        finally:
            return True
    return False


class ProbeRoleRequest(BaseModel):
    """Body for POST /api/devices/{slug}/probe-role.

    No model_config / ConfigDict on this class — pydantic v1 (which
    the Pi venv pins) treats those as fields and leaks them into the
    serialised payload; see GatewayConfigUpdate for the same caveat.
    """

    # If True, force-enable TCP-passthrough briefly even when it's off
    # (cost: ~5 s bridge restart). When False and passthrough is off,
    # the endpoint refuses so the operator can choose the disruption
    # window explicitly. Default True for one-click workflow.
    allow_brief_passthrough: bool = True


@app.post("/api/devices/{slug}/probe-role")
def probe_role(slug: str, payload: ProbeRoleRequest | None = None) -> dict[str, Any]:
    """Probe the firmware's current role + a few state knobs via TCP-CLI.

    Returns ``{role: str, repeat: str, tx_dbm: int|None, raw: {...}}``
    on success. Side effects:

    * If TCP-passthrough is already enabled for this device, we just
      connect to its port. No bridge restart.
    * If passthrough is OFF and ``allow_brief_passthrough=True``, we
      enable it (writes bridge.yaml + restarts bridge), wait for the
      socket, probe, then restore (disables passthrough + restarts again).
    * If OFF and ``allow_brief_passthrough=False``, returns 409 so the
      operator can decide whether to accept the disruption.

    The probe sends ``get role`` / ``get repeat`` / ``get tx`` —
    cheap reads, no NVS writes.
    """
    payload = payload or ProbeRoleRequest()
    if not PRODUCTION:
        # mock — give callers something to render even in test mode
        return {
            "mock": True, "role": "repeater_tdoa_rx", "repeat": "on", "tx_dbm": 10,
            "raw": {"get role": "repeater_tdoa_rx", "get repeat": "on", "get tx": "10"},
        }

    meta = _load_meta(slug) or {}
    was_enabled = bool(meta.get("tcp_proxy_enabled"))
    port = int(meta.get("tcp_proxy_port") or 0)

    enabled_by_us = False
    if not was_enabled:
        if not payload.allow_brief_passthrough:
            raise HTTPException(
                409,
                "TCP passthrough is off — enable it first OR pass "
                "allow_brief_passthrough=true (causes ~5 s bridge restart).",
            )
        # Brief enable using the existing toggle plumbing. Picks a
        # free port automatically.
        toggle_resp = toggle_tcp_proxy(
            slug, TcpProxyUpdate(enabled=True, port=0, bind="127.0.0.1"),
        )
        port = int(toggle_resp.get("port") or 0)
        enabled_by_us = True
        if not _wait_tcp_listen("127.0.0.1", port, timeout_s=12.0):
            # try to restore + bubble the failure
            try:
                toggle_tcp_proxy(slug, TcpProxyUpdate(enabled=False, port=port, bind="127.0.0.1"))
            except Exception:  # noqa: BLE001
                pass
            raise HTTPException(500, f"passthrough enabled but no socket on :{port} within 12 s")

    if port <= 0:
        raise HTTPException(500, "no TCP port available for probe (passthrough disabled?)")

    try:
        replies = _probe_run_cli(
            "127.0.0.1", port,
            ["get role", "get repeat", "get tx"],
        )
    except OSError as exc:
        replies = {"error": str(exc)}
    finally:
        # Restore prior state — if WE enabled it, disable now.
        if enabled_by_us:
            try:
                toggle_tcp_proxy(slug, TcpProxyUpdate(enabled=False, port=port, bind="127.0.0.1"))
            except Exception:  # noqa: BLE001
                # Don't let the cleanup mask the probe result — log the
                # mess but return the role we got. Operator will see
                # passthrough stuck on and can toggle it manually.
                pass

    role_raw = replies.get("get role", "")
    repeat_raw = replies.get("get repeat", "")
    tx_raw = replies.get("get tx", "")
    try:
        tx_dbm: int | None = int(tx_raw) if tx_raw else None
    except (TypeError, ValueError):
        tx_dbm = None

    return {
        "role": role_raw,
        "repeat": repeat_raw,
        "tx_dbm": tx_dbm,
        "raw": replies,
        "passthrough_kept_on": was_enabled,
    }


# --------------------------------------------------------------------------
# Runtime-state / runtime-config — generalised CLI surface (KAN-2026-05-28).
#
# ``GET  /api/devices/{slug}/runtime-state``  → live probe of role / repeat /
#                                              tx / beacon / gps. Cached in
#                                              meta.json with TTL so the
#                                              device-pill colors don't have
#                                              to bridge-restart on every
#                                              page load.
# ``POST /api/devices/{slug}/runtime-config`` → set any subset of the above;
#                                              returns per-knob feedback
#                                              ``{before, after, ok, error?}``.
#
# Both share the existing TCP-passthrough yield/restore dance via the
# ``_with_brief_passthrough`` context manager. probe_role is left as-is for
# backwards-compatibility — the new endpoints are richer + cache results.
# --------------------------------------------------------------------------

# CLI-command names that the simple_repeater_tdoa_rx firmware accepts. Each
# tuple is (cli-getter, cli-setter, value-parser, value-formatter). Setter
# is None for read-only knobs; parser/formatter handle the str ↔ Python
# round trip so the route layer stays clean.
def _parse_bool_repeat(s: str) -> bool | None:
    s = (s or "").strip().lower()
    if s in ("on", "true", "1", "yes"): return True
    if s in ("off", "false", "0", "no"): return False
    return None


def _parse_gps_status(s: str) -> dict[str, Any]:
    """Parse the MeshCore ``gps`` CLI status reply into a structured dict.

    The firmware answers a bare ``gps`` query with one of, e.g.::

        off
        on, active, no fix, 0 sats
        on, active, fix, 7 sats
        on, deactivated, no fix, 0 sats
        Can't find GPS
        gps toggle not found

    NOTE (2026-06-10): the readback command is bare ``gps`` — NOT ``get gps``.
    ``handleGetCmd()`` in the firmware has no ``gps`` case and echoes the
    unknown-command form ``??: gps``. An ``??:`` echo or an empty string
    therefore means a protocol/command MISMATCH, which we surface as
    ``state="unknown"`` / ``enabled=None`` — it must NEVER be read as a
    definite "off". This is the bug this parser fixes: the old ``get gps`` +
    ``_parse_bool_repeat`` path turned every reply into ``None`` (mismatch) on
    ASCII ``simple_repeater`` devices, masking a working GPS.

    Returns a dict with: ``enabled`` (bool|None — the back-compat toggle
    value), ``active`` (provider running), ``fix`` (has a position fix),
    ``sats`` (int|None), ``state`` (one of off/on_fix/on_nofix/on_inactive/
    error_nogps/unknown), and the original ``raw`` text.
    """
    raw = (s or "").strip()
    t = raw.lower()
    unknown = {"enabled": None, "active": None, "fix": None, "sats": None,
               "state": "unknown", "raw": raw}
    # Command mismatch / no answer — NOT "off".
    if not t or t.startswith("??") or "unknown command" in t:
        return unknown
    # GPS feature absent or the runtime toggle never registered (detection
    # failed at boot): a distinct state from a clean "off".
    if "can't find gps" in t or "cant find gps" in t or "toggle not found" in t:
        return {"enabled": None, "active": False, "fix": None, "sats": None,
                "state": "error_nogps", "raw": raw}
    if t == "off" or t.startswith("off"):
        return {"enabled": False, "active": False, "fix": False, "sats": 0,
                "state": "off", "raw": raw}
    if t.startswith("on"):
        active = "deactiv" not in t           # "deactivated" => provider inactive
        fix = ("no fix" not in t) and ("fix" in t)
        m = re.search(r"(\d+)\s*sats?", t)
        sats = int(m.group(1)) if m else None
        state = "on_fix" if fix else ("on_nofix" if active else "on_inactive")
        return {"enabled": True, "active": active, "fix": fix, "sats": sats,
                "state": state, "raw": raw}
    # Anything else unrecognised → unknown (do not assume off).
    return unknown


def _parse_int_or_none(s: str) -> int | None:
    s = (s or "").strip()
    try:
        return int(s)
    except (TypeError, ValueError):
        return None


# Map operator-facing knob names → CLI-command pairs. Keep the operator names
# stable; if the firmware changes its CLI vocabulary, only the right-hand
# tuples need to move. Order matters — the runtime-state endpoint reads them
# in this order so the modal renders them in a sensible top-to-bottom flow.
_RUNTIME_KNOBS: dict[str, dict[str, Any]] = {
    "role":     {"get": "get role",   "set": None,           "parse": lambda s: (s or "").strip() or None,
                 "description": "Firmware-advertised role (chat | repeater | room_server). "
                                "Read-only — set via the MeshCore-native CLI on the device."},
    "repeat":   {"get": "get repeat", "set": "set repeat",   "parse": _parse_bool_repeat,
                 "format": lambda v: "on" if v else "off",
                 "description": "Forward received packets back into the mesh. "
                                "ON = full repeater (more airtime, more reach). "
                                "OFF = receive-only — TDOA-RX nodes default OFF so they "
                                "don't pollute their own timing measurements with self-TX."},
    "tx_dbm":   {"get": "get tx",     "set": "set tx",       "parse": _parse_int_or_none,
                 "format": lambda v: str(int(v)),
                 "description": "LoRa output power in dBm. Range −9 … +22. EU 868 MHz is "
                                "capped at +14 dBm legally; higher values are for US/non-EU "
                                "bands. Higher = farther reach + more battery/airtime."},
    # Beacon / advert interval. MeshCore TDOA-fork CLI uses
    # ``get advert.interval`` / ``set advert.interval <minutes>``. The
    # older string ``get advert`` returns ``??: advert`` (unknown) — verified
    # live on PocV4 2026-05-29 + matches CommonCLI.cpp:518/759 in the
    # firmware tree (the parser keys on ``"advert.interval "``, not
    # ``"advert "``).
    #
    # Storage asymmetry: ``set advert.interval N`` stores ``N/2`` in
    # ``_prefs->advert_interval`` (the firmware unit is 2-minute slots —
    # CommonCLI.cpp:523). ``get advert.interval`` returns the RAW stored
    # value (so write 5 → stored 2 → get returns ``> 2``, effective 4 min).
    # The JSON field ``advert_minutes`` carries this RAW stored value;
    # the frontend converts to OPERATOR-FACING hours (raw / 30 = hours)
    # for display and converts back (hours * 60 = minutes) when writing.
    # That's the cleanest split: backend stays unit-faithful to the
    # firmware wire format; UI presents the operator-friendly unit.
    "advert_minutes": {"get": "get advert.interval", "set": "set advert.interval",
                       "parse": _parse_int_or_none,
                       "format": lambda v: str(int(v)),
                       "description": "Auto-broadcast a mesh-presence beacon every N hours. "
                                      "0 = disabled — node stays silent until an explicit "
                                      "'Send advert now' command. 1–4 hours = beacon every "
                                      "N hours (rounded to 2-minute slots by firmware). "
                                      "Recommended: 0 for TDOA-RX-only nodes; 1–2 for "
                                      "repeaters; lower for low-density nets needing fast "
                                      "discovery.",
                       "unit_display": "h"},
    # GPS on/off. Firmware CLI uses ``gps on`` / ``gps off`` to write (NOT
    # ``set gps``) and a bare ``gps`` to read back — NOT ``get gps`` (that hits
    # handleGetCmd(), which has no gps case → echoes ``??: gps``). The read
    # reply is ``off`` / ``on, active, fix, N sats`` etc.; _parse_gps_status
    # maps it to the back-compat enabled bool here, and the richer fix/sats
    # state is surfaced as ``gps_status`` by _runtime_state_text_cli.
    # (2026-06-10: corrected from ``get gps`` — that masked working GPS on
    # ASCII simple_repeater devices. T-Echo uses the binary path, unaffected.)
    "gps": {"get": "gps", "set": "gps",
            "parse": lambda s: _parse_gps_status(s)["enabled"],
            "format": lambda v: "on" if v else "off",
            "description": "Power the on-board GPS module. ON = location + PPS-disciplined "
                           "timing (required for TDOA). OFF = saves ~30 mA but timestamps "
                           "revert to free-running chip clock (no sub-second accuracy)."},
    # 2026-05-31 / 0.3.65 — three new persistent knobs surfaced from the
    # firmware CLI per fleet operator request:
    #   * dutycycle             — EU 868 MHz 1 % regulatory cap
    #   * flood_advert_interval — mesh-wide presence broadcast (hours)
    #   * rx_boost              — SX126x +3 dB sensitivity toggle
    # All three are simple atomic knobs that plug into the existing
    # _runtime_config_apply_text_cli walker. The binary protocol path
    # doesn't know them yet — gracefully returns "not yet supported"
    # on companion_radio firmware until a per-knob opcode lands.
    "dutycycle": {"get": "get dutycycle", "set": "set dutycycle",
                  "parse": _parse_int_or_none,
                  "format": lambda v: str(int(v)),
                  "description": "TX airtime clamp as a percentage (1–100). EU 868 MHz has "
                                 "a 1 % legal cap on airtime per hour per channel; busy "
                                 "repeaters can exceed this without operator intervention. "
                                 "Set to 1 for strict EU compliance; 100 (firmware default) "
                                 "for unrestricted bands."},
    "flood_advert_interval": {"get": "get flood.advert.interval",
                              "set": "set flood.advert.interval",
                              "parse": _parse_int_or_none,
                              "format": lambda v: str(int(v)),
                              "description": "Mesh-wide presence broadcast interval in HOURS. "
                                             "Distinct from the local 1-hop Advert knob: this "
                                             "is the multi-hop 'I'm here' beacon that "
                                             "propagates to N-hop neighbours. Range 3–168 "
                                             "hours. Recommended: 24–72 for repeaters on a "
                                             "stable mesh; 6–12 on a rapidly-changing one. "
                                             "Pure RX nodes can leave it at the firmware "
                                             "default.",
                              "unit_display": "h"},
    "rx_boost": {"get": "get radio.rxgain", "set": "set radio.rxgain",
                 "parse": _parse_bool_repeat,
                 "format": lambda v: "on" if v else "off",
                 "description": "Boosted RX gain mode on SX1262/SX1268 (+3 dB sensitivity "
                                "at the cost of ~2 mA extra RX power). Useful when a "
                                "receiver has chronically low SNR (e.g. indoor T-Echo). "
                                "Has no effect on SX1276 / non-SX126x radios."},
    # 2026-05-30: node_name — the NVS-stored string the firmware
    # broadcasts in every ADVERT. Plumbed here so the portal can sync
    # it into the portal's meta.json gateway_name (which the bridge
    # already reads on every publish — see
    # ``meshcore_bridge.__main__._name_from_portal_meta``). From
    # gateway_name it propagates into the MQTT envelope's gatewayId,
    # and then into the mesh-relay's on8ar `origin` field. Matches
    # upstream mctomqtt's "query node_name from connected node at
    # startup" contract.
    #
    # Firmware CLI uses ``get name`` / ``set name <value>`` — NOT
    # ``get node_name``. Confirmed live on PocV4 repeater build +
    # CommonCLI.cpp:545/770 in the firmware tree. The internal
    # ``_prefs->node_name`` field is what gets read/written; the CLI
    # command name is the shorter ``name``.
    #
    # Probe-only knob: the runtime-state endpoint reads it, but the
    # set-config endpoint does NOT expose a write path. The operator
    # must update the firmware NVS via the MeshCore-native CLI
    # (``set name <new>``); the portal then auto-syncs on the next
    # runtime-state probe. Keeps the firmware as the single source of
    # truth for the ADVERTed identity.
    "node_name": {"get": "get name", "set": None,
                  "parse": lambda s: (s or "").strip().strip('"').strip("'") or None,
                  "format": lambda v: f'"{v}"' if v else ""},
}

# In-memory + meta.json cached snapshot. Page-load color logic reads from
# the cache; only the config-modal open and explicit refresh trigger a
# fresh probe (which costs ~5 s if passthrough is off — too expensive for
# every device on every page load).
_RUNTIME_CACHE_TTL_SECONDS = 600  # 10 min: probes refresh on modal open OR after this


def _runtime_state_from_meta(slug: str) -> dict[str, Any] | None:
    """Return the cached runtime state from meta.json or None if missing/stale.

    Used by the device-list summary so the page can render coloured status
    dots without probing every device. Stale values are STILL returned but
    with ``stale: true`` so the UI can dim the dot until a fresh probe
    lands.

    0.3.29 — when the CLI cache has never been written but the bridge has
    published an info event for this device, synthesise a partial
    runtime-state from the info doc. ``has_gps`` from the bridge becomes
    ``gps`` here so the device-pill dot can flip green/amber from cached
    bridge data alone, no CLI probe needed. The synthesised entry is
    marked ``source: "bridge_info"`` so the operator-facing UI can
    distinguish it from a true CLI readback.
    """
    meta = _load_meta(slug) or {}
    cached = meta.get("runtime_state_cached")
    if isinstance(cached, dict):
        cached_at = cached.get("cached_at")
        age_s: float | None = None
        if isinstance(cached_at, (int, float)):
            age_s = max(0.0, time.time() - float(cached_at))
        # 0.3.34 — if the CLI probe returned ALL-NULL values (binary-
        # protocol firmware that doesn't expose a text CLI — see PocV4
        # repeater-tdoa-rx variant), prefer the bridge.info synthesis
        # over the empty probe. Otherwise the status dot reports
        # "GPS unknown" forever even though bridge.info knows the
        # state. The empty-probe shape is: every knob None AND raw
        # has nothing parseable.
        probe_all_null = all(
            cached.get(k) is None
            for k in ("role", "repeat", "tx_dbm", "advert_minutes", "gps")
        )
        if not probe_all_null:
            return {
                **cached,
                "age_seconds": age_s,
                "stale": age_s is not None and age_s > _RUNTIME_CACHE_TTL_SECONDS,
                "source": "cli_probe",
            }
        # Fall through to bridge_info synthesis below.
    # Cold-CLI path: synthesise from the bridge info doc when available.
    info = meta.get("last_info")
    if not isinstance(info, dict):
        # 0.3.36-fix — warm the bridge.info cache on the fly (cheap journal
        # scrape with the self-heal). Without this, the first /api/devices
        # call after a stale-meta heal returns rt=None even though
        # has_tdoa_fw + bridge.info both go live in the SAME call. Next
        # refresh would heal but operator sees amber on the first load.
        info = _refresh_last_info_cache(slug)
        if not isinstance(info, dict):
            return None
    has_gps = info.get("has_gps")
    if not isinstance(has_gps, bool):
        return None
    return {
        "role": None,
        "repeat": None,
        "tx_dbm": None,
        "advert_minutes": None,
        "gps": has_gps,
        # 0.3.65 new knobs default to None on the bridge_info synthesis
        # path — bridge.info events don't carry these fields, only the
        # CLI probe does. The frontend greys out the controls until a
        # probe lands.
        "dutycycle": None,
        "flood_advert_interval": None,
        "rx_boost": None,
        "has_tdoa_fw": bool(info.get("is_tdoa_rx")),
        "raw": {},
        "source": "bridge_info",
        "age_seconds": None,
        "stale": False,
    }


def _save_runtime_state_cache(slug: str, snapshot: dict[str, Any]) -> None:
    """Persist a fresh runtime-state probe result into meta.json.

    Stored under the ``runtime_state_cached`` key so it's separate from
    operator-set meta (gateway_name / role-text / notes etc) and a
    schema-evolution can drop or rename this key without affecting the
    operator-visible fields.
    """
    meta = _load_meta(slug) or {}
    meta["runtime_state_cached"] = {
        **snapshot,
        "cached_at": time.time(),
    }
    _save_meta(slug, meta)


@contextlib.contextmanager
def _with_brief_passthrough(slug: str, *, allow_brief: bool = True):
    """Context manager wrapping the existing TCP-passthrough yield dance.

    Yields the TCP port number (loopback) that the caller should connect
    to for CLI traffic. Exits the context by restoring prior passthrough
    state — if WE enabled it briefly, we disable it on the way out (which
    triggers the bridge to re-claim the USB-CDC and resume MQTT publishing
    for this device).

    Raises HTTPException(409) when passthrough is off and ``allow_brief``
    is False — caller can offer the operator the explicit choice to accept
    the ~5 s bridge restart cost.
    """
    meta = _load_meta(slug) or {}
    was_enabled = bool(meta.get("tcp_proxy_enabled"))
    port = int(meta.get("tcp_proxy_port") or 0)
    # 0.3.32 — meta-vs-listener self-heal. If meta says passthrough is
    # enabled but the listener isn't actually answering, treat as if
    # was_enabled=False and fall through to the brief-enable path.
    # This recovers from state-drift bugs (portal restarted after a
    # toggle without bridge restart; an earlier probe got stuck mid-
    # cleanup; bridge service crashed between toggle + listen).
    if was_enabled and port > 0:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1.0) as s:
                s.close()
        except OSError:
            # Stale state — clear meta + bridge.yaml so brief-enable
            # path can re-enable cleanly with a fresh port.
            try:
                toggle_tcp_proxy(
                    slug, TcpProxyUpdate(enabled=False, port=port, bind="127.0.0.1"),
                )
            except Exception:  # noqa: BLE001
                # Even if cleanup fails (e.g. perm issue), keep going —
                # the brief-enable will overwrite meta anyway.
                pass
            was_enabled = False
            port = 0
    enabled_by_us = False
    if not was_enabled:
        if not allow_brief:
            raise HTTPException(
                409,
                "TCP passthrough is off — enable it first OR pass "
                "allow_brief_passthrough=true (causes ~5 s bridge restart).",
            )
        toggle_resp = toggle_tcp_proxy(
            slug, TcpProxyUpdate(enabled=True, port=0, bind="127.0.0.1"),
        )
        port = int(toggle_resp.get("port") or 0)
        enabled_by_us = True
        # 0.3.31 — bumped from 12s to 30s. Two reasons:
        #  (a) Bridge.yaml-write + systemctl-restart-bridge can take 5-10s
        #      on a healthy fresh-flashed Pi; 12s was tight.
        #  (b) Diagnostic — when 12s timed out on testopi the bridge had
        #      ALREADY restarted in 4.5s but the listener never bound,
        #      because the legacy `meshcore-bridge` package on that Pi
        #      doesn't support the `tcp_passthrough_port` field at all.
        #      The longer wait + clearer error helps the operator
        #      distinguish "slow bridge" from "wrong bridge package".
        if not _wait_tcp_listen("127.0.0.1", port, timeout_s=30.0):
            try:
                toggle_tcp_proxy(slug, TcpProxyUpdate(enabled=False, port=port, bind="127.0.0.1"))
            except Exception:  # noqa: BLE001
                pass
            raise HTTPException(
                500,
                f"Bridge restarted but no TCP listener appeared on :{port} within 30 s. "
                f"Most likely cause: this Pi runs the legacy `meshcore-bridge` package "
                f"which silently ignores the `tcp_passthrough_port` field. "
                f"Upgrade the bridge service (apt install --reinstall meshcore-tdoa-gateway-bridge) "
                f"or enable TCP passthrough permanently in the gear menu so the bridge "
                f"binding lives across portal restarts.",
            )
    if port <= 0:
        raise HTTPException(500, "no TCP port available for runtime CLI (passthrough disabled?)")
    try:
        yield port
    finally:
        if enabled_by_us:
            try:
                toggle_tcp_proxy(slug, TcpProxyUpdate(enabled=False, port=port, bind="127.0.0.1"))
            except Exception:  # noqa: BLE001
                # Don't mask the caller's exception/result — log via the
                # bridge's own status endpoint instead. Operator will see
                # passthrough stuck on and can toggle it manually.
                pass


def _has_tdoa_fw(slug: str) -> bool:
    """True when the latest bridge.info.published flagged ``is_tdoa_rx``.

    0.3.29 — switched from checking a non-existent
    ``tdoa_firmware_version`` field to the actual ``is_tdoa_rx`` bool
    the bridge emits in every info event. The fw version string ("v1.15.0")
    doesn't include the TDOA tag in the wire payload — only the
    is_tdoa_rx feature flag does. Reads from cached last_info first;
    falls back to a fresh journal scrape on the cold path.
    """
    meta = _load_meta(slug) or {}
    info = meta.get("last_info")
    if not isinstance(info, dict):
        info = _refresh_last_info_cache(slug)
    if not isinstance(info, dict):
        return False
    return bool(info.get("is_tdoa_rx"))


def _gps_enabled_from_bridge_info(slug: str) -> bool | None:
    """Latest bridge.info.published has_gps flag, or None when not cached.

    Used as a fallback when the runtime-CLI probe hasn't run yet — the
    bridge already tells us via its info events whether the chip has
    GPS enabled. The runtime probe is still the truth source for the
    other knobs (repeat / tx / advert) which aren't in info events.
    """
    meta = _load_meta(slug) or {}
    info = meta.get("last_info")
    if not isinstance(info, dict):
        return None
    val = info.get("has_gps")
    if isinstance(val, bool):
        return val
    return None


class RuntimeStateResponse(BaseModel):
    """Live state pulled from the device's CLI. Mirrors _RUNTIME_KNOBS.

    Each field is None when the firmware didn't return a parseable value
    (older firmware, command not supported, etc). The frontend should grey
    out the corresponding control.
    """
    role: str | None = None
    repeat: bool | None = None
    tx_dbm: int | None = None
    # 2026-05-31 / 0.3.65 — note on units: backend stays unit-faithful
    # to the firmware (`advert_minutes` is the RAW value the firmware
    # returns, which is in 2-min slots — effective minutes = raw * 2).
    # The frontend converts to operator-facing hours for display +
    # input. The new `description` field on each _RUNTIME_KNOBS entry
    # is surfaced via `/api/runtime-knobs-meta` for the frontend to
    # render as a `title=` tooltip on each control.
    advert_minutes: int | None = None
    gps: bool | None = None
    # 0.3.65 — new persistent knobs (None when the firmware doesn't
    # know the get command, which is the case on companion_radio
    # binary-protocol fw until the per-knob opcodes land).
    dutycycle: int | None = None
    flood_advert_interval: int | None = None
    rx_boost: bool | None = None
    has_tdoa_fw: bool = False
    raw: dict[str, str] = Field(default_factory=dict)
    cached_at: float | None = None
    age_seconds: float | None = None
    stale: bool = False
    fresh: bool = True  # True when this came from a live probe, False when from cache


# 0.3.35 — firmware-protocol cache lives in meta.json alongside
# runtime_state_cached. TTL of 1 h: the protocol only changes when the
# operator flashes new firmware (which we already invalidate explicitly
# from /firmware/flash). Cheaper than re-detecting on every probe.
_FW_PROTOCOL_CACHE_TTL_SECONDS = 3600


def _firmware_protocol_from_meta(slug: str) -> tuple[str, dict[str, Any]] | None:
    """Return cached (protocol, ident_dict) from meta.json or None when stale/missing."""
    meta = _load_meta(slug) or {}
    cached = meta.get("firmware_protocol_cached")
    if not isinstance(cached, dict):
        return None
    cached_at = cached.get("cached_at")
    if not isinstance(cached_at, (int, float)):
        return None
    age = time.time() - float(cached_at)
    if age > _FW_PROTOCOL_CACHE_TTL_SECONDS:
        return None
    protocol = cached.get("protocol")
    if protocol not in ("binary", "text-cli", "unknown"):
        return None
    return (protocol, cached.get("ident") or {})


def _save_firmware_protocol_cache(slug: str, protocol: str, ident: dict[str, Any]) -> None:
    """Persist firmware-protocol detection result to meta.json.

    Cache-poison guard (0.3.59): do NOT persist a result of
    ``protocol="unknown"`` when ident carries a transport-layer error
    such as ``Connection refused`` / ``Errno 111``. That kind of
    failure means the TCP-passthrough listener wasn't ready at probe
    time (race after firmware flash) — NOT that the firmware speaks an
    unknown protocol. Caching it freezes the device into a "no probe
    data" state for the full TTL (1h). The next caller will simply
    re-detect.
    """
    if protocol == "unknown" and isinstance(ident, dict) and ident.get("error"):
        err = str(ident.get("error") or "").lower()
        transport_errors = ("connection refused", "errno 111", "errno 2",
                            "no such file or directory", "timed out", "broken pipe")
        if any(t in err for t in transport_errors):
            return
    meta = _load_meta(slug) or {}
    meta["firmware_protocol_cached"] = {
        "protocol": protocol,
        "ident": ident,
        "cached_at": time.time(),
    }
    _save_meta(slug, meta)


def _probe_runtime_state(slug: str, allow_brief: bool = True) -> dict[str, Any]:
    """Run a runtime-state probe via whichever protocol the firmware speaks.

    Dispatcher pattern (0.3.35): detect once + cache, then route to either
    :func:`_runtime_state_binary` or the legacy text-CLI path. The cache
    means subsequent probes skip the detection round-trip entirely.
    """
    with _with_brief_passthrough(slug, allow_brief=allow_brief) as port:
        cached = _firmware_protocol_from_meta(slug)
        if cached is None:
            protocol, ident = _detect_firmware_protocol("127.0.0.1", port)
            _save_firmware_protocol_cache(slug, protocol, ident)
        else:
            protocol, ident = cached
        if protocol == "binary":
            parsed = _runtime_state_binary("127.0.0.1", port, ident_seed=ident)
        elif protocol == "text-cli":
            parsed = _runtime_state_text_cli("127.0.0.1", port)
        else:
            parsed = {
                "raw": {"__error__": "firmware protocol not detected"},
                "role": None, "repeat": None, "tx_dbm": None,
                "advert_minutes": None, "gps": None,
            }
    parsed["protocol"] = protocol
    parsed["firmware_role"] = (
        parsed.get("role")
        or (ident.get("role") if isinstance(ident, dict) else None)
    )
    parsed["has_tdoa_fw"] = _has_tdoa_fw(slug)
    # GPS read on binary firmware: no runtime command returns it, so
    # fall back to the bridge.info has_gps flag the cache already carries.
    if parsed.get("gps") is None:
        parsed["gps"] = _gps_enabled_from_bridge_info(slug)
    # 2026-05-30 — surface firmware node_name into the portal's
    # meta.json gateway_name, which the bridge reads on every publish
    # and puts in the MQTT envelope's gatewayId. From there the mesh-
    # relay's formats.envelope_to_on8ar_packet uses it as the on8ar
    # `origin` field. Matches upstream mctomqtt's contract: the
    # firmware's NVS-stored node_name (the same string the node
    # broadcasts in ADVERTs) IS what external brokers see.
    # Skipped when the operator has pinned a manual override
    # (``gateway_name_pinned: true`` in meta.json).
    _sync_node_name_to_bridge(slug, parsed.get("node_name"))
    _save_runtime_state_cache(slug, parsed)
    return parsed


def _oneshot_name_probe(slug: str) -> None:
    """Fire a SINGLE firmware node_name probe the first time a device is
    onboarded, so the MQTT gatewayId tracks the firmware node_name (= the USB
    pill) without the operator having to set it (operator 2026-06-07).

    Why one-shot: the probe uses the passthrough CLI, which must stay
    operator-click-only — never a recurring background passthrough (see the
    no-auto-passthrough rule). So we attempt exactly ONCE per device, guarded by
    the ``name_probe_attempted`` meta flag, and never again on our own. After
    this, the name still tracks via the operator's normal runtime probes /
    name-unpin.

    No-op when the device already has a ``gateway_name`` (nothing to discover)
    or the probe was already attempted. Probe failures are swallowed AND still
    mark attempted — a flaky probe must not block onboarding nor retry-storm on
    every /api/devices listing. ``_probe_runtime_state`` itself syncs the
    fetched node_name into meta via ``_sync_node_name_to_bridge``."""
    meta = _load_meta(slug) or {}
    if meta.get("name_probe_attempted"):
        return
    if (meta.get("gateway_name") or "").strip():
        # Already named (operator or a prior sync) — nothing to discover.
        return
    # Mark attempted FIRST so any failure can't cause a per-listing retry storm.
    meta["name_probe_attempted"] = True
    _save_meta(slug, meta)
    try:
        _probe_runtime_state(slug)  # fetches + syncs node_name internally
    except Exception as exc:  # noqa: BLE001
        logger.warning("oneshot_name_probe.failed slug=%s err=%s", slug, exc)


def _sync_node_name_to_bridge(slug: str, node_name: str | None) -> None:
    """Auto-populate the portal's ``gateway_name`` from the firmware's
    ``node_name`` so the bridge's envelope.gatewayId tracks the firmware's
    NVS-stored identity (the same string broadcast in ADVERTs).

    No-op when:
      * ``node_name`` is None / empty (probe didn't return a value);
      * meta.json's ``gateway_name_pinned`` is True (operator picked a
        manual override via the portal UI);
      * the existing ``gateway_name`` already matches;
      * **MIGRATION SAFETY**: the existing ``gateway_name`` is non-empty
        AND ``gateway_name_source`` is unset (i.e. a legacy operator-
        edited value from before this auto-sync feature shipped).
        In that case we auto-pin it so the next probe doesn't silently
        rename a device the operator deliberately named "PocV4" or
        "NL-MST-RP03". The operator can clear the pin via
        ``POST /api/devices/{slug}/name/unpin`` to opt in to auto-sync.

    Bridge picks the new value up on the next 0x90 publish — no restart
    needed (see ``meshcore_bridge.__main__._name_from_portal_meta``).
    """
    if not node_name or not isinstance(node_name, str):
        return
    new_name = node_name.strip()
    if not new_name:
        return
    meta = _load_meta(slug) or {}
    if bool(meta.get("gateway_name_pinned")):
        return
    existing = meta.get("gateway_name")
    source = meta.get("gateway_name_source")
    if existing and not source and existing != new_name:
        # Legacy operator-named device — preserve their choice. Pin it
        # so the operator can still opt in to auto-sync later via the
        # unpin endpoint, but the immediate effect is no surprise
        # rename on first probe after the feature ships.
        meta["gateway_name_pinned"] = True
        meta["gateway_name_source"] = "operator_manual"  # promote to explicit pin
        meta["gateway_name_synced_at"] = time.time()
        _save_meta(slug, meta)
        return
    if existing == new_name:
        # Already in sync — still tag the source so the UI can show
        # "auto-synced" instead of "unknown" on devices that happened to
        # have the right name already.
        if source != "firmware_node_name":
            meta["gateway_name_source"] = "firmware_node_name"
            meta["gateway_name_synced_at"] = time.time()
            _save_meta(slug, meta)
        return
    meta["gateway_name"] = new_name
    meta["gateway_name_synced_at"] = time.time()
    meta["gateway_name_source"] = "firmware_node_name"
    _save_meta(slug, meta)


def _runtime_state_text_cli(host: str, port: int) -> dict[str, Any]:
    """Original text-CLI read path — used on simple_repeater_tdoa_rx style fw."""
    commands = [v["get"] for v in _RUNTIME_KNOBS.values()]
    try:
        replies = _probe_run_cli(host, port, commands)
    except OSError as exc:
        replies = {c: "" for c in commands}
        replies["__error__"] = str(exc)
    parsed: dict[str, Any] = {"raw": replies}
    for knob, spec in _RUNTIME_KNOBS.items():
        parsed[knob] = spec["parse"](replies.get(spec["get"], ""))
    # Surface the richer GPS state (fix / sats / active / mismatch) alongside
    # the back-compat ``gps`` enabled bool. The modal can show "on, no fix,
    # 0 sats" vs "command mismatch" instead of a bare unknown.
    gps_spec = _RUNTIME_KNOBS.get("gps")
    if gps_spec is not None:
        parsed["gps_status"] = _parse_gps_status(replies.get(gps_spec["get"], ""))
    return parsed


def _runtime_state_binary(host: str, port: int,
                          *, ident_seed: dict[str, Any] | None = None) -> dict[str, Any]:
    """Read runtime state via binary companion-protocol RPC.

    Sends CMD_APP_START + CMD_DEVICE_QUERY, parses the responses into the
    operator-facing knob dict (role / repeat / tx_dbm / advert_minutes /
    gps). The ``ident_seed`` is the detection-time parse — used as a
    fallback when this readback's frame got lost in the tee'd telemetry
    stream so we always have SOMETHING to return.

    Field source map:
      * role     ← RESP_SELF_INFO byte 0
      * tx_dbm   ← RESP_SELF_INFO byte 1
      * repeat   ← RESP_DEVICE_INFO byte 84 (client_repeat)
      * gps      ← cached bridge.info has_gps (no runtime RPC reads this)
      * advert_minutes ← None (no read RPC; operator value accepted blind on write)
    """
    self_info: dict[str, Any] = {}
    device_info: dict[str, Any] = {}
    try:
        raw = _txrx_frames(host, port, [
            _encode_frame(CMD_APP_START, b"\x00" * 7 + b"\x00"),
            _encode_frame(CMD_DEVICE_QUERY, b"\x0b"),
        ], drain_secs=2.0)
        for opcode, payload in _iter_frames(raw):
            if opcode == RESP_SELF_INFO and not self_info:
                self_info = _parse_self_info(payload)
            elif opcode == RESP_DEVICE_INFO and not device_info:
                device_info = _parse_device_info(payload)
    except OSError as exc:
        raw = b""
        self_info = {"__error__": str(exc)}
    # Fall through to seed values for any field the live readback lost.
    merged = {**(ident_seed or {}), **self_info, **device_info}
    # 0.3.39 — distinguish ADVERTISED role from RUNTIME behaviour.
    # companion_radio firmware (PocV4 + most of the fleet) hardcodes
    # role=ADV_TYPE_CHAT in RESP_SELF_INFO regardless of client_repeat
    # state — confirmed at MyMesh.cpp:2442 with developer's own comment
    # "what this node Advert identifies as (maybe node's pronouns too?? :-)".
    # The actual "is this node forwarding packets" flag is
    # _prefs.client_repeat (MyMesh.cpp:1871-1873 → allowPacketForward()).
    # So on this firmware family:
    #   advert_role = CHAT/REPEATER/ROOM (identity baked into adverts)
    #   client_repeat = true | false (runtime knob — flips packet forwarding)
    # A "repeater" node in this fleet is typically advert_role=CHAT +
    # client_repeat=true; the UI should show both so the operator
    # doesn't confuse identity with behaviour.
    return {
        "raw": {
            "self_info_bytes": len(raw),
            "self_info": self_info or None,
            "device_info": device_info or None,
        },
        # ``role`` is the operator-facing summary — prefer runtime
        # behaviour when client_repeat differs from advert. Keeps the
        # existing UI field shape working.
        "role": (
            "repeater" if merged.get("client_repeat")
            else merged.get("role")
        ),
        "advert_role": merged.get("role"),
        "is_acting_as_repeater": bool(merged.get("client_repeat")),
        "repeat": merged.get("client_repeat"),
        "tx_dbm": merged.get("tx_dbm"),
        "advert_minutes": None,  # not readable via RPC; see write path
        "gps": None,  # bridge.info filled in by _probe_runtime_state
        # 0.3.65 new knobs are not readable via binary RPC yet; the
        # operator gets `null` here and the frontend greys them out.
        "dutycycle": None,
        "flood_advert_interval": None,
        "rx_boost": None,
        "firmware_version": merged.get("firmware_version"),
        "firmware_ver_code": merged.get("firmware_ver_code"),
        "node_name": merged.get("node_name"),
        "lora_freq_hz": merged.get("lora_freq_hz"),
        "lora_bw_hz": merged.get("lora_bw_hz"),
        "lora_sf": merged.get("lora_sf"),
        "lora_cr": merged.get("lora_cr"),
    }


@app.get("/api/devices/{slug}/runtime-state")
def get_runtime_state(slug: str, refresh: bool = False,
                      allow_brief_passthrough: bool = True) -> dict[str, Any]:
    """Pull live runtime state from the firmware CLI.

    ``refresh=true`` (default false) forces a fresh probe; otherwise we
    return the cached snapshot if it's within ``_RUNTIME_CACHE_TTL_SECONDS``
    of fresh, and probe only when stale or missing. The config-modal
    on-open handler should pass ``refresh=true`` so the operator always
    sees current state; the device-list page-load summary uses the default
    so we don't bridge-restart all devices at once.
    """
    if not PRODUCTION:
        return {
            "mock": True, "role": "repeater", "repeat": True, "tx_dbm": 10,
            "advert_minutes": 30, "gps": True, "has_tdoa_fw": True,
            "raw": {}, "fresh": False, "cached_at": time.time(),
            "age_seconds": 0.0, "stale": False,
        }
    cached = _runtime_state_from_meta(slug)
    if not refresh and cached is not None and not cached.get("stale"):
        return {**cached, "fresh": False}
    # #B (2026-06-09): even with refresh=true, don't re-probe — which restarts the
    # bridge via the brief TCP passthrough (~2 restarts) — if we probed VERY
    # recently. A UI polling runtime-state on a timer would otherwise thrash the
    # bridge. Coalesce to at most one live probe per ~20 s.
    if refresh and cached is not None:
        ca = cached.get("cached_at")
        if isinstance(ca, (int, float)) and (time.time() - ca) < 20.0:
            return {**cached, "fresh": False, "coalesced": True}
    fresh = _probe_runtime_state(slug, allow_brief=allow_brief_passthrough)
    return {
        **fresh,
        "cached_at": time.time(),
        "age_seconds": 0.0,
        "stale": False,
        "fresh": True,
    }


class RuntimeConfigRequest(BaseModel):
    """Per-knob runtime config update.

    Only set the fields you want to change — None means "leave alone".
    The endpoint reads each knob before AND after the set so the per-knob
    response includes the actual before/after the firmware reports (which
    can differ from the requested value if the firmware clamps or refuses).
    """
    repeat: bool | None = None
    tx_dbm: int | None = None
    advert_minutes: int | None = None
    gps: bool | None = None
    # 0.3.65 — three new persistent knobs (text-CLI path only).
    dutycycle: int | None = None
    flood_advert_interval: int | None = None
    rx_boost: bool | None = None
    allow_brief_passthrough: bool = True


@app.post("/api/devices/{slug}/runtime-config")
def set_runtime_config(slug: str, payload: RuntimeConfigRequest | None = None) -> dict[str, Any]:
    """Apply per-knob runtime-config changes, return per-knob feedback.

    Response shape:
    ``{results: {knob: {requested, before, after, ok, error?}}, final_state: {...}}``

    ``ok`` is True when the post-set readback equals the requested value
    (or, for read-only knobs, when the readback succeeded). ``error`` carries
    a human-readable hint when the firmware refused / returned an
    unparseable reply / didn't change the value.
    """
    payload = payload or RuntimeConfigRequest()
    _ALL_WRITABLE_KNOBS = (
        "repeat", "tx_dbm", "advert_minutes", "gps",
        "dutycycle", "flood_advert_interval", "rx_boost",
    )
    if not PRODUCTION:
        return {
            "mock": True,
            "results": {
                k: {"requested": getattr(payload, k), "before": None, "after": getattr(payload, k), "ok": True}
                for k in _ALL_WRITABLE_KNOBS
                if getattr(payload, k) is not None
            },
            "final_state": {},
        }
    requested = {k: getattr(payload, k) for k in _ALL_WRITABLE_KNOBS
                 if getattr(payload, k) is not None}
    if not requested:
        return {"results": {}, "final_state": _probe_runtime_state(slug)}
    with _with_brief_passthrough(slug, allow_brief=payload.allow_brief_passthrough) as port:
        # 0.3.35 — dispatch on detected firmware protocol. Re-detect if
        # cache is stale; the runtime-state cache and the protocol cache
        # share the same meta.json store.
        cached = _firmware_protocol_from_meta(slug)
        if cached is None:
            protocol, ident = _detect_firmware_protocol("127.0.0.1", port)
            _save_firmware_protocol_cache(slug, protocol, ident)
        else:
            protocol, ident = cached
        try:
            if protocol == "binary":
                results, final_parsed = _runtime_config_apply_binary(
                    "127.0.0.1", port, requested, ident_seed=ident,
                )
            elif protocol == "text-cli":
                results, final_parsed = _runtime_config_apply_text_cli(
                    "127.0.0.1", port, requested,
                )
            else:
                raise HTTPException(
                    503,
                    "Firmware protocol unknown — open the gear menu and ↻ Refresh "
                    "to re-detect, or flash a known TDOA/MeshCore build.",
                )
        except OSError as exc:
            raise HTTPException(500, f"CLI session error: {exc}")
    final_parsed["protocol"] = protocol
    final_parsed["firmware_role"] = (
        final_parsed.get("role")
        or (ident.get("role") if isinstance(ident, dict) else None)
    )
    final_parsed["has_tdoa_fw"] = _has_tdoa_fw(slug)
    if final_parsed.get("gps") is None:
        final_parsed["gps"] = _gps_enabled_from_bridge_info(slug)
    _save_runtime_state_cache(slug, final_parsed)
    return {
        "results": results,
        "final_state": {**final_parsed, "cached_at": time.time(),
                        "age_seconds": 0.0, "stale": False, "fresh": True},
    }


# 0.3.65 — server-driven knob metadata. The frontend renders the
# `description` field as a `title=` tooltip on each control and uses
# `unit_display` for the per-knob label suffix (e.g. "h" for hours).
# Keeping this server-driven means a firmware-range or wording change
# only updates main.py — no frontend rebuild needed.
@app.get("/api/runtime-knobs-meta")
def get_runtime_knobs_meta() -> dict[str, dict[str, Any]]:
    """Return per-knob metadata (description, unit_display, writable).

    Shape: {knob_name: {description: str | None, unit_display: str | None,
                        writable: bool}}.
    The frontend pulls this once at page load and merges into the knob
    rendering loop. Tooltip text + unit suffix come from here.
    """
    out: dict[str, dict[str, Any]] = {}
    for knob, spec in _RUNTIME_KNOBS.items():
        out[knob] = {
            "description": spec.get("description"),
            "unit_display": spec.get("unit_display"),
            "writable": spec.get("set") is not None,
        }
    return out


@app.post("/api/devices/{slug}/runtime/advert")
def post_runtime_advert(slug: str,
                        allow_brief_passthrough: bool = True) -> dict[str, Any]:
    """Fire a one-shot ADVERT broadcast on the device.

    0.3.65 — operator wants to verify mesh visibility without bumping
    the persistent ``advert.interval``. The firmware CLI exposes the
    bare ``advert`` command (no args); see CommonCLI.cpp:546 in the
    MeshCore tree. Returns the CLI echo so the operator can confirm
    the firmware acknowledged it.

    Text-CLI firmware only. The companion_radio binary-protocol fw
    has no equivalent RPC opcode for this — returns 501 with a hint
    so the operator falls back to flashing a CLI-capable build.
    """
    if not PRODUCTION:
        return {"ok": True, "mock": True, "response": "ADVERT > sent"}
    with _with_brief_passthrough(slug, allow_brief=allow_brief_passthrough) as port:
        cached = _firmware_protocol_from_meta(slug)
        if cached is None:
            protocol, ident = _detect_firmware_protocol("127.0.0.1", port)
            _save_firmware_protocol_cache(slug, protocol, ident)
        else:
            protocol, _ident = cached
        if protocol != "text-cli":
            raise HTTPException(
                501,
                "Ad-hoc advert is only supported on text-CLI firmware "
                f"(this device speaks {protocol!r}). Flash a "
                "simple_repeater_tdoa_rx or equivalent build to use this "
                "action; or set advert.interval > 0 instead.",
            )
        try:
            replies = _probe_run_cli("127.0.0.1", port, ["advert"])
        except OSError as exc:
            raise HTTPException(500, f"CLI session error: {exc}")
    return {"ok": True, "response": replies.get("advert", "")}


def _runtime_config_apply_text_cli(host: str, port: int,
                                   requested: dict[str, Any]
                                   ) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    """Original text-CLI write path — used on simple_repeater_tdoa_rx style fw."""
    results: dict[str, dict[str, Any]] = {}
    get_cmds = [_RUNTIME_KNOBS[k]["get"] for k in requested]
    before_replies = _probe_run_cli(host, port, get_cmds)
    before_parsed = {k: _RUNTIME_KNOBS[k]["parse"](before_replies.get(_RUNTIME_KNOBS[k]["get"], ""))
                     for k in requested}
    for knob, value in requested.items():
        spec = _RUNTIME_KNOBS[knob]
        if spec.get("set") is None:
            results[knob] = {"requested": value, "before": before_parsed[knob],
                             "after": before_parsed[knob], "ok": False,
                             "error": "read-only knob"}
            continue
        try:
            set_cmd = f"{spec['set']} {spec['format'](value)}"
        except Exception as exc:  # noqa: BLE001
            results[knob] = {"requested": value, "before": before_parsed[knob],
                             "after": before_parsed[knob], "ok": False,
                             "error": f"format error: {exc}"}
            continue
        _ = _probe_run_cli(host, port, [set_cmd])
        after_replies = _probe_run_cli(host, port, [spec["get"]])
        after_parsed = spec["parse"](after_replies.get(spec["get"], ""))
        ok = after_parsed == value
        row: dict[str, Any] = {"requested": value, "before": before_parsed[knob],
                               "after": after_parsed, "ok": ok}
        if not ok:
            row["error"] = (
                "firmware refused" if after_parsed is None
                else f"firmware reported {after_parsed} after set"
            )
        results[knob] = row
    final_parsed = _runtime_state_text_cli(host, port)
    return results, final_parsed


def _runtime_config_apply_binary(host: str, port: int,
                                 requested: dict[str, Any],
                                 *, ident_seed: dict[str, Any] | None = None
                                 ) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    """Apply per-knob writes via binary companion-protocol RPC.

    Per-knob opcode map (per the plan):
      * tx_dbm   → CMD_SET_RADIO_TX_POWER   (int8 dBm)
      * repeat   → CMD_SET_RADIO_PARAMS     (full freq/bw/sf/cr + repeat flag)
      * gps + advert_minutes → CMD_SET_OTHER_PARAMS (bitpacked; we read
        current values from CMD_APP_START first, then mutate the requested
        field and write the whole struct back)

    Each branch reads → mutates → writes → re-reads, returning per-knob
    {requested, before, after, ok, error?} rows that match the text-CLI
    shape so the frontend save-feedback renderer doesn't need to change.

    NOTE on `gps` + `advert_minutes`: the wire format of
    CMD_SET_OTHER_PARAMS is bitpacked and varies by firmware ver_code.
    For 0.3.35 we ship the tx_dbm + repeat branches; gps + advert_minutes
    return an explicit "not yet supported on this firmware variant"
    result so the operator gets a clear message instead of a silent
    no-op. Future release wires up CMD_SET_OTHER_PARAMS per ver_code.
    """
    # Read pre-state once.
    before = _runtime_state_binary(host, port, ident_seed=ident_seed)
    results: dict[str, dict[str, Any]] = {}

    if "tx_dbm" in requested:
        value = int(requested["tx_dbm"])
        try:
            frame = _encode_frame(CMD_SET_RADIO_TX_POWER, struct.pack("<b", value))
            raw = _txrx_frames(host, port, [frame], drain_secs=1.5)
            ok_seen = err_seen = False
            for opcode, _payload in _iter_frames(raw):
                if opcode == RESP_OK:
                    ok_seen = True
                elif opcode == RESP_ERR:
                    err_seen = True
            after = _runtime_state_binary(host, port, ident_seed=ident_seed)
            actual = after.get("tx_dbm")
            ok = ok_seen and not err_seen and actual == value
            row: dict[str, Any] = {
                "requested": value,
                "before": before.get("tx_dbm"),
                "after": actual,
                "ok": ok,
            }
            if not ok:
                row["error"] = (
                    "firmware nacked (RESP_ERR)" if err_seen
                    else f"firmware reported {actual} after set"
                    if actual is not None else "no readback after set"
                )
            results["tx_dbm"] = row
        except Exception as exc:  # noqa: BLE001
            results["tx_dbm"] = {
                "requested": value, "before": before.get("tx_dbm"),
                "after": None, "ok": False, "error": f"frame error: {exc}",
            }

    if "repeat" in requested:
        # CMD_SET_RADIO_PARAMS needs freq/bw/sf/cr from self_info AND the
        # new repeat flag. If we don't have the radio params cached, this
        # write would clobber the firmware defaults — refuse + report.
        freq = before.get("lora_freq_hz")
        bw = before.get("lora_bw_hz")
        sf = before.get("lora_sf")
        cr = before.get("lora_cr")
        value = bool(requested["repeat"])
        if None in (freq, bw, sf, cr):
            results["repeat"] = {
                "requested": value, "before": before.get("repeat"),
                "after": None, "ok": False,
                "error": (
                    "cannot set repeat: firmware didn't report current freq/bw/sf/cr "
                    "in CMD_APP_START reply. ↻ Refresh and try again."
                ),
            }
        else:
            try:
                payload_bytes = (
                    struct.pack("<I", int(freq))
                    + struct.pack("<I", int(bw))
                    + struct.pack("<B", int(sf))
                    + struct.pack("<B", int(cr))
                    + struct.pack("<B", 1 if value else 0)
                )
                frame = _encode_frame(CMD_SET_RADIO_PARAMS, payload_bytes)
                raw = _txrx_frames(host, port, [frame], drain_secs=1.5)
                ok_seen = err_seen = False
                for opcode, _payload in _iter_frames(raw):
                    if opcode == RESP_OK:
                        ok_seen = True
                    elif opcode == RESP_ERR:
                        err_seen = True
                after = _runtime_state_binary(host, port, ident_seed=ident_seed)
                actual = after.get("repeat")
                ok = ok_seen and not err_seen and actual == value
                row = {
                    "requested": value,
                    "before": before.get("repeat"),
                    "after": actual,
                    "ok": ok,
                }
                if not ok:
                    row["error"] = (
                        "firmware nacked (RESP_ERR)" if err_seen
                        else f"firmware reported {actual} after set"
                        if actual is not None else "no readback after set"
                    )
                results["repeat"] = row
            except Exception as exc:  # noqa: BLE001
                results["repeat"] = {
                    "requested": value, "before": before.get("repeat"),
                    "after": None, "ok": False, "error": f"frame error: {exc}",
                }

    if "gps" in requested:
        # 0.3.40 — GPS write via CMD_SET_CUSTOM_VAR (opcode 0x29).
        # Handler at MyMesh.cpp:3207-3232 takes `"key:value"` payload;
        # `"gps:1"` / `"gps:0"` flips _prefs.gps_enabled + savePrefs(). The
        # post-write readback comes from bridge.info.published `has_gps`
        # (no companion-protocol RPC reads it directly).
        value = bool(requested["gps"])
        try:
            payload_bytes = (b"gps:1" if value else b"gps:0")
            frame = _encode_frame(CMD_SET_CUSTOM_VAR, payload_bytes)
            raw = _txrx_frames(host, port, [frame], drain_secs=1.5)
            ok_seen = err_seen = False
            for opcode, _payload in _iter_frames(raw):
                if opcode == RESP_OK:
                    ok_seen = True
                elif opcode == RESP_ERR:
                    err_seen = True
            ok = ok_seen and not err_seen
            row: dict[str, Any] = {
                "requested": value,
                "before": before.get("gps"),
                # No direct readback opcode; the firmware persisted via
                # savePrefs() but we won't see the new `has_gps` until the
                # bridge emits its next info event (5-min cadence). Report
                # the requested value as `after` when the RESP_OK lands.
                "after": value if ok else before.get("gps"),
                "ok": ok,
            }
            if not ok:
                row["error"] = (
                    "firmware nacked CMD_SET_CUSTOM_VAR (RESP_ERR)" if err_seen
                    else "no RESP_OK after set"
                )
            results["gps"] = row
        except Exception as exc:  # noqa: BLE001
            results["gps"] = {
                "requested": value, "before": before.get("gps"),
                "after": None, "ok": False,
                "error": f"frame error: {exc}",
            }

    if "advert_minutes" in requested:
        # companion_radio has CMD_SET_OTHER_PARAMS but it doesn't include
        # advert_interval (only manual_add_contacts/telemetry/loc_policy/
        # multi_acks). The advert period is only operator-mutable via the
        # text CLI on simple_repeater* variants (`set advert.interval N`),
        # or programmatically through CMD_SET_CUSTOM_VAR — but the firmware
        # doesn't expose `advert_interval` as a registered custom var.
        # Surface a clear "not supported on this firmware" instead of a
        # silent no-op.
        results["advert_minutes"] = {
            "requested": requested["advert_minutes"],
            "before": before.get("advert_minutes"),
            "after": before.get("advert_minutes"),
            "ok": False,
            "error": (
                "advert_minutes is not exposed by companion_radio firmware. "
                "To change the advert cadence, flash a simple_repeater_tdoa_rx "
                "variant (text-CLI) or use the MeshCore desktop client's "
                "settings page."
            ),
        }

    final_parsed = _runtime_state_binary(host, port, ident_seed=ident_seed)
    return results, final_parsed


# --------------------------------------------------------------------------
# Port-check: enumerate TCP listeners on TDOA-relevant ports and flag any
# foreign processes (legacy meshcore-tcp-proxy, hand-rolled socat, an old
# bridge process whose port-release lost the race, etc.). The bridge MUST
# own each port it advertises via tcp_proxy_port; an interloper means the
# MeshCore client connects to a dead-end and the user sees "no contacts".
# --------------------------------------------------------------------------


def _ss_listening_tcp() -> dict[int, tuple[int, str]]:
    """Return ``{port: (pid, comm)}`` for every IPv4 LISTEN socket.

    Parses ``ss -tlnp`` once; cheap (~5 ms). When ``users:((...))`` is
    blank (root needed and we're not root) we fall through with pid=0
    and comm='' so the caller can still see the port is bound but doesn't
    blow up on a regex miss.
    """
    out: dict[int, tuple[int, str]] = {}
    try:
        r = subprocess.run(
            ["ss", "-tlnp4"],
            capture_output=True, text=True, timeout=4,
        )
    except (OSError, subprocess.SubprocessError):
        return out
    pat = re.compile(r":(\d+)\s.*users:\(\(\"(?P<comm>[^\"]+)\",pid=(?P<pid>\d+)")
    for line in r.stdout.splitlines():
        if "LISTEN" not in line:
            continue
        m = pat.search(line)
        if not m:
            # ports we see but can't attribute (non-root). Still useful
            # to know they're bound.
            m2 = re.search(r":(\d+)\s", line)
            if m2:
                out[int(m2.group(1))] = (0, "")
            continue
        out[int(m.group(1))] = (int(m.group("pid")), m.group("comm"))
    return out


def _bridge_pids() -> set[int]:
    """Pids of the meshcore-tdoa-gateway-bridge process tree."""
    try:
        r = subprocess.run(
            ["systemctl", "show", "meshcore-tdoa-gateway-bridge",
             "-p", "MainPID,ExecMainPID"],
            capture_output=True, text=True, timeout=4,
        )
    except (OSError, subprocess.SubprocessError):
        return set()
    pids: set[int] = set()
    for line in r.stdout.splitlines():
        if "=" in line:
            val = line.split("=", 1)[1].strip()
            if val.isdigit() and int(val) > 0:
                pids.add(int(val))
    return pids


@app.get("/api/host/port-check")
def port_check() -> dict[str, Any]:
    """Audit every TCP-passthrough port for foreign-process conflicts.

    Returns ``{checks: [...], warnings: [...]}``. Each ``check`` carries
    the port, the device slug we expect to own it (from meta.json), the
    actual listening process (pid + comm), and a ``conflict`` flag iff
    the listener isn't part of the bridge's process tree.

    Used by:
      * the portal UI Brokers/Devices tab — surfaces a ⚠️ banner when
        any port has a foreign owner (the "I can connect but see no
        contacts" failure mode 2026-05-25)
      * the upstream Grafana dashboard (via /api/host/port-check + a
        scrape) — alert when ``warnings`` is non-empty

    Mock-friendly: in TEST mode ``ss`` may not list the bridge's pid
    (it's not running locally) — we surface that as ``actual_owner=null``
    instead of an error so the UI doesn't dead-end.
    """
    listeners = _ss_listening_tcp()
    bridge_pids = _bridge_pids()

    checks: list[dict[str, Any]] = []
    seen_ports: set[int] = set()

    # Per-device expected ports — operator-set in meta.json via the
    # gear-icon modal's TCP-passthrough toggle.
    for d in _list_devices():
        port = d.get("tcp_proxy_port")
        if not port:
            continue
        seen_ports.add(int(port))
        listener = listeners.get(int(port))
        pid, comm = listener if listener else (None, None)
        is_bridge = pid is not None and (pid in bridge_pids)
        # When pid couldn't be attributed (non-root ss), accept the
        # port as "owned by the bridge" if the bridge process is
        # running AND no other process is in our snapshot.
        if pid == 0 and bridge_pids:
            is_bridge = True
        checks.append({
            "port": int(port),
            "device_slug": d["slug"],
            "device_name": d.get("gateway_name") or d["slug"],
            "expected_enabled": bool(d.get("tcp_proxy_enabled")),
            "listening": listener is not None,
            "actual_pid": pid,
            "actual_comm": comm,
            "owned_by_bridge": is_bridge,
            "conflict": (listener is not None) and not is_bridge,
        })

    # Catch any TDOA-range ports bound by SOMETHING we don't expect.
    # Range 5000-5010 is the operator convention; anything in this band
    # that's NOT in seen_ports is a stray.
    for port, (pid, comm) in listeners.items():
        if 5000 <= port <= 5010 and port not in seen_ports:
            checks.append({
                "port": port,
                "device_slug": None,
                "device_name": None,
                "expected_enabled": False,
                "listening": True,
                "actual_pid": pid,
                "actual_comm": comm,
                "owned_by_bridge": pid in bridge_pids,
                "conflict": pid not in bridge_pids,
            })

    warnings = [
        f"port {c['port']} bound by foreign process '{c['actual_comm']}' "
        f"(pid {c['actual_pid']}) — TCP-passthrough won't reach the bridge"
        for c in checks if c["conflict"]
    ]
    return {
        "checks": sorted(checks, key=lambda c: c["port"]),
        "warnings": warnings,
        "bridge_pids": sorted(bridge_pids),
        "mock": not PRODUCTION,
    }


_BRIDGE_STATUS_PATH = Path("/run/meshcore-tdoa-gateway-bridge/status.json")


def _read_bridge_status() -> dict[str, Any]:
    """Load the bridge's per-port health snapshot. Empty dict on miss."""
    try:
        return json.loads(_BRIDGE_STATUS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


_BRIDGE_VERSION_STAMP = Path("/etc/meshcore-bridge/deployed_version")


def _bridge_installed_version() -> str | None:
    """The INSTALLED bridge version, from the deb's version stamp.

    The bridge deb's postinst writes its package version to
    ``/etc/meshcore-bridge/deployed_version``. This is always present once the
    bridge package is installed, even if the bridge process can't run (no broker
    / no device / crash-loop) and therefore never writes its status.json. It's
    the fallback so the top bar can still show *which* bridge is installed.
    """
    try:
        v = _BRIDGE_VERSION_STAMP.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    return v or None


def _bridge_running_version() -> str | None:
    """The bridge version for the top bar — running if known, else installed.

    Preference order:
      1. The bridge's status.json ``bridge_version`` — the *running* process's
         version (it writes this at startup and on every flush). Authoritative
         when the bridge is actually up.
      2. The deb's ``deployed_version`` stamp — the *installed* version. Used
         when the bridge can't run (no broker/device/crash-loop) so the chip
         still shows something instead of vanishing.
    Returns None only when neither source exists (bridge not installed at all),
    in which case the UI hides the bridge chip.
    """
    v = _read_bridge_status().get("bridge_version")
    if isinstance(v, str) and v:
        return v
    return _bridge_installed_version()


def _bridge_status_for_slug(slug: str) -> dict[str, Any] | None:
    """Find the per-port snapshot whose ``port`` matches this device.

    The bridge keys snapshots by the sanitized port string (same
    sanitize_port helper it uses for MQTT topics). The portal's device
    list carries the by-id name; we match by checking whether the
    snapshot's ``port`` ends with the device's by-id name.
    """
    snap = _read_bridge_status().get("ports") or {}
    by_id = None
    tty = None
    for d in _list_devices():
        if d["slug"] == slug:
            by_id = d.get("by_id_name")
            tty = d.get("tty")
            break
    if not (by_id or tty):
        return None
    for port_entry in snap.values():
        if not isinstance(port_entry, dict):
            continue
        port = port_entry.get("port") or ""
        if by_id and by_id in port:
            return port_entry
        if tty and tty == port:
            return port_entry
    return None


def _port_last_packet_age_s(
    by_id: str | None, tty: str | None, ports: dict[str, Any]
) -> int | None:
    """Seconds since the bridge last received a packet on this device's
    port, or None if unknown. Non-recursive — takes a pre-read ``ports``
    snapshot so :func:`_list_devices` can call it without recursing
    through :func:`_bridge_status_for_slug` (which itself calls
    _list_devices). Drives the page dot's stale-port detection."""
    if not (by_id or tty):
        return None
    for entry in ports.values():
        if not isinstance(entry, dict):
            continue
        port = entry.get("port") or ""
        if (by_id and by_id in port) or (tty and tty == port):
            ts = entry.get("last_packet_at")
            if isinstance(ts, (int, float)) and ts > 0:
                return max(0, int(time.time() - ts))
            return None
    return None


def _port_node_id(by_id: str | None, tty: str | None, ports: dict[str, Any]) -> str | None:
    """The node_id (hex, e.g. "feedcafe9b5e") the bridge last saw on this
    device's port, from the pre-read ``ports`` snapshot. None if unknown.
    Surfaced on the device pill as the node's identity/name."""
    if not (by_id or tty):
        return None
    for entry in ports.values():
        if not isinstance(entry, dict):
            continue
        port = entry.get("port") or ""
        if (by_id and by_id in port) or (tty and tty == port):
            nid = entry.get("node_id")
            return nid if isinstance(nid, str) and nid else None
    return None


def _port_health(
    by_id: str | None, tty: str | None, ports: dict[str, Any]
) -> tuple[str | None, str | None]:
    """The bridge-reported (health, health_detail) for this device's port,
    from the pre-read ``ports`` snapshot (Erik #3). ``health`` is one of
    ``ok`` / ``serial_error`` / ``quarantined`` / ``unavailable`` and lets the
    pill explain *why* a port has no frames. (None, None) if unknown."""
    if not (by_id or tty):
        return None, None
    for entry in ports.values():
        if not isinstance(entry, dict):
            continue
        port = entry.get("port") or ""
        if (by_id and by_id in port) or (tty and tty == port):
            kind = entry.get("health")
            if isinstance(kind, str) and kind:
                detail = entry.get("health_detail")
                return kind, (detail if isinstance(detail, str) else "")
            return None, None
    return None, None


@app.get("/api/devices/{slug}/health")
def receiver_health(slug: str) -> dict[str, Any]:
    if not PRODUCTION:
        # mock — slight per-device variation so the cards visibly differ
        # when the operator switches devices
        seed = sum(ord(c) for c in slug)
        random.seed(seed + int(socket.gethostname().encode().hex(), 16) % 1000)
        # re-seed each call's wobble
        random.seed()
        drift_base = 39.0 if "heltec" in slug or "echo" in slug else 1.5
        drift = drift_base + random.uniform(-3, 3)
        sats = random.randint(11, 14)
        gps = True
        pps = True
        mock_family = 2 if ("heltec" in slug or "echo" in slug) else 1
        mock_chip_model = "L76K" if mock_family == 2 else "ZOE-M8Q"
        return {
            "mock": True,
            "gps_fix": gps, "gps_fix_kind": "3D fix",
            "sat_count": sats, "sat_min_for_fix": 4,
            "pps_locked": pps,
            "drift_ppm": round(drift, 1),
            "drift_limit_ppm": 100,
            "drift_valid": abs(drift) <= 100,
            "last_packet_received_at": "just now (mock)",
            "gps_chip_family": mock_family,
            "gps_chip_family_name": "L76K" if mock_family == 2 else "u-blox",
            "gps_chip_model": mock_chip_model,
            "gps_chip_sw_version": "URANUS5" if mock_family == 2 else "ROM3.01",
            "gps_bootstrap_ack": 0x0F,
            "gps_enabled_gnss_mask": 0x8B,
            "fw_version": "tdoa-mock",
            "tdoa_fw_version": "tdoa-mock",
            "board_name": "MockBoard",
            "mcu_chip": "MockMCU",
            "lora_chip": "SX1262",
            "has_gps": True,
            "has_pps": True,
            "is_tdoa_rx": True,
        }
    # PRODUCTION — read the bridge's per-port snapshot file. The bridge
    # updates this on every publish_frame / publish_info / publish_telemetry
    # so values are at most ~2s stale (status-write throttle window).
    snap = _bridge_status_for_slug(slug)
    if snap is None:
        # Distinguish "bridge not running" from "bridge up but this port not seen
        # yet" (unplugged / quarantined / starting) so the operator isn't left
        # guessing why there's no data (#C).
        try:
            _up = _BRIDGE_STATUS_PATH.exists() and (time.time() - _BRIDGE_STATUS_PATH.stat().st_mtime) < 30
        except OSError:
            _up = False
        return {
            "mock": False,
            "gps_fix": None, "gps_fix_kind": "no bridge snapshot",
            "sat_count": None, "sat_min_for_fix": 4,
            "pps_locked": None,
            "drift_ppm": None, "drift_limit_ppm": 100, "drift_valid": None,
            "last_packet_received_at": None,
            "health": ("no_data" if _up else "bridge_unavailable"),
            "health_detail": (
                "bridge running but no snapshot for this port yet (unplugged, quarantined, or starting)"
                if _up else
                "bridge service not running / not writing its status file"
            ),
        }
    gps_fix = snap.get("gps_3d_fix")
    pps_locked = snap.get("pps_locked")
    sat_count = snap.get("sat_count") or snap.get("gps_sats")
    drift_ppm = snap.get("drift_ppm")
    last_pkt_ts = snap.get("last_packet_at")
    if isinstance(last_pkt_ts, (int, float)):
        import datetime as _dt
        last_pkt_str = _dt.datetime.fromtimestamp(last_pkt_ts).isoformat()
    else:
        last_pkt_str = None
    return {
        "mock": False,
        "gps_fix": gps_fix,
        "gps_fix_kind": "3D fix" if gps_fix else ("no fix" if gps_fix is False else "unknown"),
        "sat_count": sat_count,
        "sat_min_for_fix": 4,
        "pps_locked": pps_locked,
        "drift_ppm": (round(float(drift_ppm), 1) if isinstance(drift_ppm, (int, float)) else None),
        "drift_limit_ppm": 100,
        "drift_valid": (abs(float(drift_ppm)) <= 100 if isinstance(drift_ppm, (int, float)) else None),
        "last_packet_received_at": last_pkt_str,
        # tdoa 2026-05-29 PM — probe-detected GPS chip identity, cached
        # into the bridge per-port status snapshot by publish_info().
        # NULL on receivers whose firmware predates the 147-byte 0x94
        # GATEWAY_INFO tail (legacy 104/112-byte boards never populate
        # these). The portal renders a dedicated chip-identity card so
        # the operator can confirm "this Heltec V4 actually carries an
        # L76K" without leaving the gateway page.
        "gps_chip_family": snap.get("gps_chip_family"),
        "gps_chip_family_name": snap.get("gps_chip_family_name"),
        "gps_chip_model": snap.get("gps_chip_model"),
        "gps_chip_sw_version": snap.get("gps_chip_sw_version"),
        "gps_bootstrap_ack": snap.get("gps_bootstrap_ack"),
        "gps_enabled_gnss_mask": snap.get("gps_enabled_gnss_mask"),
        # Companion FW + capability flags, surfaced so the same /health
        # call populates the FW section without a second round-trip.
        "fw_version": snap.get("firmware_version"),
        "tdoa_fw_version": snap.get("tdoa_firmware_version"),
        "board_name": snap.get("board_name"),
        "mcu_chip": snap.get("mcu_chip"),
        "lora_chip": snap.get("lora_chip"),
        "has_gps": snap.get("has_gps"),
        "has_pps": snap.get("has_pps"),
        "is_tdoa_rx": snap.get("is_tdoa_rx"),
        # 2026-06-09 (#C): surface the bridge's per-port health so the UI/operator
        # sees the REAL failure (serial_error / quarantined / unavailable) instead
        # of just "no fix" / "no data". health="ok" once the port produces frames.
        "health": snap.get("health"),
        "health_detail": snap.get("health_detail"),
    }


@app.post("/api/devices/{slug}/restart")
def restart_service(slug: str) -> dict[str, Any]:
    """Restart the bridge that reads this device.

    There is ONE bridge per Pi handling all USB receivers — there is no
    per-device ``meshcore-tdoa-gateway@<slug>.service`` template (the old code
    restarted that non-existent unit → systemd "Unit not found" → HTTP 500 on
    every click; Erik 2026-06-06). "Restart this device" therefore restarts the
    bridge, which re-opens all ports including this one.
    """
    unit = _bridge_unit_name()
    if not PRODUCTION:
        return {"ok": True, "mock": True, "would_run": f"systemctl restart {unit}"}
    # _restart_bridge() uses the sudoers-allowed `sudo -n systemctl restart
    # <bridge-unit>` and raises HTTPException(500) with the real stderr on
    # failure (e.g. sudoers misconfig) — a clear, actionable error, not the
    # old "Unit meshcore-tdoa-gateway@<slug> not found".
    _restart_bridge()
    return {"ok": True, "mock": False, "unit": unit}


# ---------------------------------------------------------------------------
# Contact operator — visitor-to-operator messaging via Telegram.
#
# Visitors of the per-Pi portal page get a small "Message operator"
# form (rendered in static/index.html). The form POSTs here; this
# endpoint forwards the message to a Telegram chat the operator
# already monitors on their phone.
#
# Why Telegram instead of SMTP: no app-password dance, no DKIM, no
# inbox config — just a bot token + chat ID. Setup:
#
#   1. Open Telegram, talk to @BotFather, send /newbot, pick a name +
#      handle. BotFather replies with a token like "12345:ABC...".
#   2. Open Telegram, talk to your new bot (any message). Then visit
#      https://api.telegram.org/bot<TOKEN>/getUpdates — find
#      result[0].message.chat.id (an integer like 123456789).
#   3. Set both in /etc/meshcore-tdoa-gateway-portal/portal.env:
#        TELEGRAM_BOT_TOKEN=12345:ABC...
#        TELEGRAM_OPERATOR_CHAT_ID=123456789
#      then `systemctl restart meshcore-tdoa-gateway-portal`.
#
# If either env var is unset the endpoint returns 503 with a clear
# error and the form stays hidden in the UI.
# ---------------------------------------------------------------------------

TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_OPERATOR_CHAT_ID = os.environ.get("TELEGRAM_OPERATOR_CHAT_ID", "").strip()

# Per-IP rate limit: at most one message per N seconds. Simple in-
# memory dict — survives only as long as the portal process; that's
# fine for the "casual visitor wants to say hi" use case.
_CONTACT_RATELIMIT_SECONDS = 60
_contact_last_sent: dict[str, float] = {}


def _telegram_send(text: str, *, markdown: bool = False) -> None:
    """Post a message to the operator's Telegram chat.

    Defaults to PLAIN TEXT (markdown=False). Machine-generated content (the
    registration diagnostic, log-bundle captions) routinely contains `_`, `*`,
    `[`, backticks etc. — with parse_mode=Markdown Telegram rejects it as
    HTTP 400 "can't parse entities". Plain text is always safe. Set
    markdown=True only for a message you've authored with valid Markdown.

    Stdlib-only. Raises HTTPException(502) on any transport/API error. Callers
    must have verified TELEGRAM_BOT_TOKEN + TELEGRAM_OPERATOR_CHAT_ID.
    """
    import json as _json
    import urllib.error
    import urllib.parse
    import urllib.request

    fields = {
        "chat_id": TELEGRAM_OPERATOR_CHAT_ID,
        "text": text,
        "disable_web_page_preview": "true",
    }
    if markdown:
        fields["parse_mode"] = "Markdown"
    body = urllib.parse.urlencode(fields).encode("utf-8")
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            tg = _json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise HTTPException(502, f"Telegram API rejected the message: HTTP {exc.code}")
    except urllib.error.URLError as exc:
        raise HTTPException(502, f"Telegram API unreachable: {exc.reason}")
    if not tg.get("ok"):
        raise HTTPException(502, f"Telegram API error: {tg.get('description', '?')}")


def _telegram_send_document(filename: str, content: bytes, caption: str = "") -> None:
    """Upload a file to the operator's Telegram chat via sendDocument.

    Stdlib-only multipart/form-data (no requests dep). Used to attach a log
    bundle to a diagnostic report. Caption is plain text (Telegram caps it at
    1024 chars; we trim). Raises HTTPException(502) on any transport/API error.
    Callers must have verified TELEGRAM_BOT_TOKEN + TELEGRAM_OPERATOR_CHAT_ID.
    """
    import json as _json
    import urllib.error
    import urllib.request

    # Build a multipart body by hand. Boundary is fixed-but-unique-enough; the
    # content is our own bytes so there's no injection surface.
    boundary = "----meshcoreTDOAlogbundle7f3a9c"
    pre = []
    pre.append(f"--{boundary}")
    pre.append('Content-Disposition: form-data; name="chat_id"')
    pre.append("")
    pre.append(str(TELEGRAM_OPERATOR_CHAT_ID))
    if caption:
        pre.append(f"--{boundary}")
        pre.append('Content-Disposition: form-data; name="caption"')
        pre.append("")
        pre.append(caption[:1024])
    pre.append(f"--{boundary}")
    pre.append(
        f'Content-Disposition: form-data; name="document"; filename="{filename}"'
    )
    pre.append("Content-Type: text/plain; charset=utf-8")
    pre.append("")
    head = ("\r\n".join(pre) + "\r\n").encode("utf-8")
    tail = (f"\r\n--{boundary}--\r\n").encode("utf-8")
    data = head + content + tail

    req = urllib.request.Request(
        f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendDocument",
        data=data,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            tg = _json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise HTTPException(502, f"Telegram API rejected the document: HTTP {exc.code}")
    except urllib.error.URLError as exc:
        raise HTTPException(502, f"Telegram API unreachable: {exc.reason}")
    if not tg.get("ok"):
        raise HTTPException(502, f"Telegram API error: {tg.get('description', '?')}")


class ContactOperatorPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")
    message: str = Field(..., min_length=1, max_length=2000)
    from_name: str | None = Field(None, max_length=120)
    reply_to: str | None = Field(None, max_length=200)


@app.get("/api/contact-operator/status")
def contact_operator_status() -> dict[str, Any]:
    """Cheap probe the frontend hits on page load to decide whether to
    render the "Message operator" form at all."""
    return {
        "configured": bool(TELEGRAM_BOT_TOKEN and TELEGRAM_OPERATOR_CHAT_ID),
        "ratelimit_seconds": _CONTACT_RATELIMIT_SECONDS,
    }


@app.post("/api/contact-operator/test")
def contact_operator_test() -> dict[str, Any]:
    """Send a one-line "this is a test" message to the configured chat.

    Bypasses the visitor rate-limit (operator-only use, called from
    the helper script + the in-page Test button). Useful for:

      * confirming TELEGRAM_BOT_TOKEN + TELEGRAM_OPERATOR_CHAT_ID
        are wired correctly after editing portal.env
      * proving network egress from the Pi can reach Telegram
        (e.g. behind cloudflared)
    """
    if not (TELEGRAM_BOT_TOKEN and TELEGRAM_OPERATOR_CHAT_ID):
        raise HTTPException(503, "Operator contact not configured.")
    host = socket.gethostname()
    text = f"✅ Test message from *{host}* — Telegram link is live."
    import json as _json
    import urllib.error
    import urllib.parse
    import urllib.request

    body = urllib.parse.urlencode({
        "chat_id": TELEGRAM_OPERATOR_CHAT_ID,
        "text": text,
        "parse_mode": "Markdown",
    }).encode("utf-8")
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            tg = _json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise HTTPException(502, f"Telegram API rejected: HTTP {exc.code}")
    except urllib.error.URLError as exc:
        raise HTTPException(502, f"Telegram API unreachable: {exc.reason}")
    if not tg.get("ok"):
        raise HTTPException(502, f"Telegram API error: {tg.get('description', '?')}")
    return {"ok": True, "host": host}


@app.post("/api/contact-operator")
def contact_operator(payload: ContactOperatorPayload, request: Request) -> dict[str, Any]:
    """Forward a visitor's message to the operator's Telegram chat."""
    if not (TELEGRAM_BOT_TOKEN and TELEGRAM_OPERATOR_CHAT_ID):
        raise HTTPException(
            503,
            "Operator contact not configured on this gateway. Set "
            "TELEGRAM_BOT_TOKEN + TELEGRAM_OPERATOR_CHAT_ID in "
            "/etc/meshcore-tdoa-gateway-portal/portal.env.",
        )
    # Resolve the source IP. Cloudflared / nginx may set X-Forwarded-
    # For; fall back to the raw socket peer for direct-LAN visitors.
    ip = (
        (request.headers.get("x-forwarded-for") or "").split(",")[0].strip()
        or (request.client.host if request.client else "unknown")
    )
    now = time.time()
    last = _contact_last_sent.get(ip, 0.0)
    if now - last < _CONTACT_RATELIMIT_SECONDS:
        retry_in = int(_CONTACT_RATELIMIT_SECONDS - (now - last))
        raise HTTPException(
            429,
            f"Rate limited — try again in {retry_in}s. "
            "One message per minute per visitor.",
        )

    # Build the Telegram message. Prefix with the gateway hostname so
    # the operator instantly knows which Pi the visitor was looking at.
    host = socket.gethostname()
    parts = [
        f"📡 *{host}* portal contact",
        f"from: `{ip}`" + (
            f"  ({payload.from_name})" if payload.from_name else ""
        ),
    ]
    if payload.reply_to:
        parts.append(f"reply to: `{payload.reply_to}`")
    parts.append("")
    parts.append(payload.message)
    telegram_text = "\n".join(parts)

    # Send via Telegram's HTTP API. Stdlib only — no extra deps.
    import json as _json
    import urllib.error
    import urllib.parse
    import urllib.request

    body = urllib.parse.urlencode({
        "chat_id": TELEGRAM_OPERATOR_CHAT_ID,
        "text": telegram_text,
        "parse_mode": "Markdown",
        "disable_web_page_preview": "true",
    }).encode("utf-8")
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            tg = _json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise HTTPException(502, f"Telegram API rejected the message: HTTP {exc.code}")
    except urllib.error.URLError as exc:
        raise HTTPException(502, f"Telegram API unreachable: {exc.reason}")
    if not tg.get("ok"):
        raise HTTPException(502, f"Telegram API error: {tg.get('description', '?')}")

    _contact_last_sent[ip] = now
    return {"ok": True, "sent_at": int(now)}


# ---------------------------------------------------------------------------
# Local firmware flash — operator picks role, portal flashes the connected
# LoRa MCU with a pre-shipped image from the deb's firmware bundle.
# ---------------------------------------------------------------------------
#
# The bundle lives at /usr/share/meshcore-tdoa-gateway-portal/firmware/,
# laid out as:
#   firmware/
#       flash-modes.json
#       <hardware_id>/
#           <role>.<uf2|bin>
#           <role>.<uf2|bin>.sha256
#           <role>.<uf2|bin>.meta.json
#
# Hardware-ID resolution: the bridge publishes a bridge.info.published
# event that includes ``board`` (e.g. "Heltec V4 (LoRa32 v4)"). We map
# that board string → hardware_id via a small registry below. The
# portal's existing /api/devices/{slug}/health endpoint already reads
# bridge journals; we reuse that style here.
#
# Flash backend tools — operator NEVER touches the hardware:
#   - heltec_v4 → esptool drives DTR/RTS automatically (default
#     --before default-reset / --after hard-reset) to put the ESP32-S3
#     into USB-JTAG ROM bootloader; explicit here for clarity.
#   - lilygo_techo / rak4631 → open the USB-CDC port at 1200 baud then
#     close it. Both Adafruit-style and Nordic-style nRF52 bootloaders
#     interpret the 1200-baud touch as "drop to bootloader". This is
#     the Python primitive form — equivalent to
#     `adafruit-nrfutil dfu serial --touch 1200 -p PORT -b 115200`
#     but skips the dfu subcommand (we only want the touch; the actual
#     image goes in via UF2 dragdrop, not nrfutil's DFU protocol).
#     After the touch, the USB descriptor SWAPS — that's why every tty
#     resolution uses the stable `/dev/meshcore/serial-<hwserial>-if00`
#     symlink shipped by the 0.3.21 udev rule.

_FW_BUNDLE_DIR = Path(
    os.environ.get(
        "FW_BUNDLE_DIR",
        "/usr/share/meshcore-tdoa-gateway-portal/firmware",
    )
)

# board string → hardware_id. The board string is EITHER the firmware's clean
# GW_INFO_BOARD_NAME (e.g. "Heltec V4") OR — when the bridge hasn't published an
# info.published yet — the raw USB-descriptor slug (e.g.
# "ESPRESSIF-SYSTEMS-HELTEC-WIFI-LORA-32-V4-16-MB-FLASH-2-MB-PSRAM-"). We MUST
# match both forms, for every board we ship images for, or the FW panel shows
# "Couldn't determine hardware" (Erik/Heltec-V4 2026-06-06). Matching is
# separator-insensitive: we normalise '-' and '_' to spaces before substring
# search, so "heltec-wifi-lora-32-v4" and "Heltec V4" both hit the same needle.
_BOARD_TO_HARDWARE_ID: list[tuple[str, str]] = [
    # Heltec V4 (ESP32-S3). Clean name "Heltec V4"; USB slug
    # "Espressif_Systems_heltec_wifi_lora_32_v4__16_MB_FLASH...".
    ("heltec v4", "heltec_v4"),
    ("heltec wifi lora 32 v4", "heltec_v4"),
    ("lora32 v4", "heltec_v4"),
    # LilyGo T-Echo (nRF52). Clean "LilyGo T-Echo"; USB slug often "LilyGo"/"T-Echo".
    ("lilygo t echo", "lilygo_techo"),
    ("t echo", "lilygo_techo"),
    ("techo", "lilygo_techo"),
    ("lilygo", "lilygo_techo"),
    # RAK4631 (nRF52). Clean "RAK4631"; USB slug "RAKwireless_WisCore_RAK4631_Board".
    ("rak4631", "rak4631"),
    ("rakwireless", "rak4631"),
    ("wiscore", "rak4631"),
    # Wio-E5 mini (STM32WLE5). board_name "Wio E5 Mini"; module/dev-board spellings.
    # NOTE: its USB bridge is a generic CP2102 — we can't map CP2102 alone (also
    # used by other boards), so Wio-E5 is only matched by its board_name.
    ("wio e5 mini", "wio_e5_mini"),
    ("wio e5", "wio_e5_mini"),
    ("lora e5", "wio_e5_mini"),
]


def _hardware_id_from_board(board: str | None) -> str | None:
    if not board:
        return None
    # Normalise separators so the USB slug (hyphen/underscore-joined) and the
    # clean board name (space-separated) both match the same needles.
    b = board.lower().replace("-", " ").replace("_", " ")
    b = " ".join(b.split())  # collapse repeated spaces from "__" in USB slugs
    for needle, hw in _BOARD_TO_HARDWARE_ID:
        if needle in b:
            return hw
    return None


# 0.3.29 — human-readable hardware names + role-from-fw helpers.
# Maps the same set of hardware_ids as _BOARD_TO_HARDWARE_ID to a short
# operator-facing label. The label is what the device-pill shows
# instead of the giant USB-vendor slug ("espressif-systems-heltec-
# wifi-lora-32-v4-16-mb-flash-2-mb-psram-"). Falls back to a derived
# Title-Case-with-spaces version of the slug for hardware we haven't
# catalogued yet.
_HARDWARE_HUMAN_LABEL: dict[str, str] = {
    "heltec_v4":     "Heltec V4",
    "lilygo_techo":  "LilyGo T-Echo",
    "rak4631":       "RAK4631",
    "heltec_v3":     "Heltec V3",
    "wio_e5_mini":   "Wio-E5 mini",
}


def _humanize_hardware_label(hardware_id: str | None, slug: str) -> str:
    """Return a short operator-facing hardware label.

    Used by the device-pill on the frontend instead of the raw USB-
    vendor slug. The frontend can override / extend with operator-set
    ``gateway_name`` — this is the FALLBACK when no name is set, plus
    a tooltip-friendly board-family hint shown next to gateway_name.

    When ``hardware_id`` is None (cold path, board not yet introspected)
    we derive a best-effort Title-Case label from the slug: drop the
    common vendor prefixes, replace dashes with spaces, capitalize.
    """
    if hardware_id and hardware_id in _HARDWARE_HUMAN_LABEL:
        return _HARDWARE_HUMAN_LABEL[hardware_id]
    # Strip vendor-prefix noise we know about — leaves the model token.
    s = slug
    for prefix in (
        "espressif-systems-",
        "rakwireless-",
        "lilygo-",
        "nordic-",
        "stmicroelectronics-",
    ):
        if s.startswith(prefix):
            s = s[len(prefix):]
            break
    # Drop trailing memory-spec garbage like "16-mb-flash-2-mb-psram-"
    s = re.sub(r"-\d+-mb.*$", "", s)
    s = re.sub(r"-board-[0-9a-f]+$", "", s, flags=re.IGNORECASE)
    # Title-case the surviving tokens. "heltec-wifi-lora-32-v4" → "Heltec Wifi Lora 32 V4".
    parts = [p for p in s.split("-") if p]
    if not parts:
        return slug
    return " ".join(p.upper() if p.isupper() or len(p) <= 2 else p.capitalize()
                    for p in parts)


def _load_flash_modes() -> dict[str, Any]:
    path = _FW_BUNDLE_DIR / "flash-modes.json"
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _list_firmware_for_hardware(hardware_id: str) -> list[dict[str, Any]]:
    """Return [{role, filename, sha256, size_bytes, built_at}] for hardware_id."""
    hw_dir = _FW_BUNDLE_DIR / hardware_id
    if not hw_dir.is_dir():
        return []
    out: list[dict[str, Any]] = []
    for entry in sorted(hw_dir.iterdir()):
        if entry.suffix not in (".bin", ".uf2"):
            continue
        meta_path = entry.with_suffix(entry.suffix + ".meta.json")
        sha_path = entry.with_suffix(entry.suffix + ".sha256")
        meta: dict[str, Any] = {}
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                pass
        sha = ""
        if sha_path.exists():
            try:
                sha = sha_path.read_text(encoding="utf-8").strip()
            except OSError:
                pass
        out.append({
            "role": meta.get("role") or entry.stem,
            "filename": entry.name,
            "sha256": sha,
            "size_bytes": meta.get("size_bytes") or entry.stat().st_size,
            "built_at": meta.get("built_at"),
            "pio_env": meta.get("pio_env"),
            "git_sha": meta.get("git_sha"),
            "git_tag": meta.get("git_tag"),
            # source + version surface in the UI option label so the
            # operator sees which release each TDOA image came from.
            # ``tdoa_tag`` is populated by build-firmware-bundle.sh on
            # the TDOA-fork pull (e.g. "tdoa-1.12.16"); ``git_tag`` is
            # populated by the local PIO build (same shape, e.g.
            # "tdoa-1.12.18"); ``source`` is "tdoa-fork" for downloaded
            # artefacts, absent/None for legacy local-PIO builds.
            "source": meta.get("source"),
            "tdoa_tag": meta.get("tdoa_tag"),
            "tdoa_asset_name": meta.get("tdoa_asset_name"),
        })
    return out


def _latest_bridge_info(slug: str, *, by_id_name: str | None = None,
                        since: str = "-7d") -> dict[str, Any] | None:
    """Find the newest ``bridge.info.published`` event for this device.

    Returns the full parsed JSON payload (board, fw, mcu, lora, has_gps,
    has_pps, is_tdoa_rx, ...) or ``None`` when no event in the look-back
    window mentions this device's by-id name.

    0.3.29 — extracted from _device_hardware_id so the same journal-walk
    powers BOTH hardware_id resolution AND the runtime status-dot
    (which needs is_tdoa_rx + has_gps). Caches the result in the
    per-device meta.json under ``last_info`` so subsequent reads are
    file-cheap, not journal-shell-out-cheap.
    """
    if by_id_name is None:
        # Read directly from meta.json (not _list_devices) — _list_devices
        # now itself calls _device_hardware_id which would call back into
        # this function, causing unbounded recursion.
        meta = _load_meta(slug) or {}
        by_id_name = meta.get("by_id_name")
    if not by_id_name:
        # 0.3.29-fix — meta.json on legacy / hand-bootstrapped devices
        # doesn't carry by_id_name. Walk /dev/serial/by-id/ and pick the
        # path whose basename normalises to this slug. Without this,
        # _has_tdoa_fw + hardware_label both stay empty on the live
        # fleet because the journal scrape has no needle to grep on.
        by_id_name = _by_id_name_for_slug(slug)
        if by_id_name:
            # Persist for future calls so we don't walk the FS again.
            meta = _load_meta(slug) or {}
            meta["by_id_name"] = by_id_name
            _save_meta(slug, meta)
    if not by_id_name:
        return None
    try:
        proc = subprocess.run(
            [
                "journalctl",
                "-u", "meshcore-bridge.service",
                "-u", "meshcore-tdoa-gateway-bridge.service",
                "--since", since,
                "-o", "cat",
                "--no-pager",
            ],
            capture_output=True, text=True, timeout=10,
        )
        lines = proc.stdout.splitlines()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return None
    # Walk newest-first looking for an info.published event for this device.
    for line in reversed(lines):
        if "bridge.info.published" not in line or by_id_name not in line:
            continue
        idx = line.find("{")
        if idx < 0:
            continue
        try:
            doc = json.loads(line[idx:])
        except (ValueError, TypeError):
            continue
        return doc
    # 0.3.35 — stale by_id_name self-heal (DFU descriptor swap).
    # T-Echo enumerates as "LilyGo T-Echo" in some boot modes and
    # "Nordic_NRF52_DK" in others; the cached value can fall out of
    # sync with what the bridge is currently publishing. If the cached
    # name yielded nothing AND the live FS walk returns a different
    # name, retry the scrape with the fresh value + update meta so
    # subsequent reads use the right needle.
    live = _by_id_name_for_slug(slug)
    if live and live != by_id_name:
        for line in reversed(lines):
            if "bridge.info.published" not in line or live not in line:
                continue
            idx = line.find("{")
            if idx < 0:
                continue
            try:
                doc = json.loads(line[idx:])
            except (ValueError, TypeError):
                continue
            # Cache the fresh by_id_name so the next call uses it directly.
            meta = _load_meta(slug) or {}
            meta["by_id_name"] = live
            _save_meta(slug, meta)
            return doc
    return None


def _refresh_last_info_cache(slug: str) -> dict[str, Any] | None:
    """Pull the latest bridge.info.published from the journal and persist it.

    Writes the FULL info doc into meta.json's ``last_info`` key with a
    ``last_info_cached_at`` timestamp. Subsequent _has_tdoa_fw /
    has_gps lookups read from this cache directly without re-scanning
    the journal (which costs ~50 ms per device per page-load
    otherwise). Called opportunistically on the cold path AND
    explicitly from the bridge-info cron sweep (added below).
    """
    info = _latest_bridge_info(slug)
    if info is None:
        return None
    meta = _load_meta(slug) or {}
    meta["last_info"] = info
    meta["last_info_cached_at"] = time.time()
    _save_meta(slug, meta)
    return info


def _device_hardware_id(slug: str) -> str | None:
    """Resolve a device slug to its hardware_id.

    Order:
      1. The bridge's cached ``last_info.board`` (the firmware's clean
         GW_INFO_BOARD_NAME) — best signal once the bridge has published.
      2. FALLBACK: the device SLUG itself. The slug is derived from the USB
         descriptor (e.g. "espressif-systems-heltec-wifi-lora-32-v4-..."),
         which _hardware_id_from_board can now match (separator-insensitive).
         This lets the FW panel resolve the board BEFORE any info.published —
         the cold-start case that showed "Couldn't determine hardware for
         ESPRESSIF-SYSTEMS-HELTEC-WIFI-LORA-32-V4-..." (Erik 2026-06-06).

    0.3.29 reads last_info from meta.json first (cheap), falling back to a
    fresh journal scrape. ``_hardware_id_from_board`` does the string-match.
    """
    meta = _load_meta(slug) or {}
    info = meta.get("last_info")
    if not isinstance(info, dict):
        info = _refresh_last_info_cache(slug)
    if isinstance(info, dict):
        hw = _hardware_id_from_board(info.get("board"))
        if hw:
            return hw
    # Cold path: no info.published yet (or board unmatched) → try the USB slug.
    return _hardware_id_from_board(slug)


# ---------------------------------------------------------------------------
# Upstream vanilla MeshCore — "revert to original" path
# ---------------------------------------------------------------------------
#
# In addition to the pre-shipped TDOA firmware bundle, the portal can flash
# the latest UPSTREAM MeshCore release (from meshcore-dev/MeshCore on
# GitHub). This is the "I want my node off the TDOA fork and back on
# stock MeshCore" path — operator selects the role (companion-radio,
# repeater, room-server) and we download + flash the matching asset from
# the upstream release. No TDOA changes survive.
#
# Asset-name patterns observed in upstream MeshCore releases (per
# v1.15.0 and onwards):
#   heltec_v4_companion_radio_usb-v1.15.0-<commit>-merged.bin
#   heltec_v4_repeater-v1.15.0-<commit>-merged.bin
#   LilyGo_T-Echo_companion_radio_usb-v1.15.0-<commit>.uf2
#   LilyGo_T-Echo_room_server-v1.15.0-<commit>.uf2
#   RAK_4631_companion_radio_usb-v1.15.0-<commit>.uf2
#   RAK_4631_repeater-v1.15.0-<commit>.uf2
#
# Per hardware_id we list which asset name PREFIXES are accepted +
# which role each maps to.  Prefixes are matched case-insensitively
# against the asset name's stem. ``ext`` is the file extension required
# (matches the flash-modes.json ``tool`` constraint: .bin for esptool,
# .uf2 for uf2-dragdrop).
_UPSTREAM_MESHCORE_REPO = "meshcore-dev/MeshCore"
_UPSTREAM_ASSET_PATTERNS: dict[str, list[tuple[str, str, str]]] = {
    # hardware_id -> [(role, asset_prefix_lowercase, required_ext), ...]
    "heltec_v4": [
        ("companion_radio_usb", "heltec_v4_companion_radio_usb-", ".bin"),
        ("companion_radio_ble", "heltec_v4_companion_radio_ble-", ".bin"),
        ("repeater",            "heltec_v4_repeater-",            ".bin"),
        ("room_server",         "heltec_v4_room_server-",         ".bin"),
    ],
    "heltec_v3": [
        ("companion_radio_usb", "heltec_v3_companion_radio_usb-", ".bin"),
        ("companion_radio_ble", "heltec_v3_companion_radio_ble-", ".bin"),
        ("repeater",            "heltec_v3_repeater-",            ".bin"),
        ("room_server",         "heltec_v3_room_server-",         ".bin"),
    ],
    "lilygo_techo": [
        ("companion_radio_usb", "lilygo_t-echo_companion_radio_usb-", ".uf2"),
        ("companion_radio_ble", "lilygo_t-echo_companion_radio_ble-", ".uf2"),
        ("repeater",            "lilygo_t-echo_repeater-",            ".uf2"),
        ("room_server",         "lilygo_t-echo_room_server-",         ".uf2"),
    ],
    "rak4631": [
        # Upstream uses "RAK_4631" with an underscore; we accept either
        # form to absorb future renaming.
        ("companion_radio_usb", "rak_4631_companion_radio_usb-",  ".uf2"),
        ("companion_radio_ble", "rak_4631_companion_radio_ble-",  ".uf2"),
        ("repeater",            "rak_4631_repeater-",             ".uf2"),
        ("room_server",         "rak_4631_room_server-",          ".uf2"),
        ("companion_radio_usb", "rak4631_companion_radio_usb-",   ".uf2"),
        ("repeater",            "rak4631_repeater-",              ".uf2"),
    ],
}


def _list_upstream_meshcore_bundled(hardware_id: str | None) -> dict[str, Any] | None:
    """Read the baked-at-build-time upstream MeshCore bundle from disk.

    The deb's build-firmware-bundle.sh downloads the latest vanilla
    meshcore-dev/MeshCore release at PACKAGE BUILD TIME and ships the
    assets under ``firmware-bundle/<hardware_id>/upstream/<role>.<ext>``
    (with ``.sha256`` + ``.meta.json`` sidecars).  We read those here
    — no GitHub round-trip, no runtime network dependency, no auth
    headaches when the Pi has spotty internet.

    Returns ``None`` when no hardware_id is known or no upstream bundle
    shipped for this hardware.  When the bundle exists but contains
    zero usable assets, returns a record with empty ``assets`` so the
    UI can show "no upstream asset available for this hardware".
    """
    if not hardware_id:
        return None
    upstream_dir = _FW_BUNDLE_DIR / hardware_id / "upstream"
    if not upstream_dir.is_dir():
        return None
    assets: list[dict[str, Any]] = []
    upstream_tag: str | None = None
    for entry in sorted(upstream_dir.iterdir()):
        if entry.suffix not in (".bin", ".uf2"):
            continue
        meta_path = entry.with_suffix(entry.suffix + ".meta.json")
        sha_path = entry.with_suffix(entry.suffix + ".sha256")
        meta: dict[str, Any] = {}
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                pass
        sha = ""
        if sha_path.exists():
            try:
                sha = sha_path.read_text(encoding="utf-8").strip()
            except OSError:
                pass
        if upstream_tag is None and meta.get("upstream_tag"):
            upstream_tag = meta["upstream_tag"]
        assets.append({
            "role": meta.get("role") or entry.stem,
            "filename": entry.name,
            "sha256": sha,
            "size_bytes": meta.get("size_bytes") or entry.stat().st_size,
            "version": meta.get("upstream_tag"),
            "upstream_asset_name": meta.get("upstream_asset_name"),
            "source": "upstream-meshcore",
        })
    return {
        "version": upstream_tag,
        "repo": _UPSTREAM_MESHCORE_REPO,
        "release_url": (
            f"https://github.com/{_UPSTREAM_MESHCORE_REPO}/releases/tag/{upstream_tag}"
            if upstream_tag else None
        ),
        "assets": assets,
    }


# node_function → set of role-prefixes that should pass the firmware
# filter.  ``companion`` accepts both vanilla companion_radio_* AND the
# TDOA-RX build (the TDOA receiver is a companion-mode firmware with
# extra timestamp telemetry on top — operationally still a companion).
# ``repeater`` / ``room_server`` are 1:1 with their upstream tag.
_NODE_FUNCTION_ROLE_PREFIXES: dict[str, tuple[str, ...]] = {
    "companion":   ("companion", "tdoa-rx", "tdoa_rx"),
    "repeater":    ("repeater",),
    "room_server": ("room-server", "room_server"),
    "tdoa_rx":     ("tdoa-rx", "tdoa_rx"),
}


def _role_matches_node_function(role: str | None, node_function: str | None) -> bool:
    """True iff this asset's role belongs to the operator-chosen node function."""
    if not node_function or not role:
        return False
    prefixes = _NODE_FUNCTION_ROLE_PREFIXES.get(node_function, ())
    rl = role.lower()
    return any(rl.startswith(p) for p in prefixes)


@app.get("/api/devices/{slug}/firmware/available")
def firmware_available(slug: str) -> dict[str, Any]:
    """List pre-shipped firmware images for the hardware connected at ``slug``.

    Returns the hardware_id, the per-role file list filtered by the
    operator-chosen ``node_function`` (from per-device meta.json), the
    flash-mode metadata, and (when no images ship for this hardware) an
    explicit ``no_firmware_available`` flag the UI uses to surface the
    "Request firmware" button.

    ``node_function`` GATES the list: when unset, both ``available`` and
    ``upstream_meshcore.assets`` are returned empty + ``node_function_required``
    is set so the UI can render a "go to config and pick a node function
    first" message instead of a flash dropdown.

    The ``upstream_meshcore`` key carries the bundled vanilla
    meshcore-dev/MeshCore assets for this hardware (baked at deb-build
    time — see build-firmware-bundle.sh).  Filtered by node_function
    same as the TDOA bundle.
    """
    hardware_id = _device_hardware_id(slug)
    flash_modes = _load_flash_modes()
    flash_mode = flash_modes.get(hardware_id) if hardware_id else None
    meta = _load_meta(slug) or {}
    node_function = meta.get("node_function")

    all_available = _list_firmware_for_hardware(hardware_id) if hardware_id else []
    all_upstream = _list_upstream_meshcore_bundled(hardware_id)

    # SAFETY/UX: the Wio-E5 is serial-flashed via OpenBootloader, which writes
    # the application at 0x08008000. Only the OpenBL-prepped (_openbl) TDOA
    # build is linked there; a normal 0x08000000-based image — or any
    # upstream-vanilla image — written at the app base has the wrong vectors
    # and bricks the node. So for wio_e5_mini we expose ONLY the prepped build
    # and never the upstream-meshcore option. The bridge dispatcher refuses
    # non-_openbl targets as a hard backstop (see is_stm32wl_openbl_target).
    if hardware_id == "wio_e5_mini":
        all_available = [
            f for f in all_available
            if "_openbl" in (
                f"{f.get('pio_env') or ''} {f.get('filename') or ''} "
                f"{f.get('role') or ''}"
            ).lower()
        ]
        all_upstream = {}

    if node_function:
        available = [
            f for f in all_available
            if _role_matches_node_function(f.get("role"), node_function)
        ]
        if all_upstream:
            upstream_filtered = dict(all_upstream)
            upstream_filtered["assets"] = [
                a for a in all_upstream.get("assets", [])
                if _role_matches_node_function(a.get("role"), node_function)
            ]
            upstream = upstream_filtered
        else:
            upstream = None
    else:
        # Operator hasn't picked a node function yet — hide everything
        # and tell the UI to render the "set node function first" hint.
        available = []
        upstream = None

    return {
        "hardware_id": hardware_id,
        "flash_mode": flash_mode,
        "available": available,
        "no_firmware_available": (
            hardware_id is not None and node_function is not None
            and not available and not (upstream and upstream.get("assets"))
        ),
        "upstream_meshcore": upstream,
        "node_function": node_function,
        "node_function_required": node_function is None and hardware_id is not None,
        "node_function_options": list(_NODE_FUNCTION_ROLE_PREFIXES.keys()),
    }


class FirmwareFlashRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    filename: str = Field(..., min_length=1, max_length=200)
    # ``source`` defaults to ``bundle`` (the pre-shipped TDOA images
    # under /usr/share/...).  Set to ``upstream-meshcore`` to flash the
    # latest vanilla meshcore-dev/MeshCore release for the matching
    # hardware + role — the portal downloads the asset to a temp file
    # then flashes it via the same auto-DFU path.
    source: str = Field("bundle", pattern=r"^(bundle|upstream-meshcore)$")


@app.post("/api/devices/{slug}/firmware/flash")
def firmware_flash(slug: str, payload: FirmwareFlashRequest) -> dict[str, Any]:
    """Flash a pre-shipped firmware image onto the device at ``slug``.

    NOTE: this is an MVP. The actual flash subprocess (esptool /
    adafruit-nrfutil + UF2 dragdrop) runs synchronously inside the
    request — total time ~30-60s. For larger images we'd hand off to
    a worker + stream logs via WebSocket; tracked as a follow-up TODO.

    Pre-flight:
      * resolve hardware_id (must match a shipped bundle)
      * verify filename matches the available list (no path traversal)
      * stop the bridge (it owns /dev/ttyACMx)
      * flash via the hardware's `tool`
      * restart the bridge
    """
    if not PRODUCTION:
        return {"ok": True, "mock": True, "would_flash": payload.filename, "source": payload.source}
    hardware_id = _device_hardware_id(slug)
    if not hardware_id:
        raise HTTPException(400, "Cannot resolve hardware_id for this device (no recent bridge.info.published).")
    log_gateway_action(
        "firmware.flash", slug,
        {"image": payload.filename, "source": payload.source, "hardware_id": hardware_id},
    )

    # Two firmware sources, both file-local:
    #  - ``bundle`` → firmware-bundle/<hw>/<filename>           (TDOA build)
    #  - ``upstream-meshcore`` → firmware-bundle/<hw>/upstream/<filename>
    #    (vanilla meshcore-dev/MeshCore release, baked at deb-build time
    #    by build-firmware-bundle.sh; no runtime GitHub call here).
    if payload.source == "upstream-meshcore":
        upstream = _list_upstream_meshcore_bundled(hardware_id)
        if not upstream or not upstream.get("assets"):
            raise HTTPException(
                404,
                f"No upstream MeshCore bundle shipped for hardware {hardware_id!r}. "
                "Build a fresh deb with build-firmware-bundle.sh (which pulls "
                "the latest meshcore-dev/MeshCore release) and reinstall.",
            )
        if not any(a["filename"] == payload.filename for a in upstream["assets"]):
            raise HTTPException(
                404,
                f"Upstream asset {payload.filename!r} not in the bundled "
                f"upstream release ({upstream.get('version')!r}). "
                "Refresh the firmware panel and try again.",
            )
        fw_path = _FW_BUNDLE_DIR / hardware_id / "upstream" / payload.filename
        if not fw_path.is_file():
            raise HTTPException(500, "Upstream firmware file disappeared between list + flash.")
    else:
        available = {f["filename"] for f in _list_firmware_for_hardware(hardware_id)}
        if payload.filename not in available:
            raise HTTPException(404, f"Firmware {payload.filename!r} not shipped for {hardware_id}.")
        fw_path = _FW_BUNDLE_DIR / hardware_id / payload.filename
        if not fw_path.is_file():
            raise HTTPException(500, "Firmware file disappeared between list + flash.")

    flash_mode = _load_flash_modes().get(hardware_id) or {}
    tool = flash_mode.get("tool")

    # Stop bridge so the USB port is free for esptool / nrfutil.
    # 0.3.41-fix: sudo -n + use the detected unit name so we don't run
    # twice on Pis that only have one of the two services installed.
    # postinst's sudoers entry grants stop + restart on BOTH unit names.
    bridge_unit = _bridge_unit_name()
    subprocess.run(
        ["sudo", "-n", "systemctl", "stop", bridge_unit],
        capture_output=True, text=True, timeout=10,
    )

    try:
        if tool == "esptool":
            # ESP32-S3 native-USB boards (Heltec V4, etc.): `--before
            # usb_reset` uses the USB SOF reset path which is the
            # reliable way to enter the USB-JTAG ROM bootloader on a
            # chip whose USB-CDC is currently busy running firmware.
            # `--before default-reset` (DTR/RTS toggle) fails on many
            # native-USB S3 boards with an I/O-error on the second
            # input-buffer flush — we tried it on 2026-05-29 against
            # PocV4 + got termios.error(5) every time. Fall back to
            # default-reset only if usb_reset doesn't succeed; covers
            # the few ESP32-S3 boards wired through a separate USB-UART
            # adapter (no native USB).
            tty = _device_tty(slug)
            if not tty:
                raise HTTPException(500, "Could not resolve tty for esptool flash.")
            base_args = ["esptool.py", "--chip", "esp32s3",
                         "--port", tty,
                         "--after", "hard_reset",
                         "write_flash", "0x10000", str(fw_path)]
            r = subprocess.run(
                base_args[:5] + ["--before", "usb_reset"] + base_args[5:],
                capture_output=True, text=True, timeout=180,
            )
            log_tail = (r.stdout + r.stderr)[-2000:]
            if r.returncode != 0:
                # Fall back to the DTR/RTS path for non-native-USB S3
                # boards. If both fail the chip is genuinely stuck.
                r = subprocess.run(
                    base_args[:5] + ["--before", "default_reset"] + base_args[5:],
                    capture_output=True, text=True, timeout=180,
                )
                log_tail += "\n\n--- usb_reset failed, retried with default_reset ---\n"
                log_tail += (r.stdout + r.stderr)[-2000:]
            ok = r.returncode == 0
            if not ok:
                raise HTTPException(
                    500,
                    "esptool flash failed — chip likely never entered "
                    "the USB-JTAG ROM bootloader. If auto-reset wiring "
                    "is missing on this board, operator must hold BOOT "
                    "while plugging USB, then retry. Log tail: "
                    + log_tail[-400:],
                )
        elif tool == "uf2-dragdrop":
            # nRF52 (RAK4631, T-Echo): 1200-baud touch the USB-CDC port
            # to drop the bootloader. Use the Python primitive — opens
            # the port at 1200 baud and immediately closes it, which is
            # what both Adafruit + Nordic bootloaders interpret as
            # "enter DFU".  No operator press required.
            tty = _device_tty(slug)
            if not tty:
                raise HTTPException(
                    500,
                    "Could not resolve tty for 1200-baud DFU touch on "
                    f"{slug} — bridge.info.published not yet seen or "
                    "stable symlink missing. Cannot enter DFU "
                    "automatically; operator would need physical reset.",
                )
            try:
                import serial  # pyserial — bundled in the portal venv
                touch = serial.Serial(tty, 1200)
                touch.close()
            except Exception as exc:  # SerialException, FileNotFoundError, …
                raise HTTPException(
                    500,
                    f"1200-baud DFU touch on {tty} failed: {exc!r}. "
                    "Chip is NOT in bootloader. Operator must double-"
                    "tap the RESET button on the carrier board and "
                    "retry — flash NOT attempted.",
                )
            # 0.3.64: poll for the bootloader USB-MSC mount up to 30s
            # instead of the earlier fixed 3s sleep. Slow Pis (OPi One
            # on testopi) regularly took 8-15s to enumerate the MSC
            # volume; the 3s window was timing out before the kernel
            # had even registered /dev/disk/by-label. Polling every
            # 0.5s also exits as soon as the path appears — fast Pis
            # still finish in 2-3s.
            _BOOT_LABELS = ("TECHOBOOT", "RAK4631", "FTHRBOOT")
            _MSC_WAIT_TIMEOUT_S = 30.0
            _MSC_POLL_INTERVAL_S = 0.5
            helper_path = "/usr/share/meshcore-tdoa-gateway-portal/scripts/mount-uf2-bootloader.sh"
            mount_root: str | None = None
            portal_fallback_mount_label: str | None = None
            deadline = time.monotonic() + _MSC_WAIT_TIMEOUT_S
            while mount_root is None and time.monotonic() < deadline:
                # Path A: udev/usbmount/udisks2 auto-mounted under
                # /media/<user>/<LABEL> or /run/media/<user>/<LABEL>.
                for candidate in ("/media", "/run/media"):
                    if not os.path.isdir(candidate):
                        continue
                    for u in os.listdir(candidate):
                        udir = os.path.join(candidate, u)
                        for boot_name in _BOOT_LABELS:
                            path = os.path.join(udir, boot_name)
                            if os.path.isdir(path):
                                mount_root = path
                                break
                        if mount_root:
                            break
                    if mount_root:
                        break
                # Path B (0.3.53 fallback): Pi has no automounter, but
                # the kernel still populates /dev/disk/by-label/<LABEL>.
                # Mount via the sudoers-gated helper.
                if not mount_root:
                    for boot_name in _BOOT_LABELS:
                        label_dev = Path(f"/dev/disk/by-label/{boot_name}")
                        if not label_dev.exists():
                            continue
                        r = subprocess.run(
                            ["sudo", "-n", helper_path, "mount", boot_name],
                            capture_output=True, text=True, timeout=10,
                        )
                        if r.returncode == 0 and r.stdout.strip():
                            mount_root = r.stdout.strip()
                            portal_fallback_mount_label = boot_name
                            break
                if mount_root is None:
                    time.sleep(_MSC_POLL_INTERVAL_S)

            # 0.3.64: DFU-serial fallback. Some nRF52 bootloaders
            # (notably some T-Echo variants on testopi) expose only a
            # CDC ACM port and never a USB-MSC volume — the MSC poll
            # above will time out cleanly. If the firmware bundle
            # carries a `.zip` sibling (the bootloader-signed package
            # adafruit-nrfutil understands), shell out to that path
            # instead of failing. The MSC + DFU-serial paths share the
            # same underlying chip state, so the 1200-baud touch from
            # earlier is still in effect.
            ok = False
            log_tail = ""
            if mount_root is None:
                zip_sibling = fw_path.with_suffix(".zip")
                if zip_sibling.is_file():
                    # Re-touch in case the bootloader has timed out
                    # back to app mode (some bootloaders auto-exit DFU
                    # after ~30s idle).
                    try:
                        touch = serial.Serial(tty, 1200)
                        touch.close()
                        time.sleep(2)
                    except Exception:
                        pass  # device may already be in DFU; nbd if touch fails
                    r = subprocess.run(
                        ["adafruit-nrfutil", "dfu", "serial",
                         "-pkg", str(zip_sibling), "-p", tty,
                         "-b", "115200", "--touch", "1200", "-sb"],
                        capture_output=True, text=True, timeout=180,
                    )
                    log_tail = (r.stdout + r.stderr)[-2000:]
                    if r.returncode == 0:
                        ok = True
                        log_tail = (
                            f"adafruit-nrfutil DFU-serial flashed "
                            f"{zip_sibling.name} on {tty} (MSC path "
                            "unavailable; .zip sibling used).\n" + log_tail
                        )
                    else:
                        raise HTTPException(
                            500,
                            f"MSC path timed out after {int(_MSC_WAIT_TIMEOUT_S)}s "
                            "AND adafruit-nrfutil DFU-serial fallback failed. "
                            "Likely causes: (a) bootloader stuck in a state "
                            "that DTR doesn't wake (physical reset required); "
                            "(b) USB cable yanked; (c) wrong bootloader "
                            f"variant for this hardware. Log tail: {log_tail[-400:]}",
                        )
                else:
                    raise HTTPException(
                        500,
                        f"1200-baud touch dispatched but no bootloader "
                        f"mass-storage mount appeared within {int(_MSC_WAIT_TIMEOUT_S)}s "
                        "(TECHOBOOT / RAK4631 / FTHRBOOT), and no `.zip` "
                        "sibling for DFU-serial fallback exists at "
                        f"{fw_path.with_suffix('.zip')}. Likely causes: "
                        "(a) udev/usbmount not configured AND /dev/disk/by-label/<LABEL> "
                        "not populated by kernel; (b) USB cable was yanked; "
                        "(c) bundle script didn't ship the .zip companion "
                        "(rebuild .deb with newer build-firmware-bundle.sh). "
                        "Chip IS in DFU — operator can finish manually with "
                        f"the .uf2 at {fw_path}.",
                    )
            else:
                import shutil
                try:
                    shutil.copy(str(fw_path), os.path.join(mount_root, payload.filename))
                    ok = True
                    log_tail = (
                        f"uf2 copied to {mount_root} (auto-DFU via 1200-baud "
                        f"touch on {tty}"
                        + (f"; fallback-mount label {portal_fallback_mount_label}"
                           if portal_fallback_mount_label else "")
                        + ")"
                    )
                finally:
                    # If we mounted via the fallback helper, unmount +
                    # clean up the temp mountpoint so the next flash
                    # starts clean.
                    if portal_fallback_mount_label:
                        subprocess.run(
                            ["sudo", "-n", helper_path,
                             "umount", portal_fallback_mount_label],
                            capture_output=True, text=True, timeout=10,
                        )
        else:
            raise HTTPException(500, f"Unknown flash tool {tool!r} for {hardware_id}.")
    finally:
        # Always try to restart the bridge so the operator isn't
        # stuck with a dead Pi after a failed flash. 0.3.41-fix: sudo
        # -n + detected unit name (sudoers grants restart on both).
        subprocess.run(
            ["sudo", "-n", "systemctl", "restart", _bridge_unit_name()],
            capture_output=True, text=True, timeout=15,
        )

    return {"ok": ok, "tool": tool, "source": payload.source, "log_tail": log_tail}


def _hwserial_from_by_id(by_id_name: str | None) -> str | None:
    """Extract the chip's iSerial from a ``usb-<vendor>_..._<SERIAL>-ifNN``
    descriptor. Mirrors the udev helper's colon-strip so the result matches
    the /dev/meshcore/serial-<hwserial>-if00 path: ESP32-S3's ROM bootloader
    reports the MAC with colons while app firmware reports it bare, and the
    helper normalizes both to the no-colon form.
    """
    if not by_id_name:
        return None
    body = re.sub(r"-if\d+$", "", by_id_name)
    body = re.sub(r"^usb-", "", body)
    # iSerial is the last underscore-delimited token. Strip colons.
    if "_" not in body:
        return None
    return body.rsplit("_", 1)[1].replace(":", "")


def _device_tty(slug: str) -> str | None:
    """Resolve ``slug`` to a tty path that's safe to hand to esptool/nrfutil.

    Resolution order, each falling through on miss:
      1. /dev/meshcore/serial-<hwserial>-if00 — stable symlink from the
         meshcore-tdoa-udev-symlink helper. Survives the ESP32-S3 app↔ROM
         and nRF52 app↔DFU descriptor flip, so it's the right answer
         whether the chip is in normal mode or stuck mid-flash. Tried
         first because it's the only one that works after a failed flash
         left the chip in its bootloader.
      2. The configured tty recorded in meta.json. Works on Pis where the
         udev helper hasn't been installed (older deb) or where the chip
         is in normal app mode.
      3. ROM-mode rescan of /dev/serial/by-id/. If the chip flipped to ROM
         and the udev rule isn't seeding /dev/meshcore (e.g. install
         predates 0.3.21), walk by-id looking for any descriptor whose
         (colon-stripped) iSerial matches the configured device — that's
         the same chip wearing a different USB hat.
    """
    target: dict[str, Any] | None = None
    for dev in _list_devices():
        if dev.get("slug") == slug:
            target = dev
            break

    by_id_name = (target or {}).get("by_id_name") or _by_id_name_for_slug(slug)
    hwserial = _hwserial_from_by_id(by_id_name)

    # 1. stable symlink — survives descriptor swap, prefer always.
    if hwserial:
        stable = MESHCORE_STABLE_DIR / f"serial-{hwserial}-if00"
        if stable.exists():
            return str(stable)

    # 2. configured tty (app mode, udev helper absent).
    if target and target.get("tty"):
        tty_path = Path(target["tty"])
        if tty_path.exists():
            return str(tty_path)

    # 3. ROM-mode by-id rescan — match the chip even if its descriptor flipped.
    if hwserial and SERIAL_BY_ID.exists():
        for entry in SERIAL_BY_ID.iterdir():
            name = entry.name
            if not name.startswith("usb-"):
                continue
            if hwserial in name.replace(":", ""):
                try:
                    resolved = entry.resolve()
                except OSError:
                    continue
                if resolved.exists():
                    return str(resolved)
    return None


class FirmwareRequestPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")
    requested_role: str = Field(..., min_length=1, max_length=64)
    notes: str | None = Field(None, max_length=1000)


@app.post("/api/devices/{slug}/firmware/request")
def firmware_request(slug: str, payload: FirmwareRequestPayload) -> dict[str, Any]:
    """When the bundle has no image for the connected hardware, surface a
    one-click "request build" path. Posts hardware fingerprint to the
    operator's Telegram chat (same plumbing as /api/contact-operator).

    Returns 503 if Telegram isn't configured on this Pi (same as
    /api/contact-operator does)."""
    if not (TELEGRAM_BOT_TOKEN and TELEGRAM_OPERATOR_CHAT_ID):
        raise HTTPException(503, "Operator Telegram not configured on this gateway.")
    hardware_id = _device_hardware_id(slug)
    host = socket.gethostname()
    text = (
        f"📦 *Firmware build request* from `{host}`\n"
        f"slug: `{slug}`\n"
        f"hardware_id: `{hardware_id or 'UNKNOWN'}`\n"
        f"requested_role: `{payload.requested_role}`\n"
        f"notes:\n{payload.notes or '_(none)_'}"
    )
    import json as _json
    import urllib.error
    import urllib.parse
    import urllib.request

    body = urllib.parse.urlencode({
        "chat_id": TELEGRAM_OPERATOR_CHAT_ID,
        "text": text,
        "parse_mode": "Markdown",
    }).encode("utf-8")
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            tg = _json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise HTTPException(502, f"Telegram API rejected: HTTP {exc.code}")
    except urllib.error.URLError as exc:
        raise HTTPException(502, f"Telegram API unreachable: {exc.reason}")
    if not tg.get("ok"):
        raise HTTPException(502, f"Telegram API error: {tg.get('description', '?')}")
    return {"ok": True, "host": host, "hardware_id": hardware_id}


class UndetectedBoardRequestPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")
    board_name: str = Field(..., min_length=1, max_length=120)
    mcu_chip: str | None = Field(None, max_length=120)
    lora_chip: str | None = Field(None, max_length=120)
    usb_id: str | None = Field(None, max_length=200)
    requested_role: str = Field(..., min_length=1, max_length=64)
    notes: str | None = Field(None, max_length=1000)


@app.post("/api/firmware/request-undetected")
def firmware_request_undetected(
    payload: UndetectedBoardRequestPayload, request: Request
) -> dict[str, Any]:
    """Request a firmware build for a board the portal did NOT auto-detect.

    Unlike /api/devices/{slug}/firmware/request (which fingerprints a
    *connected, recognised* device), this path has no slug: the operator
    types the board details by hand for hardware the bridge never
    surfaced. Forwards everything to the operator's Telegram chat along
    with the saved Observer email (if set) and the requester's source IP
    so the operator can build + ship a matching image and reach back out.
    """
    if not (TELEGRAM_BOT_TOKEN and TELEGRAM_OPERATOR_CHAT_ID):
        raise HTTPException(
            503,
            "Operator contact not configured on this gateway. Set "
            "TELEGRAM_BOT_TOKEN + TELEGRAM_OPERATOR_CHAT_ID in "
            "/etc/meshcore-tdoa-gateway-portal/portal.env.",
        )
    # Source IP — same resolution as /api/contact-operator (cloudflared /
    # nginx set X-Forwarded-For; fall back to the raw socket peer).
    ip = (
        (request.headers.get("x-forwarded-for") or "").split(",")[0].strip()
        or (request.client.host if request.client else "unknown")
    )
    now = time.time()
    last = _contact_last_sent.get(ip, 0.0)
    if now - last < _CONTACT_RATELIMIT_SECONDS:
        retry_in = int(_CONTACT_RATELIMIT_SECONDS - (now - last))
        raise HTTPException(
            429,
            f"Rate limited — try again in {retry_in}s. "
            "One request per minute per visitor.",
        )

    # Observer email from the live portal.env (the operator may have just
    # saved it without a restart). Empty string → "(not set)".
    email = (
        _read_portal_env().get("OBSERVER_EMAIL")
        or os.environ.get("OBSERVER_EMAIL", "")
    ).strip()

    host = socket.gethostname()
    text = "\n".join([
        f"🆕 *Undetected-board firmware request* from `{host}`",
        f"board: `{payload.board_name}`",
        f"MCU: `{payload.mcu_chip or '?'}`   LoRa: `{payload.lora_chip or '?'}`",
        f"USB id: `{payload.usb_id or '?'}`",
        f"requested role: `{payload.requested_role}`",
        f"requester email: `{email or '(not set)'}`",
        f"source IP: `{ip}`",
        f"portal: `{PORTAL_VERSION}`",
        "",
        f"notes:\n{payload.notes or '_(none)_'}",
    ])
    _telegram_send(text)

    _contact_last_sent[ip] = now
    log_gateway_action(
        "firmware.request_undetected",
        metadata={"board_name": payload.board_name, "role": payload.requested_role},
    )
    return {"ok": True, "host": host, "email_included": bool(email)}


# VID → MCU/board family hint for the undetected-board USB scan. Best-
# effort only — the product / by-id strings usually carry the real board
# name; this just adds a chip family the operator can confirm at a glance.
#
# Keyed on the USB *vendor* id (4 hex, lowercase). Caveats baked into the
# wording: a USB-UART bridge VID (Silicon Labs / QinHeng / FTDI) only tells
# you the bridge chip, not the host MCU — so those say "ESP32/other via …".
# Native-USB MCUs (Espressif S-series, Nordic, ST DFU, RP2040) identify the
# silicon directly. Covers the LoRa/MeshCore-adjacent fleet: Heltec V2/V3/V4,
# RAK4631 (nRF52840) + RAK3172 (STM32WL), LilyGo T-Echo/T-Beam, Seeed XIAO,
# Wio-E5 / LoRa-E5 (STM32WLE5), Nordic / ST / NXP dev kits.
_USB_VID_MCU_HINT = {
    # Native-USB MCUs — VID identifies the silicon directly.
    "303a": "ESP32-S2/S3/C-series (Espressif native USB)",
    "239a": "nRF52840 / SAMD / RP2040 (Adafruit UF2 bootloader — RAK4631, T-Echo)",
    "1915": "nRF52 / nRF53 (Nordic Semiconductor)",
    "2886": "Seeed XIAO (nRF52840 / ESP32-* / RP2040 / SAMD21)",
    "2e8a": "RP2040 (Raspberry Pi)",
    "0483": "STM32 (STMicroelectronics — STM32WL / Wio-E5 / RAK3172, ST-LINK/DFU)",
    "1fc9": "NXP Cortex-M (LPC / i.MX RT)",
    "1209": "open-source hardware (pid.codes — generic, often nRF52/STM32)",
    "2341": "Arduino (SAMD / nRF52 / RP2040 board)",
    "16c0": "Teensy / generic hobby USB (Van Ooijen)",
    # USB-UART bridges — VID is the bridge chip; host MCU is usually ESP32
    # (Heltec V2/V3, T-Beam) or an STM32/AVR behind it.
    "10c4": "ESP32/other via CP210x USB-UART bridge (Silicon Labs)",
    "1a86": "ESP32/other via CH34x/CH9102 USB-UART bridge (QinHeng)",
    "0403": "ESP32/other via FTDI USB-UART bridge",
    # On-board debug probes — board is a Cortex-M dev kit (ST/NXP/Nordic).
    "1366": "Cortex-M dev kit w/ SEGGER J-Link (often STM32 / nRF)",
    "0d28": "ARM Cortex-M dev kit w/ mbed DAPLink (often STM32 / NXP)",
    "03eb": "Microchip/Atmel (SAM / AVR)",
}


@app.get("/api/firmware/usb-candidates")
def firmware_usb_candidates() -> dict[str, Any]:
    """USB serial devices currently on the Pi — pre-fills the undetected-
    board firmware-request form.

    Even a board the bridge never surfaced (no 0x94 GATEWAY_INFO, so no
    hardware_id and nothing in the Flash list) usually still enumerates on
    /dev/serial/by-id. We list those, enrich each with VID:PID + product
    strings via pyserial, and flag any that already map to a *recognised*
    configured device so the operator can pick the genuinely-unknown one.
    """
    serial_devs = _discover_serial_devices()
    # "recognised" = a configured device that resolved a hardware_id from
    # a real bridge.info.published event (i.e. it IS in the Flash list).
    recognised_slugs = {
        d["slug"] for d in _list_devices()
        if d.get("configured") and d.get("hardware_id")
    }
    # tty -> pyserial port metadata (VID/PID/product). Best-effort: missing
    # pyserial or a permission hiccup just yields no enrichment, not a 500.
    port_by_tty: dict[str, Any] = {}
    try:
        from serial.tools import list_ports
        for p in list_ports.comports():
            port_by_tty[p.device] = p
    except Exception:  # noqa: BLE001
        pass

    candidates: list[dict[str, Any]] = []
    for d in serial_devs:
        tty = d.get("tty")
        p = port_by_tty.get(tty)
        vid = f"{p.vid:04x}" if p and getattr(p, "vid", None) is not None else None
        pid = f"{p.pid:04x}" if p and getattr(p, "pid", None) is not None else None
        candidates.append({
            "by_id_name": d["by_id_name"],
            "tty": tty,
            "vid_pid": f"{vid}:{pid}" if vid and pid else None,
            "product": getattr(p, "product", None) if p else None,
            "manufacturer": getattr(p, "manufacturer", None) if p else None,
            "guessed_mcu": _USB_VID_MCU_HINT.get(vid) if vid else None,
            "recognised": d.get("slug") in recognised_slugs,
        })
    return {"supported": bool(serial_devs), "candidates": candidates}


# ---------------------------------------------------------------------------
# Auto-update toggle. Reads + writes AUTO_UPDATE=on|off into portal.env.
# The auto-update.sh script reads the same env var and short-circuits when
# off. Default is on.
# ---------------------------------------------------------------------------

_PORTAL_ENV_PATH = Path(
    os.environ.get(
        "PORTAL_ENV_PATH",
        "/etc/meshcore-tdoa-gateway-portal/portal.env",
    )
)
_AUTO_UPDATE_STATUS_PATH = Path("/run/meshcore-tdoa/auto-update.json")


def _read_auto_update_status() -> dict[str, Any]:
    try:
        return json.loads(_AUTO_UPDATE_STATUS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _read_auto_update_enabled() -> bool:
    if not _PORTAL_ENV_PATH.exists():
        return True
    for line in _PORTAL_ENV_PATH.read_text(encoding="utf-8").splitlines():
        if line.startswith("AUTO_UPDATE="):
            value = line.split("=", 1)[1].strip().strip("\"'").lower()
            return value != "off"
    return True


@app.get("/api/auto-update/status")
def auto_update_status() -> dict[str, Any]:
    last = _read_auto_update_status()
    return {
        "enabled": _read_auto_update_enabled(),
        "last_state": last.get("state"),
        "last_run_at": last.get("at"),
        "last_msg": last.get("msg"),
        "installed_version": last.get("installed"),
    }


# ---------------------------------------------------------------------------
# Cloud-registration status. The register/heartbeat scripts record their
# outcome to /run/meshcore-tdoa/cloud-status.json; the page shows a badge so
# the operator knows whether this gateway is talking to homeprod (success)
# or not (failed — with the reason, e.g. a Cloudflare-Access 403).
# ---------------------------------------------------------------------------
_CLOUD_STATUS_PATH = Path("/run/meshcore-tdoa/cloud-status.json")
_BRIDGE_YAML_PATHS = (
    Path(os.environ.get("BRIDGE_YAML_PATH", "/etc/meshcore-tdoa-gateway/bridge.yaml")),
    Path("/etc/meshcore-bridge/config.yaml"),  # legacy bootstrap path
)


def _bridge_has_creds() -> bool:
    """Registered ⇔ the register flow wrote a non-empty MQTT username into
    bridge.yaml. Authoritative + persistent (survives reboot).

    2026-06-06: bridge.yaml is now root-only 0600 (privilege-separation fix), so
    the unprivileged portal CANNOT read it — reading it here always failed → a
    SUCCESSFUL register showed as "failed (HTTP 200)". Fall back to the
    portal-readable register status file (/run/.../cloud-status.json) the root
    register script writes (ok + http_code + pi_host_id)."""
    for p in _BRIDGE_YAML_PATHS:
        try:
            for raw in p.read_text(encoding="utf-8").splitlines():
                s = raw.strip()
                if s.startswith("username:") and s.split(":", 1)[1].strip():
                    return True
        except OSError:
            # 0600 root:root (or absent) — fall through to the status file.
            continue
    try:
        last = json.loads(_CLOUD_STATUS_PATH.read_text(encoding="utf-8"))
        # A 200-OK register OR heartbeat both PROVE the gateway is registered:
        # heartbeat authenticates with the per-Pi Basic credentials that only a
        # successful register could have written, so an ok heartbeat is itself
        # proof of registration. (register also stamps pi_host_id; heartbeat does
        # not, so don't require that field — requiring it made an ok heartbeat
        # read as "not registered" → false "Registration failed (HTTP 200)".)
        if last.get("ok") and last.get("action") in ("register", "heartbeat") and (
            last.get("http_code") == 200 or last.get("pi_host_id")
        ):
            return True
    except (OSError, json.JSONDecodeError):
        pass
    return False


@app.get("/api/registration/status")
def registration_status() -> dict[str, Any]:
    """Whether this gateway is registered with homeprod + the last
    register/heartbeat outcome (success / HTTP code / detail) the scripts
    recorded. Drives the registration badge on the page."""
    last: dict[str, Any] = {}
    try:
        last = json.loads(_CLOUD_STATUS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        last = {}
    return {
        "registered": _bridge_has_creds(),
        "last_action": last.get("action"),     # "register" | "heartbeat"
        "ok": last.get("ok"),                   # bool | None
        "http_code": last.get("http_code"),
        "detail": last.get("detail"),
        "pi_host_id": last.get("pi_host_id"),
        "at": last.get("at"),
    }


class AutoUpdateToggleRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool


@app.post("/api/auto-update/toggle")
def auto_update_toggle(payload: AutoUpdateToggleRequest) -> dict[str, Any]:
    """Write AUTO_UPDATE=on|off to portal.env. No restart required —
    the auto-update.sh script reads the file on every fire."""
    if not _PORTAL_ENV_PATH.exists():
        raise HTTPException(500, f"portal.env missing at {_PORTAL_ENV_PATH}")
    desired = "on" if payload.enabled else "off"
    lines = _PORTAL_ENV_PATH.read_text(encoding="utf-8").splitlines()
    found = False
    for i, line in enumerate(lines):
        if line.startswith("AUTO_UPDATE="):
            lines[i] = f"AUTO_UPDATE={desired}"
            found = True
            break
    if not found:
        lines.append(f"AUTO_UPDATE={desired}")
    _PORTAL_ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"enabled": payload.enabled}


# Static frontend last so /api/* routes win.
app.mount("/static", StaticFiles(directory=str(ROOT / "static")), name="static")


@app.get("/", response_class=HTMLResponse)
def index() -> HTMLResponse:
    # Append ?v=<content-hash> to the app.js / style.css links so the browser
    # re-fetches them the instant the file CHANGES — not just on a version bump.
    # Hashing the actual bytes means even an in-place hotfix to app.js (same deb
    # version) busts the cache; falls back to PORTAL_VERSION if the file is
    # unreadable. UI/endpoint changes can never be masked by a stale cached asset.
    html = (ROOT / "static" / "index.html").read_text(encoding="utf-8")

    def _asset_v(name: str) -> str:
        try:
            import hashlib
            data = (ROOT / "static" / name).read_bytes()
            return hashlib.sha1(data).hexdigest()[:12]  # noqa: S324 — cache-bust only
        except OSError:
            return PORTAL_VERSION

    html = html.replace('href="/static/style.css"',
                        f'href="/static/style.css?v={_asset_v("style.css")}"')
    html = html.replace('src="/static/app.js"',
                        f'src="/static/app.js?v={_asset_v("app.js")}"')
    # CRITICAL: the ?v=<version> cache-bust above only works if the browser
    # actually RE-FETCHES this HTML on each visit. Without no-cache the browser
    # may serve a stale index.html (with an old ?v=) from disk → it keeps loading
    # the old app.js forever and UI/endpoint changes never appear (this caused
    # operators to hit 404s against routes their cached app.js still called).
    # no-store forces a fresh HTML every load; the versioned static assets stay
    # cacheable (StaticFiles handles those), so only the tiny HTML is re-fetched.
    return HTMLResponse(
        content=html,
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "Expires": "0",
        },
    )
