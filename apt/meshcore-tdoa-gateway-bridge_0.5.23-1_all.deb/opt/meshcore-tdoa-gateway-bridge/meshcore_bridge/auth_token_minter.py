"""Periodic on-node auth-token minting for token-auth output brokers.

For each active receiver port that has a token-auth ``[[broker]]`` configured,
this asks the NODE to sign a fresh MeshCore JWT over serial (``CMD_SIGN`` — the
private key never leaves the device) and writes it to ``/run`` where the
mesh-relay reads it (see ``auth_token_signer`` + the relay's
``output_brokers._read_bridge_minted_token``). Refreshed well inside the 1-hour
token TTL.

Integration: reuses the supervisor's ``pause_port``/``resume_port`` (same as the
FW-OTA flasher) to get exclusive serial access for the brief mint transaction,
then resumes the reader. One ~1 s pause per port per refresh cycle.
"""
from __future__ import annotations

import glob
import json
import logging
import os
import re
import threading
import time
import tomllib
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING

import serial

from . import auth_token_signer as ats

if TYPE_CHECKING:
    from .serial_locks import PortSerialLocks

logger = logging.getLogger(__name__)

FRAME_IN = 0x3E  # '>' device->host
CMD_APP_START = 1
RESP_CODE_SELF_INFO = 5  # reply to CMD_APP_START; pubkey at payload offset 4
PUB_KEY_SIZE = 32

DEFAULT_DEVICES_DIR = Path("/etc/meshcore-tdoa-gateway/devices")
TOKEN_TTL_S = 3600
#: The MeshCore JWT verifier enforces its OWN max token age (~25 min observed
#: live on both letsmesh + dutchmeshcore 2026-06-10) and IGNORES our 1-h ``exp``.
#: So a long refresh interval left the token broker-stale (rc=5) for ~25 min of
#: every cycle even though our ``exp`` said valid. Re-mint well inside that
#: window so the /run token the relay reads on reconnect is always fresh enough
#: for the broker to accept. (The relay re-reads /run on every disconnect now —
#: see output_brokers._refresh_jwt — so the worst-case staleness is one mint
#: interval, kept comfortably under the ~25-min broker window.)
DEFAULT_REFRESH_INTERVAL_S = 12 * 60


def discover_token_audiences(devices_dir: Path = DEFAULT_DEVICES_DIR) -> set[str]:
    """Scan per-device ``config.toml`` for token-auth brokers; return audiences.

    The audience is what the broker verifies (``aud`` claim) — its hostname.
    """
    auds: set[str] = set()
    for cfg_path in glob.glob(str(devices_dir / "*" / "config.toml")):
        try:
            with open(cfg_path, "rb") as fh:
                cfg = tomllib.load(fh)
        except (OSError, tomllib.TOMLDecodeError):
            continue
        brokers = cfg.get("broker")
        if not isinstance(brokers, list):
            continue
        for b in brokers:
            if not isinstance(b, dict):
                continue
            auth = b.get("auth") or {}
            if str(auth.get("method", "")).lower() != "token":
                continue
            aud = auth.get("audience") or b.get("server")
            if aud:
                auds.add(str(aud))
    return auds


def _write_pubkey_to_config(
    full_port: str, pub: str, devices_dir: Path = DEFAULT_DEVICES_DIR
) -> bool:
    """Persist the node pubkey into the matching device config's [repeater].pub_key.

    The relay builds its endpoint from [repeater].pub_key (for the v1_<PUBKEY>
    broker username + the /run token lookup). It's otherwise unpopulated, so the
    bridge — which learns the real pubkey via APP_START — writes it here. Matched
    by meta.json.by_id_name == the port's by-id basename. Only fills an
    empty/UNKNOWN value (never clobbers an operator-set key); self-heals each
    cycle, so it survives a portal/deb rewrite. Returns True if written.
    """
    by_id = os.path.basename(full_port)
    for meta_path in glob.glob(str(devices_dir / "*" / "meta.json")):
        try:
            with open(meta_path) as fh:
                meta = json.load(fh)
        except (OSError, ValueError):
            continue
        if meta.get("by_id_name") != by_id:
            continue
        cfg_path = Path(meta_path).parent / "config.toml"
        try:
            text = cfg_path.read_text()
        except OSError:
            return False
        try:
            cur = (tomllib.loads(text).get("repeater") or {}).get("pub_key") or ""
        except tomllib.TOMLDecodeError:
            return False
        if cur and cur.upper() != "UNKNOWN":
            return False  # already set — don't clobber
        if re.search(r"(?m)^\s*pub_key\s*=", text):
            new = re.sub(r'(?m)^(\s*pub_key\s*=).*$', f'pub_key = "{pub}"', text, count=1)
        elif re.search(r"(?m)^\[repeater\]\s*$", text):
            new = re.sub(r"(?m)^(\[repeater\]\s*)$", r'\1\npub_key = "' + pub + '"', text, count=1)
        else:
            return False  # no [repeater] section to attach to
        try:
            cfg_path.write_text(new)
        except OSError:
            return False
        logger.info(
            "auth_token_minter.pubkey_written config=%s pub=%s", cfg_path, pub[:12]
        )
        return True
    return False


class _SerialSignTransport:
    """:class:`ats.SignTransport` over a raw pyserial handle.

    ``read_frame`` returns the next device->host frame PAYLOAD whose first byte
    is a command RESPONSE code (< 0x80), skipping the receiver's push frames
    (0x90+ — 0x90/0x91/0x93/0x95/0x97 TDOA/telemetry) that stream continuously.
    """

    def __init__(self, ser: serial.Serial) -> None:
        self._ser = ser
        self._buf = bytearray()

    def write_bytes(self, data: bytes) -> None:
        self._ser.write(data)
        try:
            self._ser.flush()
        except Exception:  # noqa: BLE001 - best-effort; read drains anyway
            pass

    def read_frame(self, timeout: float = 3.0) -> bytes:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            chunk = self._ser.read(256)
            if chunk:
                self._buf.extend(chunk)
            while True:
                i = self._buf.find(bytes([FRAME_IN]))
                if i < 0:
                    if len(self._buf) > 8192:
                        del self._buf[:-3]
                    break
                if len(self._buf) < i + 3:
                    break
                ln = int.from_bytes(self._buf[i + 1 : i + 3], "little")
                if ln < 1 or ln > 1024:
                    del self._buf[: i + 1]
                    continue
                if len(self._buf) < i + 3 + ln:
                    break
                payload = bytes(self._buf[i + 3 : i + 3 + ln])
                del self._buf[: i + 3 + ln]
                if payload and payload[0] < 0x80:  # command response, not a push
                    return payload
        return b""


def read_self_pubkey(transport: _SerialSignTransport, *, timeout: float = 5.0) -> str | None:
    """``CMD_APP_START`` -> ``RESP_CODE_SELF_INFO``; return node pubkey hex (or None)."""
    # cmd_frame[1..7] reserved, [8..] app name. Firmware requires len >= 8.
    payload = bytes([CMD_APP_START]) + bytes(7) + b"meshcore-bridge"
    transport.write_bytes(
        bytes([ats.FRAME_OUT]) + len(payload).to_bytes(2, "little") + payload
    )
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        f = transport.read_frame(timeout=min(2.0, max(0.1, deadline - time.monotonic())))
        if f and f[0] == RESP_CODE_SELF_INFO and len(f) >= 4 + PUB_KEY_SIZE:
            return f[4 : 4 + PUB_KEY_SIZE].hex()
        if not f:
            break
    return None


def mint_port_tokens(
    ser: serial.Serial,
    audiences: set[str],
    *,
    now: float,
    run_dir: Path = ats.DEFAULT_RUN_DIR,
    exp_seconds: int = TOKEN_TTL_S,
) -> tuple[str, int]:
    """Read the node pubkey, mint+sign a JWT per audience on-node, write each to /run.

    Returns ``(pubkey_hex, tokens_written)``. Raises :class:`ats.SignError` if the
    node pubkey can't be read.
    """
    transport = _SerialSignTransport(ser)
    pub = read_self_pubkey(transport)
    if not pub:
        raise ats.SignError("no SELF_INFO from node (could not read pubkey)")
    written = 0
    for aud in sorted(audiences):
        jwt = ats.mint(transport, pub, aud, int(now), exp=int(now) + exp_seconds)
        ats.write_token_file(pub, aud, jwt, run_dir=run_dir)
        written += 1
    return pub, written


class AuthTokenMinter:
    """Background thread that refreshes on-node JWTs for token-auth brokers."""

    def __init__(
        self,
        *,
        active_ports: Callable[[], list[str]],
        pause_port: Callable[[str], None],
        resume_port: Callable[[str], None],
        devices_dir: Path = DEFAULT_DEVICES_DIR,
        run_dir: Path = ats.DEFAULT_RUN_DIR,
        interval_s: float = DEFAULT_REFRESH_INTERVAL_S,
        startup_delay_s: float = 20.0,
        serial_factory: Callable[..., serial.Serial] = serial.Serial,
        clock: Callable[[], float] = time.time,
        serial_locks: PortSerialLocks | None = None,
    ) -> None:
        self._active_ports = active_ports
        self._pause_port = pause_port
        self._resume_port = resume_port
        self._devices_dir = devices_dir
        self._run_dir = run_dir
        self._interval_s = interval_s
        self._startup_delay_s = startup_delay_s
        self._serial_factory = serial_factory
        self._clock = clock
        # Per-port serial-access lock SHARED with the FW-OTA dispatcher (see
        # __main__) so a mint can't open a port the flasher is using and vice
        # versa. Private fallback when not supplied (tests).
        from .serial_locks import PortSerialLocks
        self._serial_locks = serial_locks or PortSerialLocks()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(
            target=self._run, name="auth-token-minter", daemon=True
        )
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        self._stop.set()
        thr = self._thread
        if thr is not None:
            thr.join(timeout)
        self._thread = None

    def _run(self) -> None:
        if self._stop.wait(self._startup_delay_s):
            return
        while not self._stop.is_set():
            try:
                self.mint_cycle()
            except Exception as exc:  # noqa: BLE001 - never let the loop die
                logger.warning("auth_token_minter.cycle_error error=%s", exc)
            if self._stop.wait(self._interval_s):
                break

    def mint_cycle(self) -> int:
        """One refresh pass over all active ports. Returns tokens written."""
        audiences = discover_token_audiences(self._devices_dir)
        if not audiences:
            return 0
        from .mqtt_publisher import sanitize_port

        total = 0
        for full_port in self._active_ports():
            sanitized = sanitize_port(full_port)
            paused = False
            # Hold the per-port serial lock (shared with the FW-OTA dispatcher)
            # for the whole pause→mint→resume so a flash can't grab the port
            # mid-mint. If a flash holds it, this blocks until the flash is done
            # — fine, the mint just runs a little late.
            port_lock = self._serial_locks.get(sanitized)
            port_lock.acquire()
            try:
                self._pause_port(sanitized)
                paused = True
                time.sleep(0.3)  # let the reader fully release the port
                ser = self._serial_factory(full_port, 115200, timeout=1.0, exclusive=True)
                try:
                    pub, n = mint_port_tokens(
                        ser, audiences, now=self._clock(), run_dir=self._run_dir
                    )
                    total += n
                    logger.info(
                        "auth_token_minter.minted port=%s pub=%s tokens=%d",
                        sanitized, pub[:12], n,
                    )
                    # Persist the pubkey into the device config so the relay's
                    # endpoint (v1_<PUBKEY> username + /run token lookup) works
                    # without a manual edit — survives reloads + deb upgrades.
                    _write_pubkey_to_config(full_port, pub, self._devices_dir)
                finally:
                    try:
                        ser.close()
                    except Exception:  # noqa: BLE001
                        pass
            except Exception as exc:  # noqa: BLE001 - one bad port shouldn't stall others
                logger.warning(
                    "auth_token_minter.port_error port=%s error=%s", sanitized, exc
                )
            finally:
                if paused:
                    self._resume_port(sanitized)
                # Release AFTER the reader resumes, so the flasher can't take
                # the port before the reader is back.
                try:
                    port_lock.release()
                except RuntimeError:
                    pass
        return total
