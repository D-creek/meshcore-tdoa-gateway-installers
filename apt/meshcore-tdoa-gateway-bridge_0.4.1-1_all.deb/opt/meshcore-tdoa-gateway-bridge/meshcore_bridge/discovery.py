"""Port discovery + supervisor for ``meshcore-bridge``.

Polls the configured glob list every ``rescan_interval_seconds`` and
keeps a :class:`SerialReader` alive for every matching ``/dev/tty*``
port. Cleans up dead ports (e.g., T-Echo unplugged) so we don't leak
threads.
"""

from __future__ import annotations

import glob
import os
import threading
import time
from collections.abc import Callable
from fnmatch import fnmatchcase

import structlog

from .config import HardwareMetadata, SerialConfig
from .frame import AnyFrame
from .serial_reader import SerialReader
from .tcp_passthrough import TCPPassthrough

log = structlog.get_logger(__name__)

# Stall watchdog: a healthy TDOA receiver emits a telemetry heartbeat every
# ~5 s, so a port that's gone TOTALLY silent this long — while its reader
# thread is still alive — is wedged (the serial side stopped delivering even
# though the device kept running). Observed 2026-06-04: a T-Echo port went
# dark for 8 h while the firmware's uptime kept climbing. The sweep restarts
# such a reader in place — no host reboot needed. Override via env for tests.
_STALL_RESTART_SECONDS = float(
    os.environ.get("MESHCORE_BRIDGE_STALL_RESTART_S", "180")
)


#: USB descriptor substrings that identify bootloader / DFU / JTAG
#: interfaces, NOT runtime gateway firmware. The port supervisor must
#: never open these as a normal serial reader — they are owned by the
#: OTA flasher, and a SerialReader holding them open blocks the OTA
#: dispatcher's retry path from claiming exclusive access (which is
#: how V4 got stuck in JTAG bootloader for 1h26m on 2026-05-13).
BOOTLOADER_DESCRIPTORS: tuple[str, ...] = (
    "USB_JTAG_serial_debug_unit",  # ESP32-S3 ROM bootloader
    "DFU_Runtime",                  # Generic STM32 DFU
    "Nordic_DFU",                   # nRF52 Adafruit DFU
)


def is_bootloader_port(path: str) -> bool:
    """True if the descriptor matches a known bootloader / DFU / JTAG
    interface. These ports must NOT be opened by the normal serial
    reader; only the OTA flasher's recovery path should touch them."""
    return any(marker in path for marker in BOOTLOADER_DESCRIPTORS)


def discover_ports(globs: tuple[str, ...]) -> list[str]:
    """Return the union of paths matching every glob, deduplicated, sorted,
    and with bootloader / DFU / JTAG descriptors filtered out.

    Bootloader interfaces are deliberately excluded — they exist only
    transiently while a chip is being flashed, and the supervisor
    grabbing them as if they were gateway ports is how the OTA
    dispatcher's retry path lost its race in the V4 stuck-chip
    incident. See :data:`BOOTLOADER_DESCRIPTORS`.

    Pure function — pulled out so tests can exercise the glob logic
    without poking at /dev.
    """
    seen: set[str] = set()
    for pattern in globs:
        for path in glob.glob(pattern):
            if is_bootloader_port(path):
                continue
            seen.add(path)
    return sorted(seen)


def discover_stuck_bootloaders(globs: tuple[str, ...]) -> list[str]:
    """Return the paths matching ``globs`` that ARE bootloader descriptors.

    Used by the supervisor to surface a ``bridge.stuck_chip_detected``
    event when a bootloader interface is present without a matching
    runtime descriptor — i.e., a chip is stuck in the bootloader after
    a failed flash and needs recovery intervention.
    """
    seen: set[str] = set()
    for pattern in globs:
        for path in glob.glob(pattern):
            if is_bootloader_port(path):
                seen.add(path)
    return sorted(seen)


class PortSupervisor:
    """Owns the set of live :class:`SerialReader` instances.

    Run ``start()`` to kick off the rescan loop; ``stop()`` to tear
    everything down cleanly.
    """

    def __init__(
        self,
        cfg: SerialConfig,
        on_frame: Callable[[str, AnyFrame], None],
        *,
        reader_factory: Callable[..., SerialReader] | None = None,
        ports_provider: Callable[[tuple[str, ...]], list[str]] | None = None,
        hardware: dict[str, HardwareMetadata] | None = None,
    ) -> None:
        self._cfg = cfg
        self._on_frame = on_frame
        self._reader_factory = reader_factory or SerialReader
        self._ports_provider = ports_provider or discover_ports
        self._readers: dict[str, SerialReader] = {}
        # Stall-watchdog state. ``_last_data`` = monotonic time of the last
        # frame (incl. telemetry heartbeats) per port; ``_ever_produced`` =
        # ports that have delivered ≥1 frame. A port that produced data then
        # went silent past _STALL_RESTART_SECONDS gets its reader restarted;
        # a port that has NEVER produced is left alone (could be a quiet /
        # non-emitting device, not a stall).
        self._last_data: dict[str, float] = {}
        self._ever_produced: set[str] = set()
        # Option-B TCP passthrough: when a port's hardware metadata sets
        # ``tcp_passthrough_port``, the supervisor spawns one
        # :class:`TCPPassthrough` per port and hands it to the
        # SerialReader. Bridge stays the sole USB reader; TCP clients
        # see the same byte stream, with bidirectional writes
        # forwarded back to USB. None = passthrough disabled for this
        # port. See tcp_passthrough.py for the design.
        self._hardware = hardware or {}
        self._passthroughs: dict[str, TCPPassthrough] = {}
        self._stop_evt = threading.Event()
        self._thread: threading.Thread | None = None
        # Sanitized slugs currently "paused" by the OTA dispatcher. A port
        # whose sanitize_port() value is in this set is skipped by the
        # sweep — so when the chip re-enumerates mid-flash, the supervisor
        # does NOT open the runtime port, leaving esptool's verify step
        # free to do its handshake. Without this, the runtime CDC node
        # appearing during flash triggered a race that crashed the
        # ESP32-S3 USB-CDC stack and bounced the chip back into JTAG
        # bootloader (verified on V4 job 8 + 9 on 2026-05-13).
        self._paused_slugs: set[str] = set()
        self._paused_lock = threading.Lock()

    @property
    def active_ports(self) -> list[str]:
        return sorted(self._readers)

    def _match_hardware(self, port: str) -> HardwareMetadata | None:
        """Find the first hardware-config entry whose glob matches ``port``.

        Mirrors the ``mqtt_publisher`` ``_metadata_for_port`` lookup —
        we deliberately reuse the same fnmatch-against-glob semantics
        so an operator's ``hardware:`` block lines up identically with
        both the /info-publish path and the TCP-passthrough spawn path.
        First-match-wins; operators should write more specific globs
        before more general ones.
        """
        if not self._hardware:
            return None
        for port_glob, hw in self._hardware.items():
            if fnmatchcase(port, port_glob):
                return hw
        return None

    def _start_passthrough(self, port: str) -> TCPPassthrough | None:
        """If the matched hardware block sets ``tcp_passthrough_port``,
        spawn a per-port TCP listener and return it; else None.

        Idempotent: returns the existing listener when called for a
        port that already has one (defensive — sweeps shouldn't double-
        spawn but this guards against re-add after restart_reader).
        """
        existing = self._passthroughs.get(port)
        if existing is not None:
            return existing
        hw = self._match_hardware(port)
        if hw is None or hw.tcp_passthrough_port is None:
            return None
        # Loopback default — operator opts in to LAN exposure by setting
        # ``tcp_passthrough_bind: 0.0.0.0`` in the per-port hardware
        # block. The TCPPassthrough has no auth, so a LAN-bound listener
        # accepts companion-protocol commands from anyone on the
        # subnet; documented in tcp_passthrough.py.
        bind = hw.tcp_passthrough_bind or "127.0.0.1"
        pt = TCPPassthrough(hw.tcp_passthrough_port, bind_host=bind)
        pt.start()
        self._passthroughs[port] = pt
        log.info(
            "supervisor.tcp_passthrough.started",
            port=port,
            tcp_port=hw.tcp_passthrough_port,
        )
        return pt

    def _stop_passthrough(self, port: str) -> None:
        pt = self._passthroughs.pop(port, None)
        if pt is None:
            return
        try:
            pt.stop(timeout=2.0)
        except Exception as exc:  # noqa: BLE001
            log.warning(
                "supervisor.tcp_passthrough.stop_error",
                port=port,
                error=str(exc),
            )
        log.info("supervisor.tcp_passthrough.stopped", port=port)

    # KAN-167: pause/resume/resolve so the FW-OTA dispatcher can hand
    # the USB-CDC port to esptool / nrfutil during a flash, then let
    # the supervisor's next sweep auto-restart the reader against the
    # newly-flashed firmware.

    def resolve_port(self, sanitized: str) -> str | None:
        """Map ``sanitize_port(full_path)`` back to the full path.

        Used by the FW-OTA dispatcher, which receives the sanitized
        slug in the MQTT topic but needs the full ``/dev/serial/by-id``
        path to hand to the flashing subprocess. Returns ``None`` when
        no active reader matches — caller should mark the job failed.
        """
        from .mqtt_publisher import sanitize_port

        for full_port in self._readers:
            if sanitize_port(full_port) == sanitized:
                return full_port
        return None

    def pause_port(self, sanitized: str) -> None:
        """Stop the reader for ``sanitized`` AND block future sweeps from
        re-opening any port matching the same slug.

        The slug stays in :attr:`_paused_slugs` until :meth:`resume_port`
        is called, so when the chip re-enumerates mid-flash (the runtime
        descriptor reappears with the SAME sanitize_port() value) the
        supervisor's sweep skips it and esptool's verify step gets
        exclusive access to the device. Otherwise the sweep grabs the
        runtime port the instant it reappears, esptool can't complete
        its verify handshake, and the chip's USB-CDC stack crashes back
        into the JTAG bootloader.
        """
        with self._paused_lock:
            self._paused_slugs.add(sanitized)
        full = self.resolve_port(sanitized)
        if full is None:
            return
        reader = self._readers.pop(full, None)
        if reader is None:
            return
        try:
            reader.stop(timeout=2.0)
        except Exception as exc:  # noqa: BLE001
            log.warning("supervisor.pause_port.stop_error", port=full, error=str(exc))

    def resume_port(self, sanitized: str) -> None:
        """Re-enable supervisor sweeps for ``sanitized``.

        The next sweep iteration after this call sees the runtime
        descriptor and recreates a SerialReader against it. Idempotent:
        calling resume_port for a slug that wasn't paused is a no-op.
        """
        with self._paused_lock:
            self._paused_slugs.discard(sanitized)

    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop_evt.clear()
        self._thread = threading.Thread(
            target=self._run, name="port-supervisor", daemon=True
        )
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        self._stop_evt.set()
        thr = self._thread
        if thr is not None:
            thr.join(timeout)
        self._thread = None
        # Tear down all readers.
        for port, reader in list(self._readers.items()):
            try:
                reader.stop(timeout=2.0)
            except Exception as exc:  # noqa: BLE001
                log.warning("supervisor.reader.stop.error", port=port, error=str(exc))
        self._readers.clear()
        # Tear down any TCP passthroughs (closes listening sockets +
        # disconnects clients cleanly).
        for port in list(self._passthroughs):
            self._stop_passthrough(port)

    # ------------------------------------------------------------------

    def _run(self) -> None:
        log.info("supervisor.start", port_globs=list(self._cfg.port_globs))
        # Initial sweep + then poll on rescan_interval.
        while not self._stop_evt.is_set():
            try:
                self._sweep()
            except Exception as exc:  # noqa: BLE001
                log.error(
                    "supervisor.sweep.error",
                    error=str(exc),
                    error_type=type(exc).__name__,
                )
            if self._stop_evt.wait(self._cfg.rescan_interval_seconds):
                break
        log.info("supervisor.stop")

    def _sweep(self) -> None:
        from .mqtt_publisher import sanitize_port

        raw_wanted = self._ports_provider(self._cfg.port_globs)
        with self._paused_lock:
            paused_snapshot = set(self._paused_slugs)
        wanted = {p for p in raw_wanted if sanitize_port(p) not in paused_snapshot}
        have = set(self._readers)

        # Surface stuck-in-bootloader chips. If a bootloader descriptor
        # is present without a matching runtime descriptor, the chip
        # has failed to boot the application firmware after a flash —
        # operator (or an automatic recovery path) needs to intervene
        # by flashing a known-good binary. Logged every sweep so it
        # shows up in journalctl AND can be alerted on; the OTA
        # dispatcher's retry path uses the JTAG descriptor directly.
        for stuck in discover_stuck_bootloaders(self._cfg.port_globs):
            log.warning(
                "supervisor.stuck_chip_detected",
                bootloader_port=stuck,
                hint=(
                    "chip is in DFU / JTAG bootloader mode without a "
                    "matching runtime descriptor — queue an OTA job "
                    "to recover, or flash manually via esptool/nrfutil"
                ),
            )

        # New ports → spin up readers (+ TCP passthrough if configured).
        for port in sorted(wanted - have):
            log.info("supervisor.port.added", port=port)
            self._spawn_reader(port)

        # Vanished ports → stop readers, drop entries.
        for port in sorted(have - wanted):
            log.info("supervisor.port.removed", port=port)
            reader = self._readers.pop(port)
            try:
                reader.stop(timeout=2.0)
            except Exception as exc:  # noqa: BLE001
                log.warning("supervisor.reader.stop.error", port=port, error=str(exc))
            self._stop_passthrough(port)
            self._last_data.pop(port, None)
            self._ever_produced.discard(port)

        # Restart any reader that's either DEAD (thread panicked — rare,
        # given SerialReader._run's exception envelope) or STALLED (thread
        # alive but the serial side has gone silent past the heartbeat
        # window — the 2026-06-04 T-Echo case: reader alive, zero data for
        # 8 h while the device kept running). The TCP passthrough stays
        # alive across the restart so connected clients keep their session.
        now = time.monotonic()
        for port, reader in list(self._readers.items()):
            dead = not reader.is_alive
            silent_for = now - self._last_data.get(port, now)
            stalled = port in self._ever_produced and silent_for > _STALL_RESTART_SECONDS
            if dead:
                log.warning("supervisor.reader.dead.restarting", port=port)
            elif stalled:
                log.warning(
                    "supervisor.reader.stalled.restarting",
                    port=port,
                    silent_seconds=round(silent_for),
                )
            else:
                continue
            self._restart_reader_inplace(port)

    def _spawn_reader(self, port: str) -> None:
        """Create + start a SerialReader for ``port`` (with its TCP
        passthrough if configured) and seed its stall clock."""
        passthrough = self._start_passthrough(port)
        reader = self._reader_factory(
            port,
            self._cfg.baud,
            self._record_and_forward,
            read_timeout_seconds=self._cfg.read_timeout_seconds,
            passthrough=passthrough,
        )
        reader.start()
        self._readers[port] = reader
        # Seed the stall clock so a freshly-spawned reader gets a full
        # grace window before the watchdog could consider it stalled.
        self._last_data[port] = time.monotonic()

    def _restart_reader_inplace(self, port: str) -> None:
        """Stop the current reader for ``port`` and respawn it. Keeps the
        TCP passthrough (idempotent) so clients keep their session, and
        resets the stall clock for the fresh reader."""
        old = self._readers.pop(port, None)
        if old is not None:
            try:
                old.stop(timeout=1.0)
            except Exception:  # noqa: BLE001
                pass
        self._spawn_reader(port)

    def _record_and_forward(self, port: str, frame: AnyFrame) -> None:
        """Reader callback wrapper: stamp per-port liveness for the stall
        watchdog, then forward to the real on_frame handler."""
        self._last_data[port] = time.monotonic()
        self._ever_produced.add(port)
        self._on_frame(port, frame)


def join_forever(stop_evt: threading.Event, *, poll_seconds: float = 0.5) -> None:
    """Block until ``stop_evt`` is set.

    Helper for the entry point so SIGTERM handling stays out of the
    supervisor logic.
    """
    while not stop_evt.is_set():
        time.sleep(poll_seconds)
