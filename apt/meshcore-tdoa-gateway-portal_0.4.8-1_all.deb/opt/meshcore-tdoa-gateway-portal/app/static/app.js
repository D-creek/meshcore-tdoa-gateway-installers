// MeshCore TDOA Gateway portal — vanilla JS, no framework.
// v0.2 — per-USB-device config + gateway-name editor.

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

let BROKER_TYPES = {};
let DEVICES = [];
let SELECTED_SLUG = null;

// ── Toast ──────────────────────────────────────────────────────────

function toast(msg, kind = "success", ms = 3000) {
  const el = $("#toast");
  el.textContent = msg;
  el.className = "toast " + kind;
  el.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => (el.hidden = true), ms);
}

// ── Info / hostname / mode ─────────────────────────────────────────

async function loadInfo() {
  const r = await fetch("/api/info").then((r) => r.json());
  $("#hostname").textContent = r.hostname;
  const mode = $("#mode-badge");
  if (r.production) {
    mode.textContent = "PROD";
    mode.classList.add("prod");
  } else {
    mode.textContent = "TEST";
    mode.classList.add("test");
  }
  // v0.3.5: portal-deb version chip. Falls back to "dev" when run from
  // source (no /usr/share/.../version.txt stamp). The relay-running
  // hint piggybacks on the same tooltip so the operator can correlate
  // "every broker says ? unknown" with "relay isn't running" without
  // jumping between tabs.
  const ver = $("#portal-version");
  if (ver) {
    ver.textContent = r.portal_version || "dev";
    // The chip turns yellow when the mesh-relay isn't running (Brokers pills
    // then read "? unknown"). State the ACTUAL reason in the tooltip so yellow
    // is never unexplained. Auto-update runs hourly (auto-update.timer).
    if (!r.relay_running) {
      ver.classList.add("warn");
      ver.title =
        `Installed portal version ${r.portal_version || "dev"}. ` +
        "⚠️ Yellow: the mesh-relay isn't running, so the Brokers/Message-dev " +
        "pills show '? unknown'. Auto-update runs hourly.";
    } else {
      ver.classList.remove("warn");
      ver.title =
        `Installed portal version ${r.portal_version || "dev"}. ` +
        "Auto-update runs hourly (meshcore-tdoa-auto-update.timer).";
    }
  }
  // Bridge version chip. r.bridge_version is the running build if the bridge is
  // up, else the installed deb version (deployed_version stamp). Hidden only
  // when no bridge package is installed at all (null). Label tells the operator
  // which it is, so a non-running bridge is obvious.
  const bver = $("#bridge-version");
  if (bver) {
    if (r.bridge_version) {
      const running = r.bridge_running === true;
      bver.textContent = `bridge ${r.bridge_version}${running ? "" : " (installed)"}`;
      bver.title = running
        ? `Bridge running, version ${r.bridge_version}.`
        : `Bridge installed at ${r.bridge_version} but NOT currently running ` +
          "(no broker/device, or crash-looping). Showing the installed version.";
      bver.classList.toggle("warn", !running);
      bver.hidden = false;
    } else {
      bver.hidden = true;
    }
  }
}

// ── Devices ────────────────────────────────────────────────────────

async function loadDevices() {
  DEVICES = await fetch("/api/devices").then((r) => r.json());
  if (!SELECTED_SLUG && DEVICES.length) SELECTED_SLUG = DEVICES[0].slug;
  renderDevicePills();
  renderGatewayNameInput();
  renderDeviceMeta();
}

function renderDevicePills() {
  const host = $("#device-pills");
  host.innerHTML = "";
  if (!DEVICES.length) {
    host.innerHTML =
      '<div class="hint">No USB devices configured. Plug one in or add a config dir under DEVICES_DIR.</div>';
    return;
  }
  DEVICES.forEach((d) => {
    const pill = document.createElement("button");
    pill.type = "button";
    pill.className =
      "device-pill" + (d.slug === SELECTED_SLUG ? " active" : "");
    pill.dataset.slug = d.slug;
    const newBadge = d.configured
      ? ""
      : '<span class="new-badge">NEW</span>';
    // 2026-05-26: device role(s) chip. Splits the operator-set role
    // string on commas so a device with multiple roles (e.g.
    // "repeater, room_server") shows one chip per role. Falls back to
    // a single chip when only one role is set; hidden entirely when
    // the field is empty so unconfigured devices don't grow a strip.
    const roleStr = (d.role || "").toString();
    const roleChips = roleStr
      .split(",")
      .map((r) => r.trim())
      .filter(Boolean)
      .map((r) => `<span class="role-chip">${esc(r)}</span>`)
      .join("");
    // 2026-05-28 — TDOA-fw + GPS health dot.
    //   GREEN  = TDOA fw flashed AND GPS enabled
    //   AMBER  = TDOA fw flashed AND GPS NOT enabled (or never probed)
    //   RED    = no TDOA fw confirmed
    //   GREY   = neither TDOA fw NOR runtime state known (cold path)
    // Tooltip carries the reason + remediation so the operator knows
    // WHY a node is amber/red and what to do about it.
    const rt = d.runtime_state;
    let dotClass = "status-grey";
    let dotTitle = "Status unknown — board info hasn't reached the portal yet. "
                 + "Wait ~60 s for the bridge to publish info, or open the gear menu to probe.";
    // Stale-port check FIRST: a port that's USB-present but hasn't delivered
    // a frame/telemetry in minutes is wedged or the board is offline — that
    // overrides "fw + GPS look fine" (which is cached state, not live data).
    // A healthy TDOA receiver emits telemetry every ~5 s, so >5 min of
    // silence is genuinely dead. The bridge auto-restarts a stalled reader
    // (~3 min); a dot still red here means it couldn't recover → check the
    // device. data_age_s is null when the bridge has no snapshot for the port.
    const STALE_DOT_SECONDS = 300;
    const ageS = d.data_age_s;
    if (typeof ageS === "number" && ageS > STALE_DOT_SECONDS) {
      dotClass = "status-red";
      const mins = Math.round(ageS / 60);
      dotTitle = `No data from this device in ~${mins} min — the port is wedged `
               + `or the board is offline (USB still enumerated). The bridge `
               + `auto-restarts a stalled reader; if this persists, reset/replug `
               + `the device.`;
    } else if (d.has_tdoa_fw === false && rt === null) {
      // Cold path: bridge.info.published hasn't been cached yet → we
      // truly don't know if TDOA fw is on. Stay grey, not red.
      // (covered above)
    } else if (d.has_tdoa_fw === false) {
      dotClass = "status-red";
      dotTitle = "No TDOA firmware detected on this device. "
               + "Flash a *-tdoa-rx firmware from the Firmware section "
               + "to enable TDOA reception.";
    } else if (rt && rt.gps === true) {
      dotClass = "status-green";
      const ageNote = rt.stale
        ? ` Cached ${Math.round((rt.age_seconds || 0) / 60)} min ago.`
        : "";
      dotTitle = `TDOA firmware flashed and GPS is on — fully operational.${ageNote}`;
    } else if (rt && rt.gps === false) {
      dotClass = "status-amber";
      const ageNote = rt.stale
        ? ` Cached ${Math.round((rt.age_seconds || 0) / 60)} min ago.`
        : "";
      dotTitle = `TDOA firmware flashed but GPS is OFF — node won't contribute timing data. `
               + `Open the gear menu and toggle "GPS on" to enable.${ageNote}`;
    } else if (rt && rt.gps === null) {
      dotClass = "status-amber";
      dotTitle = "TDOA fw confirmed; GPS state unknown (firmware didn't return a parseable "
               + "value). Open the gear menu and click ↻ Refresh.";
    } else if (d.has_tdoa_fw === true && typeof ageS === "number" && ageS <= STALE_DOT_SECONDS) {
      // TDOA fw confirmed AND the bridge is receiving fresh frames from this
      // device → it's genuinely working, even if the runtime knobs were never
      // probed. Show GREEN from live data instead of amber-pending-probe (the
      // post-reinstall state that wrongly looked "down" to the operator).
      dotClass = "status-green";
      dotTitle = "TDOA firmware flashed and receiving live frames — operational. "
               + "(Open the gear menu to probe GPS/TX runtime knobs.)";
    } else if (d.has_tdoa_fw === true) {
      dotClass = "status-amber";
      dotTitle = "TDOA firmware detected; runtime knobs (GPS, repeat, TX) never probed "
               + "and no recent frames. Open the gear menu to fetch live state.";
    }
    // Display name = the operator/firmware configured name. Hardware label
    // ("Heltec V4") shows SMALLER beside it. When the device has no real name
    // (unnamed), the hardware label IS the primary text and we don't repeat it.
    const hwLabel = d.hardware_label || "";
    const cfgName = (d.gateway_name || "").trim();
    const named = cfgName && cfgName !== hwLabel && cfgName !== d.slug;
    // A device we couldn't identify as one of our LoRa boards — key on
    // hardware_id (null = unmatched; hardware_label is a humanized-slug fallback
    // that's never null, so it can't be the signal). has_tdoa_fw === true also
    // counts as LoRa (the bridge saw a TDOA info frame).
    const isLora = !!d.hardware_id || d.has_tdoa_fw === true;
    let primary, tag;
    if (!isLora) {
      // Trim the long USB-vendor slug to something readable for the pill.
      const shortName = esc(d.slug.replace(/-[0-9a-f]{6,}.*$/i, "").slice(0, 28) || d.slug);
      primary = shortName;
      tag = `<span class="pill-tag pill-tag-muted" title="${esc(d.slug)} — the bridge does not open this device">not a LoRa node</span>`;
    } else if (named) {
      primary = esc(cfgName);
      tag = `<span class="pill-tag" title="${esc(d.slug)}">${esc(hwLabel)}</span>`;
    } else {
      primary = esc(hwLabel);              // unnamed → board name is the title
      tag = "";                            // don't repeat it
    }
    pill.innerHTML = `
      <span class="status-dot ${dotClass}" title="${esc(dotTitle)}"></span>
      <span class="pill-name">${primary}</span>
      ${tag}
      ${roleChips}
      ${newBadge}
    `;
    pill.addEventListener("click", () => {
      SELECTED_SLUG = d.slug;
      renderDevicePills();
      renderGatewayNameInput();
      renderDeviceMeta();
      loadBrokers();
      loadHealth();
      loadFirmware();
    });
    host.appendChild(pill);
  });
}

function selectedDevice() {
  return DEVICES.find((d) => d.slug === SELECTED_SLUG);
}

function renderGatewayNameInput() {
  // gateway name + tcp passthrough now live in the gear-icon modal.
  // Kept as a no-op stub so older inline callers (loadDevices) don't
  // break while the rest of the codebase catches up.
}

function renderDeviceMeta() {
  const dev = selectedDevice();
  const meta = $("#device-meta");
  if (!dev) {
    meta.textContent = "";
    return;
  }
  const parts = [];
  if (dev.gateway_name && dev.gateway_name !== dev.slug) {
    parts.push(`name: ${dev.gateway_name}`);
  }
  if (dev.by_id_name) parts.push(`USB id: ${dev.by_id_name}`);
  if (dev.tty) parts.push(`tty: ${dev.tty}`);
  parts.push(`config slug: ${dev.slug}`);
  if (dev.tcp_proxy_enabled) {
    parts.push(`TCP :${dev.tcp_proxy_port || 5000}`);
  }
  meta.textContent = parts.join(" · ");
  // Tooltip carries the operator role + first line of notes so an
  // operator can hover the meta strip and see context at a glance.
  const tip = [];
  if (dev.role) tip.push(`role: ${dev.role}`);
  if (dev.notes) tip.push(dev.notes.split("\n")[0]);
  meta.title = tip.join(" · ");
}

// ── Gear-icon config modal ────────────────────────────────────────
//
// Replaces the old inline "Gateway name" + "TCP client port" rows.
// One modal carries all per-device operator settings so the gateway
// pill stays clean and the operator has one place to edit hardware/
// role notes. TCP passthrough lives inside this modal as a toggle
// pill (matching the brokers-table toggle style) instead of a button.

function openConfigModal() {
  const dev = selectedDevice();
  if (!dev) { toast("Select a device first", "error"); return; }
  const modal = document.getElementById("config-modal");
  const form = document.getElementById("config-form");
  if (!modal || !form) return;
  document.getElementById("config-modal-title").textContent =
    `Gateway config · ${dev.gateway_name || dev.slug}`;
  // Pre-fill the form from the device record. Empty string is fine
  // for fields the operator hasn't set yet; the save endpoint trims
  // and treats blanks as "no change".
  const FIELDS = [
    "gateway_name", "node_function", "role", "notes", "gps_module", "gps_antenna",
    "lora_antenna", "sx1262_tcxo", "pcb_revision", "power_source",
  ];
  for (const name of FIELDS) {
    const inp = form.querySelector(`[name="${name}"]`);
    if (inp) inp.value = dev[name] || "";
  }
  // Pre-fill the (free-form) Operator role from the firmware-advertised
  // role when the operator hasn't set one — interrogated, not invented.
  // Only fills a BLANK field so a saved operator value is never clobbered.
  const roleInp = form.querySelector('[name="role"]');
  const rt = dev.runtime_state || {};
  const fwRole = rt.advert_role || rt.firmware_role || rt.role;
  if (roleInp && !roleInp.value && fwRole) roleInp.value = fwRole;
  // Gateway-name source hint + unpin button. The portal auto-syncs
  // gateway_name from the firmware's NVS-stored node_name on every
  // runtime-state probe — UNLESS the operator has pinned a manual
  // value (any PUT /api/devices/{slug}/name sets the pin). Show the
  // current source + offer to clear the pin to re-enable auto-sync.
  renderGatewayNameSourceHint(dev);
  // TCP passthrough state.
  const portInp = document.getElementById("tcp-proxy-port");
  if (portInp) {
    portInp.value = dev.tcp_proxy_port || 5000;
    portInp.disabled = !!dev.tcp_proxy_enabled;  // locked while running
  }
  syncTcpProxyToggleUI(!!dev.tcp_proxy_enabled, dev.tcp_proxy_port || 5000);
  // 2026-05-28 — pre-fill the runtime-knob inputs from the cached snapshot
  // so the modal renders instantly with last-known state. Then fire a fresh
  // probe in the background and replace the values when it resolves.
  populateRuntimeKnobs(dev.runtime_state || null, /*fresh=*/false);
  refreshRuntimeState(dev.slug);   // background probe
  // Light up the "HW confirmed" badge + offer auto-fill when the
  // firmware GpsChipProbe identity backs up the operator field. Reads
  // the same /health payload the GPS section already consumes — cached
  // by loadHealth(), but we re-fetch lazily so this works on a cold
  // modal-open before the 5s health cycle ticks.
  renderConfigChipHints(dev.slug);
  modal.hidden = false;
}

/**
 * Render the source hint under the Gateway name field: shows whether
 * the current value was auto-synced from the firmware's node_name or
 * manually pinned by the operator, and offers an unpin button to
 * re-enable auto-sync when applicable. Idempotent — called on every
 * modal open.
 */
function renderGatewayNameSourceHint(dev) {
  const txt = document.getElementById("gateway-name-source-text");
  const btn = document.getElementById("gateway-name-unpin-btn");
  if (!txt || !btn) return;
  txt.textContent = "";
  btn.hidden = true;
  btn.onclick = null;
  const source = dev.gateway_name_source;
  const pinned = !!dev.gateway_name_pinned;
  const firmwareName = dev.runtime_state && dev.runtime_state.node_name;
  if (pinned && source === "operator_manual") {
    let msg = "Manual override (pinned).";
    if (firmwareName && firmwareName !== dev.gateway_name) {
      msg += ` Firmware node_name: "${firmwareName}".`;
    }
    txt.textContent = msg;
    btn.hidden = false;
    btn.onclick = async () => {
      try {
        const r = await fetch(
          `/api/devices/${encodeURIComponent(dev.slug)}/name/unpin`,
          {method: "POST"},
        );
        const data = await r.json();
        if (r.ok && data && data.ok) {
          toast(
            "Pin cleared. Next probe will auto-sync from firmware node_name.",
            "ok",
          );
          // Trigger a fresh probe so the value updates immediately
          // (no need to wait for the cache TTL).
          refreshRuntimeState(dev.slug);
        } else {
          toast("Failed to unpin: " + (data.detail || "unknown"), "error");
        }
      } catch (e) {
        toast("Unpin request failed: " + e.message, "error");
      }
    };
  } else if (source === "firmware_node_name") {
    txt.textContent = "Auto-synced from firmware node_name.";
  } else if (source === "auto_pending_next_probe") {
    txt.textContent = "Pin cleared — will auto-sync on next probe.";
  } else if (firmwareName) {
    txt.textContent = `Firmware node_name: "${firmwareName}".`;
  }
}


/**
 * Fill the read-only "Detected (from firmware)" panel in the config
 * modal from a /health payload. Shows board / MCU / LoRa chip / fw
 * version (+ TDOA build) / GPS chip / capability flags — the fields the
 * firmware interrogates and reports via 0x94 GATEWAY_INFO. Hidden when
 * nothing has been reported yet (legacy fw / no 0x94 seen).
 */
function renderDetectedIdentity(h) {
  const panel = document.getElementById("cfg-detected");
  const body = document.getElementById("cfg-detected-body");
  if (!panel || !body) return;
  const rows = [];
  const add = (label, val) => {
    if (val !== undefined && val !== null && val !== "" && val !== false) {
      rows.push(`<div><strong>${esc(label)}:</strong> ${esc(String(val))}</div>`);
    }
  };
  add("Board", h.board_name);
  if (h.mcu_chip || h.lora_chip) {
    add("MCU / LoRa", `${h.mcu_chip || "?"} / ${h.lora_chip || "?"}`);
  }
  add("Firmware", h.fw_version);
  if (h.tdoa_fw_version && h.tdoa_fw_version !== h.fw_version) {
    add("TDOA build", h.tdoa_fw_version);
  }
  add("GPS chip", h.gps_chip_model || h.gps_chip_family_name);
  // Capability flags — only render the ones the firmware asserts true.
  const caps = [
    h.has_gps ? "GPS" : "",
    h.has_pps ? "PPS" : "",
    h.is_tdoa_rx ? "TDOA-RX" : "",
  ].filter(Boolean);
  if (caps.length) add("Capabilities", caps.join(" · "));

  if (!rows.length) {
    panel.hidden = true;
    return;
  }
  body.innerHTML = rows.join("");
  panel.hidden = false;
}

/**
 * Pulls /api/devices/{slug}/health and, if it carries probe-detected
 * chip identity, surfaces (a) a "HW confirmed: <model>" badge next to
 * the GPS module input when the operator's typed value already lines
 * up with the chip and (b) an inline "use detected" button that fills
 * the input when blank. Same lookup-string heuristic as the homeprod
 * Node-detail page (substring match against family-name or model).
 */
async function renderConfigChipHints(slug) {
  const badge = document.getElementById("gps-module-hw-badge");
  const btn = document.querySelector('[data-autofill="gps_module"]');
  const labelText = document.getElementById("gps-module-label-text");
  const input = document.querySelector('input[name="gps_module"]');
  if (!badge || !btn) return;
  // Hide the Detected panel until /health resolves (prevents stale data
  // from a previously-selected device flashing up).
  const detPanel = document.getElementById("cfg-detected");
  if (detPanel) detPanel.hidden = true;
  // Reset to free-form defaults — we'll re-lock below if probe data
  // arrives. Idempotent across re-renders.
  badge.hidden = true;
  badge.textContent = "";
  badge.classList.remove("locked");
  btn.hidden = true;
  btn.onclick = null;
  if (input) {
    input.readOnly = false;
    input.classList.remove("hw-locked");
    input.title = "";
  }
  if (labelText) labelText.textContent = "GPS module";
  if (!slug) return;
  let h;
  try {
    h = await fetch(
      `/api/devices/${encodeURIComponent(slug)}/health`,
    ).then((r) => r.json());
  } catch (_) {
    return;  // network blip — silently skip the badge
  }
  // Read-only "Detected (from firmware)" panel — the full interrogated
  // identity (board / MCU / LoRa / fw / GPS chip / capabilities) so the
  // operator sees what the device actually reports without leaving the
  // modal. Independent of the GPS-chip badge below (shows even when the
  // chip wasn't probed). Populated from the same /health payload.
  renderDetectedIdentity(h);
  if (!h || h.gps_chip_family == null) return;
  const familyName = h.gps_chip_family_name
    || GPS_FAMILY_NAMES[h.gps_chip_family]
    || "unknown";
  const detectedLabel = h.gps_chip_model || familyName;
  if (!input) return;

  // 2026-05-29 0.3.51: when the firmware has actually probed the chip,
  // the displayed value is the AUTHORITATIVE answer. Operator override
  // would just diverge from reality (chip is what it is — the silkscreen
  // can't lie via a typed string). Lock the field to the detected
  // value, swap the label to "GPS module (HW probed — locked)", and
  // render a confirmed-state badge.
  input.value = detectedLabel;
  input.readOnly = true;
  input.classList.add("hw-locked");
  input.title =
    `Firmware GpsChipProbe identifies the chip as ${detectedLabel}. ` +
    `Field locked because hardware probe is authoritative.`;
  if (labelText) labelText.textContent = "GPS module (HW probed — locked)";
  badge.textContent = `HW confirmed: ${detectedLabel}`;
  badge.title =
    `Firmware GpsChipProbe identifies the chip as ${detectedLabel}. ` +
    `If this looks wrong, the chip identity probe needs investigation — ` +
    `re-flashing operator metadata won't change it.`;
  badge.classList.add("locked");
  badge.hidden = false;
  // Fire the input event so any downstream listeners (form-dirty
  // detection, validation) pick up the value we just wrote.
  input.dispatchEvent(new Event("input", { bubbles: true }));
}

// ── Runtime knobs (Live device state fieldset) ─────────────────────

// 0.3.65 — convert firmware-raw advert value (2-min slots) ↔ operator-
// facing hours. Firmware halves `set advert.interval N` to N/2 in its
// NVS (CommonCLI.cpp:523), so the round-trip is:
//   raw = state.advert_minutes (what get advert.interval returns)
//   effective_minutes = raw * 2
//   hours = effective_minutes / 60 = raw / 30
// And on the way back:
//   minutes_to_send = hours * 60     (firmware halves to raw stored)
function advertRawToHours(raw) {
  if (raw === null || raw === undefined) return "";
  const hours = Number(raw) / 30;
  // Display whole hours when divisible; fractional only when needed.
  return Number.isInteger(hours) ? String(hours) : hours.toFixed(2);
}

function advertHoursToMinutes(hours) {
  return Math.round(Number(hours) * 60);
}

function populateRuntimeKnobs(state, fresh) {
  const caption = $("#runtime-state-caption");
  const repeatEl    = $("#rt-repeat-input");
  const gpsEl       = $("#rt-gps-input");
  const txEl        = $("#rt-tx-input");
  const advEl       = $("#rt-advert-input");
  const dutyEl      = $("#rt-dutycycle-input");
  const floodEl     = $("#rt-flood-advert-input");
  const rxBoostEl   = $("#rt-rx-boost-input");
  if (!repeatEl || !gpsEl || !txEl || !advEl) return;
  if (!state) {
    if (caption) {
      caption.textContent = "no cached state — probing now";
      caption.style.color = "var(--fg-mute,#94a3b8)";
    }
    repeatEl.checked = false; repeatEl.indeterminate = true;
    gpsEl.checked    = false; gpsEl.indeterminate    = true;
    txEl.value  = "";
    advEl.value = "";
    if (dutyEl) dutyEl.value = "";
    if (floodEl) floodEl.value = "";
    if (rxBoostEl) { rxBoostEl.checked = false; rxBoostEl.indeterminate = true; }
    return;
  }
  // 0.3.35 — caption now reads "<freshness> · role=<x> · protocol=<binary|text-cli|unknown>"
  // so the operator can see at a glance whether the runtime knobs WILL
  // work on this firmware. protocol=unknown disables the Save button.
  // 0.3.39 — on companion_radio firmware the ADVERTISED role is
  // hardcoded to CHAT regardless of whether the node ACTUALLY forwards
  // packets (controlled by the runtime client_repeat flag). Show both
  // so the operator doesn't confuse identity-of-record with behaviour.
  const advertRole = state.advert_role || state.firmware_role || state.role || "?";
  const actingAsRepeater = state.is_acting_as_repeater === true;
  const role = (
    advertRole === "?" ? "?"
    : actingAsRepeater && advertRole !== "repeater"
      ? `${advertRole} (acting as repeater)`
      : advertRole
  );
  const protocol = state.protocol || (state.source === "bridge_info" ? "bridge-info-only" : "unknown");
  const protocolLabel = {
    "binary": "binary RPC",
    "text-cli": "text CLI",
    "bridge-info-only": "read-only (bridge info)",
    "unknown": "unknown firmware",
  }[protocol] || protocol;
  if (caption) {
    let prefix;
    if (fresh) {
      prefix = "live (just probed)";
      caption.style.color = "var(--good,#4ade80)";
    } else if (state.stale) {
      const mins = Math.round((state.age_seconds || 0) / 60);
      prefix = `cached ${mins} min ago — refreshing…`;
      caption.style.color = "var(--fg-mute,#94a3b8)";
    } else {
      const mins = Math.round((state.age_seconds || 0) / 60);
      prefix = `cached ${mins} min ago`;
      caption.style.color = "var(--fg-mute,#94a3b8)";
    }
    caption.textContent = `${prefix} · role=${role} · ${protocolLabel}`;
  }
  // Disable Save when the protocol is unknown / bridge-info-only — there
  // is no path to push knob changes back to the device. Operator gets a
  // tooltip explaining why instead of a silent failure.
  const saveBtn = $("#rt-save-btn");
  if (saveBtn) {
    const writeable = protocol === "binary" || protocol === "text-cli";
    saveBtn.disabled = !writeable;
    if (writeable) {
      saveBtn.title = "";
      saveBtn.textContent = protocol === "text-cli"
        ? "Save runtime changes (text CLI)"
        : "Save runtime changes";
    } else {
      saveBtn.title = "Firmware protocol not detected on this device. "
        + "↻ Refresh to re-probe, or open the Firmware section and flash "
        + "a known TDOA/MeshCore build.";
      saveBtn.textContent = "Save (no write path)";
    }
  }
  // Each input renders indeterminate when the firmware didn't return a
  // parseable value (knob unsupported by this fw). Operator can still type
  // a value to attempt; the per-knob response will say "firmware refused".
  if (state.repeat === true || state.repeat === false) {
    repeatEl.checked = state.repeat; repeatEl.indeterminate = false;
  } else { repeatEl.checked = false; repeatEl.indeterminate = true; }
  if (state.gps === true || state.gps === false) {
    gpsEl.checked = state.gps; gpsEl.indeterminate = false;
  } else { gpsEl.checked = false; gpsEl.indeterminate = true; }
  txEl.value  = state.tx_dbm !== null && state.tx_dbm !== undefined ? state.tx_dbm : "";
  // 0.3.65 — display advert in HOURS (convert from firmware raw value).
  advEl.value = advertRawToHours(state.advert_minutes);
  // 0.3.65 — three new knobs. Greyed when fw doesn't return them.
  if (dutyEl) {
    dutyEl.value = state.dutycycle !== null && state.dutycycle !== undefined
                   ? state.dutycycle : "";
  }
  if (floodEl) {
    floodEl.value = state.flood_advert_interval !== null
                    && state.flood_advert_interval !== undefined
                    ? state.flood_advert_interval : "";
  }
  if (rxBoostEl) {
    if (state.rx_boost === true || state.rx_boost === false) {
      rxBoostEl.checked = state.rx_boost; rxBoostEl.indeterminate = false;
    } else { rxBoostEl.checked = false; rxBoostEl.indeterminate = true; }
  }
}

async function refreshRuntimeState(slug) {
  const caption = $("#runtime-state-caption");
  const fb = $("#runtime-feedback");
  if (caption) {
    caption.textContent = "probing device…";
    caption.style.color = "var(--accent,#60a5fa)";
  }
  try {
    const r = await fetch(
      `/api/devices/${encodeURIComponent(slug)}/runtime-state?refresh=true&allow_brief_passthrough=true`
    );
    if (!r.ok) {
      const t = await r.text();
      throw new Error(`HTTP ${r.status}: ${t.slice(0, 200)}`);
    }
    const state = await r.json();
    populateRuntimeKnobs(state, /*fresh=*/true);
    // Also patch the in-memory DEVICES record so the page-load dot reflects
    // the new state without a full reload (modal-close re-renders pills).
    const d = DEVICES.find((x) => x.slug === slug);
    if (d) d.runtime_state = state;
    if (fb) fb.innerHTML = "";
  } catch (e) {
    if (caption) {
      caption.textContent = `probe failed: ${e.message || e}`;
      caption.style.color = "#fca5a5";
    }
  }
}

async function saveRuntimeChanges() {
  const dev = selectedDevice();
  if (!dev) return;
  const fb = $("#runtime-feedback");
  const caption = $("#runtime-state-caption");
  // Build the payload from the inputs. Only include knobs whose value
  // differs from the currently-displayed cached state — limits the
  // batch to actual changes.
  const cur = dev.runtime_state || {};
  const repeatEl    = $("#rt-repeat-input");
  const gpsEl       = $("#rt-gps-input");
  const txEl        = $("#rt-tx-input");
  const advEl       = $("#rt-advert-input");
  const dutyEl      = $("#rt-dutycycle-input");
  const floodEl     = $("#rt-flood-advert-input");
  const rxBoostEl   = $("#rt-rx-boost-input");
  const payload = { allow_brief_passthrough: true };
  if (!repeatEl.indeterminate && repeatEl.checked !== !!cur.repeat) {
    payload.repeat = repeatEl.checked;
  }
  if (!gpsEl.indeterminate && gpsEl.checked !== !!cur.gps) {
    payload.gps = gpsEl.checked;
  }
  const txVal = txEl.value.trim();
  if (txVal !== "" && Number(txVal) !== cur.tx_dbm) {
    payload.tx_dbm = Number(txVal);
  }
  // 0.3.65 — Advert input is in HOURS; convert to minutes for the
  // firmware (which then halves again to its 2-min-slot raw value).
  // Compare against the current displayed-hour value, not the raw.
  const advVal = advEl.value.trim();
  if (advVal !== "" && Number(advVal) !== Number(advertRawToHours(cur.advert_minutes))) {
    payload.advert_minutes = advertHoursToMinutes(advVal);
  }
  // 0.3.65 — three new persistent knobs.
  if (dutyEl) {
    const v = dutyEl.value.trim();
    if (v !== "" && Number(v) !== cur.dutycycle) payload.dutycycle = Number(v);
  }
  if (floodEl) {
    const v = floodEl.value.trim();
    if (v !== "" && Number(v) !== cur.flood_advert_interval) {
      payload.flood_advert_interval = Number(v);
    }
  }
  if (rxBoostEl && !rxBoostEl.indeterminate && rxBoostEl.checked !== !!cur.rx_boost) {
    payload.rx_boost = rxBoostEl.checked;
  }
  const knobsToSet = Object.keys(payload).filter((k) => k !== "allow_brief_passthrough");
  if (knobsToSet.length === 0) {
    toast("No runtime knobs changed", "info");
    return;
  }
  if (fb) {
    fb.innerHTML = knobsToSet.map((k) =>
      `<div class="knob-row busy" data-knob="${esc(k)}">
         <span class="knob-glyph">↻</span>
         <span class="knob-name">${esc(k)}</span>
         <span class="knob-msg">sending…</span>
       </div>`
    ).join("");
  }
  if (caption) {
    caption.textContent = "applying changes…";
    caption.style.color = "var(--accent,#60a5fa)";
  }
  try {
    const r = await fetch(
      `/api/devices/${encodeURIComponent(dev.slug)}/runtime-config`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }
    );
    if (!r.ok) {
      const t = await r.text();
      throw new Error(`HTTP ${r.status}: ${t.slice(0, 200)}`);
    }
    const resp = await r.json();
    // Render per-knob feedback row replacing the "busy" placeholders.
    if (fb) {
      fb.innerHTML = Object.entries(resp.results || {}).map(([knob, row]) => {
        const klass = row.ok ? "ok" : "fail";
        const glyph = row.ok ? "✓" : "✗";
        const fmt = (v) => v === null || v === undefined ? "—" : `<code>${esc(String(v))}</code>`;
        const errText = row.error ? ` — ${esc(row.error)}` : "";
        return `<div class="knob-row ${klass}">
          <span class="knob-glyph">${glyph}</span>
          <span class="knob-name">${esc(knob)}</span>
          <span class="knob-msg">${fmt(row.before)} → ${fmt(row.after)} (requested ${fmt(row.requested)})${errText}</span>
        </div>`;
      }).join("");
    }
    // Refresh cached state from the response's final_state so the modal
    // and device-pill dot reflect the post-save reality.
    if (resp.final_state) {
      populateRuntimeKnobs(resp.final_state, /*fresh=*/true);
      const d = DEVICES.find((x) => x.slug === dev.slug);
      if (d) d.runtime_state = resp.final_state;
    }
    const okCount = Object.values(resp.results || {}).filter((r) => r.ok).length;
    const total = Object.keys(resp.results || {}).length;
    toast(`Runtime: ${okCount}/${total} change(s) applied`,
          okCount === total ? "success" : "error");
  } catch (e) {
    if (fb) {
      fb.innerHTML = `<div class="knob-row fail">
        <span class="knob-glyph">✗</span>
        <span class="knob-name">batch</span>
        <span class="knob-msg">${esc(e.message || String(e))}</span>
      </div>`;
    }
    if (caption) {
      caption.textContent = "save failed";
      caption.style.color = "#fca5a5";
    }
    toast(`Runtime save failed: ${e.message || e}`, "error");
  }
}

document.getElementById("rt-refresh-btn")?.addEventListener("click", () => {
  const dev = selectedDevice();
  if (dev) refreshRuntimeState(dev.slug);
});
document.getElementById("rt-save-btn")?.addEventListener("click", saveRuntimeChanges);

// 0.3.65 — Send advert now: fires a single ADVERT without persisting.
// Useful for verifying mesh visibility without bumping the interval.
document.getElementById("rt-advert-now-btn")?.addEventListener("click", async () => {
  const dev = selectedDevice();
  if (!dev) return;
  try {
    const r = await fetch(
      `/api/devices/${encodeURIComponent(dev.slug)}/runtime/advert?allow_brief_passthrough=true`,
      { method: "POST" },
    );
    if (!r.ok) {
      const t = await r.text();
      throw new Error(`HTTP ${r.status}: ${t.slice(0, 200)}`);
    }
    const resp = await r.json();
    const echo = (resp.response || "").trim();
    toast(`ADVERT sent${echo ? ` — ${echo}` : ""}`, "success");
  } catch (e) {
    toast(`Advert send failed: ${e.message || e}`, "error");
  }
});

// 0.3.65 — pull per-knob meta (description + unit_display) once on
// load and hydrate every `[data-rt-knob]` element's title= attribute
// so the operator gets a native browser tooltip on hover. Single
// fetch; result is cached in module scope for any future re-render.
let _runtimeKnobsMeta = null;
async function hydrateRuntimeKnobTooltips() {
  if (_runtimeKnobsMeta !== null) return;
  try {
    const r = await fetch("/api/runtime-knobs-meta");
    if (!r.ok) return;
    _runtimeKnobsMeta = await r.json();
  } catch {
    return;
  }
  document.querySelectorAll("[data-rt-knob]").forEach((el) => {
    const knob = el.getAttribute("data-rt-knob");
    const meta = _runtimeKnobsMeta && _runtimeKnobsMeta[knob];
    if (meta && meta.description) {
      el.setAttribute("title", meta.description);
    }
  });
}
hydrateRuntimeKnobTooltips();

function closeConfigModal() {
  const m = document.getElementById("config-modal");
  if (m) m.hidden = true;
}

function syncTcpProxyToggleUI(enabled, port) {
  const pill = document.getElementById("tcp-proxy-toggle");
  const lbl = document.getElementById("tcp-proxy-state-label");
  const det = document.getElementById("tcp-proxy-detail");
  if (!pill) return;
  pill.classList.toggle("on", enabled);
  pill.dataset.enabled = enabled ? "1" : "0";
  if (lbl) lbl.textContent = enabled ? "on" : "off";
  const host = document.getElementById("hostname")?.textContent?.trim() || "this-pi";
  if (det) {
    if (enabled) {
      det.textContent = `MeshCore client can connect to ${host}:${port}`;
    } else {
      det.textContent = "bridge owns the USB port";
    }
  }
  // Reveal the OS-specific MeshCore-client links + populate the host:port
  // hint when passthrough is ON, hide them when OFF. Keeps the modal
  // calm in the common "TCP off" path while making the connect-from-
  // your-phone workflow self-explanatory on first use.
  const clients = document.getElementById("tcp-proxy-clients");
  if (clients) {
    clients.hidden = !enabled;
    const hostCode = document.getElementById("tcp-proxy-clients-host");
    const portCode = document.getElementById("tcp-proxy-clients-port");
    if (hostCode) hostCode.textContent = host;
    if (portCode) portCode.textContent = String(port);
  }
}

document.getElementById("open-config-btn")?.addEventListener("click", openConfigModal);

// Click-outside / × button / Esc all close the config modal — matches
// the broker-modal behaviour so the operator has consistent UX.
document.addEventListener("click", (e) => {
  const t = e.target;
  if (!(t instanceof Element)) return;
  if (t.closest("[data-close-config]")) {
    e.preventDefault();
    closeConfigModal();
    return;
  }
  if (t.id === "config-modal") closeConfigModal();
});
document.addEventListener("keydown", (e) => {
  if ((e.key === "Escape" || e.key === "Esc")) {
    const m = document.getElementById("config-modal");
    if (m && !m.hidden) closeConfigModal();
  }
});

// Toggle pill flips state immediately + persists via the existing
// /tcp-proxy endpoint. Reuses the .toggle-pill style the brokers
// table uses (visual parity = operator pattern recognition).
async function _toggleTcpProxy() {
  const dev = selectedDevice();
  if (!dev) return;
  const pill = document.getElementById("tcp-proxy-toggle");
  const turningOn = pill?.dataset.enabled !== "1";
  const port = Number(document.getElementById("tcp-proxy-port")?.value) || 5000;
  pill?.classList.add("pending");
  try {
    const r = await fetch(
      `/api/devices/${encodeURIComponent(dev.slug)}/tcp-proxy`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled: turningOn, port }),
      },
    );
    if (r.ok) {
      const body = await r.json();
      const liveEnabled = body.enabled !== undefined ? body.enabled : turningOn;
      const livePort = body.port || port;
      syncTcpProxyToggleUI(liveEnabled, livePort);
      toast(turningOn ? `TCP proxy started on :${livePort}` : "TCP proxy stopped",
            "success");
      await loadDevices();
    } else {
      const err = await r.text();
      toast("TCP proxy toggle failed: " + err, "error");
    }
  } finally {
    pill?.classList.remove("pending");
  }
}

document.getElementById("tcp-proxy-toggle")?.addEventListener("click", _toggleTcpProxy);
document.getElementById("tcp-proxy-toggle")?.addEventListener("keydown", (e) => {
  if (e.key === " " || e.key === "Enter") {
    e.preventDefault();
    _toggleTcpProxy();
  }
});

document.getElementById("config-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const dev = selectedDevice();
  if (!dev) { toast("Select a device first", "error"); return; }
  const fd = new FormData(e.target);
  // Trim every field; blank strings drop out (treat as "unchanged")
  // so the operator can clear a value by deleting + saving but a
  // plain empty save isn't a destructive null-write storm.
  const payload = {};
  for (const [k, v] of fd.entries()) {
    if (k === "tcp_proxy_port") continue;  // handled by the toggle endpoint
    const s = (v || "").toString().trim();
    if (s) payload[k] = s;
  }
  const submit = document.getElementById("config-submit");
  if (submit) submit.disabled = true;
  try {
    const r = await fetch(
      `/api/devices/${encodeURIComponent(dev.slug)}/config`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      },
    );
    if (r.ok) {
      toast("Gateway config saved", "success");
      closeConfigModal();
      await loadDevices();
    } else {
      const err = await r.json().catch(() => ({}));
      toast("Save failed: " + (err.detail || r.status), "error");
    }
  } finally {
    if (submit) submit.disabled = false;
  }
});

// ── Health cards ───────────────────────────────────────────────────

// Idempotent card update: only touch the DOM when something actually
// changed. The health cards re-poll every 5 s; the old version rewrote
// textContent + did remove(all)/add(kind) on EVERY poll, which (because
// .health-card has `transition: border-color`) stripped the colour class
// for a frame and flashed the border/value back in — the visible flicker
// on a steady GPS reading. Guarding each write means a stable value
// produces zero mutations and zero repaint.
function applyKind(card, kind) {
  if (card.classList.contains(kind)) return; // already correct → no churn
  card.classList.remove("good", "warn", "bad", "unknown");
  card.classList.add(kind);
}

// Live matcher (not a one-shot boolean) so toggling the OS setting takes
// effect without a reload.
const REDUCED_MOTION = window.matchMedia("(prefers-reduced-motion: reduce)");

// Brief, intentional highlight when a card's VALUE actually changes — the
// counterpart to the idempotent writes: nothing moves on a steady reading,
// but a real new fix / sat count gives a quick left-accent + fade so the
// operator notices. WAAPI (no class bookkeeping); skipped under reduced-motion.
function pulseCard(card) {
  if (REDUCED_MOTION.matches || typeof card.animate !== "function") return;
  card.animate(
    [
      { boxShadow: "inset 3px 0 0 var(--accent-bright, #7c9aff)", background: "rgba(76,154,255,0.10)" },
      { boxShadow: "inset 3px 0 0 transparent", background: "transparent" },
    ],
    { duration: 450, easing: "ease-out" },
  );
}

// True when the slot still shows a placeholder (first paint), so we don't
// pulse the whole grid once on initial population.
function isPlaceholder(text) {
  return text === "" || text === "…" || text === "—";
}

function setCard(name, value, detail, kind) {
  const card = document.querySelector(`[data-card="${name}"]`);
  if (!card) return;
  const v = card.querySelector(".hc-value");
  const d = card.querySelector(".hc-detail");
  const sv = String(value);
  const valueChanged = v.textContent !== sv;
  const wasPlaceholder = isPlaceholder(v.textContent);
  if (valueChanged) v.textContent = sv;
  // detail === false → another writer owns this card's .hc-detail (the
  // GPS-fix card's rich history line is rewritten below). Don't touch it
  // here, or the two writers churn the DOM every poll → flicker.
  if (detail !== false) {
    const sd = detail || "";
    if (d.textContent !== sd) d.textContent = sd;
  }
  applyKind(card, kind);
  if (valueChanged && !wasPlaceholder) pulseCard(card);
}

// HTML-detail variant for cards that need richer layout than a single
// line of mono text (Bootstrap ACK + GNSS-enabled both want a per-bit
// ✓/✗ list so the operator can see which constellation/command is
// actually applied without decoding a hex byte in their head). Callers
// pass a trusted HTML fragment — no user input flows here.
function setCardHTML(name, value, detailHTML, kind) {
  const card = document.querySelector(`[data-card="${name}"]`);
  if (!card) return;
  const v = card.querySelector(".hc-value");
  const d = card.querySelector(".hc-detail");
  const sv = String(value);
  const sh = detailHTML || "";
  const valueChanged = v.textContent !== sv;
  const wasPlaceholder = isPlaceholder(v.textContent);
  if (valueChanged) v.textContent = sv;
  // Guard the innerHTML write too — re-parsing identical markup every 5 s
  // rebuilds the per-bit ✓/✗ list nodes and repaints for no reason.
  if (d.innerHTML !== sh) d.innerHTML = sh;
  applyKind(card, kind);
  if (valueChanged && !wasPlaceholder) pulseCard(card);
}

// Build the per-bit ✓/✗ list shown in the detail slot of the Bootstrap
// ACK + GNSS-enabled cards. Accepts both shapes:
//   * 2-tuple [bit, label]              — simple enable/disable list
//   * 3-tuple [bit, label, human_result] — bootstrap commands where
//     we want to say WHAT got applied (e.g. "GNSS selection: GPS +
//     GLONASS + BeiDou") instead of just "command ACKed".
// ``mask`` is the runtime value from the chip. Returns trusted HTML;
// safe because every label/result is a build-time constant.
function renderBitListHTML(bits, mask) {
  const rows = bits.map((entry) => {
    const bit = entry[0];
    const label = entry[1];
    const result = entry[2];  // undefined for 2-tuple inputs
    const on = (mask & bit) !== 0;
    const suffix = result
      ? `<span class="bit-result">${result}</span>`
      : "";
    return `
      <li class="${on ? "on" : "off"}">
        <span class="${on ? "bit-on" : "bit-off"}">${on ? "✓" : "✗"}</span>
        <span class="bit-label">${label}</span>
        ${suffix}
      </li>`;
  }).join("");
  const hex = `0x${mask.toString(16).padStart(2, "0")}`;
  return `<ul class="bit-list">${rows}</ul><span class="bit-hex">mask: ${hex}</span>`;
}

// GPS chip / bootstrap-ACK decoders. These mirror the bridge-side maps
// in mqtt_publisher.py + portal.py — kept duplicated rather than fetched
// from the server because they're tiny constant lookups and the page
// renders the chip card before the first API call settles.
const GPS_FAMILY_NAMES = {0: "unknown", 1: "u-blox", 2: "L76K"};

// All constellation bits the wire format can carry. The per-family
// supported-set below picks the subset the chip actually implements
// so the GNSS-enabled card doesn't render ✗ rows for constellations
// the operator can't toggle anyway (e.g. L76K has no Galileo silicon).
const GNSS_BITS = [
  [1 << 0, "GPS"],
  [1 << 1, "GLONASS"],
  [1 << 2, "Galileo"],
  [1 << 3, "BeiDou"],
  [1 << 4, "QZSS"],
  [1 << 5, "SBAS"],
];

// Per-family supported-constellation filter. Sources noted inline so
// future-me knows whether the silicon really lacks support or just
// the firmware doesn't expose it. See
// reference_gps_modules_per_board.md memory for the chip survey.
//   L76K  — Quectel datasheet: GPS + GLONASS + BeiDou, 3 concurrent.
//           No Galileo silicon. No QZSS. SBAS not supported.
//   u-blox ZOE-M8Q — M8 module, GPS + Galileo + BeiDou + QZSS + SBAS
//           (no GLONASS at concurrent rate — 3 system max).
// When the chip family is unknown (legacy firmware without probe data)
// we render the full bit list so the operator still sees what's set.
const SUPPORTED_GNSS_BY_FAMILY = {
  // L76K
  2: new Set(["GPS", "GLONASS", "BeiDou"]),
  // u-blox
  1: new Set(["GPS", "Galileo", "BeiDou", "QZSS", "SBAS"]),
};

// Per-bit bootstrap entries: [bitmask, short_label, human_result].
// ``short_label`` names the wire command (operator sees this when
// debugging). ``human_result`` describes what the chip actually got
// configured to do once the command succeeded — answers "what got
// applied" not just "did a command succeed". For L76K every command
// applies a single concrete behaviour; for u-blox the GNSS-CFG one
// is the variable one (the others are toggle/save).
const BOOTSTRAP_BITS_BY_FAMILY = {
  // L76K (Quectel PCAS) — bit position == bootstrap step in the firmware.
  2: [
    [1 << 0, "GNSS selection",   "GPS + GLONASS + BeiDou"],
    [1 << 1, "Update rate",      "1 Hz fix output"],
    [1 << 2, "Static navigation","threshold 0.4 m/s"],
    [1 << 3, "Save config",      "written to chip flash"],
  ],
  // u-blox (UBX-CFG-* binary)
  1: [
    [1 << 0, "Dynamic model",   "Stationary (low-noise)"],
    [1 << 1, "SBAS",            "WAAS / EGNOS enabled"],
    [1 << 2, "GNSS selection",  "GPS + Galileo + BeiDou"],
    [1 << 3, "Save config",     "written to BBR + Flash"],
  ],
};

function decodeGnssMask(mask) {
  if (mask == null) return "";
  const labels = GNSS_BITS
    .filter(([bit, _]) => (mask & bit) !== 0)
    .map(([_, label]) => label);
  return labels.length ? labels.join("+") : "(none)";
}

function decodeBootstrapAck(family, ack) {
  if (ack == null) return "";
  const bits = BOOTSTRAP_BITS_BY_FAMILY[family];
  if (!bits) return `0x${ack.toString(16).padStart(2, "0")}`;
  const labels = bits
    .filter(([bit]) => (ack & bit) !== 0)
    .map((row) => row[1]);
  return labels.length ? labels.join(" · ") : "(none ACKed)";
}

// Reduce the GNSS-bit list to just the constellations the chip family
// actually implements. Without this, an L76K renders a ✗-Galileo row
// the operator can't turn on no matter what — confusing noise. Unknown
// families fall through to the full list so we don't hide info we
// can't reason about.
function gnssBitsForFamily(family) {
  const supported = SUPPORTED_GNSS_BY_FAMILY[family];
  if (!supported) return GNSS_BITS;
  return GNSS_BITS.filter(([, label]) => supported.has(label));
}

// Staleness: a frozen last-known value must not masquerade as live. When a
// health fetch fails we dim the cards + show "stale Ns" rather than leaving
// the previous reading looking fresh. Tracked across polls; we only toast on
// the transition into staleness (not every 5 s) so a down bridge isn't noisy.
let lastHealthOkAt = 0;
let healthStale = false;
function setHealthStale(stale) {
  const hint = document.getElementById("health-hint");
  if (stale) {
    document.querySelectorAll(".health-grid").forEach((g) => g.classList.add("stale"));
    const ago = lastHealthOkAt ? Math.round((Date.now() - lastHealthOkAt) / 1000) : null;
    if (hint) hint.textContent = ago != null ? `stale — last good ${ago}s ago` : "stale — no data yet";
    if (!healthStale) toast("Health fetch failed — showing last-known (stale)", "error", 4000);
    healthStale = true;
  } else {
    document.querySelectorAll(".health-grid").forEach((g) => g.classList.remove("stale"));
    lastHealthOkAt = Date.now();
    healthStale = false;
  }
}

async function loadHealth() {
  if (!SELECTED_SLUG) return;
  try {
    const h = await fetch(
      `/api/devices/${encodeURIComponent(SELECTED_SLUG)}/health`,
    ).then((r) => r.json());
    setHealthStale(false);
    if (h.gps_fix === null || h.gps_fix === undefined) {
      setCard("gps_fix", "—", "no data yet", "unknown");
      setCard("sat_count", "—", "no data yet", "unknown");
      setCard("pps_locked", "—", "no data yet", "unknown");
      setCard("drift", "—", "no data yet", "unknown");
      setCard("gps_chip", "—", "no probe yet", "unknown");
      setCard("gps_chip_sw", "—", "no probe yet", "unknown");
      setCard("gps_bootstrap", "—", "no probe yet", "unknown");
      setCard("gps_gnss", "—", "no probe yet", "unknown");
      return;
    }
    // detail=false: the gps-history block below owns this card's detail
    // line (last fix / lost / reacq). Passing a string here would write
    // textContent that the history innerHTML immediately overwrites — the
    // double-write that flickered the GPS-fix card every poll.
    setCard("gps_fix",
      h.gps_fix ? h.gps_fix_kind : "no fix",
      false,
      h.gps_fix ? "good" : "bad");
    setCard("sat_count",
      h.sat_count != null ? `${h.sat_count}` : "—",
      h.sat_count != null
        ? `min ${h.sat_min_for_fix} for 3D fix · used in fix`
        : "",
      h.sat_count == null ? "unknown"
        : h.sat_count >= h.sat_min_for_fix ? "good"
          : h.sat_count > 0 ? "warn" : "bad");
    setCard("pps_locked",
      h.pps_locked ? "Locked" : "No lock",
      h.pps_locked ? "PPS edges arriving 1 Hz" : "no PPS edge in window",
      h.pps_locked ? "good" : "bad");
    if (h.drift_ppm != null) {
      const sign = h.drift_ppm > 0 ? "+" : "";
      setCard("drift",
        `${sign}${h.drift_ppm.toFixed(1)} ppm`,
        h.drift_valid
          ? `within ±${h.drift_limit_ppm} ppm spec`
          : `EXCEEDS ±${h.drift_limit_ppm} ppm`,
        h.drift_valid ? "good" : "bad");
    } else {
      setCard("drift", "—", "no PPS samples yet", "unknown");
    }
    // GPS chip identity (boot-time GpsChipProbe → 0x94 GATEWAY_INFO tail).
    // These four cards are populated lazily — they stay blank until the
    // first 0x94 lands (next bridge heartbeat after a flash, ~30s). On
    // legacy firmware that ships the 104/112-byte 0x94 with no chip
    // tail, the bridge passes through nulls and we render "—" so the
    // operator knows the chip wasn't probed (rather than "no chip").
    if (h.gps_chip_family != null) {
      const familyName = h.gps_chip_family_name
        || GPS_FAMILY_NAMES[h.gps_chip_family]
        || "unknown";
      setCard("gps_chip",
        familyName,
        h.gps_chip_model
          ? `model: ${h.gps_chip_model} · HW confirmed`
          : "family detected · no model string",
        h.gps_chip_family > 0 ? "good" : "unknown");
    } else {
      setCard("gps_chip",
        "— (no probe)",
        "firmware predates GpsChipProbe (147-byte 0x94)",
        "unknown");
    }
    if (h.gps_chip_sw_version) {
      setCard("gps_chip_sw",
        h.gps_chip_sw_version,
        h.gps_chip_model ? `as reported by ${h.gps_chip_model}` : "",
        "good");
    } else {
      setCard("gps_chip_sw", "—", "no probe data", "unknown");
    }
    if (h.gps_bootstrap_ack != null) {
      // Render each bootstrap command on its own ✓/✗ row so the operator
      // can read what's actually applied without decoding a hex byte.
      // "All four bits ACKed" = full configure-success; anything less
      // shows up as missing rows AND a warn-tinted border.
      const ack = h.gps_bootstrap_ack;
      const bits = BOOTSTRAP_BITS_BY_FAMILY[h.gps_chip_family] || [];
      const allAcked = ack === 0x0F;
      const headline = allAcked
        ? "All applied"
        : `${bits.filter(([b]) => (ack & b) !== 0).length} / ${bits.length} applied`;
      const detailHTML = bits.length
        ? renderBitListHTML(bits, ack)
        : `<span>0x${ack.toString(16).padStart(2, "0")} (no decode table for family)</span>`;
      setCardHTML("gps_bootstrap", headline, detailHTML,
        allAcked ? "good" : (ack > 0 ? "warn" : "bad"));
    } else {
      setCard("gps_bootstrap", "—", "no probe data", "unknown");
    }
    if (h.gps_enabled_gnss_mask != null) {
      // GNSS-enabled: render only the constellations this chip family
      // actually implements (L76K has no Galileo silicon — showing
      // ✗-Galileo would suggest the operator could toggle it). The
      // mask's high sentinel bit (0x80) is the "chip responded" flag
      // — never rendered as a row; visible in the mask-summary line.
      const mask = h.gps_enabled_gnss_mask;
      const bits = gnssBitsForFamily(h.gps_chip_family);
      const enabled = bits.filter(([bit]) => (mask & bit) !== 0)
        .map(([, label]) => label);
      const headline = enabled.length
        ? `${enabled.length} / ${bits.length} enabled`
        : "(none)";
      setCardHTML("gps_gnss", headline,
        renderBitListHTML(bits, mask),
        mask > 0 ? "good" : "warn");
    } else {
      setCard("gps_gnss", "—", "no probe data", "unknown");
    }

    // FW summary cards (mirrors GPS chip cards — populated from the same
    // bridge per-port snapshot so we don't need a second API call).
    setCard("fw_version",
      h.fw_version || "—",
      h.tdoa_fw_version && h.tdoa_fw_version !== h.fw_version
        ? `TDOA build: ${h.tdoa_fw_version}` : "",
      h.fw_version ? "good" : "unknown");
    setCard("fw_board",
      h.board_name || "—",
      "",
      h.board_name ? "good" : "unknown");
    if (h.mcu_chip || h.lora_chip) {
      setCard("fw_chips",
        `${h.mcu_chip || "?"} / ${h.lora_chip || "?"}`,
        "",
        "good");
    } else {
      setCard("fw_chips", "—", "", "unknown");
    }
    const caps = [];
    if (h.has_gps) caps.push("GPS");
    if (h.has_pps) caps.push("PPS");
    if (h.is_tdoa_rx) caps.push("TDOA RX");
    setCard("fw_caps",
      caps.length ? caps.join(" + ") : "—",
      "",
      caps.length ? "good" : "unknown");

    $("#health-hint").textContent = h.mock
      ? "mock data (test LXC) · 5 s refresh"
      : "live · 5 s refresh";

    // Augment the GPS fix card with sampler-driven history
    // (last_fix / last_lost / last_reacquired / 24h-loss-count).
    // Uses innerHTML on .hc-detail so setCard's textContent line
    // gets replaced by a richer 4-field line; tooltip keeps the
    // formatted version for hover.
    try {
      const g = await fetch(
        `/api/devices/${encodeURIComponent(SELECTED_SLUG)}/gps-history`,
      ).then((r) => r.json());
      const card = document.querySelector('[data-card="gps_fix"]');
      if (card) {
        const fmt = (ts) =>
          ts ? new Date(ts * 1000).toLocaleString() : "—";
        const lastFix = fmt(g.last_fix_at);
        const lastLost = fmt(g.last_lost_at);
        const lastReacq = fmt(g.last_reacquired_at);
        const losses = g.losses_24h ?? 0;
        const detail = card.querySelector(".hc-detail");
        if (detail) {
          // Guard both writes: these are absolute timestamps, so on a
          // steady fix the strings are identical poll-to-poll — rewriting
          // innerHTML anyway re-parses the node and repaints (the flicker).
          const html =
            `last fix: ${esc(lastFix)}` +
            ` · lost: ${esc(lastLost)}` +
            ` · reacq: ${esc(lastReacq)}` +
            ` · 24h-lost: ${losses}`;
          const title =
            `Last 3D-fix:        ${lastFix}\n` +
            `Last fix-lost:      ${lastLost}\n` +
            `Last reacquired:    ${lastReacq}\n` +
            `Fix-loss events 24h: ${losses}\n` +
            `Source: portal sampler (1-min poll).`;
          if (detail.innerHTML !== html) detail.innerHTML = html;
          if (detail.title !== title) detail.title = title;
        }
      }
    } catch (_) { /* gps-history is best-effort */ }
  } catch (_e) {
    // Don't leave the last reading looking live — dim + show staleness.
    // setHealthStale handles the one-shot toast so a down bridge isn't noisy.
    setHealthStale(true);
  }
}

// ── Broker types pulldown ──────────────────────────────────────────

async function loadBrokerTypes() {
  BROKER_TYPES = await fetch("/api/broker-types").then((r) => r.json());
  const sel = $("#broker-type-select");
  sel.innerHTML = "";
  Object.entries(BROKER_TYPES).forEach(([k, v]) => {
    const opt = document.createElement("option");
    opt.value = k;
    opt.textContent = v.label;
    sel.appendChild(opt);
  });
  sel.addEventListener("change", () => {
    renderDynamicFields(sel.value);
    syncEnabledCheckboxToType(sel.value);
  });
  renderDynamicFields(sel.value);
  syncEnabledCheckboxToType(sel.value);
}

// New-broker default-enabled policy: TDOA-protocol presets default ON,
// everything else (on8ar, letsmesh, generic templates)
// defaults OFF. The operator can still toggle before submit; the
// backend uses the same rule when payload.enabled is omitted.
// Only runs while the modal is in "add" mode — edit mode pre-loads the
// existing broker's enabled state and shouldn't be clobbered.
function syncEnabledCheckboxToType(typeKey) {
  if (MODAL_MODE && MODAL_MODE.edit) return;
  const t = BROKER_TYPES[typeKey];
  const cb = document.querySelector('#broker-form [name="_enabled"]');
  if (!cb || !t) return;
  cb.checked = (t.protocol || "").toLowerCase() === "tdoa";
}

function renderDynamicFields(typeKey) {
  const container = $("#dynamic-fields");
  container.innerHTML = "";
  const t = BROKER_TYPES[typeKey];
  if (!t || !t.user_fields) return;
  t.user_fields.forEach(([path, label, kind, required]) => {
    const wrap = document.createElement("label");
    wrap.textContent = label + (required ? " *" : "");
    const input = document.createElement("input");
    input.type = kind || "text";
    input.name = path;
    if (required) input.required = true;
    if (kind === "number") input.inputMode = "numeric";
    wrap.appendChild(input);
    container.appendChild(wrap);
  });

  // 2026-05-25: pre-defined projects (meshcore-tdoa, home-prod-wss,
  // on8ar, letsmesh-us) carry a baked-in `protocol`; the
  // backend resolves it from BROKER_TYPES without operator input.
  // Generic templates (tcp-userpass, wss-noauth, etc.) have
  // `protocol: null` and MUST present a dropdown for the operator to
  // pick "tdoa" or "mctomqtt". Hidden field carries the baked value
  // through so the submit handler can read `_protocol` uniformly.
  const protocolWrap = document.createElement("label");
  if (t.protocol) {
    protocolWrap.style.opacity = "0.7";
    protocolWrap.textContent = `Protocol (pre-set: ${t.protocol})`;
    const hidden = document.createElement("input");
    hidden.type = "hidden";
    hidden.name = "_protocol";
    hidden.value = t.protocol;
    protocolWrap.appendChild(hidden);
  } else {
    protocolWrap.textContent = "Wire protocol *";
    const sel = document.createElement("select");
    sel.name = "_protocol";
    sel.required = true;
    const blank = document.createElement("option");
    blank.value = "";
    blank.textContent = "— choose —";
    blank.disabled = true;
    blank.selected = true;
    sel.appendChild(blank);
    [["tdoa", "★ tdoa (our TDOA envelope)"],
     ["mctomqtt", "meshcoretomqtt (on8ar / letsmesh / public)"]
    ].forEach(([v, label]) => {
      const opt = document.createElement("option");
      opt.value = v;
      opt.textContent = label;
      sel.appendChild(opt);
    });
    protocolWrap.appendChild(sel);
  }
  container.appendChild(protocolWrap);
}

// ── Brokers table ──────────────────────────────────────────────────

async function loadBrokers() {
  if (!SELECTED_SLUG) {
    $("#brokers-tbody").innerHTML =
      '<tr><td colspan="8" class="empty">Select a device above.</td></tr>';
    return;
  }
  try {
    const brokers = await fetch(
      `/api/devices/${encodeURIComponent(SELECTED_SLUG)}/brokers`,
    ).then((r) => r.json());
    const tb = $("#brokers-tbody");
    tb.innerHTML = "";
    if (!brokers.length) {
      tb.innerHTML =
        '<tr><td colspan="8" class="empty">No brokers configured for this device. Click "+ Add broker".</td></tr>';
      return;
    }
    brokers.forEach((b) => tb.appendChild(brokerRow(b)));
    // 2026-05-26: fetch sampler-backed 24h history and paint sparklines
    // into the 24h-exported column. Fire-and-forget so a slow sampler
    // file doesn't block the broker table from rendering.
    fetch("/api/broker-history?hours=24&bucket_minutes=60")
      .then((r) => r.json())
      .then((hist) => {
        const buckets = hist?.brokers || {};
        document.querySelectorAll(".broker-export-24h").forEach((el) => {
          // 2026-05-29 0.3.52: skip rows where this DEVICE has the broker
          // disabled. The history endpoint is keyed by broker NAME
          // globally (sampler aggregates across all Pis), so a disabled
          // letsmesh-us row on D_Creek would otherwise inherit FeedCafe's
          // sparkline + total — the operator sees "23 exports" on a row
          // they explicitly turned off. The dashed placeholder rendered
          // by brokerRow() stays put.
          if (el.dataset.enabled !== "1") return;
          const name = el.dataset.broker;
          const series = buckets[name] || [];
          const total = series.reduce((a, b) => a + (b.ok || 0), 0);
          const peak = Math.max(1, ...series.map((s) => s.ok || 0));
          const bars = series
            .map((s) => {
              const h = Math.max(1, Math.round(((s.ok || 0) / peak) * 16));
              return `<span class="spark-bar" style="height:${h}px" title="${new Date(s.ts * 1000).toLocaleTimeString()}: ${s.ok}"></span>`;
            })
            .join("");
          el.innerHTML = `<span class="spark">${bars}</span><span class="spark-total">${total}</span>`;
        });
      })
      .catch(() => { /* sampler may not have run yet; leave the … placeholder */ });
  } catch (e) {
    toast("Brokers fetch failed: " + e, "error");
  }
}

// Render the per-broker live status as a coloured emoji pill.
//
// The meshcore-tdoa broker is owned by the bridge process, not the
// mesh-relay sidecar. The portal API populates its status from
// `systemctl is-active meshcore-tdoa-gateway-bridge` so this row
// gets a real green/red pill instead of a transparent placeholder
// (which read as "missing" — operator reported 2026-05-20).
function statusPill(b) {
  if (!b.enabled) {
    return '<span class="status-pill disabled" title="Disabled in config — relay skips it">⚪ disabled</span>';
  }
  const s = b.status;
  if (!s) {
    return '<span class="status-pill unknown" title="meshcore-mesh-relay isn\'t running OR this broker name isn\'t in its snapshot">? unknown</span>';
  }
  // TDOA broker: bridge-proxied status. Render "🟢 bridge" / "🔴 bridge"
  // so the operator immediately sees both the connection state AND that
  // this row's signal comes from the bridge, not the relay's publish
  // counters (publish_ok/fail are always 0 for this row).
  if (b.type === "meshcore-tdoa") {
    if (s.connected) {
      return '<span class="status-pill ok" title="Bridge service is active — assumed connected to the TDOA broker (relay deliberately skips this broker)">🟢 bridge</span>';
    }
    const err = s.last_error ? ` (${esc(s.last_error)})` : "";
    return `<span class="status-pill bad" title="Bridge unit is not active${err}">🔴 bridge</span>`;
  }
  if (!s.connected) {
    const err = s.last_error ? ` (${s.last_error})` : "";
    return `<span class="status-pill bad" title="Socket down or auth failed${esc(err)}">🔴 down</span>`;
  }
  const now = Date.now() / 1000;
  const idleSeconds = s.last_publish_ok_at ? now - s.last_publish_ok_at : 1e9;
  if (s.publish_ok === 0 || idleSeconds > 300) {
    return `<span class="status-pill idle" title="Connected, last publish ${s.last_publish_ok_at ? Math.round(idleSeconds) + 's ago' : 'never'} (ok=${s.publish_ok} fail=${s.publish_fail})">🟡 idle</span>`;
  }
  return `<span class="status-pill ok" title="ok=${s.publish_ok} fail=${s.publish_fail} last ${Math.round(idleSeconds)}s ago">🟢 ok</span>`;
}

function brokerRow(b) {
  const tr = document.createElement("tr");
  // 2026-05-26 operator directive: star + green-styling apply to ANY
  // broker with protocol=tdoa, not just the one literally named
  // meshcore-tdoa. So home-prod-wss (mqtt.dahllie.nl) shows with the
  // star too, since it carries our TDOA envelope. The retired
  // tdoa-server / TransIP-VPS preset is gone from the registry.
  const protocol = b.protocol || "mctomqtt";
  const isTdoa = protocol === "tdoa";
  // 2026-05-29 0.3.53: strip the trailing parenthetical from the type
  // label ("(WSS + TLS, TDOA format)", "(TCP, mctomqtt format)",
  // "(WSS + token)") — Protocol, Server, and Auth columns each show
  // those facts in their own cells, so repeating them in Type makes the
  // column wider than it needs to be AND duplicates info the operator
  // is already reading row-wise.
  const typeLabel = (BROKER_TYPES[b.type]?.label || b.type)
    .replace(/^★\s*/, "")
    .replace(/\s*\([^()]*\)\s*$/, "");
  // 2026-05-29 0.3.54: Protocol moved out of its own column into the
  // Type cell as a "type / protocol" combo, and the inline <select> is
  // gone — protocol is now edited via the row's edit modal. The main
  // table was too wide to fit inside the section frame; protocol
  // changes are a low-frequency action so the modal is a better home.
  const protoLabel = isTdoa ? "★ tdoa" : "mctomqtt";
  tr.innerHTML = `
    <td data-label="Name"><span class="broker-name">${esc(b.name)}</span></td>
    <td data-label="Type / Protocol"><span class="broker-type-badge ${isTdoa ? "tdoa" : b.type === "unknown" ? "unknown" : ""}">${esc(typeLabel)}</span> <span class="broker-protocol-inline">${protoLabel}</span></td>
    <td data-label="Server"><span class="broker-server">${esc(b.server || "—")}${b.port ? ":" + b.port : ""}</span></td>
    <td data-label="Auth"><span class="broker-server">${esc(b.auth_method || "—")}</span></td>
    <td data-label="Status">${statusPill(b)}</td>
    <td data-label="24h exported"><span class="broker-export-24h" data-broker="${esc(b.name)}" data-enabled="${b.enabled ? "1" : "0"}" title="${b.enabled ? "exported packets per hour, last 24h (sampler-driven)" : "broker disabled — stats from sibling devices with the same broker name suppressed"}">${b.enabled ? "…" : '<span class="spark-disabled">—</span>'}</span></td>
    <td data-label="Enabled"><div class="toggle-pill ${b.enabled ? "on" : ""}" data-name="${esc(b.name)}" role="button" aria-label="toggle"></div></td>
    <td class="actions">
      <div class="row-actions">
        <button type="button" class="icon-btn" data-edit="${esc(b.name)}" title="Edit broker fields">edit</button>
        <button type="button" class="icon-btn danger" data-delete="${esc(b.name)}">delete</button>
      </div>
    </td>
  `;
  tr.querySelector("[data-edit]").addEventListener("click", () => {
    openEditModal(b);
  });
  tr.querySelector(".toggle-pill").addEventListener("click", async (e) => {
    const name = e.currentTarget.dataset.name;
    await fetch(
      `/api/devices/${encodeURIComponent(SELECTED_SLUG)}/brokers/${encodeURIComponent(name)}/toggle`,
      { method: "POST" },
    );
    loadBrokers();
  });
  // (.protocol-select moved into the edit modal in 0.3.54; no inline
  // handler needed in the row.)
  tr.querySelector("[data-delete]").addEventListener("click", async (e) => {
    const name = e.currentTarget.dataset.delete;
    if (!confirm(`Delete broker "${name}" from ${SELECTED_SLUG}?`)) return;
    const r = await fetch(
      `/api/devices/${encodeURIComponent(SELECTED_SLUG)}/brokers/${encodeURIComponent(name)}`,
      { method: "DELETE" },
    );
    if (r.ok) {
      toast(`Deleted "${name}"`, "success");
      loadBrokers();
    } else toast("Delete failed", "error");
  });
  return tr;
}

function esc(s) {
  if (s == null) return "";
  return String(s).replace(
    /[&<>"']/g,
    (c) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;",
      })[c],
  );
}

// ── Modal ──────────────────────────────────────────────────────────

// Mode is either "create" (POST /brokers) or {edit: "<original-name>"}
// (PUT /brokers/<name>). Stashed on the modal element so the submit
// handler can pick the right verb + URL.
let MODAL_MODE = "create";

function openModal() {
  if (!SELECTED_SLUG) {
    toast("Select a device first", "error");
    return;
  }
  MODAL_MODE = "create";
  $("#modal-title").textContent = `Add MQTT broker · ${SELECTED_SLUG}`;
  $("#modal-submit").textContent = "Add broker";
  $("#broker-modal").hidden = false;
  $("#broker-form").reset();
  $("#broker-type-select").disabled = false;
  // raw-override textarea is edit-only.
  const rawWrap = document.getElementById("raw-override-wrap");
  if (rawWrap) rawWrap.hidden = true;
  renderDynamicFields($("#broker-type-select").value);
}

// Open the modal pre-populated with an existing broker's fields.
function openEditModal(b) {
  if (!SELECTED_SLUG) return;
  MODAL_MODE = { edit: b.name };
  $("#modal-title").textContent = `Edit broker "${b.name}" · ${SELECTED_SLUG}`;
  $("#modal-submit").textContent = "Save changes";
  $("#broker-modal").hidden = false;
  $("#broker-form").reset();
  // Type is auto-classified server-side from server/auth/transport,
  // so we render the dynamic fields based on the CURRENT b.type and
  // disable the type-select itself (changing type would require
  // recreating the broker — out of scope for a quick edit).
  const typeSel = $("#broker-type-select");
  typeSel.value = b.type;
  typeSel.disabled = true;
  renderDynamicFields(b.type);
  // Pre-fill _name and _enabled.
  $("#broker-form").querySelector('[name="_name"]').value = b.name;
  $("#broker-form").querySelector('[name="_enabled"]').checked = b.enabled !== false;
  // 2026-05-29 0.3.54: Protocol selector lives in the modal now.
  // Pre-fill from the broker's current protocol; on change, PUT to
  // /protocol so the operator doesn't have to Save the whole modal
  // for a one-field protocol flip.
  const protoRow = document.getElementById("protocol-edit-row");
  const protoSel = document.getElementById("broker-protocol-select");
  if (protoRow && protoSel) {
    protoRow.hidden = false;
    protoSel.value = (b.protocol || "mctomqtt");
    protoSel.onchange = async () => {
      const r = await fetch(
        `/api/devices/${encodeURIComponent(SELECTED_SLUG)}/brokers/${encodeURIComponent(b.name)}/protocol`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ protocol: protoSel.value }),
        },
      );
      if (r.ok) {
        toast(`Protocol set to ${protoSel.value}`, "success");
      } else {
        toast("Protocol change failed", "error");
      }
    };
  }
  // Pre-fill each dynamic field from b.raw via dotted lookup.
  document.querySelectorAll('#dynamic-fields [name]').forEach((inp) => {
    const path = inp.name.split(".");
    let v = b.raw;
    for (const p of path) {
      if (v && typeof v === "object" && p in v) v = v[p];
      else { v = ""; break; }
    }
    if (v !== "" && v !== undefined && v !== null) {
      if (inp.type === "checkbox") inp.checked = Boolean(v);
      else inp.value = String(v);
    }
  });
  // Reveal the "override anything" raw-JSON textarea pre-populated
  // with the broker's current block (minus auto-derived name field —
  // the name input above is the source of truth for that).
  const rawWrap = document.getElementById("raw-override-wrap");
  const rawInp = document.getElementById("raw-block-input");
  if (rawWrap && rawInp) {
    rawWrap.hidden = false;
    const copy = { ...b.raw };
    delete copy.name;
    rawInp.value = JSON.stringify(copy, null, 2);
  }
}
function closeModal() {
  const m = document.getElementById("broker-modal");
  if (m) m.hidden = true;
  // 2026-05-29 0.3.54: hide the protocol-edit row when the modal closes
  // so the next "Add broker" open doesn't show it (protocol falls out
  // of the Type pick in add-mode).
  const protoRow = document.getElementById("protocol-edit-row");
  if (protoRow) protoRow.hidden = true;
}

$("#add-broker-btn").addEventListener("click", openModal);

// Belt + braces: event delegation on the document so the X / Cancel /
// click-outside / Esc key all reach closeModal even if a direct
// listener ever fails to attach.
document.addEventListener("click", (e) => {
  const target = e.target;
  if (!(target instanceof Element)) return;
  if (target.closest("[data-close-modal]")) {
    e.preventDefault();
    closeModal();
    return;
  }
  if (target.id === "broker-modal") closeModal();
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" || e.key === "Esc") {
    const m = document.getElementById("broker-modal");
    if (m && !m.hidden) closeModal();
  }
});

$("#broker-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!SELECTED_SLUG) {
    toast("Select a device first", "error");
    return;
  }
  const fd = new FormData(e.target);
  const name = fd.get("_name");
  const type = fd.get("_type");
  const enabled = fd.get("_enabled") === "on";
  const fields = {};
  for (const [k, v] of fd.entries()) {
    if (k.startsWith("_")) continue;
    const inp = document.querySelector(`#dynamic-fields [name="${k}"]`);
    if (inp && inp.type === "number" && v !== "") fields[k] = Number(v);
    else fields[k] = v;
  }
  let r;
  if (MODAL_MODE === "create") {
    const protocol = fd.get("_protocol");
    if (!protocol) {
      toast("Pick a wire protocol (tdoa or mctomqtt)", "error");
      return;
    }
    r = await fetch(
      `/api/devices/${encodeURIComponent(SELECTED_SLUG)}/brokers`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, type, enabled, fields, protocol }),
      },
    );
  } else {
    const original = MODAL_MODE.edit;
    // Parse optional raw_block override. JSON is what the backend
    // expects (we already store TOML as dict-of-primitives). If the
    // textarea is empty or whitespace-only, send no override and
    // let the dotted-field merge apply as usual.
    let rawBlock;
    const rawStr = (fd.get("_raw_block") || "").toString().trim();
    if (rawStr) {
      try {
        rawBlock = JSON.parse(rawStr);
      } catch (parseErr) {
        toast("Raw override is not valid JSON: " + parseErr.message, "error");
        return;
      }
    }
    r = await fetch(
      `/api/devices/${encodeURIComponent(SELECTED_SLUG)}/brokers/${encodeURIComponent(original)}`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          enabled,
          fields,
          new_name: name !== original ? name : undefined,
          raw_block: rawBlock,
        }),
      },
    );
  }
  if (r.ok) {
    closeModal();
    toast(MODAL_MODE === "create" ? `Added "${name}"` : `Saved "${name}"`, "success");
    loadBrokers();
  } else {
    const err = await r.json().catch(() => ({}));
    toast((MODAL_MODE === "create" ? "Add" : "Save") + " failed: " + (err.detail || r.status), "error");
  }
});

// ── Restart ───────────────────────────────────────────────────────

$("#restart-btn").addEventListener("click", async () => {
  if (!SELECTED_SLUG) {
    toast("Select a device first", "error");
    return;
  }
  if (
    !confirm(
      `Restart mctomqtt for ${SELECTED_SLUG}? Brief gap in MQTT publishing.`,
    )
  )
    return;
  const r = await fetch(
    `/api/devices/${encodeURIComponent(SELECTED_SLUG)}/restart`,
    { method: "POST" },
  ).then((r) => r.json());
  if (r.mock) {
    toast(`(test) would run: ${r.would_run}`, "success");
  } else {
    toast(`Restarted ${r.unit || SELECTED_SLUG}`, "success");
  }
});

// ── Page switching (SPA-style) ──────────────────────────────────────
//
// Each nav target is its own PAGE. Clicking a nav item shows that page's
// sections and hides the others, so "Info" and "Message dev" are genuine
// separate views (not just scroll anchors on one long page). The frozen
// top bar stays put at all times. Sections not in any page (none today)
// would always show; keep PAGES exhaustive over the page-section ids.
const PAGES = {
  // MeshCore Nodes: pick a node here and see ALL its config + details on one
  // page — the device bar, GPS chain, firmware, auto-update, and apply.
  "device-bar": ["device-bar", "status", "firmware", "auto-update", "actions"],
  observer: ["observer"],
  brokers: ["brokers"], // Message dev
  info: ["info", "contact-operator"], // Info + contact operator
};
const DEFAULT_PAGE = "device-bar";

// contact-operator + auto-update are revealed/hidden by their own probes;
// remember that so page-switching doesn't force-show a gated section.
const ALWAYS_GATED = new Set(["contact-operator"]);
const _gatedVisible = {}; // id -> bool, updated by the gating probes

function showPage(target) {
  const page = PAGES[target] ? target : DEFAULT_PAGE;
  const visibleIds = new Set(PAGES[page]);
  for (const ids of Object.values(PAGES)) {
    for (const id of ids) {
      const el = document.getElementById(id);
      if (!el) continue;
      const onThisPage = visibleIds.has(id);
      // A gated section only shows when (a) it's on this page AND (b) its
      // probe said it should be visible. Everything else: show iff on page.
      if (ALWAYS_GATED.has(id)) {
        el.hidden = !(onThisPage && _gatedVisible[id]);
      } else {
        el.hidden = !onThisPage;
      }
    }
  }
  $$(".nav-link, .bottom-nav a").forEach((a) => {
    a.classList.toggle("active", a.dataset.target === page);
  });
  // Reflect in the hash without triggering a scroll jump.
  if (location.hash !== `#${page}`) {
    history.replaceState(null, "", `#${page}`);
  }
  window.scrollTo({ top: 0, behavior: "auto" });
}

// Mark a gated section's desired visibility, then re-apply the current page
// so a probe that resolves after first paint doesn't pop a section onto the
// wrong page.
function setGatedVisible(id, visible) {
  _gatedVisible[id] = visible;
  showPage(currentPage());
}

function currentPage() {
  const h = (location.hash || "").replace(/^#/, "");
  return PAGES[h] ? h : DEFAULT_PAGE;
}

$$(".nav-link, .bottom-nav a").forEach((a) => {
  a.addEventListener("click", (e) => {
    const target = a.dataset.target;
    if (!target) return;
    e.preventDefault();
    // bottom-nav targets (actions) map onto their owning page.
    const page = PAGES[target]
      ? target
      : Object.keys(PAGES).find((p) => PAGES[p].includes(target)) || DEFAULT_PAGE;
    showPage(page);
  });
});
window.addEventListener("hashchange", () => showPage(currentPage()));
window.addEventListener("load", () => showPage(currentPage()));

// ── Contact operator (Telegram) ─────────────────────────────────────
//
// Hidden unless /api/contact-operator/status reports configured=true
// (i.e. TELEGRAM_BOT_TOKEN + TELEGRAM_OPERATOR_CHAT_ID are set in
// portal.env). Single POST handler; rate-limit is enforced server
// side and surfaced via the 429 response.

async function maybeShowContactForm() {
  const section = document.getElementById("contact-operator");
  if (!section) return;
  try {
    const status = await fetch("/api/contact-operator/status").then((r) => r.json());
    if (!status.configured) return;  // stays hidden (gated-not-visible)
    // Gated: only show when configured AND the Info page is active. Routed
    // through setGatedVisible so page-switching keeps it on the Info page.
    setGatedVisible("contact-operator", true);
    const rateHint = document.getElementById("contact-rate-hint");
    if (rateHint && status.ratelimit_seconds) {
      const s = Number(status.ratelimit_seconds);
      rateHint.textContent = `1 message every ${s}s`;
    }
    // The "request firmware for an undetected board" block uses the same
    // Telegram channel, so reveal it under the same configured-gate.
    const fwUndetected = document.getElementById("fw-undetected");
    if (fwUndetected) fwUndetected.hidden = false;
  } catch (_) { /* probe failed — leave hidden, don't toast */ }
}

// Alpha-software banner: dismiss (per session) + point at the contact
// form when the operator has Telegram configured.
function initAlphaBanner() {
  const banner = document.getElementById("alpha-banner");
  if (!banner) return;
  if (sessionStorage.getItem("mctdoa.alphaBannerDismissed") === "1") {
    banner.hidden = true;
    return;
  }
  const closeBtn = document.getElementById("alpha-banner-close");
  closeBtn?.addEventListener("click", () => {
    try { sessionStorage.setItem("mctdoa.alphaBannerDismissed", "1"); } catch (_) { /* ignore */ }
    banner.hidden = true;
  });
  // If a contact channel is configured, add a link that jumps to the form.
  fetch("/api/contact-operator/status")
    .then((r) => r.json())
    .then((s) => {
      const span = document.getElementById("alpha-banner-contact");
      if (span && s && s.configured) {
        span.innerHTML =
          ' — <a href="#contact-operator" style="color:#7c4a02;font-weight:600">message the operator below</a>';
      }
    })
    .catch(() => { /* leave the plain text */ });
}

document.getElementById("contact-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.currentTarget;
  const fd = new FormData(form);
  const submit = document.getElementById("contact-submit");
  if (submit) submit.disabled = true;
  try {
    const r = await fetch("/api/contact-operator", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        from_name: fd.get("from_name") || null,
        reply_to:  fd.get("reply_to")  || null,
        message:   fd.get("message")   || "",
      }),
    });
    if (r.ok) {
      toast("Message sent — the operator will see it in Telegram.", "success");
      form.reset();
    } else {
      const err = await r.json().catch(() => ({}));
      toast(`Send failed: ${err.detail || r.status}`, "error", 6000);
    }
  } catch (err) {
    toast(`Send failed: ${err}`, "error", 6000);
  } finally {
    if (submit) submit.disabled = false;
  }
});

// Derive a friendly board label from a /dev/serial/by-id basename:
//   usb-Espressif_Systems_heltec_wifi_lora_32_v4__..._AA-if00
//     → "Espressif Systems heltec wifi lora 32 v4"
function prettyByIdLabel(byId) {
  if (!byId) return "";
  return byId
    .replace(/^usb-/, "")
    .replace(/-if\d+$/, "")
    .replace(/_[0-9A-Fa-f]{6,}$/, "")  // drop trailing serial token
    .replace(/_+/g, " ")
    .trim();
}

// Scan the Pi's USB serial devices and offer one-click pre-fill for the
// undetected-board form. Runs when the <details> panel is opened.
async function loadUsbCandidates() {
  const host = document.getElementById("fw-undetected-usb");
  if (!host) return;
  host.innerHTML = '<p class="hint">scanning USB…</p>';
  let data;
  try {
    data = await fetch("/api/firmware/usb-candidates").then((r) => r.json());
  } catch (_) {
    host.innerHTML = "";  // scan failed — operator can still type manually
    return;
  }
  const cands = (data && data.candidates) || [];
  if (!cands.length) {
    host.innerHTML = '<p class="hint">No USB serial devices detected on this gateway — fill the form manually.</p>';
    return;
  }
  const rows = cands.map((c, i) => {
    const label = c.product || prettyByIdLabel(c.by_id_name) || "USB device";
    const bits = [
      c.vid_pid ? `VID:PID ${esc(c.vid_pid)}` : "",
      c.guessed_mcu ? esc(c.guessed_mcu) : "",
      c.recognised ? "<span class=\"hint\">(already a configured device)</span>" : "",
    ].filter(Boolean).join(" · ");
    return `
      <div class="usb-cand" style="display:flex;align-items:center;gap:0.5em;margin:0.25em 0">
        <button type="button" class="btn" data-usb-idx="${i}">use this</button>
        <span><code>${esc(label)}</code>${bits ? ` — ${bits}` : ""}</span>
      </div>`;
  }).join("");
  host.innerHTML = `<p class="hint" style="margin:0.4em 0">Detected USB devices on this gateway — click <em>use this</em> to pre-fill:</p>${rows}`;
  host.querySelectorAll("button[data-usb-idx]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const c = cands[Number(btn.dataset.usbIdx)];
      const form = document.getElementById("fw-undetected-form");
      if (!form || !c) return;
      const set = (name, val) => {
        const el = form.elements[name];
        if (el && val) el.value = val;
      };
      // board name: product string, else the by-id-derived label.
      set("board_name", c.product || prettyByIdLabel(c.by_id_name));
      // MCU: the VID-based family guess (strip the parenthetical detail).
      if (c.guessed_mcu) set("mcu_chip", c.guessed_mcu.replace(/\s*\(.*\)$/, ""));
      // USB id: the stable by-id path (+ VID:PID for the operator).
      set("usb_id", c.by_id_name + (c.vid_pid ? `  [${c.vid_pid}]` : ""));
      toast("Pre-filled from USB — review, then add LoRa chip / role.", "success", 4000);
    });
  });
}

// Lazy-scan USB only when the operator opens the undetected panel (avoids
// a /dev walk on every page load).
(() => {
  const panel = document.getElementById("fw-undetected");
  if (!panel) return;
  panel.addEventListener("toggle", () => {
    if (panel.open) loadUsbCandidates();
  });
})();

// Request a firmware build for a board the portal didn't auto-detect.
// No slug — the operator types the board details by hand; the backend
// stamps the saved Observer email + source IP and forwards to Telegram.
document.getElementById("fw-undetected-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.currentTarget;
  const fd = new FormData(form);
  const submit = document.getElementById("fw-undetected-submit");
  if (submit) submit.disabled = true;
  try {
    const r = await fetch("/api/firmware/request-undetected", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        board_name:     fd.get("board_name")     || "",
        mcu_chip:       fd.get("mcu_chip")        || null,
        lora_chip:      fd.get("lora_chip")       || null,
        usb_id:         fd.get("usb_id")          || null,
        requested_role: fd.get("requested_role")  || "tdoa-rx",
        notes:          fd.get("notes")           || null,
      }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.ok) {
      toast(
        j.email_included
          ? "Sent — operator notified via Telegram (your email was included)."
          : "Sent — operator notified via Telegram.",
        "success", 6000,
      );
      form.reset();
    } else {
      toast(`Request failed: ${j.detail || r.status}`, "error", 6000);
    }
  } catch (err) {
    toast(`Request failed: ${err}`, "error", 6000);
  } finally {
    if (submit) submit.disabled = false;
  }
});

// ── Firmware (local flash + Telegram-request fallback) ────────────
//
// Reads /api/devices/{slug}/firmware/available on every device-change.
// Renders a role-picker + Flash button when a bundle is shipped, or a
// "Request firmware build" button when no images match the connected
// hardware. Flash POSTs to /firmware/flash; request POSTs to
// /firmware/request which forwards to Telegram.

async function loadFirmware() {
  const dev = selectedDevice();
  const host = document.getElementById("fw-body");
  const current = document.getElementById("fw-current");
  if (!dev || !host) return;
  current.textContent = `${dev.slug}`;
  host.innerHTML = '<p class="hint">loading firmware bundle…</p>';
  let data;
  try {
    data = await fetch(`/api/devices/${encodeURIComponent(dev.slug)}/firmware/available`)
      .then((r) => r.json());
  } catch (err) {
    host.innerHTML = `<p class="hint" style="color:#fda4af">firmware fetch failed: ${esc(String(err))}</p>`;
    return;
  }
  if (!data.hardware_id) {
    host.innerHTML = `
      <p class="hint">Couldn't determine hardware for <code>${esc(dev.slug)}</code>.</p>
      <p class="hint">The bridge needs to publish at least one <code>info.published</code> event with a known board name before flashing.</p>`;
    return;
  }
  const mode = data.flash_mode || {};
  const instructions = mode.instructions || "—";
  const label = mode.label || data.hardware_id;

  // node_function gating — operator must pick companion/repeater/
  // room_server in the config gear before the firmware list will offer
  // anything. Render a disabled-looking dropdown + an explicit "open
  // config" CTA instead of an empty file picker.
  if (data.node_function_required) {
    host.innerHTML = `
      <p><strong>${esc(label)}</strong> — set the <em>Node function</em> in
        config before picking a firmware.</p>
      <label>Pick a firmware
        <select id="fw-file-select" disabled>
          <option>— set Node function first (Config → Node function) —</option>
        </select>
      </label>
      <footer>
        <button class="btn" id="fw-open-config-btn">⚙ Open config</button>
        <button class="btn btn-primary" disabled>⚡ Flash</button>
      </footer>`;
    document.getElementById("fw-open-config-btn")?.addEventListener("click", openConfigModal);
    return;
  }

  if (data.no_firmware_available) {
    host.innerHTML = `
      <p><strong>${esc(label)}</strong> — no pre-shipped firmware available for this hardware yet.</p>
      <p class="hint">Click the button below to send the hardware fingerprint to the operator's Telegram so they can build + ship one.</p>
      <details><summary>Flash mode is automatic — manual fallback if needed</summary><p>${esc(instructions)}</p></details>
      <label>Requested role
        <select id="fw-role-select">
          <option value="tdoa-rx">📡 TDOA receiver</option>
          <option value="companion-radio">💬 Companion radio</option>
          <option value="repeater">🔁 Repeater</option>
          <option value="room-server">🏠 Room server</option>
        </select>
      </label>
      <label>Notes (optional)
        <textarea id="fw-request-notes" rows="2" maxlength="1000" placeholder="Anything the operator should know — e.g. preferred LoRa region, antenna, etc."></textarea>
      </label>
      <footer><button class="btn btn-primary" id="fw-request-btn">📨 Request firmware build</button></footer>`;
    document.getElementById("fw-request-btn")?.addEventListener("click", () => requestFirmware(dev.slug));
    return;
  }
  // Single firmware list with TDOA images + vanilla upstream MeshCore
  // images grouped under <optgroup>s. Each option carries
  // ``data-source="bundle"|"upstream-meshcore"`` so the Flash handler
  // POSTs the correct source without needing a second selector.
  // TDOA-fork artefacts carry ``tdoa_tag`` (the release the binary came
  // from, e.g. "tdoa-1.12.16"); fall back to the local filename for
  // legacy locally-PIO-built images that don't have the tag.
  const tdoaOpts = data.available.map((f) => {
    // Prefer the explicit tag fields; ``tdoa_tag`` comes from the
    // TDOA-fork release pull, ``git_tag`` from a local PIO build.
    // Fall back to git_sha or a "local" placeholder so the operator
    // can always see what they're about to flash.
    const tag = f.tdoa_tag || f.git_tag || f.git_sha || "local";
    const label = `${f.role} · ${tag} · ${f.tdoa_asset_name || f.filename}`;
    return `<option value="${esc(f.filename)}" data-source="bundle">🛰️ ${esc(label)} (${f.size_bytes} bytes)</option>`;
  }).join("");

  const upstream = data.upstream_meshcore;
  let upstreamOpts = "";
  let upstreamGroupLabel = "";
  let upstreamCount = 0;
  if (upstream && upstream.assets && upstream.assets.length) {
    upstreamCount = upstream.assets.length;
    upstreamOpts = upstream.assets.map((a) =>
      `<option value="${esc(a.filename)}" data-source="upstream-meshcore">🌱 ${esc(a.role)} · ${esc(a.upstream_asset_name || a.filename)} (${a.size_bytes} bytes)</option>`
    ).join("");
    const tag = upstream.version || "unknown";
    upstreamGroupLabel = `Vanilla MeshCore ${tag} (removes TDOA mods)`;
  }

  const groups = [
    `<optgroup label="TDOA build">${tdoaOpts}</optgroup>`,
    upstreamOpts ? `<optgroup label="${esc(upstreamGroupLabel)}">${upstreamOpts}</optgroup>` : "",
  ].join("");

  const releaseLink = upstream && upstream.release_url
    ? ` · <a href="${esc(upstream.release_url)}" target="_blank" rel="noopener">${esc(upstream.version || "upstream")}</a>`
    : "";
  const upstreamHint = upstreamCount
    ? `Includes ${upstreamCount} vanilla MeshCore variant(s)${releaseLink}.`
    : "No vanilla MeshCore variants shipped for this hardware in the current deb.";

  host.innerHTML = `
    <p><strong>${esc(label)}</strong> — ${data.available.length} pre-shipped TDOA image(s). <span class="hint">${upstreamHint}</span></p>
    <p class="hint">Pick an image and click Flash — normally you don't need to touch the board: the portal triggers flash mode for you (1200-baud USB touch on nRF52 like RAK4631 / T-Echo; esptool DTR/RTS reset on ESP32). See the per-board note below for when the manual fallback is needed.</p>
    <details open><summary>Flash mode is automatic — manual fallback if needed</summary><p>${esc(instructions)}</p></details>
    <label>Pick a firmware
      <select id="fw-file-select">${groups}</select>
    </label>
    <footer>
      <button class="btn btn-primary" id="fw-flash-btn">⚡ Flash</button>
    </footer>
    <pre id="fw-flash-log" hidden style="background:#0b0b0b;color:#cbd5f5;padding:8px;border-radius:4px;max-height:240px;overflow:auto;"></pre>`;
  document.getElementById("fw-flash-btn")?.addEventListener("click", () => flashFirmware(dev.slug));
}

async function flashFirmware(slug) {
  const sel = document.getElementById("fw-file-select");
  const btn = document.getElementById("fw-flash-btn");
  const logEl = document.getElementById("fw-flash-log");
  if (!sel || !btn || !logEl) return;
  // The single firmware select carries both TDOA bundle options + the
  // vanilla MeshCore options under separate <optgroup>s. Each <option>
  // has data-source="bundle" or "upstream-meshcore" so we can route the
  // flash POST without needing a second selector.
  const source = sel.selectedOptions[0]?.dataset.source || "bundle";
  const promptLine = source === "upstream-meshcore"
    ? `Flash UPSTREAM ${sel.value} onto ${slug}? This REMOVES all TDOA mods. The bridge will be stopped for the duration.`
    : `Flash ${sel.value} onto ${slug}? The bridge will be stopped for the duration.`;
  if (!confirm(promptLine)) return;
  btn.disabled = true;
  btn.textContent = "Flashing…";
  logEl.hidden = false;
  logEl.textContent = `flashing ${sel.value} (source=${source})…`;
  try {
    const r = await fetch(`/api/devices/${encodeURIComponent(slug)}/firmware/flash`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename: sel.value, source }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.ok) {
      toast(`Flash OK (${j.tool}, source=${j.source || source})`, "success", 6000);
      logEl.textContent = j.log_tail || "(no log)";
    } else {
      toast(`Flash failed: ${j.detail || r.status}`, "error", 8000);
      logEl.textContent = JSON.stringify(j, null, 2);
    }
  } catch (err) {
    toast(`Flash error: ${err}`, "error", 8000);
  } finally {
    btn.disabled = false;
    btn.textContent = "⚡ Flash";
  }
}

async function requestFirmware(slug) {
  const role = document.getElementById("fw-role-select")?.value;
  const notes = document.getElementById("fw-request-notes")?.value || "";
  const btn = document.getElementById("fw-request-btn");
  if (btn) btn.disabled = true;
  try {
    const r = await fetch(`/api/devices/${encodeURIComponent(slug)}/firmware/request`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ requested_role: role, notes }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.ok) {
      toast(`Sent — operator notified via Telegram`, "success", 5000);
    } else {
      toast(`Request failed: ${j.detail || r.status}`, "error", 6000);
    }
  } catch (err) {
    toast(`Request error: ${err}`, "error", 6000);
  } finally {
    if (btn) btn.disabled = false;
  }
}

// ── Auto-update toggle ─────────────────────────────────────────────

// Cloud-registration badge — is this gateway registered with homeprod
// (success) or not (failed, with the reason)? Reads /api/registration/status,
// which combines bridge.yaml creds (authoritative "registered") with the
// last register/heartbeat outcome the scripts recorded in /run.
async function loadRegistrationStatus() {
  const wrap = document.getElementById('registration-badge');
  const dot = document.getElementById('registration-dot');
  const head = document.getElementById('registration-headline');
  const det = document.getElementById('registration-detail');
  if (!wrap || !dot || !head || !det) return;
  let s;
  try {
    s = await fetch('/api/registration/status').then((r) => r.json());
  } catch (_) {
    return; // probe failed — leave whatever's shown
  }
  wrap.hidden = false;
  const ago = s.at ? `${Math.max(0, Math.round(Date.now() / 1000 - s.at))}s ago` : '';
  const lastNote =
    s.last_action && s.ok != null
      ? ` · last ${esc(s.last_action)} ${s.ok ? 'ok' : 'failed'}${ago ? ` (${ago})` : ''}`
      : '';

  if (s.registered) {
    // Registered. If the most recent contact failed (e.g. heartbeat 403),
    // amber it so the operator knows ongoing check-ins are broken.
    const degraded = s.ok === false;
    dot.textContent = degraded ? '🟠' : '✅';
    wrap.style.borderColor = degraded ? '#b45309' : '#15803d';
    head.textContent = degraded
      ? 'Registered — but last check-in failed'
      : 'Registered with homeprod';
    det.textContent =
      (s.pi_host_id ? `${s.pi_host_id}` : 'MQTT credentials present') +
      (s.detail && degraded ? ` — ${esc(s.detail)}` : lastNote);
  } else {
    dot.textContent = '❌';
    wrap.style.borderColor = '#b91c1c';
    head.textContent = 'Not registered with homeprod';
    det.textContent = s.detail
      ? esc(s.detail)
      : 'No cloud credentials yet — add a device, then registration runs automatically.' +
        lastNote;
  }
}

async function loadAutoUpdate() {
  try {
    const s = await fetch("/api/auto-update/status").then((r) => r.json());
    syncAutoUpdateToggleUI(s);
  } catch (err) {
    const detail = document.getElementById("auto-update-detail");
    if (detail) detail.textContent = `status fetch failed: ${err}`;
  }
}

function syncAutoUpdateToggleUI(s) {
  const pill = document.getElementById("auto-update-toggle");
  const lbl = document.getElementById("auto-update-state-label");
  const det = document.getElementById("auto-update-detail");
  const last = document.getElementById("auto-update-last");
  if (!pill) return;
  const enabled = !!s.enabled;
  pill.classList.toggle("on", enabled);
  pill.dataset.enabled = enabled ? "1" : "0";
  if (lbl) lbl.textContent = enabled ? "on" : "off";
  if (det) det.textContent = enabled
    ? "checks hourly; new debs auto-install"
    : "disabled — operator must apt-get install manually";
  if (last) {
    const state = s.last_state || "unknown";
    const when = s.last_run_at || "never";
    const ver = s.installed_version || "?";
    last.textContent = `last: ${state} @ ${when} · installed: ${ver}`;
  }
}

document.getElementById("auto-update-toggle")?.addEventListener("click", async () => {
  const pill = document.getElementById("auto-update-toggle");
  if (!pill) return;
  const desired = pill.dataset.enabled !== "1";
  try {
    const r = await fetch("/api/auto-update/toggle", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled: desired }),
    });
    if (r.ok) {
      toast(`Auto-update ${desired ? "enabled" : "disabled"}`, "success");
      await loadAutoUpdate();
    } else {
      const j = await r.json().catch(() => ({}));
      toast(`Toggle failed: ${j.detail || r.status}`, "error");
    }
  } catch (err) {
    toast(`Toggle error: ${err}`, "error");
  }
});

// ── TDOA Observer email → cloud My-Fleet ───────────────────────────

async function loadObserverEmail() {
  try {
    const r = await fetch("/api/observer-email").then((r) => r.json());
    const input = document.getElementById("observer-email");
    if (input && typeof r.email === "string") input.value = r.email;
    const link = document.getElementById("observer-myfleet-link");
    if (link && r.my_fleet_url) link.href = r.my_fleet_url;
    const status = document.getElementById("observer-status");
    if (status) {
      status.textContent = r.email
        ? `Linked to ${r.email} — sign in to My Fleet with this email.`
        : "";
      status.className = "observer-status" + (r.email ? " ok" : "");
    }
  } catch (err) {
    // Non-fatal: a portal.env we can't read just leaves the field blank.
    console.warn("loadObserverEmail failed", err);
  }
}

// Optional sign-up nudge: shown after saving an Observer email that has no
// TDOA cloud account yet. Pure invitation — dismissible, and the gateway
// works fine whether or not they ever sign up. Built as a lightweight
// overlay so it needs no markup in index.html.
function showSignupNudge(email, signupUrl) {
  document.getElementById("signup-nudge-overlay")?.remove();
  const url = signupUrl || "https://homeprod.dahllie.nl/my-fleet";
  const ov = document.createElement("div");
  ov.id = "signup-nudge-overlay";
  ov.style.cssText =
    "position:fixed;inset:0;z-index:1200;display:flex;align-items:center;" +
    "justify-content:center;background:rgba(0,0,0,0.55);padding:16px";
  ov.innerHTML = `
    <div role="dialog" aria-modal="true" aria-labelledby="signup-nudge-title"
         style="max-width:440px;width:100%;background:#0d1422;border:1px solid #2a3344;
                border-radius:10px;padding:20px 22px;color:#e2e8f0">
      <div style="font-size:20px;margin-bottom:6px">🔭</div>
      <h3 id="signup-nudge-title" style="margin:0 0 8px;font-size:17px">
        See this gateway on the TDOA network
      </h3>
      <p style="margin:0 0 10px;font-size:13px;line-height:1.5;color:#cbd5f5">
        <code style="color:#e2e8f0">${esc(email)}</code> doesn't have a TDOA
        account yet. Create one (free, with this same email) to log in to the
        TDOA front-end and see the live maps, your gateway, and the nodes it
        hears across the network.
      </p>
      <p style="margin:0 0 16px;font-size:12px;color:#94a3b8">
        Don't want cloud access? You can ignore this — your gateway keeps
        running and contributing to the network either way. The email stays
        saved, so it'll link automatically if you sign up later.
      </p>
      <div style="display:flex;gap:8px;justify-content:flex-end">
        <button type="button" id="signup-nudge-dismiss" class="btn"
                style="background:transparent">Maybe later</button>
        <a href="${esc(url)}" target="_blank" rel="noopener"
           class="btn btn-primary" id="signup-nudge-go"
           style="text-decoration:none">Create account / Sign in ↗</a>
      </div>
    </div>`;
  const close = () => ov.remove();
  ov.addEventListener("click", (e) => { if (e.target === ov) close(); });
  document.body.appendChild(ov);
  document.getElementById("signup-nudge-dismiss")?.addEventListener("click", close);
  document.getElementById("signup-nudge-go")?.addEventListener("click", close);
}

// ── Message dev: chat-to-developers box ─────────────────────────────
// Prefills the email with the gateway's saved Observer email; if none is
// saved, the field stays empty and required so the user supplies one (so the
// dev can reply). Posts to the existing /api/contact-operator → Telegram.
async function initDevMessage() {
  const form = document.getElementById("devmsg-form");
  if (!form) return;
  const emailEl = document.getElementById("devmsg-email");
  const hintEl = document.getElementById("devmsg-email-hint");
  // Prefill from the saved Observer email.
  try {
    const r = await fetch("/api/observer-email").then((x) => x.json());
    if (emailEl && r && typeof r.email === "string" && r.email) {
      emailEl.value = r.email;
    } else if (hintEl) {
      hintEl.style.display = "";
      hintEl.textContent =
        "No email saved on this gateway yet — enter one so the developers can reply.";
    }
  } catch (_) { /* leave blank + required */ }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const statusEl = document.getElementById("devmsg-status");
    const btn = document.getElementById("devmsg-send");
    const email = (emailEl?.value || "").trim();
    const text = (document.getElementById("devmsg-text")?.value || "").trim();
    if (!text) { toast("Type a message first.", "error"); return; }
    if (!email) { toast("Add your email so we can reply.", "error"); return; }
    if (btn) btn.disabled = true;
    if (statusEl) statusEl.textContent = "Sending…";
    try {
      const r = await fetch("/api/contact-operator", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, reply_to: email }),
      });
      const j = await r.json().catch(() => ({}));
      if (r.ok) {
        toast("Message sent to the developers 🐸", "success");
        if (statusEl) statusEl.textContent = "Sent — thanks! We'll get back to you.";
        const ta = document.getElementById("devmsg-text");
        if (ta) ta.value = "";
      } else if (r.status === 503) {
        // Channel not set up on this gateway — keep it user-friendly.
        toast("Messaging isn't set up on this gateway — share a screenshot with whoever runs it.", "info");
        if (statusEl) statusEl.textContent = "";
      } else if (r.status === 429) {
        toast(j.detail || "Too fast — wait a moment and try again.", "error");
        if (statusEl) statusEl.textContent = "";
      } else {
        toast(`Couldn't send: ${j.detail || r.status}`, "error");
        if (statusEl) statusEl.textContent = "";
      }
    } catch (err) {
      toast(`Send error: ${err}`, "error");
      if (statusEl) statusEl.textContent = "";
    } finally {
      if (btn) btn.disabled = false;
    }
  });
}

document.getElementById("observer-form")?.addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = document.getElementById("observer-email");
  const btn = document.getElementById("observer-save-btn");
  const status = document.getElementById("observer-status");
  const email = (input?.value || "").trim();
  if (btn) btn.disabled = true;
  try {
    const r = await fetch("/api/observer-email", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok) {
      if (status) {
        status.textContent = email
          ? `Saved. Linking applies on the next check-in — then open My Fleet and sign in as ${email}.`
          : "Cleared — this gateway is no longer linked by email.";
        status.className = "observer-status ok";
      }
      const link = document.getElementById("observer-myfleet-link");
      if (link && j.my_fleet_url) link.href = j.my_fleet_url;
      toast(email ? "Observer email saved" : "Observer email cleared", "success");
      // If this email has no TDOA account yet (j.registered !== true), nudge
      // the operator to sign up so they can view this gateway + the TDOA maps
      // online. Purely optional — the gateway works regardless; they can
      // dismiss and ignore it.
      if (email && j.registered !== true) {
        showSignupNudge(email, j.signup_url || j.my_fleet_url);
      }
    } else {
      if (status) {
        status.textContent = `Could not save: ${j.detail || r.status}`;
        status.className = "observer-status err";
      }
      toast(`Save failed: ${j.detail || r.status}`, "error");
    }
  } catch (err) {
    if (status) {
      status.textContent = `Save error: ${err}`;
      status.className = "observer-status err";
    }
    toast(`Save error: ${err}`, "error");
  } finally {
    if (btn) btn.disabled = false;
  }
});

// ── Connectivity + registration status (top-bar indicator) ──────────
// Polls the layered /api/registration/diagnostic and reflects the overall
// state on the top-bar chip: green = online + registered, amber = a
// non-blocking issue, red = a hard failure. The tooltip lists every layered
// step + the specific reason for the first failure. Clicking the chip sends
// the full diagnostic to the operator over Telegram.
async function loadConnectivity() {
  const chip = document.getElementById("conn-status");
  const dot = document.getElementById("conn-dot");
  const label = document.getElementById("conn-label");
  if (!chip || !dot || !label) return;
  try {
    const r = await fetch("/api/registration/diagnostic");
    // Guard against a stale/old backend that doesn't have this endpoint (404)
    // or returns an unexpected shape — without this the tooltip rendered the
    // literal text "undefined" from missing fields (s.label / d.summary).
    if (!r.ok) throw new Error(`diagnostic HTTP ${r.status}`);
    const d = await r.json();
    const cls =
      d.status === "ok" ? "conn-ok" : d.status === "degraded" ? "conn-warn" : "conn-down";
    chip.className = "brand-conn " + cls;
    dot.className = "conn-dot " + cls;
    label.textContent = d.status === "ok" ? "Online" : d.summary || "Issue";
    const sym = { true: "✅", false: "❌", null: "▫️" };
    const lines = (d.steps || []).map(
      (s) =>
        `${sym[String(s.ok)]} ${s.label || s.name || "step"}` +
        (s.ok === false && s.detail ? `\n    → ${s.detail}` : "")
    );
    chip.title =
      `${d.summary || "Connectivity"}\n\n` +
      lines.join("\n") +
      "\n\n(Click to send this report to the operator via Telegram)";
  } catch (_e) {
    chip.className = "brand-conn conn-unknown";
    dot.className = "conn-dot conn-unknown";
    label.textContent = "Status ?";
    chip.title = "Could not fetch connectivity status.";
  }
}

async function sendDiagnosticToTelegram() {
  // Don't fire a doomed POST (and a scary error) when the operator hasn't set
  // up the contact channel. The status dot is ALWAYS clickable, so a user who
  // taps it just to inspect status shouldn't get a config error. Probe first.
  try {
    const st = await fetch("/api/contact-operator/status").then((r) => r.json());
    if (!st.configured) {
      toast(
        "Status shown above. Direct reporting isn't set up on this gateway — " +
          "share a screenshot with whoever runs it.",
        "info",
      );
      return;
    }
  } catch (_) { /* probe failed — fall through and let the POST surface it */ }
  try {
    const r = await fetch("/api/registration/diagnostic/telegram", { method: "POST" });
    const j = await r.json().catch(() => ({}));
    if (r.ok) toast("Diagnostic report sent to the operator (Telegram)", "success");
    else if (r.status === 404)
      // 404 here means this page (app.js) is newer than the running portal —
      // a stale cache mismatch. Tell the operator what to do instead of "not found".
      toast("This page is out of date — reload the page (it'll auto-update).", "error");
    else toast(`Telegram not sent: ${j.detail || r.status}`, "error");
  } catch (e) {
    toast(`Telegram error: ${e}`, "error");
  }
}

// ── Info / Changelog page ───────────────────────────────────────────
async function loadChangelog() {
  const el = document.getElementById("changelog-body");
  if (!el) return;
  try {
    const d = await fetch("/api/changelog").then((r) => r.json());
    el.replaceChildren();
    for (const entry of d.entries || []) {
      const block = document.createElement("div");
      block.className = "changelog-entry";
      const h = document.createElement("h3");
      h.className = "changelog-version";
      h.textContent =
        entry.version +
        (entry.version === d.current ? "  (installed)" : "") +
        (entry.date ? ` · ${entry.date}` : "");
      block.appendChild(h);
      const ul = document.createElement("ul");
      ul.className = "changelog-list";
      for (const c of entry.changes || []) {
        const li = document.createElement("li");
        li.textContent = c;
        ul.appendChild(li);
      }
      block.appendChild(ul);
      el.appendChild(block);
    }
  } catch (_e) {
    el.textContent = "Could not load the changelog.";
  }
}

// ── Boot ───────────────────────────────────────────────────────────

(async function init() {
  await loadInfo();
  await loadBrokerTypes();
  await loadDevices();
  await loadBrokers();
  await loadHealth();
  await loadFirmware();
  await loadAutoUpdate();
  await loadRegistrationStatus();
  await loadObserverEmail();
  await loadConnectivity();
  await loadChangelog();
  document
    .getElementById("conn-status")
    ?.addEventListener("click", sendDiagnosticToTelegram);
  maybeShowContactForm();
  initAlphaBanner();
  initDevMessage();
  // Poll GPS/FW health only while the tab is visible — no Pi load or
  // operator-battery drain on a backgrounded tab, and no catch-up render
  // storm on refocus. Refresh once immediately when the tab regains focus.
  setInterval(() => {
    if (document.visibilityState === "visible") loadHealth();
  }, 5000);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") loadHealth();
  });
  // Refresh firmware view on every device-pill click — wire via the
  // existing renderDevicePills click handler chain.
  setInterval(loadAutoUpdate, 60_000);
  setInterval(loadRegistrationStatus, 60_000);
  setInterval(() => {
    if (document.visibilityState === "visible") loadConnectivity();
  }, 30_000);
})();
