"""Pre-flash USB recovery for native-USB flash targets (nRF52, ESP32-S3).

When a native-USB device (nRF52840 T-Echo / RAK4631 / T114, ESP32-S3 Heltec V4)
is present on the bus (visible under ``/sys/bus/usb/devices``) but its
``/dev/serial/by-id`` port node never appeared — typically after a failed
``SET_CONFIGURATION`` or a ``device descriptor read/64, error -110`` during
(re)enumeration — none of the descriptor-glob recovery paths
(``find_techo_dfu_port`` / ``find_jtag_recovery_port`` / the
``/dev/meshcore/serial-*`` symlink / wildcard scans) can help: they hunt for a
*different* port node, but here there is *no* usable port node at all.

The remedy is a **single-device re-enumeration**: toggle that one device's sysfs
``authorized`` flag ``0 -> 1``, which tears down and re-enumerates ONLY that
device (re-running ``SET_CONFIGURATION``) **without touching any sibling receiver
on the same USB hub**. This is deliberately NOT a hub unbind/bind — multi-receiver
Pis (e.g. D_Creek runs several receivers on one hub) would otherwise have every
sibling reset mid-operation.

Scope:
* Call this ONLY from native-USB flash paths (``fwota_techo`` / ``fwota_v4``).
  External USB-UART bridges (CP2102 / CH340 / FTDI — e.g. Wio-E5/STM32WL) never
  drop their USB node on flash, so this never applies; as defence in depth we
  detect those VIDs and skip (resetting them would bounce the persistent bridge
  and the MCU behind it).
* The bridge runs as root (CapabilityBoundingSet incl. ``CAP_DAC_OVERRIDE``), so
  it writes the sysfs file directly — no sudo helper / sudoers entry needed.

Everything that touches the system (file existence, sysfs reads/writes, sleeps)
is injectable so the logic is unit-tested against a fake sysfs tree with no real
hardware.
"""

from __future__ import annotations

import logging
import os
import time
from collections.abc import Callable

logger = logging.getLogger(__name__)

_SYSFS_USB = "/sys/bus/usb/devices"

#: USB-UART bridge chip vendor IDs. Their /dev node never vanishes on flash, so a
#: port-missing recovery never applies — and a reset would bounce the persistent
#: bridge + the MCU behind it. CP2102/N (10c4), CH340/CH341 (1a86), FTDI (0403).
_UART_BRIDGE_VIDS = frozenset({"10c4", "1a86", "0403"})


def _read_attr(path: str) -> str | None:
    """Read a sysfs attribute, stripped; None on any error."""
    try:
        with open(path, encoding="ascii", errors="replace") as fh:
            return fh.read().strip()
    except OSError:
        return None


def _default_write(path: str, value: str) -> bool:
    """Write a sysfs attribute; True on success, False on any error."""
    try:
        with open(path, "w", encoding="ascii") as fh:
            fh.write(value)
        return True
    except OSError:
        return False


def _find_usb_device(by_id_basename: str, sysfs: str) -> tuple[str | None, str]:
    """Find the USB device whose serial is embedded in the by-id name.

    /dev/serial/by-id names are built from the device's USB serial, so the
    device's sysfs ``serial`` attribute is a substring of the by-id basename.
    Returns (device_sysfs_path, idVendor_lower) or (None, "").
    """
    try:
        entries = sorted(os.listdir(sysfs))
    except OSError:
        return None, ""
    for name in entries:
        # Skip interface/endpoint nodes (e.g. "2-1.4:1.0") — only whole-device
        # nodes carry a `serial` + `authorized`.
        if ":" in name:
            continue
        dev = os.path.join(sysfs, name)
        serial = _read_attr(os.path.join(dev, "serial"))
        if serial and serial in by_id_basename:
            vid = (_read_attr(os.path.join(dev, "idVendor")) or "").lower()
            return dev, vid
    return None, ""


def ensure_serial_enumerated(
    by_id_path: str,
    *,
    timeout_s: float = 12.0,
    poll_s: float = 0.5,
    settle_s: float = 1.0,
    sysfs: str = _SYSFS_USB,
    exists: Callable[[str], bool] = os.path.exists,
    write_attr: Callable[[str, str], bool] = _default_write,
    sleep: Callable[[float], None] = time.sleep,
) -> bool:
    """Ensure ``by_id_path`` exists, re-enumerating its USB device if not.

    Fast no-op (returns True) when the port is already present — the common case.
    Otherwise locate the single USB device behind the by-id name, toggle its
    ``authorized`` flag to force a re-enumeration of THAT device only, and poll
    up to ``timeout_s`` for the port to reappear.

    Returns True if the port exists after the attempt, else False. Returns False
    without touching anything if the device can't be located; returns the current
    existence (no reset) for external UART bridges (not susceptible).
    """
    if exists(by_id_path):
        return True

    basename = os.path.basename(by_id_path)
    dev, vid = _find_usb_device(basename, sysfs)
    if dev is None:
        logger.warning(
            "fwota.usb_recovery.device_not_found by_id=%s — device not on the "
            "bus (unplugged / dead), nothing to re-enumerate",
            basename,
        )
        return False
    if vid in _UART_BRIDGE_VIDS:
        # External UART bridge — its USB node never disappears, so a missing
        # port is not an enumeration failure we can fix by resetting it.
        return exists(by_id_path)

    authorized = os.path.join(dev, "authorized")
    logger.warning(
        "fwota.usb_recovery.reenumerate dev=%s by_id=%s vid=%s — port missing, "
        "toggling authorized to re-enumerate this device only",
        os.path.basename(dev),
        basename,
        vid,
    )
    if not write_attr(authorized, "0"):
        logger.error("fwota.usb_recovery.write_failed dev=%s op=deauthorize", dev)
        return exists(by_id_path)
    sleep(settle_s)
    if not write_attr(authorized, "1"):
        logger.error("fwota.usb_recovery.write_failed dev=%s op=reauthorize", dev)
        return exists(by_id_path)

    waited = 0.0
    while waited < timeout_s:
        sleep(poll_s)
        waited += poll_s
        if exists(by_id_path):
            logger.info(
                "fwota.usb_recovery.recovered by_id=%s waited_s=%.1f",
                basename,
                waited,
            )
            return True
    logger.error(
        "fwota.usb_recovery.timeout by_id=%s waited_s=%.1f — port still absent "
        "after re-enumeration",
        basename,
        timeout_s,
    )
    return False
