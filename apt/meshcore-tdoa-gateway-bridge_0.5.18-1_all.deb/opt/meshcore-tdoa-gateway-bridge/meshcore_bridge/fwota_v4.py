"""Remote firmware OTA for Heltec WiFi LoRa 32 v4 receivers (KAN-168).

The bridge is the only host with USB-CDC reach to a V4 receiver, so
remote firmware upgrades funnel through here: the API server queues a
job, the bridge downloads the artifact, then this module hands the
binary off to ``esptool`` over the receiver's CDC port and verifies the
chip re-enumerates with a valid bootloader.

Hardware specifics encoded below:

* Heltec WiFi LoRa 32 v4 — ESP32-S3-WROOM-1, 16 MB flash, 2 MB PSRAM.
* Runtime CDC descriptor::

      usb-Espressif_Systems_heltec_wifi_lora_32_v4__16_MB_FLASH__2_MB_PSRAM_*

* Bootloader (post-reset) CDC descriptor::

      usb-Espressif_USB_JTAG_serial_debug_unit_*

  When ``esptool`` issues its sync sequence and toggles DTR/RTS, the
  ESP32-S3 ROM bootloader engages automatically — we don't need an
  out-of-band reboot. After the write, the chip boots the new firmware
  and the runtime descriptor reappears under ``/dev/serial/by-id/``.

* Flash command we use::

      esptool --chip esp32s3 --port <jtag-port> --baud 460800 \\
              --before default-reset --after hard-reset \\
              write-flash 0x10000 <fw.bin>

  ``--before default-reset`` is what makes the ROM bootloader engage
  natively without a separate reboot step. ``--after hard-reset`` then
  boots the freshly-flashed image.

The function is async-first so the caller (a per-job task spawned by
the bridge's HTTP handler) can ``await`` flash progress without
blocking the supervisor thread that owns USB rescans.

The caller is responsible for stopping the serial reader on the port
BEFORE calling :func:`flash_v4` — esptool needs exclusive access to
the CDC node and a concurrent ``serial.Serial.read`` will fight it.
This module never mutates :class:`~meshcore_bridge.serial_reader.SerialReader`
state directly so its responsibility boundary stays narrow and testable.
"""

from __future__ import annotations

import asyncio
import glob
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Literal

import structlog

from . import usb_recovery

log = structlog.get_logger(__name__)


#: Re-enumeration glob for the V4's RUNTIME (post-flash) CDC descriptor.
#: The trailing ``*`` matches the per-MAC suffix udev appends; one V4 plugged
#: in shows exactly one match. When two V4s share a bridge the caller passes
#: a more specific glob via :attr:`FlashOptions.runtime_glob`.
DEFAULT_RUNTIME_GLOB = (
    "/dev/serial/by-id/"
    "usb-Espressif_Systems_heltec_wifi_lora_32_v4__16_MB_FLASH__2_MB_PSRAM_*"
)

#: Default upper bound for re-enumeration polling. The V4 typically reboots
#: + re-enumerates in 4-8 s on a clean USB hub; 90 s leaves headroom for a
#: cold-cache udev fire and a slow Pi-side ``by-id`` symlink refresh.
DEFAULT_REENUM_TIMEOUT_S = 90.0

#: Polling interval for the re-enumeration loop. Slow enough that we don't
#: burn the bridge CPU, fast enough that a healthy reboot is detected within
#: ~1 s of the symlink appearing.
_REENUM_POLL_INTERVAL_S = 0.5

#: How long to wait for esptool's subprocess to finish a write. The 660 KB
#: artifact flashes in <30 s on a clean USB hub at 460800 baud; 5 min covers
#: a degraded link or a UART-glitch retry without escaping into "the job
#: hung forever" territory.
DEFAULT_FLASH_TIMEOUT_S = 300.0

#: Verification step's timeout — a ``flash-id`` query that just asks the
#: bootloader to identify itself. Usually completes in <5 s; 30 s covers a
#: slow USB hub or a transient enumeration glitch.
DEFAULT_VERIFY_TIMEOUT_S = 30.0

#: Default flashing baud rate. 460800 is the speed we've used successfully
#: against the V4's ROM bootloader on the OPi One bridge. Higher rates work
#: on shorter cables but degrade reliability on a long bus run.
DEFAULT_FLASH_BAUD = 460800

#: Offset of the V4's primary application partition within the SPI flash.
#: 0x10000 (64 KiB) is the PlatformIO default for the
#: ``heltec_v4_companion_radio_usb_tdoa_rx`` env (and for every ESP-IDF
#: project that uses the stock partition table).
DEFAULT_FLASH_OFFSET = "0x10000"


FlashState = Literal[
    "success",
    "rolled_back_to_previous",
    "failed_verify",
    "failed_flash",
    "failed_no_reenum",
    "failed_timeout",
    "failed_boot_loop",
]

#: How long to wait after the runtime CDC descriptor reappears before
#: declaring the flash a success. A bad firmware enumerates briefly
#: (the bootloader hands off, USB-CDC comes up) then crashes back into
#: the JTAG ROM bootloader within ~4 s — see the V4 tdoa-1.8.5 incident
#: on 2026-05-13 where every flash succeeded at bytes-on-disk but the
#: firmware faulted within 4 s of boot. 8 s gives ~2x headroom over
#: that observed boot-loop interval; a healthy firmware is still
#: enumerated continuously for the entire window.
BOOT_STABILITY_WAIT_S = 8.0

#: Baud rate for the JTAG-bootloader recovery path. The JTAG ROM
#: bootloader is less tolerant of high baud rates than the application
#: serial path, especially on long USB cables / hubs. 115_200 is the
#: ESP32-S3 ROM default and works reliably; the 460_800 we use for
#: normal application flashing intermittently fails on the JTAG path
#: which is exactly the failure pattern that bricked the V4 on
#: 2026-05-13. Belt-and-braces: also bump --connect-attempts.
JTAG_RETRY_BAUD = 115_200

#: Initial sleep before the JTAG retry attempt. The runtime-port flash
#: that failed will have dropped the chip into JTAG bootloader; the OS
#: needs ~1-2 s to enumerate the new descriptor and stabilise its
#: udev symlink. 5 s gives generous headroom — but if the chip is slow
#: to transition, see JTAG_DETECT_TOTAL_S for the upper bound.
JTAG_RETRY_WAIT_S = 5.0

#: Upper bound on the JTAG-descriptor polling loop. If the chip is
#: still in runtime mode 5 s after the failed handshake (the previous
#: behaviour gave up here), some chips need an extra few seconds to
#: actually transition. Poll every JTAG_DETECT_POLL_S until the
#: JTAG descriptor appears or this deadline elapses. Verified on V4
#: job 12 on 2026-05-13: the chip transitioned to JTAG ~7 s after
#: esptool exit, well past the previous single-shot glob window.
JTAG_DETECT_TOTAL_S = 20.0
JTAG_DETECT_POLL_S = 1.0

#: --connect-attempts passed to the JTAG retry esptool invocation.
#: esptool's default is 7 internally but our prior code didn't pass
#: it explicitly. Setting it high is cheap (only affects the failure
#: path) and makes the retry succeed across more flaky USB hubs.
JTAG_CONNECT_ATTEMPTS = 7


ProgressCallback = Callable[[str], None]


@dataclass(frozen=True)
class FlashOptions:
    """Tunables for :func:`flash_v4`. All defaults work for production V4s.

    Surfaced as a dataclass so the bridge's HTTP handler can override
    timeouts for slow USB hubs (Pi 3 + powered hub on a long cable) without
    re-passing eight kwargs. Frozen so tests can share one instance across
    multiple flash attempts without worrying about accidental mutation.
    """

    esptool_path: str = "esptool"
    chip: str = "esp32s3"
    baud: int = DEFAULT_FLASH_BAUD
    flash_offset: str = DEFAULT_FLASH_OFFSET
    runtime_glob: str = DEFAULT_RUNTIME_GLOB
    flash_timeout_s: float = DEFAULT_FLASH_TIMEOUT_S
    reenum_timeout_s: float = DEFAULT_REENUM_TIMEOUT_S
    verify_timeout_s: float = DEFAULT_VERIFY_TIMEOUT_S


@dataclass
class FlashResult:
    """Outcome of a single :func:`flash_v4` invocation.

    Always populated regardless of ``state`` — even on a hard failure the
    caller gets the partial log and the elapsed wall time so the API can
    surface "we tried for 6 s before esptool died".

    ``new_port`` is the post-reenum CDC path the chip came back on (used by
    the supervisor to restart its serial reader on the same logical
    receiver). ``None`` when re-enumeration never completed.
    """

    state: FlashState
    elapsed_s: float
    log: list[str] = field(default_factory=list)
    new_port: str | None = None
    error: str | None = None


def _now() -> float:
    """Wall-clock seconds; pulled out so tests can patch it deterministically."""
    return time.monotonic()


async def _stream_lines(
    stream: asyncio.StreamReader | None,
    log_lines: list[str],
    on_progress: ProgressCallback | None,
) -> None:
    """Drain ``stream`` line-by-line into ``log_lines`` and (optionally) ``on_progress``.

    ESP32 ``esptool`` interleaves progress lines on stdout (percentage bar)
    with status on stderr (errors, sync retries); we tee both streams through
    the same callback so the caller's UI sees a chronological view. Lines are
    decoded with ``errors="replace"`` so a stray non-UTF-8 byte from the
    JTAG-CDC serial path doesn't crash the drain task.
    """
    if stream is None:
        return
    while True:
        chunk = await stream.readline()
        if not chunk:
            return
        line = chunk.decode("utf-8", errors="replace").rstrip("\r\n")
        log_lines.append(line)
        if on_progress is not None:
            try:
                on_progress(line)
            except Exception as exc:  # noqa: BLE001 - callback must not kill the drain
                # Log but don't propagate; a misbehaving progress callback
                # should never abort an in-progress flash.
                log.warning(
                    "fwota.progress_callback_error",
                    error=str(exc),
                    error_type=type(exc).__name__,
                )


async def _await_reenum(
    glob_pattern: str,
    *,
    timeout_s: float,
    deadline_start: float,
    glob_fn: Callable[[str], list[str]] = glob.glob,
    sleep_fn: Callable[[float], asyncio.Future[None]] | None = None,
) -> str | None:
    """Poll ``glob_pattern`` until at least one path appears, or ``timeout_s`` elapses.

    Returns the first matching path (sorted, for determinism when two V4s
    share a hub) or ``None`` on timeout. Tests inject ``glob_fn`` to drive
    a synthetic re-enumeration without touching ``/dev``.
    """
    deadline = deadline_start + timeout_s
    while _now() < deadline:
        matches = sorted(glob_fn(glob_pattern))
        if matches:
            return matches[0]
        if sleep_fn is not None:
            await sleep_fn(_REENUM_POLL_INTERVAL_S)
        else:
            await asyncio.sleep(_REENUM_POLL_INTERVAL_S)
    return None


async def _run_esptool(
    argv: list[str],
    *,
    log_lines: list[str],
    on_progress: ProgressCallback | None,
    timeout_s: float,
    subprocess_factory: (
        Callable[..., asyncio.Future[asyncio.subprocess.Process]] | None
    ) = None,
) -> tuple[int, bool]:
    """Spawn esptool, stream its output, return ``(returncode, timed_out)``.

    The factory indirection exists so the test suite can swap in a fake
    ``Process`` object without monkeypatching the ``asyncio`` module
    itself — leaner test isolation, less risk of cross-test bleed.

    A ``timed_out=True`` indicates we hit ``timeout_s`` and killed the
    subprocess; the returncode in that case is whatever
    ``Process.wait()`` reports after ``kill()`` (-9 on POSIX, 1 on
    Windows). The caller treats either signal as ``failed_timeout``.
    """
    create = subprocess_factory or asyncio.create_subprocess_exec
    log_lines.append(f"$ {' '.join(argv)}")
    if on_progress is not None:
        try:
            on_progress(f"$ {' '.join(argv)}")
        except Exception:  # noqa: BLE001
            pass
    proc = await create(
        *argv,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    drain_stdout = asyncio.create_task(
        _stream_lines(proc.stdout, log_lines, on_progress)
    )
    drain_stderr = asyncio.create_task(
        _stream_lines(proc.stderr, log_lines, on_progress)
    )
    timed_out = False
    try:
        await asyncio.wait_for(proc.wait(), timeout=timeout_s)
    except TimeoutError:
        timed_out = True
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        # Give the killed process a moment to release its pipes so the
        # drain tasks can finish naturally rather than getting cancelled
        # mid-readline.
        try:
            await asyncio.wait_for(proc.wait(), timeout=5.0)
        except TimeoutError:
            pass
    # Make sure both stream-drain tasks finish (or get cancelled) before
    # returning — otherwise their output gets attributed to the wrong
    # invocation when the caller chains a verify call afterwards.
    #
    # When the process exited cleanly we give the drains a short grace
    # period to finish reading whatever buffered output the kernel still
    # has queued (esptool can emit its last "Hash of data verified" line
    # AFTER its return code goes through the pipe on some kernels). On a
    # timeout-kill path the kernel has already torn the pipes down so the
    # drains finish near-instantly anyway.
    drain_grace_s = 2.0 if not timed_out else 0.5
    try:
        await asyncio.wait_for(
            asyncio.gather(drain_stdout, drain_stderr, return_exceptions=True),
            timeout=drain_grace_s,
        )
    except TimeoutError:
        # Drains still going — cancel them and absorb the CancelledError so
        # the caller never sees a leaked task.
        for task in (drain_stdout, drain_stderr):
            if not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):  # noqa: BLE001
                    pass
    returncode = proc.returncode if proc.returncode is not None else 1
    return returncode, timed_out


async def flash_v4(
    port: str,
    fw_bin_path: str,
    *,
    on_progress: ProgressCallback | None = None,
    options: FlashOptions | None = None,
    glob_fn: Callable[[str], list[str]] = glob.glob,
    subprocess_factory: (
        Callable[..., asyncio.Future[asyncio.subprocess.Process]] | None
    ) = None,
    sleep_fn: Callable[[float], asyncio.Future[None]] | None = None,
    rollback_fw_bin_path: str | None = None,
    # Pre-flash USB recovery seam (default: real single-device re-enumeration).
    # Tests pass a no-op to avoid touching the host's /sys/bus/usb.
    ensure_port: Callable[[str], bool] | None = None,
) -> FlashResult:
    """Flash ``fw_bin_path`` onto the Heltec V4 currently reachable at ``port``.

    The caller must have STOPPED any serial reader holding ``port`` before
    calling this — esptool needs exclusive USB-CDC access. This function
    never touches the bridge's :class:`SerialReader` registry directly so
    the responsibility boundary stays narrow.

    Flow:

    1. Spawn ``esptool --before default-reset --after hard-reset write-flash``.
       The ROM bootloader auto-engages from the DTR/RTS toggle esptool emits
       natively; we don't issue a separate reboot. Output streams through
       ``on_progress`` line-by-line.
    2. If esptool exits non-zero (or times out) — return ``failed_flash`` /
       ``failed_timeout``.
    3. Wait up to ``options.reenum_timeout_s`` for the runtime CDC glob to
       reappear. Some other ``Espressif_Systems_heltec*`` symlink → we have
       a healthy chip back. None → ``failed_no_reenum``.
    4. Spawn a short ``esptool flash-id`` against the new port to prove the
       chip is responsive (not just enumerated). Non-zero → ``failed_verify``.
    5. ``success`` — log elapsed time and return.

    The returned :class:`FlashResult` always carries the full streamed log,
    even on failure, so the API server can persist it to the job row.

    ``glob_fn`` / ``subprocess_factory`` / ``sleep_fn`` are test seams — the
    production caller never sets them.
    """
    opts = options or FlashOptions()
    started = _now()
    log_lines: list[str] = []

    plog = log.bind(port=port, fw=fw_bin_path, opts=opts)
    plog.info("fwota.flash.start")

    # Pre-flash USB recovery: esptool is about to drive the reset on `port`. If
    # that port vanished (device on the bus but no ttyACM — failed
    # SET_CONFIGURATION / "descriptor read -110"), re-enumerate THIS device only
    # (sysfs `authorized` toggle — never a hub reset, so sibling receivers stay
    # up) and wait for the port. Best-effort + a no-op when the port is present.
    if not (ensure_port or usb_recovery.ensure_serial_enumerated)(port):
        plog.warning("fwota.usb_recovery.port_still_absent_continuing")

    write_argv: list[str] = [
        opts.esptool_path,
        "--chip", opts.chip,
        "--port", port,
        "--baud", str(opts.baud),
        "--before", "default-reset",
        "--after", "hard-reset",
        "write-flash",
        opts.flash_offset,
        fw_bin_path,
    ]
    try:
        rc, timed_out = await _run_esptool(
            write_argv,
            log_lines=log_lines,
            on_progress=on_progress,
            timeout_s=opts.flash_timeout_s,
            subprocess_factory=subprocess_factory,
        )
    except FileNotFoundError as exc:
        plog.error("fwota.flash.esptool_missing", error=str(exc))
        return FlashResult(
            state="failed_flash",
            elapsed_s=_now() - started,
            log=log_lines,
            error=f"esptool not found: {exc}",
        )

    if timed_out:
        plog.warning("fwota.flash.timeout", elapsed_s=_now() - started)
        return FlashResult(
            state="failed_timeout",
            elapsed_s=_now() - started,
            log=log_lines,
            error=f"esptool exceeded {opts.flash_timeout_s}s",
        )
    if rc != 0:
        plog.warning("fwota.flash.nonzero_exit", returncode=rc)
        # Real-world V4 behaviour: the first ``--before default-reset``
        # attempt often fails because the chip is mid-`micros()` and
        # esptool's DTR/RTS toggle can't sync. The failure ALSO drops
        # the chip into the USB-JTAG ROM bootloader (descriptor flips
        # to ``Espressif_USB_JTAG_serial_debug_unit_*``). Detect that
        # and retry against the new port — this is exactly the manual
        # recovery dance we have done on the bench.
        # Poll for the JTAG descriptor — chip can take ~5-15 s after a
        # failed esptool handshake to actually transition into the ROM
        # JTAG bootloader and re-enumerate. A one-shot glob after only
        # 5 s misses this window on slower chips (V4 job 12 transitioned
        # at ~7 s post-fail). Initial wait then poll every JTAG_DETECT_POLL_S
        # up to JTAG_DETECT_TOTAL_S.
        if sleep_fn is None:
            await asyncio.sleep(JTAG_RETRY_WAIT_S)
        else:
            await sleep_fn(JTAG_RETRY_WAIT_S)
        jtag_glob = "/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_*"
        jtag_deadline = _now() + (JTAG_DETECT_TOTAL_S - JTAG_RETRY_WAIT_S)
        jtag_ports: list[str] = sorted(glob_fn(jtag_glob))
        while not jtag_ports and _now() < jtag_deadline:
            if sleep_fn is None:
                await asyncio.sleep(JTAG_DETECT_POLL_S)
            else:
                await sleep_fn(JTAG_DETECT_POLL_S)
            jtag_ports = sorted(glob_fn(jtag_glob))
        if not jtag_ports:
            return FlashResult(
                state="failed_flash",
                elapsed_s=_now() - started,
                log=log_lines,
                error=(
                    f"esptool exited with code {rc}; no JTAG-bootloader "
                    f"descriptor appeared within {JTAG_DETECT_TOTAL_S}s"
                ),
            )
        jtag_port = jtag_ports[0]
        plog.info(
            "fwota.flash.jtag_descriptor_detected",
            jtag_port=jtag_port,
            wait_elapsed_s=_now() - started,
        )

        async def _retry_via_jtag(payload_path: str, *, label: str) -> tuple[int, bool]:
            """Helper to run one esptool invocation against the JTAG port.

            Encapsulated so the rollback path below can reuse the
            slower-baud / more-connect-attempts settings without
            duplicating the argv construction.
            """
            plog.info(
                "fwota.flash.retry_via_jtag_bootloader",
                jtag_port=jtag_port,
                label=label,
                baud=JTAG_RETRY_BAUD,
                connect_attempts=JTAG_CONNECT_ATTEMPTS,
            )
            retry_argv = [
                opts.esptool_path,
                "--chip", opts.chip,
                "--port", jtag_port,
                # Slower baud is more tolerant of flaky USB hubs on the
                # JTAG path. Application-side flashes still use opts.baud.
                "--baud", str(JTAG_RETRY_BAUD),
                "--connect-attempts", str(JTAG_CONNECT_ATTEMPTS),
                "--before", "default-reset",
                "--after", "hard-reset",
                "write-flash",
                opts.flash_offset,
                payload_path,
            ]
            return await _run_esptool(
                retry_argv,
                log_lines=log_lines,
                on_progress=on_progress,
                timeout_s=opts.flash_timeout_s,
                subprocess_factory=subprocess_factory,
            )

        try:
            rc2, timed_out2 = await _retry_via_jtag(fw_bin_path, label="primary")
        except FileNotFoundError as exc:
            return FlashResult(
                state="failed_flash",
                elapsed_s=_now() - started,
                log=log_lines,
                error=f"esptool not found on retry: {exc}",
            )
        if timed_out2:
            return FlashResult(
                state="failed_timeout",
                elapsed_s=_now() - started,
                log=log_lines,
                error=f"esptool retry exceeded {opts.flash_timeout_s}s",
            )
        if rc2 != 0:
            # Last-chance recovery: the requested firmware can't be
            # flashed (corrupt image, hardware regression, etc.) AND
            # the chip is stuck in JTAG bootloader. If the caller has
            # supplied a known-good rollback binary, flash THAT so the
            # chip comes back to a runnable state. Without this path
            # the chip stays bricked in bootloader mode until the
            # operator manually intervenes — which is exactly the
            # 2026-05-13 V4 incident we are hardening against.
            if rollback_fw_bin_path is not None:
                plog.warning(
                    "fwota.flash.rolling_back",
                    rc=rc2,
                    rollback_fw=rollback_fw_bin_path,
                )
                try:
                    rc3, timed_out3 = await _retry_via_jtag(
                        rollback_fw_bin_path, label="rollback"
                    )
                except FileNotFoundError as exc:
                    return FlashResult(
                        state="failed_flash",
                        elapsed_s=_now() - started,
                        log=log_lines,
                        error=f"esptool not found on rollback: {exc}",
                    )
                if not timed_out3 and rc3 == 0:
                    plog.info("fwota.flash.rollback_succeeded")
                    # Wait for runtime descriptor + verify so the
                    # caller sees a real success of the rollback path.
                    new_port_rb = await _await_reenum(
                        opts.runtime_glob,
                        timeout_s=opts.reenum_timeout_s,
                        deadline_start=_now(),
                        glob_fn=glob_fn,
                        sleep_fn=sleep_fn,
                    )
                    return FlashResult(
                        state="rolled_back_to_previous",
                        elapsed_s=_now() - started,
                        log=log_lines,
                        new_port=new_port_rb,
                        error=(
                            f"requested version failed (rc={rc2}); "
                            f"rolled back to previous via JTAG"
                        ),
                    )
            return FlashResult(
                state="failed_flash",
                elapsed_s=_now() - started,
                log=log_lines,
                error=f"esptool retry exited with code {rc2}",
            )
        # JTAG-path retry succeeded; fall through to the reenum loop.

    plog.info("fwota.flash.write_complete", awaiting_reenum_s=opts.reenum_timeout_s)
    new_port = await _await_reenum(
        opts.runtime_glob,
        timeout_s=opts.reenum_timeout_s,
        deadline_start=_now(),
        glob_fn=glob_fn,
        sleep_fn=sleep_fn,
    )
    if new_port is None:
        plog.warning("fwota.flash.no_reenum", glob=opts.runtime_glob)
        return FlashResult(
            state="failed_no_reenum",
            elapsed_s=_now() - started,
            log=log_lines,
            error=f"runtime CDC descriptor never reappeared at {opts.runtime_glob}",
        )

    plog.info("fwota.flash.reenum_seen", new_port=new_port)

    # Boot-stability check, replacing the destabilising esptool flash-id
    # verify step. The previous post-flash ``flash-id`` query issued its
    # own ``--before default-reset`` DTR/RTS dance, and the ESP32-S3
    # USB-CDC stack reliably mishandled the reset — every flash that
    # wrote successfully also "failed verify" and ended with the chip
    # bricked in JTAG bootloader. Replacing it with a passive
    # re-enumeration-still-present check: wait BOOT_STABILITY_WAIT_S
    # after reenum, then confirm the runtime descriptor is still present.
    # A boot-looping firmware will have crashed back into the JTAG
    # bootloader by then; a healthy firmware will still be enumerated.
    if sleep_fn is None:
        await asyncio.sleep(BOOT_STABILITY_WAIT_S)
    else:
        await sleep_fn(BOOT_STABILITY_WAIT_S)
    post_check_matches = sorted(glob_fn(opts.runtime_glob))
    if not post_check_matches:
        plog.warning(
            "fwota.flash.boot_unstable",
            new_port=new_port,
            stability_wait_s=BOOT_STABILITY_WAIT_S,
        )
        # Boot-loop: chip enumerated briefly then crashed back to
        # bootloader. If the caller supplied a rollback target, flash
        # it via the same JTAG path the dispatcher walked in on; the
        # ESP32-S3 should be in JTAG bootloader by now.
        if rollback_fw_bin_path is not None:
            jtag_glob = "/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_*"
            jtag_matches = sorted(glob_fn(jtag_glob))
            if jtag_matches:
                jtag_port = jtag_matches[0]
                plog.warning(
                    "fwota.flash.rolling_back_after_boot_loop",
                    rollback_fw=rollback_fw_bin_path,
                    jtag_port=jtag_port,
                )
                rollback_argv = [
                    opts.esptool_path,
                    "--chip", opts.chip,
                    "--port", jtag_port,
                    "--baud", str(JTAG_RETRY_BAUD),
                    "--connect-attempts", str(JTAG_CONNECT_ATTEMPTS),
                    "--before", "default-reset",
                    "--after", "hard-reset",
                    "write-flash",
                    opts.flash_offset,
                    rollback_fw_bin_path,
                ]
                try:
                    rb_rc, rb_timed_out = await _run_esptool(
                        rollback_argv,
                        log_lines=log_lines,
                        on_progress=on_progress,
                        timeout_s=opts.flash_timeout_s,
                        subprocess_factory=subprocess_factory,
                    )
                    if not rb_timed_out and rb_rc == 0:
                        plog.info("fwota.flash.rollback_succeeded")
                        rb_port = await _await_reenum(
                            opts.runtime_glob,
                            timeout_s=opts.reenum_timeout_s,
                            deadline_start=_now(),
                            glob_fn=glob_fn,
                            sleep_fn=sleep_fn,
                        )
                        return FlashResult(
                            state="rolled_back_to_previous",
                            elapsed_s=_now() - started,
                            log=log_lines,
                            new_port=rb_port,
                            error="requested firmware boot-looped; rolled back",
                        )
                except FileNotFoundError as exc:
                    plog.error("fwota.flash.rollback_esptool_missing", error=str(exc))
        return FlashResult(
            state="failed_boot_loop",
            elapsed_s=_now() - started,
            log=log_lines,
            new_port=new_port,
            error=(
                f"runtime CDC descriptor gone {BOOT_STABILITY_WAIT_S}s "
                "after reenum — firmware boot-looped"
            ),
        )
    plog.info("fwota.flash.boot_stable", new_port=new_port)

    elapsed = _now() - started
    plog.info("fwota.flash.success", elapsed_s=elapsed, new_port=new_port)
    return FlashResult(
        state="success",
        elapsed_s=elapsed,
        log=log_lines,
        new_port=new_port,
    )
