#!/bin/sh
# Build a 0x497 (STM32WLE5)-capable stm32flash and install it ahead of the
# Debian package in PATH. Debian's stm32flash 0.7 does not know device id
# 0x497, so it refuses the Wio-E5 OTA path ("Unknown/unsupported device").
# We add the one missing dev_table.c entry and rebuild. Idempotent; gcc-guarded
# (no-op if a toolchain isn't present — the Wio OTA path just stays unavailable
# on that gateway). Run by the portal postinst; safe to run by hand.
# MeshCore-TDOA — see the OpenBootloader serial-flash design (tools/openbl-wle5).
set -e
DEST="${1:-/usr/local/bin}"
TAG="[stm32flash-wle5]"

command -v gcc  >/dev/null 2>&1 || { echo "$TAG gcc not found; skipping build"; exit 0; }
command -v make >/dev/null 2>&1 || { echo "$TAG make not found; skipping build"; exit 0; }
command -v python3 >/dev/null 2>&1 || { echo "$TAG python3 not found; skipping build"; exit 0; }

# Already have a 0x497-capable stm32flash on PATH? then nothing to do.
if command -v stm32flash >/dev/null 2>&1 && \
   strings "$(command -v stm32flash)" 2>/dev/null | grep -q "STM32WLE5"; then
  echo "$TAG stm32flash already supports STM32WLE5; skipping"
  exit 0
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cd "$TMP"
URL="https://deb.debian.org/debian/pool/main/s/stm32flash/stm32flash_0.7.orig.tar.gz"
( curl -fsSL "$URL" -o s.tgz 2>/dev/null || wget -q "$URL" -O s.tgz ) || {
  echo "$TAG could not fetch stm32flash source (offline?); skipping"; exit 0; }
tar xzf s.tgz
cd stm32flash-0.7

# Activate + fill the commented-out 0x497 placeholder in the device table.
python3 - <<'PY'
import re
f = "dev_table.c"
s = open(f).read()
entry = ('\t{0x497, "STM32WLE5xx/WL55xx", 0x20002000, 0x20010000, '
         '0x08000000, 0x08040000,  1, p_2k  , 0x1FFF7800, 0x1FFF787F, '
         '0x1FFF0000, 0x1FFF4000, 0},')
s2 = re.sub(r"/\*\s*\{0x497,.*?\*/", entry, s, count=1)
if s2 == s:
    raise SystemExit("0x497 placeholder not found in dev_table.c")
open(f, "w").write(s2)
PY

make >/dev/null 2>&1
install -d "$DEST"
install -m 0755 stm32flash "$DEST/stm32flash"
echo "$TAG installed 0x497-capable stm32flash -> $DEST/stm32flash"
