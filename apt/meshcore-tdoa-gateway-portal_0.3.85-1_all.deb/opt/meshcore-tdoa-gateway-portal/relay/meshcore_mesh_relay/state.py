"""Per-gateway state cache for the on8ar /status broadcast path.

The on8ar canonical /status envelope (mirrored from mctomqtt nodes
already on the broker — BE-JBE-ETG-O1, NL-VNR-OBS, etc.) carries:

    model, radio, stats{battery_mv,uptime_secs,last_rssi,last_snr,…},
    origin, origin_id, status="online", timestamp,
    client_version, firmware_version

Most of those values arrive on separate bridge topics:

    /info       — model, radio, firmware_version, client_version,
                  buildDatePrefix (every 5 min)
    /telemetry  — battery, uptime, gps_sats, pps_jitter,
                  mcu_temp, radio_temp (every 5 s)
    /uplink     — last_rssi, last_snr (every RX)

To assemble a complete /status envelope we cache the most recent value
of each, keyed by gateway_id. Lookups are O(1); the cache is small
(handful of gateways) and the writers (paho-MQTT callbacks from
input_mqtt.py) compete with one reader (the periodic publisher in
__main__.py), so a single threading.Lock is sufficient.

NULL fields propagate as-is — the on8ar formatter omits keys whose
source value is None so an empty cache slot doesn't poison the
status envelope with literal "null" strings.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any


logger = logging.getLogger(__name__)


@dataclass
class _GatewayEntry:
    """Per-gateway snapshot of every field we want to surface on /status."""

    # Populated from 0x94 GATEWAY_INFO frames (bridge's /info topic).
    hardware: dict[str, Any] = field(default_factory=dict)
    # Populated from 0x96 DEVICE_TELEMETRY frames (bridge's /telemetry topic).
    telemetry: dict[str, Any] = field(default_factory=dict)
    # Last RSSI / SNR from any /uplink envelope this gateway forwarded.
    last_rssi: float | None = None
    last_snr: float | None = None
    # display_name resolved by the bridge (operator-set port-names.json).
    # When set on /info this fills the on8ar `origin` per-gateway.
    display_name: str | None = None
    # Full 32-byte pubkey of the gateway, hex. Set from /uplink envelopes
    # (meta.pubkey_hex). Used by the per-device /status path so each
    # receiver heartbeats with its own origin_id rather than the relay's
    # single primary identity.
    pubkey_hex: str | None = None
    # Monotonic when we last published a /status for this gateway.
    # The publisher loop uses this to throttle the 60 s heartbeat.
    last_status_pub_at: float = 0.0
    # Wall-clock when we last heard *anything* about this gateway.
    # If we go > ~10 min without a packet/info/telemetry we treat the
    # gateway as offline and skip the status heartbeat (the on8ar
    # convention is that offline nodes simply stop publishing).
    last_seen_at: float = 0.0


class GatewayCache:
    """Thread-safe per-gateway hardware/telemetry/rssi cache.

    The cache is the single source of truth for the on8ar /status
    formatter. All public methods are safe to call from any thread.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._entries: dict[str, _GatewayEntry] = {}

    # ------- writers -------

    def update_hardware(self, gateway_id: str, hardware: dict[str, Any], *,
                        display_name: str | None = None) -> None:
        """Refresh the hardware block from a /info envelope.

        The full hardware dict is stored verbatim; the on8ar formatter
        picks the keys it needs (boardName, firmwareVersion, portalVersion,
        radio.*, buildDatePrefix). Other keys (tdoaFirmwareVersion,
        capabilities, operator-hardware) are kept for future use but
        deliberately not surfaced to on8ar.
        """
        if not gateway_id or not isinstance(hardware, dict):
            return
        now = time.monotonic()
        with self._lock:
            e = self._entries.setdefault(gateway_id, _GatewayEntry())
            e.hardware = dict(hardware)
            if display_name:
                e.display_name = display_name
            e.last_seen_at = now

    def update_telemetry(self, gateway_id: str, telemetry: dict[str, Any]) -> None:
        """Refresh the telemetry block from a /telemetry envelope."""
        if not gateway_id or not isinstance(telemetry, dict):
            return
        now = time.monotonic()
        with self._lock:
            e = self._entries.setdefault(gateway_id, _GatewayEntry())
            e.telemetry = dict(telemetry)
            e.last_seen_at = now

    def note_packet(self, gateway_id: str, *, rssi: float | None,
                    snr: float | None,
                    display_name: str | None = None,
                    pubkey_hex: str | None = None) -> None:
        """Record RX RSSI/SNR for this gateway, plus optional identity refresh.

        Called from every /uplink forward so the on8ar /status envelope's
        ``stats.last_rssi`` / ``stats.last_snr`` track real RF activity.
        The optional identity args let the uplink path keep ``display_name``
        + ``pubkey_hex`` fresh (the /uplink envelope is the only stream that
        carries the full pubkey — /info doesn't).
        """
        if not gateway_id:
            return
        now = time.monotonic()
        with self._lock:
            e = self._entries.setdefault(gateway_id, _GatewayEntry())
            if rssi is not None:
                e.last_rssi = float(rssi)
            if snr is not None:
                e.last_snr = float(snr)
            if display_name:
                e.display_name = display_name
            if pubkey_hex:
                e.pubkey_hex = pubkey_hex
            e.last_seen_at = now

    def mark_status_published(self, gateway_id: str) -> None:
        """Stamp the monotonic clock so the periodic publisher can throttle.

        The publisher walks the cache every loop tick; this guard keeps
        each gateway's /status emit-rate at most once per 60 s (configured
        in __main__.py).
        """
        if not gateway_id:
            return
        now = time.monotonic()
        with self._lock:
            e = self._entries.setdefault(gateway_id, _GatewayEntry())
            e.last_status_pub_at = now

    # ------- readers -------

    def snapshot(self, gateway_id: str) -> dict[str, Any] | None:
        """Return a copy of one gateway's cached state, or None if unknown.

        The dict shape is the one the on8ar formatter consumes — flat
        keys for the per-gateway fields plus the nested hardware /
        telemetry blocks unchanged.
        """
        with self._lock:
            e = self._entries.get(gateway_id)
            if e is None:
                return None
            return {
                "gateway_id": gateway_id,
                "hardware": dict(e.hardware),
                "telemetry": dict(e.telemetry),
                "last_rssi": e.last_rssi,
                "last_snr": e.last_snr,
                "display_name": e.display_name,
                "pubkey_hex": e.pubkey_hex,
                "last_status_pub_at": e.last_status_pub_at,
                "last_seen_at": e.last_seen_at,
            }

    def gateways_due_for_status(self, *, heartbeat_secs: float,
                                offline_after_secs: float) -> list[str]:
        """Return gateway_ids whose /status should be re-published now.

        A gateway is "due" when its last status publish was more than
        ``heartbeat_secs`` ago AND we've heard something from it within
        ``offline_after_secs`` (no point heartbeating a node we've not
        seen — on8ar consumers infer "offline" from absence).
        """
        now = time.monotonic()
        due: list[str] = []
        with self._lock:
            for gw_id, e in self._entries.items():
                if now - e.last_seen_at > offline_after_secs:
                    continue
                if now - e.last_status_pub_at >= heartbeat_secs:
                    due.append(gw_id)
        return due
