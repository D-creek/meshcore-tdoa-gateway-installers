"""meshcore-mesh-relay — TDOA-bridge MQTT → legacy broker fan-out.

Background: the SkyPi4 Heltec V4 OLED was repurposed as a TDOA receiver, so
the `meshcore-tdoa-gateway-bridge` now exclusively owns its USB-CDC serial
and publishes only to the TDOA broker (tdoa.dahllie.nl:1884). The legacy
`mctomqtt` Node-shaped Python daemon that previously fanned the same
node's mesh traffic out to local-mqtt + letsmesh-us + meshrank + emqx-public
(on8ar.eu) is now starved — no serial input.

This sidecar restores the legacy fan-out without touching the serial port:

  bridge -> tdoa.dahllie.nl (existing)
                 |
                 v (also subscribed by us)
       meshcore-mesh-relay   <-- this package
                 |
                 +-> local-mqtt   (mctomqtt format)
                 +-> letsmesh-us  (mctomqtt format)
                 +-> meshrank     (mctomqtt format)
                 +-> emqx-public  (mctomqtt format, on8ar.eu)

TDOA-specific frames (0x90/0x92/0x94/0x96/0x9A) are deliberately NOT
republished — those belong to the TDOA broker only. We only forward the
underlying mesh content recovered from each 0x90 envelope's
``meta.raw_packet_hex`` field.
"""

__version__ = "0.2.13"
