"""Subscribe to the TDOA-bridge's prod MQTT output and yield 0x90 envelopes.

The bridge publishes one JSON message per parsed 0x90 to
``gateway/<port_slug>/uplink`` on ``tdoa.dahllie.nl:1884`` (or whichever
broker the bridge is pointed at — passed in as args). We subscribe with
a single client, queue every uplink message, and let the main loop pull
+ fan them out.

Why subscribe to the upstream broker rather than tee from the bridge
locally: the SkyPi4 IS already publishing there, so the network path is
the same one the bridge uses; no co-located mosquitto needed and the
bridge code stays untouched. Trade-off: relay traffic transits the
internet (SkyPi4 → tdoa.dahllie.nl → SkyPi4 → external brokers) — fine
for our packet rate (<10/s peak) and obvious in tcpdump if it matters.
"""
from __future__ import annotations

import json
import logging
import queue
import ssl
import threading
from dataclasses import dataclass
from typing import Any

import paho.mqtt.client as mqtt


logger = logging.getLogger(__name__)


@dataclass
class InputBrokerSettings:
    """Connection info for the upstream TDOA broker (one connection)."""

    host: str
    port: int
    username: str | None
    password: str | None
    tls: bool
    # /uplink filter (legacy field name — kept so --input-topic still works).
    topic_filter: str
    # Additional inputs for the on8ar /status path (v0.2). When None,
    # the subscriber skips them — the relay falls back to /uplink-only
    # behaviour identical to v0.1.
    info_topic_filter: str | None = "gateway/+/info"
    telemetry_topic_filter: str | None = "gateway/+/telemetry"
    client_id: str = "meshcore-mesh-relay-in"
    # 2026-05-26: paho transport. "tcp" (default — back-compatible with
    # the v0.2 relay.env) or "websockets" — needed for the homeprod
    # broker at mqtt.dahllie.nl:443 (CF-fronted WSS+TLS) after the
    # TransIP-hosted plaintext broker was retired.
    transport: str = "tcp"


# Synthetic keys we attach to envelopes BEFORE queueing so the main
# loop can route by topic kind without re-parsing. Underscored to
# advertise "relay-only field, never serialise downstream".
_RELAY_KIND_KEY = "_relay_topic_kind"
_RELAY_GW_KEY = "_relay_gateway_id"


def _kind_from_topic(topic: str) -> str:
    """Map `gateway/<slug>/<event>` → ``"uplink"`` / ``"info"`` / ``"telemetry"``.

    Returns ``""`` on any topic that doesn't fit the canonical 3-segment
    bridge layout — caller drops the message.
    """
    parts = topic.split("/")
    if len(parts) < 3 or parts[0] != "gateway":
        return ""
    suffix = parts[-1]
    if suffix in ("uplink", "info", "telemetry"):
        return suffix
    return ""


def _gateway_id_from_topic(topic: str) -> str:
    """Extract the `<slug>` from `gateway/<slug>/<event>`."""
    parts = topic.split("/")
    if len(parts) >= 3 and parts[0] == "gateway":
        return parts[1]
    return ""


class UplinkSubscriber:
    """Background MQTT subscriber. Pull envelopes via ``next_envelope()``."""

    def __init__(self, settings: InputBrokerSettings, *, max_queue: int = 1024) -> None:
        self._s = settings
        self._q: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=max_queue)
        # 2026-05-26: thread transport so WSS reaches mqtt.dahllie.nl:443.
        transport = (getattr(settings, "transport", "tcp") or "tcp").lower()
        self._client = mqtt.Client(
            client_id=settings.client_id,
            clean_session=True,
            transport=transport,
        )
        if settings.username:
            self._client.username_pw_set(settings.username, settings.password or "")
        if settings.tls:
            self._client.tls_set(cert_reqs=ssl.CERT_REQUIRED)
        self._client.on_connect = self._on_connect
        self._client.on_message = self._on_message
        self._client.on_disconnect = self._on_disconnect
        self._stop_evt = threading.Event()

    def start(self) -> None:
        """Connect + start the paho network loop in a background thread."""
        topics = [self._s.topic_filter]
        if self._s.info_topic_filter:
            topics.append(self._s.info_topic_filter)
        if self._s.telemetry_topic_filter:
            topics.append(self._s.telemetry_topic_filter)
        logger.info("input.connecting host=%s port=%s topics=%s",
                    self._s.host, self._s.port, topics)
        self._client.connect_async(self._s.host, self._s.port, keepalive=60)
        self._client.loop_start()

    def stop(self) -> None:
        self._stop_evt.set()
        try:
            self._client.loop_stop()
            self._client.disconnect()
        except Exception:  # noqa: BLE001
            pass

    def next_envelope(self, timeout: float | None = None) -> dict[str, Any] | None:
        """Block up to ``timeout`` seconds for the next envelope; None on timeout."""
        try:
            return self._q.get(timeout=timeout)
        except queue.Empty:
            return None

    # ------- paho callbacks -------

    def _on_connect(self, _c: mqtt.Client, _u: Any, _f: Any, rc: int) -> None:
        if rc == 0:
            logger.info("input.connected rc=%s", rc)
            # Batch-subscribe so a slow individual call can't leak between
            # reconnect cycles. Each filter has its own QoS=0.
            subs = [(self._s.topic_filter, 0)]
            if self._s.info_topic_filter:
                subs.append((self._s.info_topic_filter, 0))
            if self._s.telemetry_topic_filter:
                subs.append((self._s.telemetry_topic_filter, 0))
            self._client.subscribe(subs)
        else:
            logger.warning("input.connect_failed rc=%s", rc)

    def _on_disconnect(self, _c: mqtt.Client, _u: Any, rc: int) -> None:
        if rc != 0:
            logger.warning("input.disconnected rc=%s (auto-reconnect)", rc)

    def _on_message(self, _c: mqtt.Client, _u: Any, msg: mqtt.MQTTMessage) -> None:
        kind = _kind_from_topic(msg.topic)
        if not kind:
            logger.debug("input.unknown_topic topic=%s", msg.topic)
            return
        try:
            envelope = json.loads(msg.payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            logger.debug("input.bad_json topic=%s error=%s", msg.topic, exc)
            return
        if not isinstance(envelope, dict):
            logger.debug("input.envelope_not_dict topic=%s", msg.topic)
            return
        # Tag with synthetic keys the main loop uses to route. Stripped
        # by formatters before any downstream broker sees the payload.
        envelope[_RELAY_KIND_KEY] = kind
        envelope[_RELAY_GW_KEY] = _gateway_id_from_topic(msg.topic)
        try:
            self._q.put_nowait(envelope)
        except queue.Full:
            # Bias towards freshness — drop oldest, push new. Saves us
            # from a permanently backed-up queue if downstream brokers
            # are slow.
            try:
                self._q.get_nowait()
            except queue.Empty:
                pass
            try:
                self._q.put_nowait(envelope)
            except queue.Full:
                logger.warning("input.queue_full_dropped topic=%s", msg.topic)
