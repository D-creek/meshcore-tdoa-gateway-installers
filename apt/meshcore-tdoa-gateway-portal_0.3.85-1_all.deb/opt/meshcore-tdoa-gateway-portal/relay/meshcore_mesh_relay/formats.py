"""Build a mesh-only subset of the TDOA-bridge envelope for non-TDOA brokers.

The user's rule (2026-05-16): "publish to all brokers, but only TDOA-specific
details to the TDOA server." So when fanning out to `on8ar.eu`, `letsmesh-us`,
`meshrank`, `local-mqtt`, we MUST strip the TDOA-only timing fields
(``cc_packet``, ``cc_pps``, ``ppsIntervalUs``, ``fractionalSecond``,
``freqErrorHz``, ``countsSincePps``, ``rxIrqMicros``, ``fineTimeSinceGpsEpoch``).

What we keep:
- ``gateway_id`` / ``node_id_hex`` — which gateway received it
- ``rssi`` / ``snr`` — RF quality, useful on every broker
- ``tx_display_name`` / ``tx_pubkey_hex`` — who sent it (when known)
- ``embedded_packet_hash`` / ``last_hop_hash`` — content + route identifiers
- ``pps_locked`` / ``gps_3d_fix`` — boolean status, not timing
- ``sat_count`` — coarse signal quality, not TDOA-precision
- ``raw_packet_hex`` — only present for adverts (via 0x9A AUX); when present
  it's the actual LoRa wire bytes downstream consumers can decode further
- ``received_at`` — wall-clock receive timestamp

Wire-format note: this is NOT byte-for-byte compatible with the legacy
mctomqtt JSON (which carried `type=PACKET`, mctomqtt-specific timestamps,
etc.). Operators consuming on8ar.eu will see a richer but differently
shaped object. A full mctomqtt-format adapter requires the firmware's
text-debug stream (MESH_PACKET_LOGGING=1 lines) which the bridge currently
doesn't capture — separate follow-up.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any


logger = logging.getLogger(__name__)


# Allowlist of meta keys to forward. Easier to read + safer than a denylist
# (new TDOA-leaking fields added to the bridge won't accidentally leak
# through).
_MESH_META_KEYS = {
    "node_id_hex",
    "tx_display_name",
    "tx_pubkey_hex",
    "embeddedPacketHash",
    "lastHopHash",
    "ppsLocked",
    "gps3dFix",
    "satCount",
    "raw_packet_hex",  # only set for adverts (0x9A AUX caching)
    "originalHeader",
    "pathLenByte",
    "freq_hz",
    "bandwidth_hz",
    "spread_factor",
    "coderate",
    "source",
}

# Explicit denylist (defensive — kept in sync with the bridge envelope
# fields we know are TDOA-only).
_TDOA_META_KEYS = {
    "rxIrqMicros",
    "ccPacket",
    "ccPps",
    "freqErrorHz",
    "countsSincePps",
    "ppsIntervalUs",
    "fractionalSecond",
    "mqtt_client_id",  # bridge metadata, internal
}


def envelope_to_mesh_subset(
    envelope: dict[str, Any],
    *,
    repeater_name: str,
    repeater_pub_key: str,
) -> dict[str, Any]:
    """Return a TDOA-stripped copy of the envelope safe for public brokers."""
    meta_in = envelope.get("meta") or {}
    meta_out: dict[str, Any] = {}
    for k, v in meta_in.items():
        if k in _TDOA_META_KEYS:
            continue
        if k in _MESH_META_KEYS:
            meta_out[k] = v
        # Any unrecognised key is dropped by default (fail-closed).

    rx_in = (envelope.get("rxInfo") or [{}])[0]
    rx_out = {
        "rssi": rx_in.get("rssi"),
        "snr": rx_in.get("snr"),
        # fineTimeSinceGpsEpoch is TDOA-only → dropped on purpose.
    }

    return {
        "gateway_id": envelope.get("gatewayId") or meta_in.get("node_id_hex"),
        "repeater_name": repeater_name,
        "repeater_pub_key": repeater_pub_key,
        "received_at": datetime.now(timezone.utc).isoformat(),
        "rx": rx_out,
        "meta": meta_out,
    }


def serialise(payload: dict[str, Any]) -> bytes:
    """JSON-encode for an MQTT publish — bytes, UTF-8."""
    return json.dumps(payload, separators=(",", ":")).encode("utf-8")


# ---------------------------------------------------------------------------
# on8ar canonical (mctomqtt-style) formatters.
#
# Used ONLY when the destination broker's broker_kind is "emqx-public"
# (today: emqx.on8ar.eu). Other brokers continue receiving the leaner
# envelope_to_mesh_subset shape above.
#
# Shape was derived empirically from a few hours of subscribing to the
# broker and observing what every other peer publishes — same key set,
# all values as JSON strings (so the broker's dashboards index them
# uniformly).
# ---------------------------------------------------------------------------

# Explicit denylist for the on8ar canonical path. Same fields stripped
# in envelope_to_mesh_subset, restated here so a unit test can assert
# none of them appear in the on8ar payload regardless of formatter
# path.
_TDOA_FIELDS = (
    "ccPacket",
    "ccPps",
    "freqErrorHz",
    "countsSincePps",
    "ppsIntervalUs",
    "fractionalSecond",
    "rxIrqMicros",
    "ccPacketPreamble",
    "anchorEdgesSeen",
    "mqtt_client_id",
)


def _packet_score(rssi: float, snr: float) -> int:
    """Match the firmware's `radio->packetScore` shape.

    on8ar samples show ~890 for (rssi=-69, snr=11). Empirical fit
    against published peer envelopes:
        score = clamp((200 + rssi) * 6 + snr * 30, 0, 1000)
    For (-69, 11): (131 * 6) + (11 * 30) = 786 + 330 = 1116 → clamped 1000;
    on8ar shows 890, so a slightly tamer coefficient fits better. Use
    a heuristic that yields the right order of magnitude — operators
    care about ranking, not exact match.
    """
    raw = (200.0 + float(rssi)) * 5.0 + float(snr) * 25.0
    return int(max(0, min(1000, round(raw))))


def _pad_pubkey(node_id_hex: str | None, tx_pubkey_hex: str | None) -> str:
    """mctomqtt-style origin_id resolution.

    Returns the SENDER's full 64-hex pubkey when the bridge has resolved
    it (advert receptions or receivers that previously heard one — see
    bridge `tx_pubkey_hex` meta field), otherwise returns "" so consumers
    can distinguish "sender resolved" from "sender unknown".

    The earlier behaviour zero-padded the GATEWAY's 6-byte node_id when
    the sender was unknown, which made every relayed packet look like it
    originated from our own gateway's prefix. mctomqtt-style is honest:
    if we don't know the sender, the field is empty.

    ``node_id_hex`` is accepted for API stability (callers pass it) but
    deliberately NOT used as a fall-back source — it is the receiver, not
    the sender. Kept in the signature so existing call sites compile;
    will be removed in a future version once all callers drop it.
    """
    if tx_pubkey_hex:
        s = tx_pubkey_hex.strip()
        if len(s) >= 64:
            return s[:64].upper()
        return (s + "0" * (64 - len(s))).upper()
    # No sender pubkey known — mctomqtt-style empty rather than a
    # misleading gateway-id pad. ``node_id_hex`` intentionally ignored.
    _ = node_id_hex
    return ""


def _origin_label(tx_display_name: str | None, tx_pubkey_hex: str | None) -> str:
    """on8ar ``origin`` field with sane fallbacks.

    Resolution order:

    1. ``tx_display_name`` — the bridge-firmware-cached display name
       (populated when the receiver has previously decoded an ADVERT
       from this sender).
    2. ``"@<first 8 hex of tx_pubkey>"`` — pubkey-derived stable label.
       Lets on8ar consumers attribute the packet consistently while
       the bridge cache catches up. Matches on8ar UI convention for
       hash-prefix references.
    3. ``"Unknown"`` — final fallback for packets carrying neither a
       cached name nor a pubkey (synthetic / malformed frames).

    Prior to 2026-05-20 the implementation fell through to "Unknown"
    on every cache-miss, which made the operator's own node appear as
    "Unknown" on on8ar between ADVERT broadcasts.
    """
    name = (tx_display_name or "").strip()
    if name:
        return name
    pk = (tx_pubkey_hex or "").strip()
    if len(pk) >= 8:
        return f"@{pk[:8].lower()}"
    return "Unknown"


def _route_letter(original_header: Any) -> str:
    """LoRa header bits 0-1 → 'F' (flood) / 'D' (direct) / 'U' (unknown)."""
    if original_header is None:
        return "U"
    try:
        bits = int(original_header) & 0x03
    except (TypeError, ValueError):
        return "U"
    if bits == 0:
        return "F"
    if bits == 3:
        return "D"
    return "U"


def _packet_type(original_header: Any) -> str:
    """LoRa header byte's payload-type nibble as a string."""
    if original_header is None:
        return "0"
    try:
        return str((int(original_header) >> 2) & 0x0F)
    except (TypeError, ValueError):
        return "0"


def envelope_to_on8ar_packet(
    envelope: dict[str, Any],
    *,
    repeater_name: str,
    repeater_pub_key: str,
) -> dict[str, Any]:
    """Return an on8ar canonical /packets dict for one 0x90 RX envelope.

    All values are JSON strings to match the canonical shape exactly
    (on8ar samples carry ``"len":"150"``, ``"score":"890"`` — integers
    are stringified). The returned dict has no None values.

    The TDOA-only timing fields (cc_packet, cc_pps, freq_error_hz, etc.)
    are NEVER copied out of the input envelope. The unit test
    ``test_envelope_to_on8ar_packet_strips_tdoa_fields`` enforces this.

    2026-05-21 (mctomqtt-parity): ``origin`` is the LOCAL repeater's name
    (always known from config), NOT the TX-er's resolved display name.
    This matches Cisien/meshcoretomqtt's ``message_parser.py`` which sets
    ``origin = state.repeater_name`` + ``origin_id = state.repeater_pub_key``
    on every publish — the broker's "origin" field means "which repeater
    observed this packet", not "who sent the original". TX-er identity
    travels in the ``raw`` bytes for downstream decoders that want it.
    Reverts a regression where we resolved tx_display_name into origin
    and ended up publishing ``@<pubkey-prefix>`` whenever an ADVERT
    hadn't been decoded yet.

    2026-05-30 (firmware-node_name source): ``origin`` now prefers the
    envelope's ``gatewayId`` over the static ``repeater_name`` config
    value. The bridge populates ``gatewayId`` from
    ``/etc/meshcore-bridge/port-names.json``, which the portal keeps in
    sync with the firmware's NVS-stored ``node_name`` (what the node
    broadcasts in ADVERTs). This makes the on8ar ``origin`` track the
    firmware-side identity automatically — matching upstream
    mctomqtt's "query node_name from the connected node at startup"
    contract — without requiring a per-device-config edit. The static
    ``repeater_name`` from RelayConfig remains as a defensive fallback
    for legacy bridges that don't set ``gatewayId``, or for hand-
    injected test envelopes.
    """
    meta = envelope.get("meta") or {}
    rx = (envelope.get("rxInfo") or [{}])[0]
    now = datetime.now()  # local time, matches on8ar samples

    rssi = rx.get("rssi")
    snr = rx.get("snr")
    if rssi is None:
        rssi_str = ""
    else:
        rssi_str = str(int(round(float(rssi))))
    if snr is None:
        snr_str = ""
    else:
        # 2026-05-27: mctomqtt's regex for SNR is ``-?\d+`` (integer
        # only). Floats like ``"4.5"`` failed downstream regex-parse on
        # at least one on8ar consumer. Match the reference exporter by
        # rounding to integer dB; sub-dB precision is lost but the SNR
        # field is already advisory (the raw float is preserved in
        # mesh_bytes for internal consumers).
        snr_str = str(int(round(float(snr))))
    score_str = (
        str(_packet_score(rssi, snr))
        if rssi is not None and snr is not None
        else "0"
    )

    raw_hex = meta.get("raw_packet_hex") or ""
    raw_upper = raw_hex.upper() if isinstance(raw_hex, str) else ""

    # `%-d` (no-leading-zero day) is Linux-only — Windows tests choke on
    # the format spec. Format the date manually so the same code passes
    # local CI and matches the on8ar sample shape (e.g. "5/8/2026").
    date_str = f"{now.day}/{now.month}/{now.year}"
    # mctomqtt-parity: origin/origin_id identify THIS repeater (the
    # observer of the packet), not the TX-er. Pad the pubkey to 64 hex
    # so on8ar's identity-matching code doesn't have to handle short
    # forms — mctomqtt always sends the full key.
    origin_id_padded = repeater_pub_key.upper() if repeater_pub_key else ""
    if origin_id_padded and len(origin_id_padded) < 64:
        origin_id_padded = (origin_id_padded + "0" * (64 - len(origin_id_padded))).upper()
    # 2026-05-30: prefer the envelope's gatewayId (bridge-resolved from
    # port-names.json → firmware node_name) over the static
    # config-derived repeater_name. See docstring "firmware-node_name
    # source" section. repeater_name stays as a defensive fallback.
    envelope_gateway_id = envelope.get("gatewayId")
    origin_value = envelope_gateway_id or repeater_name or "Unknown"
    out: dict[str, Any] = {
        "type": "PACKET",
        "direction": "rx",
        "date": date_str,
        "time": now.strftime("%H:%M:%S"),
        "timestamp": now.isoformat(timespec="microseconds"),
        "origin": origin_value,
        "origin_id": origin_id_padded,
        "hash": (meta.get("embeddedPacketHash") or "").upper(),
        "route": _route_letter(meta.get("originalHeader")),
        "RSSI": rssi_str,
        "SNR": snr_str,
        "score": score_str,
        "duration": "0",  # airtime computation deferred (v0.2)
        "packet_type": _packet_type(meta.get("originalHeader")),
    }
    # 2026-05-27: mctomqtt emits ``path`` only when route == "D" (Direct
    # — single-hop path field is meaningful). For "F" (Flood) and "U"
    # (Unicast) the field is omitted; downstream consumers treat its
    # presence as a routing-mode hint. Was previously emitted on any
    # non-empty ``lastHopHash``, which made our envelopes diverge from
    # the on8ar reference shape for flood-routed packets.
    last_hop = meta.get("lastHopHash")
    if last_hop and out["route"] == "D":
        out["path"] = str(last_hop).upper()
    if raw_upper:
        out["raw"] = raw_upper
        # len is byte count of the raw packet
        out["len"] = str(len(raw_upper) // 2)
        # payload_len = total len minus header bytes (1) minus path_len
        # (variable, encoded in pathLenByte). High 2 bits = hash size,
        # low 6 = hop count. We do a best-effort estimate; legacy frames
        # with missing pathLenByte fall back to len - 1.
        path_len_byte = meta.get("pathLenByte")
        header_overhead = 1
        if isinstance(path_len_byte, int):
            hash_size = ((path_len_byte >> 6) & 0x03) + 1
            hop_count = path_len_byte & 0x3F
            header_overhead += 1 + hash_size * hop_count
        payload_len_int = max(0, (len(raw_upper) // 2) - header_overhead)
        out["payload_len"] = str(payload_len_int)
    return out


def _format_radio(hardware_radio: dict[str, Any] | None) -> str:
    """`hardware.radio` dict → on8ar canonical `"freq_mhz,bw_khz,sf,cr"` string.

    on8ar samples: ``"869.618,62.5,8,8"``. Our bridge emits
    ``freqHz`` in Hz (869618000) and ``bwHz`` in Hz (62500); convert
    to the human-readable units on the way out.

    2026-05-24 — added plausibility validation against the LoRa PHY
    envelope so a contaminated gateway-info cache (from pre-filter
    garbage 0x94 frames) can't leak nonsense values into the on8ar /
    meshrank status publishes. Observed garbage in the wild:
    ``168.107778 MHz``, ``3226.2 kHz bandwidth``, ``SF=93``, ``CR=147``.
    Defense-in-depth — the bridge's 0x94 filter (frame.py) now blocks
    these upstream too, but the cache may still hold stale bad values
    from before the filter shipped.
    """
    if not isinstance(hardware_radio, dict):
        return ""
    freq_hz = hardware_radio.get("freqHz")
    bw_hz = hardware_radio.get("bwHz")
    sf = hardware_radio.get("sf")
    cr = hardware_radio.get("cr")
    if freq_hz is None or bw_hz is None or sf is None or cr is None:
        return ""
    try:
        freq_hz_f = float(freq_hz)
        bw_hz_f = float(bw_hz)
        sf_i = int(sf)
        cr_i = int(cr)
    except (TypeError, ValueError):
        return ""
    # LoRa-physics validation. EU868 / US915 / AS923 cover ~400 MHz to
    # ~960 MHz; anything outside [100 MHz, 2.5 GHz] is impossible for a
    # SX126x at our antenna. BW must be one of the SX126x-supported
    # values (62.5/125/250/500 kHz) — accept anything ≤ 500 kHz to be
    # tolerant. SF: 5..12. CR denominator: 5..8.
    if not (100_000_000 <= freq_hz_f <= 2_500_000_000):
        return ""
    if not (0 < bw_hz_f <= 500_000):
        return ""
    if not (5 <= sf_i <= 12):
        return ""
    if not (5 <= cr_i <= 8):
        return ""
    freq_mhz = freq_hz_f / 1_000_000.0
    bw_khz = bw_hz_f / 1_000.0
    # Strip trailing zeros from the decimals so output matches on8ar
    # convention ("869.618" not "869.618000").
    freq_str = f"{freq_mhz:.6f}".rstrip("0").rstrip(".")
    bw_str = f"{bw_khz:.3f}".rstrip("0").rstrip(".")
    return f"{freq_str},{bw_str},{sf_i},{cr_i}"


def _format_firmware_version(hardware: dict[str, Any]) -> str:
    """Combined ``<upstream-MeshCore> / <TDOA-fork>`` version string.

    Reads BOTH ``hardware.firmwareVersion`` (the upstream MeshCore
    release this fork is based on, e.g. ``"v1.15.0"``) and
    ``hardware.tdoaFirmwareVersion`` (our fork string, e.g.
    ``"tdoa-1.12.11"``) and joins them with `` / ``. Operator rule
    (revised twice on 2026-05-20 — once to combine the values, once
    to switch the separator from `` - `` to `` / `` for visual
    clarity on the on8ar dashboards).

    Output shape, ordered by what each field is populated:
      both:        ``"v1.15.0 / tdoa-1.12.11"``
      upstream-only: ``"v1.15.0"``
      tdoa-only:   ``"tdoa-1.12.11"``  (rare; firmware predates KAN-129)
      neither:     ``""``

    When the bridge knows the build-date prefix, append it once at
    the end so it qualifies the combined string:
      ``"v1.15.0 / tdoa-1.12.11 (Build: 19-Apr-2026)"``.
    """
    upstream = (hardware.get("firmwareVersion") or "").strip()
    tdoa = (hardware.get("tdoaFirmwareVersion") or "").strip()
    # 2026-05-24 — shape validation. Reject obvious garbage from a stale
    # gateway-info cache (pre-filter days saw firmware_version land on
    # ``"(type=0, route= / F, payload_len=2"`` and hash-pair strings).
    # ``upstream`` must look like ``v<digit>...`` (MeshCore upstream tag
    # convention); ``tdoa`` must start with ``tdoa-<digit>``. Mirrors the
    # bridge-side filter in frame.py so contaminated values can't leak
    # out via the relay even if they slip through the upstream cache.
    if upstream and not (len(upstream) >= 2 and upstream[0] == "v" and upstream[1].isdigit()):
        upstream = ""
    if tdoa and not (tdoa.startswith("tdoa-") and len(tdoa) > 5 and tdoa[5].isdigit()):
        tdoa = ""
    if upstream and tdoa:
        combined = f"{upstream} / {tdoa}"
    elif upstream:
        combined = upstream
    elif tdoa:
        combined = tdoa
    else:
        return ""
    # The firmware ships only the first 4 bytes of its compile-time
    # __DATE__ string in 0x94's body (struct fmt `4s`), so today's
    # bridge envelopes carry strings like "19 A" — useless and
    # actively confusing once formatted as "(Build: 19 A)". Suppress
    # the suffix when the value is too short to be a real DD-MMM-YYYY
    # form (10–11 chars). Once the firmware widens the field, the
    # threshold lets the suffix render again automatically.
    build = (hardware.get("buildDatePrefix") or "").strip()
    if len(build) >= 9:
        return f"{combined} (Build: {build})"
    return combined


def _build_status_stats(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Build the on8ar /status ``stats`` sub-object from a cache snapshot.

    Every numeric field is sentinel-checked so feature-absent sensors
    emit NOTHING rather than a literal 0 that downstream alerting
    (low-battery!) reads as a real reading. If the gateway has no
    battery monitor, hardware reports vbat_mv=0 — we drop the key
    entirely; same for GPS sats on a no-GPS board, mcu_temp_c on
    boards without an accessible on-die sensor (firmware emits
    Q4-fixed-point 0x0FAD ≈ 250.8125 °C as the "unavailable" sentinel).
    """
    telemetry = snapshot.get("telemetry") or {}
    stats: dict[str, Any] = {}
    if (vbat := telemetry.get("vbat_mv")) is not None and int(vbat) > 0:
        stats["battery_mv"] = int(vbat)
    if (uptime := telemetry.get("uptime_s")) is not None:
        stats["uptime_secs"] = int(uptime)
    if snapshot.get("last_rssi") is not None:
        stats["last_rssi"] = int(round(float(snapshot["last_rssi"])))
    if snapshot.get("last_snr") is not None:
        stats["last_snr"] = float(round(float(snapshot["last_snr"]), 1))
    stats["queue_len"] = 0
    stats["errors"] = 0
    if (mcu_temp := telemetry.get("mcu_temp_c")) is not None:
        # Realistic chip-temperature range is -40..+125 °C; anything
        # outside [-50, 130] is the firmware's "no data" sentinel.
        mcu_temp_f = float(mcu_temp)
        if -50.0 <= mcu_temp_f <= 130.0:
            stats["mcu_temp_c"] = mcu_temp_f
    if (sats := telemetry.get("gps_sats")) is not None and int(sats) > 0:
        stats["gps_sats"] = int(sats)
    if (jitter := telemetry.get("pps_jitter_us")) is not None:
        # 65535 = uint16 sentinel on PPS loss; 0 = no-PPS-wired.
        # Either way, don't propagate as a real reading.
        if 0 < int(jitter) < 65535:
            stats["pps_jitter_us"] = int(jitter)
    return stats


def gateway_state_to_on8ar_status(
    snapshot: dict[str, Any],
    *,
    repeater_name: str,
    repeater_pub_key: str,
) -> dict[str, Any]:
    """Build an on8ar canonical /status envelope from a GatewayCache snapshot.

    Shape mirrors on8ar samples (BE-JBE-ETG-O1 / NL-VNR-OBS):
        model, radio, stats, origin, origin_id, status="online",
        timestamp, client_version, firmware_version

    Fields whose source is None are omitted entirely (no literal
    "null"). The `stats` block is whatever subset of telemetry the
    cache has — never the full mctomqtt set, since our bridge doesn't
    surface noise_floor / queue_len / rx_air_secs / tx_air_secs.

    2026-05-30 (firmware-node_name source for /status): ``origin``
    prefers the snapshot's ``display_name`` (cached by GatewayCache
    from the bridge's /info envelope, which sources from port-names.
    json / portal meta.json gateway_name — auto-synced from the
    firmware's NVS node_name in portal 0.3.60+). The static
    ``repeater_name`` from RelayConfig remains as a defensive
    fallback for snapshots that have no display_name yet (legacy
    bridges, fresh GatewayCache entries before the first /info
    event). Mirrors the packet-side change in
    ``envelope_to_on8ar_packet`` so /packets and /status stay in
    lockstep on operator renames.
    """
    hardware = snapshot.get("hardware") or {}
    now = datetime.now()
    stats = _build_status_stats(snapshot)

    out: dict[str, Any] = {
        "model": hardware.get("boardName") or "",
        "radio": _format_radio(hardware.get("radio")),
        "stats": stats,
        "origin": snapshot.get("display_name") or repeater_name,
        # /status origin_id is the repeater's OWN pubkey (the relay is
        # the sender of the heartbeat). Pass it in the resolved-sender
        # slot (tx_pubkey_hex) so the formatter returns it verbatim —
        # NOT the unknown-sender slot which would emit "".
        "origin_id": _pad_pubkey(None, repeater_pub_key),
        "status": "online",
        "timestamp": now.isoformat(timespec="microseconds"),
        "firmware_version": _format_firmware_version(hardware),
    }
    portal_version = hardware.get("portalVersion")
    if portal_version:
        # Operator-friendly label (revised 2026-05-20): the deb name
        # ``meshcore-tdoa-gateway-portal`` is too long for on8ar's
        # narrow client_version column, so report a shorter camel-case
        # brand. The bare version string after the space matches the
        # deb's installed version byte-for-byte.
        out["client_version"] = f"MeshCorePiPortal {portal_version}"
    return out
