"""MQTT publishing path for ``meshcore-bridge``.

The shape of the published JSON deliberately mirrors the ChirpStack
Gateway Bridge uplink event so the Windows-side collector can subscribe
to the Pi bridge and to ChirpStack interchangeably (Phase-1 vs Phase-2)
without a special-case adapter.

ChirpStack uplink (relevant fields):

```json
{
  "gatewayId":  "<hex>",
  "data":       "<base64 of LoRa PHY payload>",
  "rxInfo": [
    {
      "gatewayId":          "<hex>",
      "rssi":               -77,
      "snr":                10.5,
      "fineTimeSinceGpsEpoch": "PT1234567890.123456789S"
    }
  ]
}
```

For the Pi-bridge we substitute:

* ``gatewayId``                   ← embedded ``node_id`` from the 0x90 frame
                                    (T-Echo's public-key prefix), hex-encoded
* ``data``                        ← base64(raw 23-byte 0x90 frame)
* ``rxInfo[0].rssi``              ← int16 RSSI from frame
* ``rxInfo[0].snr``               ← int8  SNR  from frame
* ``rxInfo[0].fineTimeSinceGpsEpoch`` ← formatted RFC3339 duration
                                         ``PT<sec>.<ns>S`` from the µs
                                         timestamp in the frame
"""

from __future__ import annotations

import base64
import fnmatch
import json
import logging
import os
import re
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

import paho.mqtt.client as mqtt

from .config import HardwareMetadata, LoRaConfig, MQTTConfig
from .frame import (
    DeviceTelemetryFrame,
    GatewayInfoFrame,
    GatewayPositionFrame,
    GpsQualityFrame,
    TdoaAdvertAuxFrame,
    TDOAFrame,
)

logger = logging.getLogger(__name__)

# Pi-side deb version, read once at module import. Path is written by
# the meshcore-tdoa-gateway-portal deb (debhelper substitutes the
# DEB_VERSION from debian/changelog at build time so the contents match
# the installed package). Source-installed bridges (no deb, no
# /usr/share/.../version.txt) leave this None — the field then reaches
# the collector as null, and the COALESCE-on-UPDATE preserves any prior
# good value during a dev-shell session.
_PORTAL_VERSION_PATH = "/usr/share/meshcore-tdoa-gateway-portal/version.txt"


def _read_portal_version() -> str | None:
    try:
        with open(_PORTAL_VERSION_PATH, encoding="ascii") as f:
            v = f.read().strip()
            return v or None
    except OSError:
        return None


#: Deb-written version file, mirroring the portal's working mechanism. The deb
#: ships this under /usr/share (unpacked BEFORE any maintainer script or service
#: (re)start, so it's always present + race-free), and — critically — /usr/share
#: is readable under the service's ``ProtectSystem=strict`` sandbox, whereas the
#: legacy ``/etc/meshcore-bridge`` stamp below is NOT reachable from the service
#: context (it published ``bridgeVersion: null`` fleet-wide — 2026-06-07). Read
#: this FIRST; the /etc stamp + git rev-parse remain fallbacks for git-deploys.
_BRIDGE_VERSION_TXT = Path("/usr/share/meshcore-tdoa-gateway-bridge/version.txt")
#: deploy-bridge.sh stamps the deployed git SHA here so the running version is
#: knowable even when the bridge is imported from dist-packages (pip-installed,
#: no git context). Fallback after the deb version.txt; git rev-parse is last.
_BRIDGE_VERSION_STAMP = Path("/etc/meshcore-bridge/deployed_version")
#: The git repo the bridge is deployed from (deploy-bridge.sh REPO default), so
#: `git rev-parse` works even though __file__ lives under dist-packages.
_BRIDGE_REPO_DIR = Path("/opt/meshcore-tdoa")


def _git_short_sha(repo: Path) -> str | None:
    """``git rev-parse --short HEAD`` (+ '-dirty') for ``repo``, or None if it
    isn't a git repo / git is unavailable. Best-effort; never raises."""
    import subprocess  # local import: keep module import cheap + side-effect-free

    try:
        sha = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, timeout=3,
        )
        if sha.returncode != 0 or not sha.stdout.strip():
            return None
        rev = sha.stdout.strip()
        dirty = subprocess.run(
            ["git", "-C", str(repo), "status", "--porcelain"],
            capture_output=True, text=True, timeout=3,
        )
        if dirty.returncode == 0 and dirty.stdout.strip():
            rev += "-dirty"
        return rev
    except (OSError, subprocess.SubprocessError):
        return None


def _read_bridge_version() -> str | None:
    """Best-effort 'proven running' version of THIS bridge process.

    The bridge ships via git (deploy-bridge.sh syncs the repo + pip-installs),
    not a deb, so the pyproject version is a static placeholder. The signal that
    actually identifies the RUNNING build is the git commit it was deployed from
    — captured at import time, so it reflects the running process even after a
    later on-disk re-sync (until the bridge restarts).

    Resolution order:
      1. the deploy-time stamp file (deploy-bridge.sh writes the SHA there) —
         survives pip-install losing git context.
      2. a live `git rev-parse` of the deploy repo, then the package dir
         (covers a dev checkout the stamp hasn't been written for).
      3. the installed package version via importlib.metadata — last-ditch.
    Returns None if none resolve (the portal then hides the bridge chip).
    """
    # Deb install: /usr/share version.txt (race-free, readable under the
    # service sandbox). Authoritative for deb-installed bridges.
    try:
        v = _BRIDGE_VERSION_TXT.read_text(encoding="ascii").strip()
        if v:
            return v
    except OSError:
        pass

    try:
        v = _BRIDGE_VERSION_STAMP.read_text(encoding="ascii").strip()
        if v:
            return v
    except OSError:
        pass

    for repo in (_BRIDGE_REPO_DIR, Path(__file__).resolve().parent):
        rev = _git_short_sha(repo)
        if rev:
            return rev

    try:
        import importlib.metadata as _md
        return _md.version("meshcore-bridge")
    except Exception:  # noqa: BLE001 — best-effort; never block startup
        return None


_PORTAL_VERSION: str | None = _read_portal_version()
_BRIDGE_VERSION: str | None = _read_bridge_version()

# GPS chip family integer → human-readable label exposed in MQTT events
# and the portal "GPS Info Radiator". Mirrors the firmware-side enum
# in src/helpers/sensors/GpsChipProbe.h.
_GPS_FAMILY_NAMES: dict[int, str] = {
    0: "unknown",
    1: "u-blox",
    2: "L76K",
}

# A name resolver maps a sanitised port (e.g. ``ttyACM0``) to a user-defined
# display_name (e.g. ``"Living Room T-Echo"``) or ``None`` when unset. The
# bridge wires this to a function that re-reads /etc/meshcore-bridge/port-names.json
# so saves through the portal take effect on the next published frame.
NameResolver = Callable[[str], str | None]

_PORT_SANITIZE_RE = re.compile(r"[^A-Za-z0-9_-]+")

# Plausibility window for the pps_interval field. The bridge needs to
# tolerate TWO units because firmware paths emit different ones:
#
#   * SW-``micros()`` path (V4 today, T-Echo pre-1.8.2) — pps_interval
#     is in µs. Healthy reading ≈ 1,000,000 ±2%.
#   * HW TIMER4 capture path (T-Echo tdoa-1.8.2+) — pps_interval is in
#     raw 16 MHz ticks. Healthy reading ≈ 16,000,000 ±2%.
#
# We accept either window; the ``fractional_second = counts_since_pps /
# pps_interval`` math is unit-agnostic so both routes produce the same
# normalized fraction. Pre-PPS-lock readings (~10^8 or 0) fall outside
# both windows and are suppressed by the gate.
_PPS_INTERVAL_SW_MIN = 980_000
_PPS_INTERVAL_SW_MAX = 1_020_000
_PPS_INTERVAL_HW_MIN = 15_700_000   # 16M − 2%
_PPS_INTERVAL_HW_MAX = 16_300_000   # 16M + 2%


def _pps_interval_plausible(value: int) -> bool:
    """True when ``value`` is within ±2% of either 1 µs or 62.5 ns tick rate."""
    return (
        _PPS_INTERVAL_SW_MIN <= value <= _PPS_INTERVAL_SW_MAX
        or _PPS_INTERVAL_HW_MIN <= value <= _PPS_INTERVAL_HW_MAX
    )


def sanitize_port(port: str) -> str:
    """Reduce ``/dev/ttyUSB0`` → ``ttyUSB0`` for use in an MQTT topic.

    MQTT topic levels disallow ``+``, ``#``, ``/``, plus the bridge avoids
    NUL/whitespace. We strip the dirname, then squash any remaining
    non-[A-Za-z0-9_-] character to ``_`` so a future port name like
    ``/dev/serial/by-id/usb-X.Y_AB:CD-port0`` still gives a stable topic
    fragment.
    """
    base = os.path.basename(port) or port
    sanitized = _PORT_SANITIZE_RE.sub("_", base).strip("_")
    return sanitized or "unknown"


def _format_fine_time(timestamp_us: int) -> str:
    """Format a microsecond GPS timestamp as RFC3339 duration ``PT<sec>.<ns>S``.

    Matches ChirpStack's ``fineTimeSinceGpsEpoch`` shape — and matches what
    services/collector parses (see ``_extract_fine_ts_ns`` / "PT..." prefix).
    We promote our µs precision to ns by multiplying by 1000; the trailing
    three digits are always zero, which is honest about our actual precision.
    """
    if timestamp_us < 0:
        # Defensive: shouldn't happen in real receivers but the parser
        # accepts negative int64 values, so we mirror struct semantics.
        sign = "-"
        timestamp_us = -timestamp_us
    else:
        sign = ""
    secs, us_remainder = divmod(timestamp_us, 1_000_000)
    ns_remainder = us_remainder * 1000
    return f"PT{sign}{secs}.{ns_remainder:09d}S"


def build_uplink_envelope(
    frame: TDOAFrame,
    *,
    display_name: str | None = None,
    mqtt_client_id: str | None = None,
    lora: LoRaConfig | None = None,
    tx_lat: float | None = None,
    tx_lon: float | None = None,
    raw_packet_hex: str | None = None,
    gateway_pubkey_hex: str | None = None,
    node_type: str | None = None,
) -> dict[str, Any]:
    """ChirpStack-shaped JSON envelope for a single 0x90 frame.

    Returned as a plain dict; the caller json.dumps() it. Tested
    independently of MQTT so the payload contract is locked down.

    ``display_name`` (optional) is a user-set TDOA-receiver identity from
    the portal's port-names.json. When set, it BECOMES the ``gatewayId``
    so the row in ``gateways`` (and everything downstream — packets, map
    markers, admin) reads as the friendly label. The 6-byte hex node-id
    is preserved under ``meta.node_id_hex`` for traceability. When no
    name is set, ``gatewayId`` falls back to the hex node-id, keeping
    the bridge backwards-compatible.

    Caveat: renaming a port creates a NEW gateways row (different PK) and
    orphans the old one. If preserving rename-history matters, name once
    and don't change.

    ``lora`` (KAN-134) is the bridge-side RF profile attached to every
    envelope so the legacy MQTT ingest path can populate
    ``packet_receptions.{freq_hz,bandwidth_hz,spread_factor,coderate}``
    (the firmware-side 0x90 frame doesn't carry these fields). Defaults
    to a fresh :class:`LoRaConfig` (MeshCore EU868) when not supplied,
    keeping a one-arg call site working for older tests.

    KAN-134 also attaches ``meta.timestamp_source`` so the collector
    can label the per-reception row's ``timestamp_source`` column
    without a follow-up DB lookup. The bridge classifies based on the
    firmware's ``gps_time_sync_confirmed`` runtime quality flag (carried
    in the 0x94 GATEWAY_INFO frame's flags byte; KAN-129); since the
    0x90 frame itself only carries a coarser ``pps_locked`` bit, we
    publish ``"sw_micros"`` as a conservative default and let the
    collector promote to ``"pps_disciplined_micros"`` based on the
    gateway-row's ``gps_time_sync_confirmed`` column it already
    receives via the 0x94 path.
    """
    gateway_id_hex = frame.node_id.hex()
    gateway_id = display_name if display_name else gateway_id_hex
    meta: dict[str, Any] = {
        "source": "pi-bridge",
        "embeddedPacketHash": frame.embedded_packet_hash.hex(),
        "ppsLocked": frame.pps_locked,
        "gps3dFix": frame.gps_3d_fix,
        "node_id_hex": gateway_id_hex,
    }
    if gateway_pubkey_hex:
        meta["pubkey_hex"] = gateway_pubkey_hex
    # F-15: per-port operator-declared role (matches migration 0043's
    # ``gateways.node_type`` vocabulary: repeater | companion | anchor |
    # unknown). The downstream mesh-relay uses this to skip external
    # broker fanout for companion-role nodes — their decoded chat
    # belongs in the DB only. Omitted (rather than serialised as
    # ``"unknown"``) when the operator hasn't classified the port yet,
    # so the relay's fall-through ("missing == treat as external-safe")
    # preserves current behaviour for unclassified ports.
    if node_type:
        meta["node_type"] = node_type
    # 2026-05-11: per-reception RF parameters now come from the
    # receiver's 0x94 heartbeat (cached per-port in MQTTPublisher).
    # When the bridge hasn't seen a /info from this port yet, ``lora``
    # is None and we OMIT the four fields entirely — honest absence
    # beats reporting a synthetic guess that may not match the
    # receiver's actual tune.
    if lora is not None:
        meta["freq_hz"] = int(lora.freq_hz)
        meta["bandwidth_hz"] = int(lora.bandwidth_hz)
        meta["spread_factor"] = int(lora.spread_factor)
        meta["coderate"] = str(lora.coderate)
    if display_name:
        meta["gateway_display_name"] = display_name
    if mqtt_client_id:
        # The Pi/host that's forwarding this gateway's traffic. Lets the
        # Observers tab render a "Reported by" column distinct from the
        # node's own friendly name.
        meta["mqtt_client_id"] = mqtt_client_id
    # KAN-137: post-KAN-108 firmware optionally tags each 0x90 reception
    # with the transmitter's pubkey + cached display_name (when the
    # receiver had heard a prior advert from that node). Legacy firmware
    # — and new firmware that hadn't seen the transmitter yet — leaves
    # both fields ``None``, in which case we omit them entirely so the
    # collector can distinguish "we genuinely don't know who sent this"
    # from "the bridge dropped the data" purely by key presence.
    if frame.tx_pubkey is not None:
        meta["tx_pubkey_hex"] = frame.tx_pubkey.hex()
    if frame.tx_display_name is not None:
        meta["tx_display_name"] = frame.tx_display_name
    # tdoa-1.8.0: transmitter coordinates + raw LoRa packet bytes
    # merged from the matching 0x9A TDOA_ADVERT_AUX frame (correlated
    # by packet_hash). The bridge caches aux frames in a small
    # per-publisher dict; this envelope-build merges whatever was
    # cached at the moment the 0x90 was dispatched. All three keys
    # are omitted when the corresponding field is None so the
    # collector can distinguish "we don't know" from "we know it was
    # absent" by key presence.
    if tx_lat is not None:
        meta["tx_lat"] = tx_lat
    if tx_lon is not None:
        meta["tx_lon"] = tx_lon
    if raw_packet_hex is not None:
        meta["raw_packet_hex"] = raw_packet_hex
    # tdoa-1.8.1 debug timing trailer. Three uint32s — surfaced under
    # camelCase keys to match the existing meta naming convention
    # (e.g. ``ppsLocked``, ``gps3dFix``, ``countsSincePps``). NULL on
    # pre-1.8.1 firmware; collector falls back to NULL columns.
    if frame.rx_irq_micros is not None:
        meta["rxIrqMicros"] = int(frame.rx_irq_micros)
    if frame.cc_packet is not None:
        meta["ccPacket"] = int(frame.cc_packet)
    if frame.cc_pps is not None:
        meta["ccPps"] = int(frame.cc_pps)
    # tdoa-1.8.16: SX126x demodulator frequency-error (signed Hz). Used by
    # the collector for the Δt = freq_error_hz / chirp_rate correction
    # experiment (chirp_rate = BW²/2^SF). Pre-1.8.16 firmware leaves this
    # as None — collector then stores NULL and applies no correction.
    if frame.freq_error_hz is not None:
        meta["freqErrorHz"] = int(frame.freq_error_hz)
    # tdoa-1.12.0: dual-anchor MCPWM capture. ``ccPacket`` (above) holds
    # the value latched at RX_DONE; ``ccPacketPreamble`` holds the value
    # latched at PREAMBLE_DETECTED (typically ~packet-airtime EARLIER on
    # the same timeline). ``anchorEdgesSeen`` reports how many DIO1
    # transitions fired in the RX window so the collector can flag
    # corrupt rows (0 = ISR machinery broken, 1 = preamble missed,
    # 2 = clean, 3+ = spurious edge). Pre-1.12.0 firmware leaves both
    # as None — collector stores NULL on both columns.
    if frame.cc_packet_preamble is not None:
        meta["ccPacketPreamble"] = int(frame.cc_packet_preamble)
    if frame.anchor_edges_seen is not None:
        meta["anchorEdgesSeen"] = int(frame.anchor_edges_seen)
    # KAN-153 follow-up: firmware tdoa-1.5.3+ packs the receiver's
    # currently-locked satellite count into bits 2-7 of the 0x90
    # flags byte. The frame parser surfaces it as ``frame.sat_count``;
    # we forward it to the collector under ``meta.satCount`` so the
    # ``packet_receptions.sat_count`` column gets populated per packet.
    # Pre-1.5.3 firmware leaves the high bits at 0, which is read as
    # ``sat_count=0`` — surfaced honestly here, indistinguishable from
    # a real "no sats locked" reading on a healthy fix loss.
    if frame.sat_count is not None:
        meta["satCount"] = int(frame.sat_count)
    # tdoa-1.6.6 route trailer. ``originalHeader`` carries the LoRa
    # packet's first byte (the collector derives route_type from its
    # low two bits and renders Direct / Flood on the Packet Reception
    # tab); ``pathLenByte`` carries the firmware-emitted path_len byte
    # (hop count in low 6 bits, hash size in high 2). ``lastHopHash``
    # is the 4-byte hex of the last path entry (zero-padded). All
    # three are absent on pre-1.6.6 firmware frames so downstream
    # consumers can tell "we don't know" from "we know it was direct".
    if frame.original_header is not None:
        meta["originalHeader"] = int(frame.original_header)
    if frame.path_len_byte is not None:
        meta["pathLenByte"] = int(frame.path_len_byte)
    if frame.last_hop_hash is not None:
        meta["lastHopHash"] = frame.last_hop_hash.hex()
    # tdoa-1.7.0 PPS-counts trailer (SpaceTeam/TDoA_Analysis strategy).
    # ``countsSincePps`` is the firmware's measured (micros() -
    # pps_micros) at packet RX, expressed in raw micros() ticks.
    # ``ppsIntervalUs`` is the locally-measured tick count over the
    # most recent PPS-to-PPS interval. The collector divides them to
    # get a fractional-second timestamp that's invariant across
    # receivers regardless of xtal drift, sleep states, or temp.
    # ``fractionalSecond`` is the pre-computed ratio surfaced for
    # convenience; collector code may recompute from the raw fields
    # when it wants full precision.
    if frame.counts_since_pps is not None:
        meta["countsSincePps"] = int(frame.counts_since_pps)
    if frame.pps_interval_us is not None:
        meta["ppsIntervalUs"] = int(frame.pps_interval_us)
        # Plausibility gate for the precomputed fractionalSecond:
        # micros() ticks once per microsecond, so a healthy PPS-to-PPS
        # interval is ~1,000,000 ticks. ±2% covers any realistic xtal
        # tolerance + temperature drift; anything outside that range
        # means the firmware hasn't seen two clean consecutive PPS
        # edges (e.g., post-boot before GPS fix, or a stutter), and a
        # fractional value derived from it would be garbage. The raw
        # countsSincePps + ppsIntervalUs are still surfaced so the
        # collector / dashboards can decide for themselves; we just
        # don't pre-compute a fractionalSecond that will look like a
        # valid 0..1 reading but isn't.
        # The second gate (counts_since_pps within ~1.1x the interval)
        # catches the uint32 underflow case: when the PPS ISR fires
        # almost simultaneously with packet RX, pps_micros may have
        # been updated BEFORE logRxRaw reads (rx_irq_micros -
        # pps_micros), producing a modular result near 2^32 = 4.29B
        # that looks like "packet arrived ~4290 seconds past the
        # edge". The raw uint32 ride-through is still useful for
        # offline analysis (those rows represent real packets, just
        # in the previous PPS interval), but a pre-computed
        # fractionalSecond from them would be nonsense.
        if (
            frame.pps_interval_us is not None
            and frame.counts_since_pps is not None
            and _pps_interval_plausible(frame.pps_interval_us)
            and frame.counts_since_pps <= frame.pps_interval_us * 11 // 10
        ):
            meta["fractionalSecond"] = (
                float(frame.counts_since_pps) / float(frame.pps_interval_us)
            )
    return {
        "gatewayId": gateway_id,
        # Immutable hardware-derived unique id (the firmware hex node-id).
        # gatewayId may be the operator-set display name (mutable, can collide
        # on a rename); gatewayUid is the stable join key the collector
        # persists so a receiver's identity survives renames. Stamped on every
        # frame type so EVERY MQTT packet carries it.
        "gatewayUid": gateway_id_hex,
        "data": base64.b64encode(frame.raw).decode("ascii"),
        "rxInfo": [
            {
                "gatewayId": gateway_id,
                "rssi": int(frame.rssi),
                "snr": float(frame.snr),
                "fineTimeSinceGpsEpoch": _format_fine_time(int(frame.timestamp_us)),
            }
        ],
        "meta": meta,
    }


def build_position_envelope(
    frame: GatewayPositionFrame,
    *,
    display_name: str | None = None,
    mqtt_client_id: str | None = None,
    gateway_pubkey_hex: str | None = None,
) -> dict[str, Any]:
    """JSON envelope for a single 0x92 GATEWAY_POSITION frame.

    Shaped to mirror the uplink envelope's gatewayId / meta scheme so
    the collector can route both topics through the same name-resolution
    + gateway-upsert path. ``stats`` mimics ChirpStack's gateway-stats
    event — convenient if we later want to subscribe to real ChirpStack
    stats interchangeably.
    """
    gateway_id_hex = frame.node_id.hex()
    gateway_id = display_name if display_name else gateway_id_hex
    meta: dict[str, Any] = {
        "source": "pi-bridge",
        "ppsLocked": frame.pps_locked,
        "gps3dFix": frame.gps_3d_fix,
        "positionValid": frame.position_valid,
        "node_id_hex": gateway_id_hex,
    }
    if gateway_pubkey_hex:
        meta["pubkey_hex"] = gateway_pubkey_hex
    if display_name:
        meta["gateway_display_name"] = display_name
    if mqtt_client_id:
        meta["mqtt_client_id"] = mqtt_client_id
    return {
        "gatewayId": gateway_id,
        "gatewayUid": gateway_id_hex,  # stable hardware hex id (see build_uplink_envelope)
        "stats": {
            "location": {
                "latitude": frame.lat,
                "longitude": frame.lon,
                "altitude": int(frame.alt_m),
                "source": "GPS",
            },
            "metaData": {
                "satCount": int(frame.sat_count),
                "hdop": frame.hdop if frame.hdop is not None else None,
            },
        },
        "meta": meta,
    }


def build_info_envelope(
    frame: GatewayInfoFrame,
    *,
    display_name: str | None = None,
    mqtt_client_id: str | None = None,
    operator_hardware: HardwareMetadata | None = None,
) -> dict[str, Any]:
    """JSON envelope for a single 0x94 GATEWAY_INFO frame.

    Shape mirrors a ChirpStack-ish gateway-info event so the collector
    can route through the same name-resolution + upsert path as uplink
    + position. Capability flags are unpacked into a dict so consumers
    can render badges without reaching back into the firmware spec.

    Timing-campaign Phase 1: when ``operator_hardware`` is supplied
    (from the bridge's ``config.yaml`` ``hardware:`` block), the
    fields it carries are emitted under ``hardware.operator``. The
    collector COALESCEs them onto the gateway row so prior good
    values aren't clobbered when a YAML omits a field. ``None``
    fields are omitted from the envelope entirely — that's how
    "operator did not specify" propagates through the chain.
    """
    gateway_id_hex = frame.node_id.hex()
    gateway_id = display_name if display_name else gateway_id_hex
    meta: dict[str, Any] = {
        "source": "pi-bridge",
        "node_id_hex": gateway_id_hex,
    }
    if operator_hardware is not None and operator_hardware.pubkey:
        meta["pubkey_hex"] = operator_hardware.pubkey
    if display_name:
        meta["gateway_display_name"] = display_name
    if mqtt_client_id:
        meta["mqtt_client_id"] = mqtt_client_id
    # The 0x94 GATEWAY_INFO frame ALSO carries lat/lon as a "convenience"
    # so a single retained MQTT message can populate ``gateways.location``
    # at boot. We deliberately zero those fields out here because the
    # firmware's ``position_valid`` bit lies — observed on T-Echo @ fw
    # v1.15.0 it stays asserted with stale last-known coordinates after
    # the chip has dropped its fix and ``sat_count`` is 0. The 0x94 frame
    # has no satellite count for us to sanity-check against, so we can't
    # apply the same threshold filter we use on 0x92 GATEWAY_POSITION.
    # Solution: never trust 0x94 for location — only the filtered 0x92
    # path may set ``gateways.location``. The collector skips the upsert
    # when ``position.valid`` is false (or the field is omitted), so the
    # zeroed-out block below is a no-op for a healthy gateway and
    # actively prevents the stale-coords bug for an unhealthy one.
    hardware_block: dict[str, Any] = {
        "boardName": frame.board_name,
        "firmwareVersion": frame.fw_version,
        "tdoaFirmwareVersion": frame.tdoa_fw_version,
        # Pi-side deb version of meshcore-tdoa-gateway-portal. Distinct
        # from tdoaFirmwareVersion (the device-side fork string). Lets
        # the operator see on the Observer page when the 6-hour auto-
        # update timer has flipped a Pi to a new deb. Omitted from
        # the envelope when the bridge runs source-installed (no
        # /usr/share/.../version.txt) so the collector's COALESCE
        # preserves any prior good value.
        "portalVersion": _PORTAL_VERSION,
        # 2026-06-07: also ship the BRIDGE deb version so the fleet view can show
        # both the gateway (portal) and the bridge version per gateway. Omitted
        # when source-installed (no deployed_version stamp) → collector COALESCE
        # preserves any prior value.
        "bridgeVersion": _BRIDGE_VERSION,
        "mcuChip": frame.mcu_chip,
        "loraChip": frame.lora_chip,
        "buildDatePrefix": frame.build_date_prefix,
        "capabilities": {
            "hasGps": frame.has_gps,
            "hasDisplay": frame.has_display,
            "isTdoaRx": frame.is_tdoa_rx,
            "hasPps": frame.has_pps,
            # KAN-129: runtime quality, not a static capability —
            # the firmware (KAN-125) clears the bit whenever the
            # 3D fix is lost or the PPS counter drifts. Surfaced
            # here so the collector can persist it on the gateways
            # row and the TDOA solver can gate epoch membership.
            # Falls back to False on bridges/firmware that predate
            # the bit (the flag byte's high reserved bits are zero).
            "gpsTimeSyncConfirmed": frame.gps_time_sync_confirmed,
            # tdoa-1.6.0: paired IRQ-TS capability bits. ``hasIrqTimestamping``
            # is compile-time (the firmware has the DIO1 hardware
            # capture path), ``irqTimestampingProven`` is runtime
            # (the boot self-test has confirmed the path actually
            # works on this build — see IrqTimestamp.cpp). The
            # Observer page renders these as a single "IRQ-TS"
            # badge: green when proven, grey when capable but not
            # yet proven, hidden when not capable at all.
            "hasIrqTimestamping": frame.has_irq_timestamping,
            "irqTimestampingProven": frame.irq_timestamping_proven,
        },
        "rawFlags": int(frame.flags),
        # tdoa-1.6.5: live radio config (freq + BW + SF + CR) the
        # receiver was tuned to when it emitted this 0x94. Surfaced
        # at the gateway level rather than per-packet because the
        # config doesn't change packet-to-packet — the Packet
        # Reception tab joins on gateway_id to display them. Each
        # field is null on a legacy 104-byte frame from pre-1.6.5
        # firmware so the collector doesn't overwrite known values
        # with synthetic zeros during a mixed-fleet rollout.
        "radio": {
            "freqHz": frame.radio_freq_hz,
            "bwHz": (
                int(frame.radio_bw_x10_khz) * 100  # 0.1 kHz units → Hz
                if frame.radio_bw_x10_khz is not None
                else None
            ),
            "sf": frame.radio_sf,
            "cr": frame.radio_cr,
        },
        # tdoa 2026-05-29 PM: probe-detected GPS chip identity. Populated
        # when the firmware ran GpsChipProbe and the 0x94 carries the
        # 147-byte GPS-tail variant. ``family`` is the canonical integer
        # (0=unknown / 1=u-blox / 2=L76K); ``familyName`` is the
        # human-readable label used by the frontend "GPS Info Radiator".
        # All five fields are ``null`` on the legacy 104/112-byte 0x94
        # so the collector's COALESCE leaves the gateways row alone for
        # boards that haven't been re-flashed yet.
        "gpsChip": {
            "family":      frame.gps_chip_family,
            "familyName":  (
                _GPS_FAMILY_NAMES.get(int(frame.gps_chip_family))
                if frame.gps_chip_family is not None
                else None
            ),
            "model":       frame.gps_chip_model,
            "swVersion":   frame.gps_chip_sw_version,
            "bootstrapAck": frame.gps_bootstrap_ack,
            "enabledGnssMask": frame.gps_enabled_gnss_mask,
            "hardwareConfirmed": (
                frame.gps_chip_family is not None
                and frame.gps_chip_family != 0
            ),
        },
    }
    # Timing-campaign Phase 1: operator-supplied hardware ground-truth
    # (GPS module model, antenna details, oscillator type, PCB rev,
    # power source, role, free-text notes). Sourced from the bridge's
    # ``config.yaml`` ``hardware:`` block, keyed by USB port glob.
    # The fields are not runtime-detectable so the operator describes
    # them once per node. Each ``None`` field is omitted from the
    # envelope — the collector's COALESCE-on-update preserves prior
    # good values when a YAML partial-update arrives.
    if operator_hardware is not None:
        operator_block = {
            k: v
            for k, v in {
                "gpsModule": operator_hardware.gps_module,
                "gpsAntenna": operator_hardware.gps_antenna,
                "loraAntenna": operator_hardware.lora_antenna,
                "sx1262Tcxo": operator_hardware.sx1262_tcxo,
                "powerSource": operator_hardware.power_source,
                "pcbRevision": operator_hardware.pcb_revision,
                "role": operator_hardware.role,
                "notes": operator_hardware.notes,
            }.items()
            if v is not None
        }
        # Only attach the operator block when at least one field is
        # supplied. An empty dict here would carry no signal and
        # bloats every retained /info envelope on the broker.
        if operator_block:
            hardware_block["operator"] = operator_block
    return {
        "gatewayId": gateway_id,
        "gatewayUid": gateway_id_hex,  # stable hardware hex id (see build_uplink_envelope)
        "hardware": hardware_block,
        "position": {
            "valid": False,
            "latitude": None,
            "longitude": None,
        },
        "meta": meta,
    }


def build_telemetry_envelope(
    frame: DeviceTelemetryFrame,
    *,
    display_name: str | None = None,
    mqtt_client_id: str | None = None,
    gateway_pubkey_hex: str | None = None,
) -> dict[str, Any]:
    """JSON envelope for a single 0x96 DEVICE_TELEMETRY frame (KAN-101).

    Shape mirrors the uplink/position/info envelopes' ``gatewayId`` +
    ``meta`` scheme so the collector can route every topic through the
    same name-resolution + gateway-upsert path. The body lives under
    ``telemetry`` so the JSON consumer can pluck a single sub-object
    without re-parsing the whole envelope.

    Sentinel values from the wire (INT16_MIN MCU temp, INT8_MIN radio
    temp, 0 HDOP) are decoded into ``null`` here so the collector
    doesn't have to repeat the firmware-spec checks. The raw integers
    are preserved under ``raw`` for downstream callers that want the
    untranslated wire values (debugging, replay).
    """
    gateway_id_hex = frame.node_id.hex()
    gateway_id = display_name if display_name else gateway_id_hex
    meta: dict[str, Any] = {
        "source": "pi-bridge",
        "node_id_hex": gateway_id_hex,
    }
    if gateway_pubkey_hex:
        meta["pubkey_hex"] = gateway_pubkey_hex
    if display_name:
        meta["gateway_display_name"] = display_name
    if mqtt_client_id:
        meta["mqtt_client_id"] = mqtt_client_id
    return {
        "gatewayId": gateway_id,
        "gatewayUid": gateway_id_hex,  # stable hardware hex id (see build_uplink_envelope)
        "telemetry": {
            "uptime_s": int(frame.uptime_s),
            "boot_count": int(frame.boot_count),
            "reset_reason": int(frame.reset_reason),
            # Float Celsius for human consumption; raw Q12.4 preserved
            # under .raw.mcu_temp_q4 for callers that need the integer
            # representation (e.g. equality checks against a stored
            # snapshot).
            "mcu_temp_c": frame.mcu_temp_c,
            "radio_temp_c": frame.radio_temp_c_or_none,
            "vbat_mv": int(frame.vbat_mv),
            "gps_sats": int(frame.gps_sats),
            "gps_hdop": frame.gps_hdop,
            "gps_fix": bool(frame.gps_fix),
            "pps_jitter_us": int(frame.pps_jitter_us),
            "ble_active": bool(frame.ble_active),
            "free_heap": int(frame.free_heap),
        },
        "raw": {
            "mcu_temp_q4": int(frame.mcu_temp_q4),
            "radio_temp_c": int(frame.radio_temp_c),
            "gps_hdop_x10": int(frame.gps_hdop_x10),
        },
        "meta": meta,
    }


def build_gps_quality_envelope(
    frame: GpsQualityFrame,
    *,
    display_name: str | None = None,
    mqtt_client_id: str | None = None,
    gateway_pubkey_hex: str | None = None,
) -> dict[str, Any]:
    """JSON envelope for a single 0x9F GPS_QUALITY frame (Phase-2).

    Shape mirrors the telemetry envelope's ``gatewayId`` + ``meta``
    scheme so the collector can route every topic through the same
    name-resolution + gateway-upsert path. The body lives under
    ``gpsQuality`` so the JSON consumer can pluck a single sub-object
    without re-parsing the whole envelope.

    Sentinel values from the wire (HDOP/PDOP/VDOP zero, geoid INT16_MIN,
    SOG 0xFFFF) are decoded into JSON ``null`` here via the frame's
    convenience properties so the collector doesn't have to repeat the
    firmware-spec checks.
    """
    gateway_id_hex = frame.node_id.hex()
    gateway_id = display_name if display_name else gateway_id_hex
    meta: dict[str, Any] = {
        "source": "pi-bridge",
        "node_id_hex": gateway_id_hex,
    }
    if gateway_pubkey_hex:
        meta["pubkey_hex"] = gateway_pubkey_hex
    if display_name:
        meta["gateway_display_name"] = display_name
    if mqtt_client_id:
        meta["mqtt_client_id"] = mqtt_client_id
    return {
        "gatewayId": gateway_id,
        "gatewayUid": gateway_id_hex,  # stable hardware hex id (see build_uplink_envelope)
        "gpsQuality": {
            "hdop": frame.hdop,
            "pdop": frame.pdop,
            "vdop": frame.vdop,
            "sats": {
                "gps": int(frame.gps_sats),
                "glonass": int(frame.glonass_sats),
                "beidou": int(frame.beidou_sats),
                "galileo": int(frame.galileo_sats),
                "qzss": int(frame.qzss_sats),
                "total": int(frame.sat_total),
            },
            "fixQuality": int(frame.fix_quality),
            "geoidSeparationM": frame.geoid_sep_m,
            "speedMps": frame.speed_mps,
        },
        "meta": meta,
    }


class MQTTPublisher:
    """Thin wrapper around ``paho.mqtt.client.Client``.

    Owns the connection, exposes a single ``publish_frame`` method, and
    transparently reconnects via paho's ``reconnect_delay_set``. The
    bridge can construct one publisher and call it from multiple per-port
    reader threads safely (paho's loop_start runs its own thread; the
    ``client.publish`` call is documented thread-safe).
    """

    def __init__(
        self,
        cfg: MQTTConfig,
        *,
        client_factory: Any | None = None,
        name_resolver: NameResolver | None = None,
        lora: LoRaConfig | None = None,
        hardware: dict[str, HardwareMetadata] | None = None,
    ) -> None:
        self._cfg = cfg
        self._name_resolver = name_resolver
        # 2026-05-11: the bridge no longer attaches a hardcoded LoRa RF
        # profile to uplinks. The receiver's actual radio params come
        # from the 0x94 GATEWAY_INFO frame's radio tail (tdoa-1.6.5+);
        # if a port hasn't sent a 0x94 yet the envelope's meta omits the
        # radio fields entirely rather than reporting a synthetic
        # bridge-side guess. The ``lora`` constructor kwarg is kept for
        # backward compatibility with older callers/tests but is unused
        # in the per-port cache path; an explicit non-None value gets
        # written into the cache under the special "*" wildcard key so
        # tests that drive ``publish_frame`` without a prior
        # ``publish_info`` still see the expected fields.
        if lora is not None:
            self._lora_per_port: dict[str, LoRaConfig] = {"*": lora}
        else:
            self._lora_per_port = {}
        # Timing-campaign Phase 1: operator-supplied hardware metadata
        # keyed by USB port glob (from ``cfg.hardware`` YAML block).
        # Looked up at /info publish time by ``fnmatch``ing the actual
        # serial port path against each glob in insertion order. Empty
        # dict when no ``hardware:`` block is configured — no envelope
        # change in that case (downstream still works, just no
        # operator fields shipped).
        self._hardware_per_glob: dict[str, HardwareMetadata] = (
            dict(hardware) if hardware else {}
        )
        # Pubkey-centric identity (docs/proto-pubkey-identity.md): the receiver's
        # AUTO-LEARNED 64-hex self-pubkey, cached per sanitized port from the
        # 0x94 V210 GATEWAY_INFO frame. Preferred over the operator-declared
        # hardware pubkey in ``_resolve_pubkey`` once a node reports it, so the
        # identity flows with zero operator config.
        self._pubkey_per_port: dict[str, str] = {}
        # tdoa-1.8.0: cache of recently-received 0x9A TDOA_ADVERT_AUX
        # frames keyed by packet_hash (4 B). Firmware emits the aux
        # frame BEFORE the matching 0x90 so the bridge sees aux first;
        # this dict holds the aux payload (tx_lat/tx_lon/raw_packet)
        # until the 0x90 with the same hash arrives in publish_frame.
        # Bounded LRU — old entries auto-evict via the size cap so
        # orphaned aux (firmware emitted aux but the 0x90 was lost on
        # the serial bus) doesn't bloat memory indefinitely. 64 entries
        # at ~150 B each ≈ 10 kB ceiling.
        self._aux_cache: dict[bytes, tuple[float | None, float | None, str | None]] = {}
        self._aux_cache_max = 64
        # 2026-05-24 — per-port status snapshot for the gateway portal's
        # local Health cards (the local portal :8080 → /api/devices/<slug>/health).
        # Production-mode endpoint used to return all-nulls because it
        # had no path back to the live data; this dict gives the portal
        # a file to read. Updated on every uplink / info / telemetry /
        # position publish; flushed to disk at most once every 2s to
        # avoid burning IOPS during a packet storm.
        self._status_lock = threading.Lock()
        self._status_last_write = 0.0
        self._status_path = Path("/run/meshcore-tdoa-gateway-bridge/status.json")
        # 2026-05-25 — also mirror to /var/lib so a reboot doesn't wipe
        # the cards. /run is tmpfs (cleared at boot); /var/lib survives.
        # On startup we prefer /run (freshest if bridge restarted without
        # reboot), then fall back to /var (after a reboot). Either way
        # the cards show prior fw/board/gps state instead of blanks
        # while we wait for the next 0x94 / 0x96 / 0x90.
        self._status_path_persistent = Path(
            "/var/lib/meshcore-tdoa-gateway-bridge/status.json"
        )
        self._per_port_status: dict[str, dict[str, Any]] = self._bootstrap_status(
            hardware=self._hardware_per_glob,
        )
        # Write status.json once at startup so the portal can show the bridge's
        # running version immediately — even on a Pi that hasn't published a
        # device frame yet (otherwise bridge_version only lands on the first
        # _update_status flush, which needs a device emitting).
        with self._status_lock:
            self._flush_status(self._status_snapshot())
        # client_factory exists so tests can inject a mock paho Client.
        # 2026-05-26: thread `transport` through so WSS reaches paho.
        if client_factory is None:
            transport = getattr(cfg, "transport", "tcp") or "tcp"
            client_factory = lambda: mqtt.Client(  # noqa: E731
                client_id=cfg.client_id,
                callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
                transport=transport,
            )
        self._client = client_factory()
        if cfg.username:
            self._client.username_pw_set(cfg.username, cfg.password or "")
        # 2026-05-26: opt-in TLS via cfg.tls_enabled. paho's tls_set()
        # with no args uses system CAs (ca-certificates), which works for
        # a CF-fronted broker with a public CA (e.g. Let's Encrypt) cert.
        # tls_insecure flips hostname-check off — local-dev only.
        if getattr(cfg, "tls_enabled", False):
            self._client.tls_set()
            if getattr(cfg, "tls_insecure", False):
                self._client.tls_insecure_set(True)
        # 1s → 30s reconnect backoff (matches services/collector pattern).
        self._client.reconnect_delay_set(min_delay=1, max_delay=30)
        self._connected = threading.Event()
        # Bridge-level broker health (Erik #3 / dbblinddb): a gateway that
        # registers over HTTP but whose bridge can't AUTH to the broker
        # publishes nothing → invisible on the fleet page. Capture the
        # CONNACK reason so the portal can show "broker auth failed" instead
        # of a silent no-data. Only set the on_connect hook if the factory
        # gave us a real paho client (tests pass a stub without it).
        self._mqtt_health = "connecting"
        if hasattr(self._client, "on_connect"):
            self._client.on_connect = self._on_connect

    #: Canonical retained meta topic any TDOA producer publishes on
    #: connect so subscribers can MQTT-natively detect that this broker
    #: carries TDOA-format traffic. Subscribed by the relay's per-
    #: output-broker client (see output_brokers.py::_on_connect).
    #: Replaces the prior hostname/IP fingerprint scheme in the portal.
    _TDOA_META_TOPIC = "tdoa_gateway/_meta/protocol"

    def _on_connect(self, client: Any, userdata: Any, flags: Any,
                    reason_code: Any, properties: Any = None) -> None:
        """paho VERSION2 CONNACK handler — classify broker health.

        reason_code 0 / "Success" → connected. A "not authorized" / "bad
        username or password" code is the Erik/dbblinddb class: bridge can
        reach the broker but creds are wrong/missing, so it never publishes.
        We surface that as a bridge-level ``mqtt`` status in status.json.
        """
        rc = reason_code
        is_ok = (rc == 0) or (getattr(rc, "value", None) == 0) or (
            getattr(rc, "is_failure", False) is False
        )
        if is_ok:
            self._mqtt_health = "connected"
        else:
            name = str(getattr(rc, "getName", lambda: rc)() if hasattr(rc, "getName") else rc)
            self._mqtt_health = (
                "unauthorized"
                if "auth" in name.lower() or "password" in name.lower()
                else "connect_failed"
            )
            logger.warning("publisher.mqtt.connack_failure reason=%s", name)
        # Flush so the portal sees the broker state without waiting for the
        # next per-port status update (a never-publishing bridge has none).
        try:
            with self._status_lock:
                snapshot = self._status_snapshot()
            self._flush_status(snapshot)
        except Exception:  # noqa: BLE001
            pass

    def connect(self) -> None:
        """Connect to the broker, start the paho loop, then publish a
        retained TDOA-protocol meta topic so MQTT-side subscribers can
        auto-detect this broker as TDOA.

        Synchronous up to the TCP/MQTT-CONNECT handshake; the loop runs
        on a background thread thereafter. Idempotent — calling twice
        is a no-op (paho returns immediately on a second loop_start).
        """
        self._client.connect(self._cfg.host, self._cfg.port, keepalive=60)
        self._client.loop_start()
        self._connected.set()
        self._publish_tdoa_meta()

    def _publish_tdoa_meta(self) -> None:
        """Announce ourselves as a TDOA-format producer on this broker.

        Retained so a late-joining subscriber (the relay's per-output-
        broker client, the portal's status reader) gets the marker on
        first connect without waiting for the next bridge restart.
        Cheap (~40 B), QoS 1, fire-and-forget. Skipping the publish on
        any error is fine — the relay's hostname-based default kept
        working for years before this marker existed.
        """
        try:
            payload = json.dumps({
                "format": "tdoa",
                "version": 1,
                "source": "meshcore-tdoa-gateway-bridge",
                "client_id": self._cfg.client_id,
            }, separators=(",", ":")).encode("utf-8")
            self._client.publish(
                self._TDOA_META_TOPIC, payload, qos=1, retain=True,
            )
        except Exception:  # noqa: BLE001
            # Marker publish is best-effort; never let it block bridge
            # startup. A failed publish just means MQTT subscribers
            # fall back to the relay's `broker_kind == meshcore-tdoa`
            # default branch in BrokerConfig.effective_protocol.
            pass

    def disconnect(self) -> None:
        if not self._connected.is_set():
            return
        try:
            self._client.loop_stop()
        finally:
            try:
                self._client.disconnect()
            finally:
                self._connected.clear()

    def _resolve_name(self, sanitized: str) -> str | None:
        if self._name_resolver is None:
            return None
        try:
            return self._name_resolver(sanitized)
        except Exception:
            # Name resolution is best-effort; never block a publish on it.
            return None

    def publish_aux(self, port: str, frame: TdoaAdvertAuxFrame) -> None:
        """Cache a 0x9A TDOA_ADVERT_AUX frame for the next matching 0x90.

        No MQTT message is published from the aux frame directly —
        instead, the (tx_lat, tx_lon, raw_packet_hex) tuple is stored
        in :attr:`_aux_cache` keyed by ``packet_hash``. The next
        :meth:`publish_frame` call with the same ``embedded_packet_hash``
        pops the entry and merges it into the uplink envelope.

        ``port`` is accepted for symmetry with the other publish_*
        methods (and to keep the caller's dispatch table uniform) but
        not used today — the packet_hash is a globally-unique key.
        """
        del port  # unused; reserved for future per-port scoping
        lat_deg = (frame.tx_lat_e6 / 1_000_000.0) if frame.tx_lat_e6 is not None else None
        lon_deg = (frame.tx_lon_e6 / 1_000_000.0) if frame.tx_lon_e6 is not None else None
        raw_hex = frame.raw_packet.hex() if frame.raw_packet is not None else None
        self._aux_cache[frame.packet_hash] = (lat_deg, lon_deg, raw_hex)
        # Bounded eviction — drop oldest insertion if over the cap.
        # Python dict preserves insertion order so popitem(last=False)
        # via iter+next gets the oldest key.
        while len(self._aux_cache) > self._aux_cache_max:
            oldest = next(iter(self._aux_cache))
            del self._aux_cache[oldest]

    def _mirror_to_pubkey(
        self, port: str, suffix: str, payload: bytes, *, retain: bool
    ) -> None:
        """Dual-mode pubkey identity (docs/proto-pubkey-identity.md).

        When ``mqtt.dual_publish_pubkey`` is enabled AND this port's receiver
        pubkey is known, ALSO publish ``payload`` under
        ``<prefix>/<pubkey>/<suffix>`` — the same bytes the legacy
        ``<prefix>/<sanitized-port>/<suffix>`` topic just carried. The caller
        always does the legacy publish first; this only adds the mirror.

        Default OFF, and a no-op when the pubkey is unknown, so a Pi on old
        firmware / without a declared pubkey behaves exactly as before. Safe to
        enable only once the collector dedupes uplinks by payload identity
        (gatewayUid/pubkey in the body), else the mirror double-counts.
        """
        if not self._cfg.dual_publish_pubkey:
            return
        pubkey = self._resolve_pubkey(port)
        if not pubkey:
            return
        topic = f"{self._cfg.topic_prefix}/{pubkey}/{suffix}"
        self._client.publish(topic, payload, qos=self._cfg.qos, retain=retain)

    def publish_frame(self, port: str, frame: TDOAFrame) -> None:
        """Publish a single 0x90 frame under ``<prefix>/<sanitized-port>/uplink``.

        Resolves a per-port display_name via the ``name_resolver`` (if set)
        so the collector can store a user-friendly gateway label.

        Attaches the per-port LoRa config the bridge learned from this
        gateway's most recent 0x94 GATEWAY_INFO heartbeat. If no /info
        has been seen yet for this port the envelope omits the radio
        fields entirely — better honest absence than a synthetic
        bridge-side guess that may not match the receiver.

        tdoa-1.8.0: looks up a cached 0x9A aux frame by ``embedded_packet_hash``;
        when present, merges its tx coordinates + raw LoRa packet bytes into
        the envelope's ``meta`` block. Pre-1.8.0 firmware never emits the aux
        frame so the lookup always misses — envelope shape stays the same.
        """
        sanitized = sanitize_port(port)
        topic = f"{self._cfg.topic_prefix}/{sanitized}/uplink"
        lora = self._lora_per_port.get(sanitized) or self._lora_per_port.get("*")
        # Use ``get`` not ``pop`` — when multiple gateways hear the same
        # on-air packet the aux fields are identical (same LoRa PHY
        # bytes), so each gateway's 0x90 should read the SAME cache
        # entry. Eviction is via the size cap (LRU-by-insertion) so
        # entries naturally retire as new aux frames arrive.
        aux = self._aux_cache.get(frame.embedded_packet_hash)
        tx_lat = aux[0] if aux is not None else None
        tx_lon = aux[1] if aux is not None else None
        raw_packet_hex = aux[2] if aux is not None else None
        envelope = build_uplink_envelope(
            frame,
            display_name=self._resolve_name(sanitized),
            mqtt_client_id=self._cfg.client_id,
            lora=lora,
            tx_lat=tx_lat,
            tx_lon=tx_lon,
            raw_packet_hex=raw_packet_hex,
            gateway_pubkey_hex=self._resolve_pubkey(port),
            node_type=self._resolve_node_type(port),
        )
        payload = json.dumps(envelope, separators=(",", ":")).encode("utf-8")
        self._client.publish(topic, payload, qos=self._cfg.qos, retain=False)
        self._mirror_to_pubkey(port, "uplink", payload, retain=False)
        # Health-snapshot update: live per-packet flags for the portal.
        # pps_interval_us → drift_ppm = (pps_interval_us - 1_000_000).
        # Single-sample drift is noisy but the portal can average client-
        # side if the cards ever want a rolling figure; for now we ship
        # the freshest reading and let the operator eyeball the band.
        pps_interval_us = getattr(frame, "pps_interval_us", None)
        drift_ppm = (
            float(pps_interval_us) - 1_000_000.0
            if isinstance(pps_interval_us, int) and 980_000 <= pps_interval_us <= 1_020_000
            else None
        )
        self._update_status(
            port,
            last_packet_at=time.time(),
            last_rssi=getattr(frame, "rssi", None),
            last_snr=getattr(frame, "snr", None),
            pps_locked=getattr(frame, "pps_locked", None),
            gps_3d_fix=getattr(frame, "gps_3d_fix", None),
            sat_count=getattr(frame, "sat_count", None),
            last_pps_interval_us=pps_interval_us,
            drift_ppm=drift_ppm,
        )

    def publish_position(self, port: str, frame: GatewayPositionFrame) -> None:
        """Publish a single 0x92 frame under ``<prefix>/<sanitized-port>/position``.

        Position events are RETAINED on the broker — a fresh subscriber
        (e.g. a restarted collector) sees each gateway's last-known
        position immediately, without having to wait up to 60 s for the
        next firmware-side broadcast.
        """
        sanitized = sanitize_port(port)
        topic = f"{self._cfg.topic_prefix}/{sanitized}/position"
        envelope = build_position_envelope(
            frame,
            display_name=self._resolve_name(sanitized),
            mqtt_client_id=self._cfg.client_id,
            gateway_pubkey_hex=self._resolve_pubkey(port),
        )
        payload = json.dumps(envelope, separators=(",", ":")).encode("utf-8")
        self._client.publish(topic, payload, qos=self._cfg.qos, retain=True)
        self._mirror_to_pubkey(port, "position", payload, retain=True)

    def publish_info(self, port: str, frame: GatewayInfoFrame) -> None:
        """Publish a single 0x94 frame under ``<prefix>/<sanitized-port>/info``.

        Hardware-info events are RETAINED on the broker — board / firmware
        / chipset metadata is compile-time-static, so a fresh subscriber
        (Observer-tab page load, restarted collector) sees the data
        instantly without waiting an hour for the next heartbeat.

        tdoa-1.6.5: when the frame carries a radio-config tail
        (radio_freq_hz et al. all non-None), cache the values keyed by
        sanitized port so subsequent ``publish_frame`` calls attach the
        receiver's actual radio config to every uplink envelope. Older
        firmware that emits the legacy 104-byte 0x94 with no tail
        leaves the cache untouched — the bridge then falls back to the
        boot-default LoRaConfig for that port's uplinks.
        """
        sanitized = sanitize_port(port)
        # Auto-learn the receiver's self-pubkey from the V210 0x94 tail and
        # cache it per port (docs/proto-pubkey-identity.md). Subsequent frames
        # resolve their gateway pubkey from this cache, so the pubkey identity
        # flows without any operator declaration. Sticks once learned; older
        # firmware (no tail) leaves the cache untouched and the operator-declared
        # pubkey remains the fallback.
        if frame.self_pubkey is not None:
            self._pubkey_per_port[sanitized] = frame.self_pubkey.hex()
        if frame.radio_freq_hz is not None and frame.radio_bw_x10_khz is not None \
                and frame.radio_sf is not None and frame.radio_cr is not None:
            self._lora_per_port[sanitized] = LoRaConfig(
                freq_hz=frame.radio_freq_hz,
                # Wire carries BW in 0.1 kHz units; LoRaConfig wants Hz.
                bandwidth_hz=frame.radio_bw_x10_khz * 100,
                spread_factor=frame.radio_sf,
                # LoRaConfig.coderate is a "4/N" string; the firmware
                # emits the bare denominator (5..8).
                coderate=f"4/{frame.radio_cr}",
            )
        topic = f"{self._cfg.topic_prefix}/{sanitized}/info"
        envelope = build_info_envelope(
            frame,
            display_name=self._resolve_name(sanitized),
            mqtt_client_id=self._cfg.client_id,
            operator_hardware=self._match_operator_hardware(port),
        )
        payload = json.dumps(envelope, separators=(",", ":")).encode("utf-8")
        self._client.publish(topic, payload, qos=self._cfg.qos, retain=True)
        self._mirror_to_pubkey(port, "info", payload, retain=True)
        # Snapshot for the portal's Health cards. Field names match
        # GatewayInfoFrame's actual attribute names (``fw_version`` /
        # ``tdoa_fw_version``); the legacy ``firmware_version`` /
        # ``tdoa_firmware_version`` getattrs silently returned None and
        # the cards stayed blank.
        self._update_status(
            port,
            # node_id (6-byte pubkey prefix) is the node's identity — surfaced
            # to the portal so it can label the USB device by its node name/id
            # instead of only the USB-vendor slug (operator 2026-06-06).
            node_id=(frame.node_id.hex() if getattr(frame, "node_id", None) else None),
            board_name=getattr(frame, "board_name", None),
            firmware_version=getattr(frame, "fw_version", None),
            tdoa_firmware_version=getattr(frame, "tdoa_fw_version", None),
            mcu_chip=getattr(frame, "mcu_chip", None),
            lora_chip=getattr(frame, "lora_chip", None),
            has_gps=getattr(frame, "has_gps", None),
            has_pps=getattr(frame, "has_pps", None),
            is_tdoa_rx=getattr(frame, "is_tdoa_rx", None),
            gps_time_sync_confirmed=getattr(frame, "gps_time_sync_confirmed", None),
            # tdoa 2026-05-29 PM: probe-detected GPS chip identity. Cached
            # into the per-port status snapshot so the portal /api/devices
            # /{slug}/health endpoint can surface "GPS chip: L76K v2.0
            # (HW confirmed)" the moment the page loads.
            gps_chip_family=getattr(frame, "gps_chip_family", None),
            gps_chip_family_name=(
                _GPS_FAMILY_NAMES.get(int(frame.gps_chip_family))
                if getattr(frame, "gps_chip_family", None) is not None
                else None
            ),
            gps_chip_model=getattr(frame, "gps_chip_model", None),
            gps_chip_sw_version=getattr(frame, "gps_chip_sw_version", None),
            gps_bootstrap_ack=getattr(frame, "gps_bootstrap_ack", None),
            gps_enabled_gnss_mask=getattr(frame, "gps_enabled_gnss_mask", None),
        )

    def _match_operator_hardware(
        self, port: str
    ) -> HardwareMetadata | None:
        """Find the first ``hardware:`` config block whose glob matches
        ``port``. Globs are checked in YAML insertion order; the first
        match wins. Returns ``None`` when nothing matches — the
        envelope then omits the ``hardware.operator`` sub-block and
        the gateway row keeps whatever it had before.
        """
        if not self._hardware_per_glob:
            return None
        for glob, meta in self._hardware_per_glob.items():
            if fnmatch.fnmatch(port, glob):
                return meta
        return None

    def _resolve_pubkey(self, port: str) -> str | None:
        """Return the receiver's 64-hex pubkey for ``port``, if known.

        Prefers the AUTO-LEARNED pubkey cached from the 0x94 V210 self-pubkey
        tail (docs/proto-pubkey-identity.md); falls back to the operator-declared
        ``hardware:<glob>::pubkey``. Used by the uplink/position/telemetry/
        gps_quality envelopes (and the pubkey topic mirror). The /info envelope
        still passes the full HardwareMetadata since it surfaces every operator
        field.
        """
        learned = self._pubkey_per_port.get(sanitize_port(port))
        if learned:
            return learned
        hw = self._match_operator_hardware(port)
        return hw.pubkey if hw is not None else None

    def _resolve_node_type(self, port: str) -> str | None:
        """Return the controlled mesh node_type for ``port`` (or ``None``).

        The value is the operator-declared ``hardware:<glob>::node_type``
        (``anchor | companion | repeater | unknown``), validated ONCE at config
        load (:func:`config._coerce_node_type`) — not here. It's attached as
        ``meta.node_type`` on every uplink so the downstream mesh-relay can gate
        companion-role traffic out of the public-fanout brokers without a DB
        lookup; ``None`` lets the relay fall through to its
        "missing == external-fanout-enabled" default.

        The free-form ``hardware:<glob>::role`` deployment label (operators write
        "reference", "under-test", "production" for timing-campaign notes) is
        deliberately NOT consulted here — conflating the two is what produced a
        per-publish ``node_type.off_vocab`` warning every ~2 s for such labels.
        Legacy configs that put a controlled value in ``role`` are promoted to
        ``node_type`` at config load for back-compat.
        """
        hw = self._match_operator_hardware(port)
        return hw.node_type if hw is not None else None

    def _bootstrap_status(
        self, *, hardware: dict[str, HardwareMetadata],
    ) -> dict[str, dict[str, Any]]:
        """Restore per-port snapshot at startup so portal cards aren't blank.

        Read priority:
          1. /run/.../status.json (freshest — written by the previous
             bridge process within the last 2s before it died)
          2. /var/lib/.../status.json (boot-persistent — only stale by
             how long the box was off)
          3. Empty dict if neither exists.

        On top of whichever snapshot we recovered, we layer any operator-
        declared hardware metadata from ``config.yaml``. The operator-
        supplied fields (gpsModule, role, etc.) NEVER change at runtime
        so it's safe to seed them unconditionally; they get overwritten
        only by an actual 0x94 emit. This means a brand-new portal show-
        ing a Pi that hasn't fired its first 0x94 yet still renders
        operator-known facts (board family, role, etc.) immediately.
        """
        snapshot: dict[str, dict[str, Any]] = {}
        for candidate in (self._status_path, self._status_path_persistent):
            try:
                raw = candidate.read_text(encoding="utf-8")
            except OSError:
                continue
            try:
                loaded = json.loads(raw)
            except (ValueError, TypeError):
                continue
            ports = loaded.get("ports") if isinstance(loaded, dict) else None
            if isinstance(ports, dict):
                # Defensive copy + type check — we don't want a corrupt
                # status.json to crash the bridge on boot.
                snapshot = {
                    str(k): dict(v) for k, v in ports.items()
                    if isinstance(v, dict)
                }
                break
        # Layer operator hardware metadata on top so brand-new ports
        # have something to render even before the first 0x94 fires.
        for glob, meta in hardware.items():
            # The glob *might* not match a sanitized-port key we've
            # seen before — that's fine; the actual port-key will
            # overwrite on first publish. We key by the glob string
            # so a Pi with multiple receivers configured has all of
            # them visible at boot.
            key = sanitize_port(glob.replace("*", "X"))
            st = snapshot.setdefault(key, {})
            for src, dst in (
                ("role", "role"),
                ("notes", "notes"),
                ("gps_module", "gps_module"),
                ("lora_antenna", "lora_antenna"),
                ("power_source", "power_source"),
                ("pcb_revision", "pcb_revision"),
            ):
                val = getattr(meta, src, None)
                if val is not None and st.get(dst) is None:
                    st[dst] = val
        return snapshot

    def update_port_health(self, port: str, kind: str, detail: str = "") -> None:
        """Record a per-port health class in status.json (Erik #3).

        ``kind`` ∈ {ok, serial_error, quarantined, unavailable,
        mqtt_unauthorized}. The portal reads ``health`` + ``health_detail``
        from each port entry and renders a precise badge explaining *why* a
        port has no frames. ``ok`` clears the detail so a recovered port
        doesn't keep showing a stale error string.

        Public (called by the supervisor's on_health hook via __main__);
        delegates to ``_update_status`` so the throttled flush is reused.
        """
        self._update_status(
            port,
            health=kind,
            health_detail=(detail or None) if kind != "ok" else "",
        )

    def _update_status(self, port: str, **fields: Any) -> None:
        """Merge ``fields`` into the per-port snapshot and flush to disk.

        Called from publish_frame / publish_info / publish_telemetry /
        publish_position with the freshest values they have. The flush
        is throttled to once per 2s so a 50 fps uplink storm doesn't
        spam the disk.
        """
        sanitized = sanitize_port(port)
        with self._status_lock:
            st = self._per_port_status.setdefault(sanitized, {
                "port": port,
                "sanitized": sanitized,
            })
            # Only overwrite with non-None — preserves bootstrapped or
            # operator-supplied defaults when this particular event
            # doesn't carry a fresher value (e.g. a 0x90 uplink doesn't
            # know board_name, so we skip it rather than null it).
            for k, v in fields.items():
                if v is not None:
                    st[k] = v
            # Persist the auto-learned V210 self-pubkey so the portal can backfill
            # the relay's [repeater].pub_key from status.json (#2) WITHOUT the
            # operator hand-editing bridge.yaml. Once a 0x94 V210 frame is seen,
            # _pubkey_per_port has it; surface it here for downstream readers.
            learned_pk = self._pubkey_per_port.get(sanitized)
            if learned_pk and not st.get("pubkey_hex"):
                st["pubkey_hex"] = learned_pk
            st["updated_at"] = time.time()
            now = time.monotonic()
            if now - self._status_last_write < 2.0:
                return
            self._status_last_write = now
            snapshot = self._status_snapshot()
        self._flush_status(snapshot)

    def _status_snapshot(self) -> dict[str, Any]:
        """Build the status.json payload. ``bridge_version`` is the 'proven
        running' version (this process wrote the file) surfaced in the portal
        top bar next to the portal deb version; ``portal_version`` rides along
        so a single read gives both. Caller must hold ``self._status_lock``."""
        return {
            "bridge_version": _BRIDGE_VERSION,
            "portal_version": _PORTAL_VERSION,
            "mqtt": getattr(self, "_mqtt_health", "connecting"),
            # Non-secret destination of the bridge's TDOA export (the
            # backend/homeprod broker). The unprivileged portal can't read
            # the root-only bridge.yaml, so it surfaces host/port/transport
            # for the read-only "TDOA export" broker-list row from here.
            # Credentials are NEVER written to status.json.
            "broker_host": self._cfg.host or None,
            "broker_port": self._cfg.port,
            "broker_transport": self._cfg.transport,
            "ports": dict(self._per_port_status),
        }

    def _flush_status(self, snapshot: dict[str, Any]) -> None:
        """Write the snapshot to both status paths. Best-effort — never raises
        (the publish path must not fail because /run wasn't writable)."""
        payload = json.dumps(snapshot, indent=2)
        for path in (self._status_path, self._status_path_persistent):
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(payload, encoding="utf-8")
            except OSError:
                continue

    def publish_telemetry(self, port: str, frame: DeviceTelemetryFrame) -> None:
        """Publish a single 0x96 frame under ``<prefix>/<sanitized-port>/telemetry``.

        Telemetry events are RETAINED on the broker so a freshly-
        subscribed consumer (Observer tab, restarted collector) sees
        the most recent device-health snapshot per receiver without
        waiting up to ``TELEMETRY_INTERVAL_MS`` (firmware default 5 s)
        for the next periodic emission. The retained payload is
        overwritten on every subsequent publish, so disk usage on the
        broker is bounded.

        Topic shape matches the existing ``/uplink|/position|/info``
        family so the collector's ChirpStack-shaped subscriber can
        absorb the new family with a single topic-pattern addition.
        The KAN-102 backend storage path consumes this on
        ``gateway/{eui}/telemetry`` once routed through the collector.
        """
        sanitized = sanitize_port(port)
        topic = f"{self._cfg.topic_prefix}/{sanitized}/telemetry"
        envelope = build_telemetry_envelope(
            frame,
            display_name=self._resolve_name(sanitized),
            mqtt_client_id=self._cfg.client_id,
            gateway_pubkey_hex=self._resolve_pubkey(port),
        )
        payload = json.dumps(envelope, separators=(",", ":")).encode("utf-8")
        self._client.publish(topic, payload, qos=self._cfg.qos, retain=True)
        self._mirror_to_pubkey(port, "telemetry", payload, retain=True)
        # Refresh portal-side health snapshot. Every field on the 0x96
        # carries through unchanged so the portal can render its cards
        # without reaching into the cloud DB.
        self._update_status(
            port,
            gateway_id=frame.node_id_hex if hasattr(frame, "node_id_hex") else None,
            gps_sats=getattr(frame, "gps_sats", None),
            pps_jitter_us=getattr(frame, "pps_jitter_us", None),
            mcu_temp_c=getattr(frame, "mcu_temp_c", None),
            vbat_mv=getattr(frame, "vbat_mv", None),
            uptime_s=getattr(frame, "uptime_s", None),
        )

    def publish_gps_quality(self, port: str, frame: GpsQualityFrame) -> None:
        """Publish a single 0x9F frame under ``<prefix>/<sanitized-port>/gps_quality``.

        GPS-quality events are NOT retained on the broker — they are
        time-series data (one snapshot per emission) and overwriting a
        retained payload would lose the per-epoch history the timing
        pipeline correlates against. A late-joining subscriber catches
        up on the next firmware emission instead.

        Topic shape matches the existing ``/uplink|/position|/info|/telemetry``
        family so the collector's ChirpStack-shaped subscriber can
        absorb the new family with a single topic-pattern addition.
        """
        sanitized = sanitize_port(port)
        topic = f"{self._cfg.topic_prefix}/{sanitized}/gps_quality"
        envelope = build_gps_quality_envelope(
            frame,
            display_name=self._resolve_name(sanitized),
            mqtt_client_id=self._cfg.client_id,
            gateway_pubkey_hex=self._resolve_pubkey(port),
        )
        payload = json.dumps(envelope, separators=(",", ":")).encode("utf-8")
        self._client.publish(topic, payload, qos=self._cfg.qos, retain=False)
        self._mirror_to_pubkey(port, "gps_quality", payload, retain=False)
        # Refresh portal-side health snapshot with the GPS-quality fields
        # so the Health endpoint can render DOP / fix / sat-total without
        # subscribing to MQTT. None values are filtered by _update_status.
        self._update_status(
            port,
            last_hdop=frame.hdop,
            last_pdop=frame.pdop,
            last_vdop=frame.vdop,
            last_fix_quality=int(frame.fix_quality),
            last_sat_total=int(frame.sat_total),
        )
