"""IATA region-code resolution for the DutchMeshCore observer topic.

DMC topics are ``meshcore/{IATA}/{pubkey}/{type}`` where ``{IATA}`` is a
3-letter airport code used purely as a regional routing tag. We resolve it,
in priority order:

  1. an explicit operator setting (``dutchmeshcore.iata`` in node config), else
  2. the nearest airport to the gateway's GPS position, else
  3. ``None`` — the caller treats "no GPS fix AND no IATA set" as an error
     (the DMC broker can't be addressed, so its status goes red).

The airport table is a curated set of major airports (dense over the
Netherlands / Europe, plus global hubs) — accuracy to the *nearest major
airport* is all the region tag needs; it is not a precise geocoder.
"""
from __future__ import annotations

import math

#: (IATA, latitude, longitude). Curated — NL + EU dense, global hubs sparse.
_AIRPORTS: tuple[tuple[str, float, float], ...] = (
    # Netherlands
    ("AMS", 52.3105, 4.7683),   # Amsterdam Schiphol
    ("RTM", 51.9569, 4.4375),   # Rotterdam The Hague
    ("EIN", 51.4500, 5.3747),   # Eindhoven
    ("MST", 50.9117, 5.7701),   # Maastricht Aachen
    ("GRQ", 53.1197, 6.5794),   # Groningen Eelde
    ("ENS", 52.2700, 6.8745),   # Enschede Twente
    # Belgium / Luxembourg
    ("BRU", 50.9014, 4.4844),   # Brussels
    ("ANR", 51.1894, 4.4603),   # Antwerp
    ("CRL", 50.4592, 4.4538),   # Brussels South Charleroi
    ("LGG", 50.6374, 5.4432),   # Liège
    ("OST", 51.1989, 2.8622),   # Ostend
    ("LUX", 49.6266, 6.2115),   # Luxembourg
    # Germany (west / near NL)
    ("DUS", 51.2895, 6.7668),   # Düsseldorf
    ("CGN", 50.8659, 7.1427),   # Cologne Bonn
    ("FRA", 50.0379, 8.5622),   # Frankfurt
    ("FMO", 52.1346, 7.6848),   # Münster Osnabrück
    ("NRN", 51.6024, 6.1422),   # Weeze (Niederrhein)
    ("BER", 52.3667, 13.5033),  # Berlin Brandenburg
    ("MUC", 48.3538, 11.7861),  # Munich
    ("HAM", 53.6304, 9.9882),   # Hamburg
    # France / UK / Ireland
    ("CDG", 49.0097, 2.5479),   # Paris CDG
    ("LIL", 50.5619, 3.0894),   # Lille
    ("LHR", 51.4700, -0.4543),  # London Heathrow
    ("LGW", 51.1537, -0.1821),  # London Gatwick
    ("MAN", 53.3537, -2.2750),  # Manchester
    ("DUB", 53.4213, -6.2701),  # Dublin
    # Iberia / Italy / Nordics / East
    ("MAD", 40.4719, -3.5626),  # Madrid
    ("BCN", 41.2974, 2.0833),   # Barcelona
    ("LIS", 38.7742, -9.1342),  # Lisbon
    ("FCO", 41.8003, 12.2389),  # Rome
    ("MXP", 45.6306, 8.7281),   # Milan Malpensa
    ("ZRH", 47.4582, 8.5556),   # Zurich
    ("VIE", 48.1103, 16.5697),  # Vienna
    ("CPH", 55.6180, 12.6508),  # Copenhagen
    ("ARN", 59.6519, 17.9186),  # Stockholm Arlanda
    ("OSL", 60.1939, 11.1004),  # Oslo
    ("HEL", 60.3172, 24.9633),  # Helsinki
    ("WAW", 52.1657, 20.9671),  # Warsaw
    ("PRG", 50.1008, 14.2600),  # Prague
    ("IST", 41.2753, 28.7519),  # Istanbul
    # Rest of world (sparse — keep non-EU gateways from snapping to Europe)
    ("JFK", 40.6413, -73.7781),
    ("LAX", 33.9416, -118.4085),
    ("ORD", 41.9742, -87.9073),
    ("SEA", 47.4502, -122.3088),
    ("ATL", 33.6407, -84.4277),
    ("YYZ", 43.6777, -79.6248),
    ("GRU", -23.4356, -46.4731),
    ("DXB", 25.2532, 55.3657),
    ("SIN", 1.3644, 103.9915),
    ("HKG", 22.3080, 113.9185),
    ("NRT", 35.7720, 140.3929),
    ("SYD", -33.9399, 151.1753),
    ("JNB", -26.1392, 28.2460),
    ("BOM", 19.0896, 72.8656),
)


def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in km between two lat/lon points."""
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlmb = math.radians(lon2 - lon1)
    a = (
        math.sin(dphi / 2) ** 2
        + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    )
    return 2 * r * math.asin(math.sqrt(a))


def nearest_iata(lat: float, lon: float) -> str:
    """Return the IATA code of the nearest airport in the curated table."""
    return min(
        _AIRPORTS, key=lambda a: _haversine_km(lat, lon, a[1], a[2])
    )[0]


def resolve_iata(
    configured: str | None,
    lat: float | None,
    lon: float | None,
) -> str | None:
    """Resolve the DMC IATA: explicit config wins, else nearest-airport from
    GPS, else ``None`` (no GPS + no config — caller flags an error).

    A configured value is normalised to upper-case; only a plausible 3-letter
    code is accepted, otherwise we fall through to GPS.
    """
    if configured:
        code = configured.strip().upper()
        if len(code) == 3 and code.isalpha():
            return code
    if lat is not None and lon is not None and (lat != 0.0 or lon != 0.0):
        return nearest_iata(lat, lon)
    return None
