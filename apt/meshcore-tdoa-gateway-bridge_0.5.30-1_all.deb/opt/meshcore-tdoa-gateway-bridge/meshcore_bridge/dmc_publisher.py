"""DutchMeshCore observer publish path (opt-in, off by default).

DMC (https://dutchmeshcore.nl/#cluster) is a public MeshCore observer cluster.
Publishing to it is a real protocol — NOT a raw mirror of our TDOA envelope:

* Connection: WSS :443, TLS, ``collector1.dutchmeshcore.nl`` (collector2 failover).
* Auth: Ed25519 JWT. Username ``v1_{UPPERCASE_PUBKEY}``; password a JWT signed
  with the gateway's Ed25519 private key (payload carries the pubkey + owner
  email), auto-renewed before its 24h expiry.
* Topic: ``meshcore/{IATA}/{PUBKEY}/{packets|status}``. IATA is the regional
  tag — operator-set, else auto from GPS (nearest airport, :mod:`.iata`).
* Payload: the MeshCore observer JSON (origin / origin_id / SNR / RSSI / hash /
  raw …), one message per heard packet.

This module owns the identity (key), the auth token, the payload translation,
and the status/reason the UI shows. The paho connection lifecycle is the thin
:class:`DmcObserverPublisher` at the bottom.

⚠ Prep: the exact JWT claim names DMC's broker verifies are not yet confirmed
against the live cluster — keep DMC off until an end-to-end publish is verified
with a key registered at portal.dutchmeshcore.nl.
"""
from __future__ import annotations

import base64
import json
import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .config import DutchMeshCoreConfig
from .iata import resolve_iata

JWT_TTL_SECONDS = 24 * 3600


def _b64url(data: bytes) -> str:
    """URL-safe base64 without padding (JWT segment encoding)."""
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


@dataclass
class DmcIdentity:
    """The gateway's own Ed25519 identity for DMC (distinct from the LoRa
    node's key — the bridge never holds the device private key)."""

    _private: Ed25519PrivateKey

    @classmethod
    def load_or_create(cls, key_path: str) -> DmcIdentity:
        """Load the persisted raw-32-byte Ed25519 private key, or generate +
        persist one (0600) on first use."""
        p = Path(key_path)
        if p.exists():
            return cls(Ed25519PrivateKey.from_private_bytes(p.read_bytes()))
        priv = Ed25519PrivateKey.generate()
        from cryptography.hazmat.primitives import serialization

        raw = priv.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )
        p.parent.mkdir(parents=True, exist_ok=True)
        # Write 0600 atomically-ish.
        fd = os.open(str(p), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(raw)
        return cls(priv)

    def public_hex(self) -> str:
        """Uppercase hex of the raw 32-byte Ed25519 public key."""
        from cryptography.hazmat.primitives import serialization

        raw = self._private.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        return raw.hex().upper()

    def username(self) -> str:
        """DMC MQTT username: ``v1_{UPPERCASE_PUBKEY}``."""
        return f"v1_{self.public_hex()}"

    def sign(self, data: bytes) -> bytes:
        return self._private.sign(data)


def build_jwt(
    identity: DmcIdentity, email: str | None, now: datetime, ttl_s: int = JWT_TTL_SECONDS
) -> str:
    """Build an Ed25519 (EdDSA) JWT for DMC auth.

    Claims: ``pub`` (the auth pubkey), ``email`` (DMC ties the key to an
    owner), ``iat`` / ``exp``. The signature is verifiable with the pubkey in
    the username.
    """
    iat = int(now.timestamp())
    header = {"alg": "EdDSA", "typ": "JWT"}
    payload: dict[str, Any] = {
        "pub": identity.public_hex(),
        "iat": iat,
        "exp": iat + ttl_s,
    }
    if email:
        payload["email"] = email
    signing_input = (
        _b64url(json.dumps(header, separators=(",", ":")).encode())
        + "."
        + _b64url(json.dumps(payload, separators=(",", ":")).encode())
    )
    sig = identity.sign(signing_input.encode("ascii"))
    return signing_input + "." + _b64url(sig)


def observer_packet(
    *,
    origin: str,
    origin_id: str,
    raw_hex: str,
    snr: float | None,
    rssi: int | None,
    packet_hash_hex: str,
    when: datetime,
) -> dict[str, Any]:
    """Translate one heard packet into the MeshCore observer JSON DMC expects."""
    return {
        "origin": origin,
        "origin_id": origin_id,
        "timestamp": when.isoformat(),
        "type": "PACKET",
        "direction": "rx",
        "time": when.strftime("%H:%M:%S"),
        "date": when.strftime("%d/%m/%Y"),
        "len": str(len(raw_hex) // 2),
        "SNR": "" if snr is None else str(snr),
        "RSSI": "" if rssi is None else str(rssi),
        "hash": packet_hash_hex.upper(),
        "raw": raw_hex.upper(),
    }


def packets_topic(iata: str, pubkey_hex: str) -> str:
    return f"meshcore/{iata}/{pubkey_hex}/packets"


def status_topic(iata: str, pubkey_hex: str) -> str:
    return f"meshcore/{iata}/{pubkey_hex}/status"


def dmc_status(
    cfg: DutchMeshCoreConfig, lat: float | None, lon: float | None
) -> tuple[str, str]:
    """Compute the DMC broker's status + reason for the UI.

    Returns one of:
      ('disabled', …)  — not enabled (grey).
      ('error', …)     — enabled but no IATA resolvable: no GPS fix AND no
                         ``iata`` configured, so no topic can be addressed (red).
      ('ok', …)        — enabled and a topic is addressable (green).
    """
    if not cfg.enabled:
        return "disabled", "DutchMeshCore publish is off"
    iata = resolve_iata(cfg.iata, lat, lon)
    if iata is None:
        return (
            "error",
            "No GPS fix and no IATA set — can't address a DutchMeshCore "
            "topic. Set the node's GPS location or configure an IATA code.",
        )
    return "ok", f"Publishing to DutchMeshCore (region {iata})"
