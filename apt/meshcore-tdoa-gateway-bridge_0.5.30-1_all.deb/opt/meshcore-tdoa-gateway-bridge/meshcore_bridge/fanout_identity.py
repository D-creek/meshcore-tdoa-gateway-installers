"""Decide whether a pubkey is a real device identity safe to publish under.

Fan-out identity need only be a structurally-valid, non-degenerate 64-hex
Ed25519 public key. We deliberately do NOT keep a placeholder/denylist:
field finding (skypi4) confirmed that "magic number" vanity keys like
``FEEDCAFE...`` (Heltec V4) and ``C0FFEE...`` (RAK4631) are REAL keypairs the
devices actually hold — the bridge's auth_token_minter had the RAK device SIGN
a JWT with the C0FFEE key, which is only possible if the device holds the
matching Ed25519 private key. So those vanity keys are legitimate identities.

Anti-laundering protection comes from the ARCHITECTURE, not from a denylist:
each bridge fans out ONLY its own local frames under its own resolved identity
— there is no wildcard subscription and no primary-fallback identity — so a
device cannot launder another device's traffic regardless of its pubkey value.

We therefore only reject values that cannot be a real key: missing/empty,
length != 64, non-hex, the all-zeros and all-f degenerate keys, and the literal
"unknown" sentinel (case-insensitive — the relay's config fallback used
"UNKNOWN" when no identity was declared).
"""
from __future__ import annotations


def is_real_pubkey(pubkey: str | None) -> bool:
    if not pubkey:
        return False
    pk = pubkey.strip().lower()
    if pk == "unknown":
        return False
    if len(pk) != 64:
        return False
    try:
        int(pk, 16)
    except ValueError:
        return False
    if set(pk) <= {"0"} or set(pk) <= {"f"}:
        return False
    return True
