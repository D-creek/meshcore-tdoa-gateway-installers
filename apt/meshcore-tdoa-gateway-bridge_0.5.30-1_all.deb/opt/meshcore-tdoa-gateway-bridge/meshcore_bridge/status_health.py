"""Per-enabled-broker publish-health verdict + the typed gateway_status envelope.

Pure functions — no I/O — so they unit-test cleanly. The bridge's status
publisher (see __main__) feeds these the broker snapshots from
FanoutManager.snapshot() (+ primary/secondary), the per-port last_packet_at,
and the previous-tick publish_ok counts.
"""
from __future__ import annotations

from typing import Any


def compute_broker_verdict(
    broker: dict[str, Any],
    *,
    prev_publish_ok: int,
    port_last_packet_at: float | None,
) -> tuple[bool, str]:
    """(healthy, reason) for ONE enabled broker.

    healthy = connected & no last_error & (publish_ok advanced since the last
    status tick OR no rx traffic arrived since the last successful publish).
    A quiet gateway (no packets to forward) stays healthy.
    """
    if not broker.get("connected"):
        return False, "disconnected"
    err = broker.get("last_error")
    if err:
        return False, f"error: {err}"
    publish_ok = int(broker.get("publish_ok") or 0)
    advanced = publish_ok > prev_publish_ok
    last_pub = float(broker.get("last_publish_ok_at") or 0.0)
    rx_since_pub = (port_last_packet_at or 0.0) > last_pub
    if rx_since_pub and not advanced:
        return False, "rx traffic present but publish stalled"
    return True, ("publishing" if advanced else "idle (no traffic to forward)")


def build_gateway_status(
    *,
    gateway_id: str,
    gateway_uid: str,
    port: str,
    brokers: list[dict[str, Any]],
    prev_ok: dict[str, int],
    port_last_packet_at: float | None,
    now: float,
) -> tuple[dict[str, Any], dict[str, int]]:
    """Build the typed gateway_status envelope + the next prev_ok map.

    Only ENABLED brokers are reported. Each entry carries the raw counters
    (for the hover) plus the computed healthy/reason verdict.
    """
    out_brokers: list[dict[str, Any]] = []
    next_prev: dict[str, int] = {}
    for b in brokers:
        if not b.get("enabled", True):
            continue
        name = str(b.get("name") or "?")
        prev = int(prev_ok.get(name, 0))
        healthy, reason = compute_broker_verdict(
            b, prev_publish_ok=prev, port_last_packet_at=port_last_packet_at
        )
        next_prev[name] = int(b.get("publish_ok") or 0)
        out_brokers.append({
            "name": name,
            "kind": b.get("kind"),
            "connected": bool(b.get("connected")),
            "publish_ok": int(b.get("publish_ok") or 0),
            "publish_fail": int(b.get("publish_fail") or 0),
            "last_publish_ok_at": b.get("last_publish_ok_at"),
            "last_error": b.get("last_error"),
            "healthy": healthy,
            "reason": reason,
        })
    envelope = {
        "type": "gateway_status",
        "gatewayId": gateway_id,
        "gatewayUid": gateway_uid,
        "meta": {"source": "pi-bridge", "port": port},
        "brokers": out_brokers,
        "status_emitted_at": now,
    }
    return envelope, next_prev
