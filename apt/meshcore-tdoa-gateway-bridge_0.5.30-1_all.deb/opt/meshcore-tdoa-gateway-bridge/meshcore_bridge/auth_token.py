"""MeshCore-signed JWT minting for token-auth brokers (letsmesh-us / -eu).

Letsmesh expects a JWT signed by the device's Ed25519 private key (stored
on-device as ``prv.key``). The signing is delegated to the ``meshcore-decoder``
npm CLI tool (same binary mctomqtt uses) — re-implementing Ed25519 with
MeshCore's specific signature framing in Python is more risk than value.

Refresh policy: tokens expire after ``expiry_seconds`` (default 1 h). The
BrokerClient calls ``mint()`` synchronously on connect + every refresh
cycle; we mint a NEW token rather than re-using the cached one so the
broker can't reject a stale signature mid-session.

prv.key sourcing: the relay receives it via the
``BRIDGE_REPEATER_PRIV_KEY`` env var (same approach as mctomqtt — read
once from the device and stored in the EnvironmentFile). The relay never
touches the serial port.
"""
from __future__ import annotations

import json
import logging
import subprocess

logger = logging.getLogger("meshcore_bridge.auth_token")


_CLI = "meshcore-decoder"


def mint(
    public_key_hex: str,
    private_key_hex: str,
    *,
    expiry_seconds: int = 3600,
    **claims: object,
) -> str:
    """Return a fresh JWT signed by the MeshCore Ed25519 key.

    Raises FileNotFoundError if the meshcore-decoder CLI is not on PATH
    (install with ``npm install -g @michaelhart/meshcore-decoder``).
    Raises RuntimeError on any signing failure.
    """
    cmd = [_CLI, "auth-token", public_key_hex, private_key_hex,
           "-e", str(expiry_seconds)]
    if claims:
        cmd.extend(["-c", json.dumps(claims)])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10, check=False)
    except FileNotFoundError as exc:
        raise FileNotFoundError(
            f"{_CLI} not found on PATH — install with "
            "`npm install -g @michaelhart/meshcore-decoder`"
        ) from exc

    if result.returncode != 0:
        raise RuntimeError(f"{_CLI} returned {result.returncode}: {result.stderr.strip()}")

    token = result.stdout.strip()
    # JWTs are exactly two dots (header.payload.signature). Anything else is
    # a malformed reply from the CLI — surface loudly instead of pushing
    # garbage at the broker.
    if token.count(".") != 2:
        raise RuntimeError(f"{_CLI} returned non-JWT output: {token[:80]!r}")
    return token
