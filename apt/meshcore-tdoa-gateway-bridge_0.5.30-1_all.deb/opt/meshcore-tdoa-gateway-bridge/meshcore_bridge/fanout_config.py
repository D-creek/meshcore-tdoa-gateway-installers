"""Load and validate the per-device mctomqtt-style config.toml for fan-out.

The portal (D-creek/meshcore-toad-gateway repo) writes this exact file at
``/etc/meshcore-tdoa-gateway/devices/<slug>/config.toml``; reusing it as the
sole source of truth so the operator only edits brokers in one place. We
deliberately do NOT define a separate config schema.

Format reference: same as the legacy `mctomqtt` (TOML with [[broker]]
array of tables, each carrying name/server/port/transport/auth/topics).
We accept whatever the portal emits and only validate the fields we need
to publish (server, port, auth.method, custom_topic or topics.packets).

Fan-out identity is the device's auto-learned 0x94 self-pubkey, supplied
by the bridge. Config-declared pubkeys (repeater.pub_key, broker auth.owner)
are placeholders (FEEDCAFE/C0FFEE) and are NEVER used as fan-out identity.
"""
from __future__ import annotations

import logging
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger("meshcore_bridge.fanout_config")


@dataclass
class FanoutBrokerConfig:
    """A single [[broker]] entry from config.toml, normalised."""

    name: str
    enabled: bool
    server: str
    port: int
    transport: str  # "tcp" | "websockets"
    keepalive: int
    qos: int
    retain: bool
    tls_enabled: bool
    tls_verify: bool
    auth_method: str  # "none" | "password" | "token"
    auth_username: str | None
    auth_password: str | None
    auth_token_audience: str | None
    auth_token_owner: str | None
    auth_token_email: str | None
    custom_topic: str | None
    topics: dict[str, str]  # broker-level topic templates
    # Per-broker payload protocol override (set by the gateway portal's
    # PUT /api/devices/{slug}/brokers/{name}/protocol). "tdoa" = our own
    # TDOA-extended JSON envelope; "mctomqtt" = legacy Cisien/meshcoretomqtt-
    # shaped on8ar payload; None = no override, fall back to the auto-
    # classify default in `broker_kind`.
    protocol_override: str | None
    raw: dict[str, Any]  # the original block, for diagnostic logging

    @property
    def broker_kind(self) -> str:
        """Classify the broker by its server address — used by the router to skip the TDOA broker.

        Mirrors `app/main.py::_classify` in the portal repo (must stay in
        sync — server-substring match is the only signal we have).
        """
        s = self.server.lower()
        if "tdoa" in s:
            return "meshcore-tdoa"
        if "letsmesh" in s:
            return "letsmesh"
        if "meshrank" in s:
            return "meshrank"
        if "on8ar" in s or "emqx" in s:
            return "emqx-public"
        return "generic-mqtt"

    @property
    def effective_protocol(self) -> str:
        """The wire format the dispatcher should use for this broker.

        Resolution order:
          1. Operator override via the portal (TOML ``protocol = "tdoa" |
             "mctomqtt"``) wins outright.
          2. **Topic-marker auto-detect**: any topic template (custom_topic
             or topics.*) containing ``tdoa_gateway`` flags this broker
             as TDOA. The collector also publishes a ``tdoa_gateway``
             status topic on first connect; an MQTT subscriber that
             sees it can call back to the portal to flip the broker.
             Works on first-time nodes — no pubkey needed (vs. the
             earlier ``{PUBLIC_KEY}``-templated approach).
          3. broker_kind == "meshcore-tdoa" → "tdoa" by default
             (legacy match on plain "tdoa" substring, e.g.
             ````).
          4. Everything else → "mctomqtt" (the legacy on8ar shape).
        """
        if self.protocol_override in ("tdoa", "mctomqtt"):
            return self.protocol_override
        all_topics: list[str] = list(self.topics.values())
        if self.custom_topic:
            all_topics.append(self.custom_topic)
        for t in all_topics:
            if "tdoa_gateway" in str(t).lower():
                return "tdoa"
        # #1B (2026-06-09): NO server-substring fallback. A broker is TDOA only if
        # it SAYS so (protocol="tdoa") or carries a tdoa_gateway topic — not because
        # its hostname happens to contain "tdoa". homeprod (mqtt.dahllie.nl) sets
        # protocol explicitly, so it still classes correctly; a generic broker no
        # longer mis-classes on a host substring (broker_kind stays for diagnostics).
        return "mctomqtt"


@dataclass
class FanoutDeviceConfig:
    """Top-level fan-out device config — IATA + brokers + global topic templates.

    Identity (pub_key) is intentionally absent: the bridge supplies it from
    the auto-learned 0x94 self-pubkey, never from config. Config-declared
    pub_key values are operator placeholders and must never be re-used as
    fan-out identity.
    """

    iata: str
    repeater_name: str
    brokers: list[FanoutBrokerConfig]
    global_topics: dict[str, str] = field(default_factory=dict)


def load_device_fanout(path: Path) -> FanoutDeviceConfig:
    """Parse the TOML at ``path`` and return a normalised FanoutDeviceConfig.

    Raises ``FileNotFoundError`` on missing path, ``ValueError`` on
    structural problems (missing iata, missing brokers, etc.). Logs a
    warning + skips any broker missing required fields so a single bad
    entry doesn't blow up the entire fan-out.
    """
    if not path.is_file():
        raise FileNotFoundError(f"config not found: {path}")

    with path.open("rb") as fh:
        doc = tomllib.load(fh)

    general = doc.get("general", {})
    iata = str(general.get("iata", "")).strip()
    if not iata:
        # Not fatal — topic templates that use {IATA} will end up with an
        # empty substitution. mctomqtt does the same.
        logger.warning("config.iata.missing path=%s — {IATA} substitutions will be empty", path)

    repeater = doc.get("repeater", {})
    repeater_name = str(repeater.get("name", "unknown-repeater"))

    # NOTE: repeater.pub_key and broker auth.owner are intentionally NOT read.
    # Those fields carry operator-declared placeholder values (FEEDCAFE/C0FFEE).
    # Fan-out identity is the device's auto-learned 0x94 self-pubkey, supplied
    # by the bridge — never from config.

    brokers: list[FanoutBrokerConfig] = []
    for raw in doc.get("broker", []) or []:
        try:
            brokers.append(_normalise_broker(raw))
        except KeyError as exc:
            logger.warning(
                "config.broker.skipped name=%s reason=missing-field field=%s",
                raw.get("name", "?"),
                exc.args[0],
            )

    if not brokers:
        raise ValueError(f"no [[broker]] entries found in {path}")

    global_topics = doc.get("topics", {}) or {}

    return FanoutDeviceConfig(
        iata=iata,
        repeater_name=repeater_name,
        brokers=brokers,
        global_topics=global_topics,
    )


def _normalise_broker(raw: dict[str, Any]) -> FanoutBrokerConfig:
    """Lift the TOML block into a typed FanoutBrokerConfig, raising on missing keys."""
    name = str(raw["name"])
    server = str(raw["server"])
    # Port can land as int or quoted str in TOML — coerce.
    port = int(str(raw.get("port", 1883)))
    transport = str(raw.get("transport", "tcp")).lower()
    # 2026-06-12 (#5): default a MISSING `enabled` to TRUE, matching the portal +
    # sampler (which both read `enabled` defaulting True). The old default-False
    # meant a hand-edited / legacy broker block with no `enabled` key showed
    # ACTIVE in the portal but was silently skipped by the relay → silent fan-out
    # data loss. An explicit `enabled = false` still disables it.
    enabled = bool(raw.get("enabled", True))
    keepalive = int(raw.get("keepalive", 60))
    qos = int(raw.get("qos", 0))
    # 2026-05-27: letsmesh's reference exporter (Cisien/meshcoretomqtt)
    # publishes with retain=True so the analyzer's last-known-state view
    # survives observer reconnects. Other brokers default retain=False
    # (the MQTT default); operators can still override per-broker in TOML.
    retain_default = "letsmesh" in server.lower()
    retain = bool(raw.get("retain", retain_default))

    tls = raw.get("tls", {}) or {}
    tls_enabled = bool(tls.get("enabled", False))
    tls_verify = bool(tls.get("verify", True))

    auth = raw.get("auth", {}) or {}
    auth_method = str(auth.get("method", "none")).lower()
    auth_username = auth.get("username")
    auth_password = auth.get("password")
    auth_token_audience = auth.get("audience")
    auth_token_owner = auth.get("owner")
    auth_token_email = auth.get("email")

    custom_topic = raw.get("custom_topic")
    topics = raw.get("topics", {}) or {}

    # Per-broker protocol override; only honor "tdoa" / "mctomqtt".
    raw_proto = str(raw.get("protocol") or "").lower().strip()
    protocol_override = raw_proto if raw_proto in ("tdoa", "mctomqtt") else None

    return FanoutBrokerConfig(
        name=name,
        enabled=enabled,
        server=server,
        port=port,
        transport=transport,
        keepalive=keepalive,
        qos=qos,
        retain=retain,
        tls_enabled=tls_enabled,
        tls_verify=tls_verify,
        auth_method=auth_method,
        auth_username=str(auth_username) if auth_username else None,
        auth_password=str(auth_password) if auth_password else None,
        auth_token_audience=str(auth_token_audience) if auth_token_audience else None,
        auth_token_owner=str(auth_token_owner) if auth_token_owner else None,
        auth_token_email=str(auth_token_email) if auth_token_email else None,
        custom_topic=str(custom_topic) if custom_topic else None,
        topics={str(k): str(v) for k, v in topics.items()},
        protocol_override=protocol_override,
        raw=raw,
    )


def resolve_topic(template: str, iata: str, pub_key: str) -> str:
    """Apply {IATA} and {PUBLIC_KEY} substitutions exactly as mctomqtt does."""
    return template.replace("{IATA}", iata).replace("{PUBLIC_KEY}", pub_key)


def load_all_device_fanout(devices_root: Path) -> dict[str, FanoutDeviceConfig]:
    """Scan ``<devices_root>/<slug>/config.toml`` and return ``{slug: FanoutDeviceConfig}``.

    Used by the bridge to attach per-device config (repeater_name + broker
    list) to outbound fan-out packets — so on8ar / letsmesh / etc. see each
    USB-attached receiver on the Pi as its own node. Identity (pubkey) is
    supplied at runtime from the auto-learned 0x94 self-pubkey, not from
    this config.

    Each ``slug`` is the device directory name, which the bridge also
    uses as the MQTT ``gateway/<slug>/uplink`` topic — so the slug
    extracted from the inbound topic in input_mqtt.py directly indexes
    this dict.

    Broken / unparseable per-device configs are skipped with a warning;
    the bridge keeps running with whatever did load. Missing root dir
    returns an empty dict (caller falls back gracefully).
    """
    out: dict[str, FanoutDeviceConfig] = {}
    if not devices_root.is_dir():
        return out
    for entry in sorted(devices_root.iterdir()):
        if not entry.is_dir():
            continue
        cfg_path = entry / "config.toml"
        if not cfg_path.is_file():
            continue
        try:
            out[entry.name] = load_device_fanout(cfg_path)
        except (FileNotFoundError, ValueError) as exc:
            logger.warning(
                "device_config.skipped slug=%s reason=%s", entry.name, exc,
            )
    return out
