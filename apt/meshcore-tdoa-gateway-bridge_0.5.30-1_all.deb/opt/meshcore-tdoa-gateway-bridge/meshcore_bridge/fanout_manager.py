"""Per-port public-broker fan-out, sourced from the bridge's own frames.

Each USB port gets a FanoutPool built lazily the first time its REAL pubkey is
auto-learned from the 0x94 tail. Packets and status are translated with the
relay-parity formatters and published under that device's own identity. No
central subscription, no primary-fallback, no placeholder identity.
"""
from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from . import fanout_formats
from .fanout_brokers import FanoutPool
from .fanout_config import FanoutDeviceConfig, load_all_device_fanout
from .fanout_identity import is_real_pubkey
from .mqtt_publisher import sanitize_port

log = logging.getLogger("meshcore_bridge.fanout_manager")


class FanoutManager:
    def __init__(
        self,
        devices_root: Path,
        *,
        pool_factory: Callable[..., Any] = FanoutPool,
        priv_key_for: Callable[[str], str | None] | None = None,
    ) -> None:
        self._devices_root = Path(devices_root)
        self._pool_factory = pool_factory
        self._priv_key_for = priv_key_for or (lambda _slug: None)
        self._pools: dict[str, Any] = {}            # sanitized port -> pool
        self._pubkey: dict[str, str] = {}           # sanitized port -> pubkey used
        self._warned_unknown: set[str] = set()
        self._device_cfgs: dict[str, FanoutDeviceConfig] = load_all_device_fanout(
            self._devices_root
        )

    def _cfg_for_slug(self, slug: str | None) -> FanoutDeviceConfig | None:
        if slug and slug in self._device_cfgs:
            return self._device_cfgs[slug]
        return None

    def ensure_pool(self, port: str, pubkey: str, slug: str | None = None) -> bool:
        """Build (or rebuild) this port's pool once a REAL pubkey is known.

        Returns True if a pool now exists for the port, else False.
        """
        sanitized = sanitize_port(port)
        if not is_real_pubkey(pubkey):
            if sanitized not in self._warned_unknown:
                log.warning(
                    "fanout.skip.no_real_pubkey port=%s pubkey=%s "
                    "(device must report its 0x94 self-pubkey before fan-out)",
                    sanitized, pubkey,
                )
                self._warned_unknown.add(sanitized)
            return False
        pk = pubkey.strip().lower()
        if self._pools.get(sanitized) is not None and self._pubkey.get(sanitized) == pk:
            return True  # already built with this identity
        cfg = self._cfg_for_slug(slug) or self._cfg_for_slug(
            _slug_guess(sanitize_port(port), self._device_cfgs)
        )
        if cfg is None:
            log.warning("fanout.skip.no_device_config port=%s slug=%s", sanitized, slug)
            return False
        # tear down a stale pool if the identity changed
        old = self._pools.pop(sanitized, None)
        if old is not None:
            try:
                old.stop()
            except Exception:  # noqa: BLE001
                pass
        pool = self._pool_factory(
            cfg.brokers,
            iata=cfg.iata,
            pub_key=pk,
            priv_key=self._priv_key_for(slug or ""),
            scope_suffix=pk[:12],
        )
        try:
            pool.start()
        except Exception as exc:  # noqa: BLE001
            log.warning("fanout.pool.start_failed port=%s error=%s", sanitized, exc)
        self._pools[sanitized] = pool
        self._pubkey[sanitized] = pk
        self._warned_unknown.discard(sanitized)
        log.info("fanout.pool.ready port=%s pubkey=%s brokers=%d",
                 sanitized, pk[:12], getattr(pool, "client_count", 0))
        return True

    def publish_packet(self, port: str, envelope: dict[str, Any]) -> None:
        sanitized = sanitize_port(port)
        pool = self._pools.get(sanitized)
        if pool is None:
            return  # no real identity yet → nothing published (yellow-dot state)
        cfg = self._cfg_for_slug(_slug_guess(sanitized, self._device_cfgs))
        name = cfg.repeater_name if cfg else (envelope.get("gatewayId") or "Unknown")
        pk = self._pubkey[sanitized]
        on8ar_bytes = fanout_formats.serialise(
            fanout_formats.envelope_to_on8ar_packet(
                envelope, repeater_name=name, repeater_pub_key=pk
            )
        )
        mesh_bytes = fanout_formats.serialise(
            fanout_formats.envelope_to_mesh_subset(
                envelope, repeater_name=name, repeater_pub_key=pk
            )
        )
        pool.publish_per_broker(
            {"emqx-public": on8ar_bytes, "meshrank": on8ar_bytes, "letsmesh": on8ar_bytes},
            default_payload=mesh_bytes,
        )

    def publish_status(self, port: str, snapshot: dict[str, Any]) -> None:
        sanitized = sanitize_port(port)
        pool = self._pools.get(sanitized)
        if pool is None:
            return
        cfg = self._cfg_for_slug(_slug_guess(sanitized, self._device_cfgs))
        name = cfg.repeater_name if cfg else (snapshot.get("display_name") or "Unknown")
        pk = self._pubkey[sanitized]
        status_bytes = fanout_formats.serialise(
            fanout_formats.gateway_state_to_on8ar_status(
                snapshot, repeater_name=name, repeater_pub_key=pk
            )
        )
        for kind in ("emqx-public", "meshrank", "letsmesh"):
            pool.publish_status_to_kind(kind, status_bytes)

    def stop(self) -> None:
        for pool in self._pools.values():
            try:
                pool.stop()
            except Exception:  # noqa: BLE001
                pass
        self._pools.clear()

    def snapshot(self) -> dict[str, list[dict[str, Any]]]:
        """Per-port fan-out broker snapshots (sanitized port -> [broker dicts])."""
        return {port: pool.snapshot() for port, pool in self._pools.items()}


def _slug_guess(sanitized_port: str, cfgs: dict[str, FanoutDeviceConfig]) -> str | None:
    """Map a sanitized port back to a device slug by normalised containment.

    Mirrors the bridge's existing portal-meta matcher: strip non-alphanumerics,
    lowercase, and check the slug-form is contained in the port-form.
    """
    def norm(s: str) -> str:
        return "".join(c for c in s.lower() if c.isalnum())
    np = norm(sanitized_port)
    for slug in cfgs:
        ns = norm(slug)
        if ns and ns in np:
            return slug
    return None
