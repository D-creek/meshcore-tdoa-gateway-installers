"""Minimal systemd sd_notify(3) client for the bridge.

Sends datagram notifications to ``$NOTIFY_SOCKET`` so systemd can track
the bridge's readiness and liveness without an external sd_notify binary.

Only two messages are needed:

* ``READY=1``       — sent once after the bridge has fully initialised
  (supervisor started, MQTT connected, fwota dispatcher wired). Tells
  systemd to transition the service from ``activating`` → ``active``.
  Required for ``Type=notify`` services: if it never arrives, systemd
  considers the start a failure after ``TimeoutStartSec``.

* ``WATCHDOG=1``    — sent periodically (every ``WATCHDOG_PING_INTERVAL``
  seconds) as long as the port supervisor is doing live sweeps. If systemd
  doesn't receive this within ``WatchdogSec``, it kills and restarts the
  service. This is the liveness signal — it fires ONLY when the supervisor's
  ``last_sweep_monotonic`` is fresh; a hung or deadlocked bridge will miss
  the heartbeat and be restarted automatically.

Protocol (sd_notify wire format):
  * ``$NOTIFY_SOCKET`` is a path to a Unix SOCK_DGRAM socket.
  * If the path starts with ``@`` or ``\\x00``, it is an abstract socket
    (the first byte of the address is ``\\x00`` rather than a path
    character).
  * Send a single ASCII datagram: ``b"READY=1\\n"`` or ``b"WATCHDOG=1\\n"``.
  * No reply is expected; errors are swallowed (logging a warning is
    sufficient — a missed ping is always less bad than crashing the bridge).

References: https://www.freedesktop.org/software/systemd/man/sd_notify.html
"""

from __future__ import annotations

import logging
import os
import socket

logger = logging.getLogger(__name__)

#: How often the watchdog pinger thread sends ``WATCHDOG=1``.
#: Must be well under ``WatchdogSec`` (90 s in the service unit) so at
#: least two pings arrive per watchdog window even under moderate load.
#: WatchdogSec=90 → ping every 30 s leaves 3× headroom.
WATCHDOG_PING_INTERVAL = 30.0

#: A sweep is considered "fresh" if it completed within this many seconds.
#: The supervisor's rescan_interval is ~20 s; 2× = 40 s means one missed
#: sweep is tolerated (transient load spike, GC pause) before the watchdog
#: refuses to ping systemd. Set comfortably above 2× rescan but below
#: WatchdogSec so the watchdog fires before systemd kills us.
SWEEP_STALE_THRESHOLD = 60.0


def _notify_socket_path() -> str | None:
    """Return the ``$NOTIFY_SOCKET`` value, or None when unset/empty."""
    return os.environ.get("NOTIFY_SOCKET") or None


def _send(msg: bytes) -> None:
    """Send ``msg`` to ``$NOTIFY_SOCKET``.

    No-op when ``NOTIFY_SOCKET`` is unset (non-systemd / test contexts).
    Errors are logged at WARNING and swallowed — a missed ping is never
    worth crashing the bridge over.
    """
    path = _notify_socket_path()
    if path is None:
        return
    # Abstract socket: ``@`` prefix (systemd convention) or literal ``\x00``
    # (kernel convention). Both map to a null-byte-prefixed address.
    if path.startswith("@"):
        addr: str | bytes = "\x00" + path[1:]
    elif path.startswith("\x00"):
        addr = path  # already raw abstract form
    else:
        addr = path  # filesystem socket
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as sock:
            sock.sendto(msg, addr)
    except OSError as exc:
        logger.warning(
            "sd_notify.send_failed notify_socket=%s error=%s", path, exc
        )


def notify_ready() -> None:
    """Send ``READY=1`` to systemd.

    Call exactly ONCE after the bridge has fully initialised — supervisor
    started, primary MQTT publisher connected, fwota dispatcher wired.
    A ``Type=notify`` service will fail to start (timeout) if this is never
    sent, which means a missing ``READY=1`` would take down the entire fleet
    on the next deploy. Validate on testOPI before merging to main.
    """
    _send(b"READY=1\n")
    logger.info("sd_notify.ready_sent")


def notify_watchdog() -> None:
    """Send ``WATCHDOG=1`` to systemd.

    Call periodically from the watchdog pinger thread ONLY when the
    supervisor's ``last_sweep_monotonic`` is fresh (within
    ``SWEEP_STALE_THRESHOLD``). A hung supervisor stops updating that
    timestamp → pings stop → systemd restarts the bridge after
    ``WatchdogSec``.
    """
    _send(b"WATCHDOG=1\n")
    logger.debug("sd_notify.watchdog_sent")
