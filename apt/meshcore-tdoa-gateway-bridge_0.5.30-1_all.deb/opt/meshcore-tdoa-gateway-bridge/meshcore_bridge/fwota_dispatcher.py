"""KAN-167: bridge-side FW-OTA job dispatcher.

Listens on ``gateway/+/cmd/fw-upgrade`` MQTT topic; when a job message
arrives the dispatcher:

  1. Resolves the target USB port from the topic's sanitized-port path.
  2. Downloads the firmware artifact to a local cache (verifying sha256).
  3. Calls the right per-platform flash function (fwota_v4.flash_v4 for
     ESP32-S3 boards, fwota_techo.flash_techo for nRF52840 boards
     including T-Echo + RAK4631).
  4. Publishes a series of status messages on
     ``gateway/{port}/cmd/fw-upgrade/status`` so the collector + API
     can show live progress in the frontend.

Job payload shape (published by the API on POST /admin/.../firmware-upgrade):

    {
      "job_id":       <int>,
      "release_id":   <int>,
      "target_board": "heltec_v4_companion_radio_usb_tdoa_rx" | "LilyGo_T-Echo_..." | ...,
      "download_url": "https://<firmware-host>/firmware/blobs/<sha>",
      "sha256":       "<64-hex>",
      "version":      "tdoa-1.8.5"
    }

Status payload shape (published back on .../status):

    {"job_id": <int>, "state": "pending"|"downloading"|"flashing"|"done"|"failed_*",
     "log_chunk": "..."}

The dispatcher is intentionally a separate MQTT client from the
publisher so we don't tangle pub + sub state. Wired into ``__main__.py``
alongside the publisher.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import time
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

import paho.mqtt.client as mqtt
import structlog

if TYPE_CHECKING:
    from .serial_locks import PortSerialLocks

from .config import MQTTConfig
from .fwota_h743 import flash_h743
from .fwota_stm32wl import FlashResult, flash_stm32wl
from .fwota_t114 import flash_t114
from .fwota_techo import HeartbeatProbe, flash_techo
from .fwota_v4 import flash_v4, is_native_usb_descriptor
from .usb_recovery import reenumerate_by_serial

log = structlog.get_logger(__name__)

#: Matches an HTTP Authorization bearer/basic credential that a urllib error
#: string may carry (e.g. when it echoes the failed request's headers). The
#: firmware download attaches ``Authorization: Bearer <github_token>``, so an
#: unsanitised ``str(exc)`` could leak the PAT into the root-readable journal
#: (security fix 2026-06-06). We also catch a bare ``ghp_``/``github_pat_``.
_CRED_RE = re.compile(
    r"(Authorization|Bearer|Basic)\s*[:=]?\s*\S+|ghp_\w+|github_pat_\w+",
    re.IGNORECASE,
)


def _safe_err(exc: BaseException) -> str:
    """A log-safe one-line description of ``exc`` with any credential redacted.

    Prefer the structured ``code``/``reason`` of a urllib/OS error (which never
    carry the request headers) and scrub the fallback string so a leaked
    ``Authorization: Bearer <PAT>`` can't reach the journal."""
    code = getattr(exc, "code", None)
    reason = getattr(exc, "reason", None)
    if code is not None or reason is not None:
        _code = code if code is not None else ""
        _reason = reason if reason is not None else ""
        base = f"{type(exc).__name__}: {_code} {_reason}".strip()
    else:
        base = f"{type(exc).__name__}: {exc}"
    return _CRED_RE.sub("<redacted>", base)


#: Where flashing artifacts get cached on the bridge host. Each is named
#: by sha256 so re-downloads are idempotent and a corrupted artifact
#: can be re-downloaded by deleting the file.
#:
#: Resolved from systemd's ``$STATE_DIRECTORY`` (set by the unit's
#: ``StateDirectory=``). Both the deb unit (``meshcore-tdoa-gateway-bridge``)
#: and the legacy image unit run ``ProtectSystem=strict``, so the ONLY writable
#: ``/var/lib`` path is whatever ``StateDirectory`` grants. The old hard-coded
#: ``/var/lib/meshcore-bridge`` did NOT match the deb's
#: ``/var/lib/meshcore-tdoa-gateway-bridge`` StateDirectory, so every flash
#: failed at download with ``OSError [Errno 30] Read-only file system`` under
#: the sandbox. ``$STATE_DIRECTORY`` may be colon-separated → take the first;
#: fall back to the deb path for non-systemd / test contexts.
_STATE_DIR = (os.environ.get("STATE_DIRECTORY") or "").split(":")[0].strip()
_BRIDGE_STATE_DIR = _STATE_DIR or "/var/lib/meshcore-tdoa-gateway-bridge"
DEFAULT_FW_CACHE_DIR = os.path.join(_BRIDGE_STATE_DIR, "fw-cache")

#: On-disk dedup map for per-(job_id,attempt) duplicate suppression (STEP 2,
#: shared contract #2). A QoS=1 redelivery — or a bridge RESTART mid-flash that
#: leaves the broker holding an un-acked job that gets redelivered on reconnect
#: — would otherwise re-run a flash the bridge already started/finished. We
#: persist the recently-seen ``(job_id,attempt) -> wall-ts`` map here so the
#: dedup survives a restart. A legitimate collector retry carries a NEW attempt
#: number (shared contract #1) so it is NOT deduped.
DEFAULT_FWOTA_SEEN_PATH = os.path.join(_BRIDGE_STATE_DIR, "fwota_seen.json")

#: Cooldown a completed/in-flight ``(job_id,attempt)`` stays in the seen map.
#: Must exceed broker redelivery + the post-flash verify window so a redelivery
#: arriving after the flash finished is still suppressed (shared contract #2:
#: ">= broker redelivery + verify window"). 900 s per the contract.
_FWOTA_SEEN_COOLDOWN_S = 900.0

#: STEP 5 — generous bound for the version-aware post-flash heartbeat probe.
#: The first GOOD 0x94 GATEWAY_INFO frame can be ~5 min out on a cold-GPS boot
#: (observed), so the old 90-120 s windows declared a healthy flash a failure.
#: Default 360 s; env-tunable so a slow Pi / cold GPS gets headroom without a
#: code change. The seen-map cooldown (900 s) is deliberately larger than this
#: so a redelivery during the probe is still suppressed.
_POST_FLASH_HEARTBEAT_S = float(
    os.environ.get("FWOTA_POST_FLASH_HEARTBEAT_S", "360")
)

#: Stable per-device serial symlink the gateway-portal udev rule ships
#: (shared contract #4): ``/dev/meshcore/serial-<HEX>-if00``. The post-flash
#: probe re-finds the device by THIS, not the USB product descriptor (which
#: changes WisCore↔WisBlock / app↔JTAG across a flash/reboot).
_STABLE_SERIAL_SYMLINK_TEMPLATE = "/dev/meshcore/serial-{serial}-if00"

#: Topic patterns. The dispatcher subscribes to the wildcard variant
#: and parses the sanitized-port out of the second level.
TOPIC_CMD_SUB = "gateway/+/cmd/fw-upgrade"
TOPIC_STATUS_TEMPLATE = "gateway/{sanitized}/cmd/fw-upgrade/status"

#: When the topic looks like ``gateway/abc/cmd/fw-upgrade`` we extract
#: ``abc`` as the sanitized port. The sanitize_port helper in
#: mqtt_publisher applies the same scheme so this is reversible.
_TOPIC_PORT_RE = re.compile(r"^gateway/([^/]+)/cmd/fw-upgrade$")


@dataclass(frozen=True)
class JobPayload:
    """Parsed inbound job message.

    Optional ``previous_*`` fields carry the known-good firmware the
    flash should roll back to if BOTH the requested-version flash AND
    the JTAG-bootloader retry fail. Without them a corrupt or
    incompatible build leaves the chip stuck in bootloader mode (the
    2026-05-13 V4 incident); with them the bridge auto-recovers to
    the last-running firmware.
    """

    job_id: int
    release_id: int
    target_board: str
    download_url: str
    sha256: str
    version: str
    #: Retry attempt this job message represents (shared contract #1). The API's
    #: initial publish sets it to the job row's attempt_count (0 for a fresh
    #: job); the collector's republish sets the NEW post-increment count. The
    #: bridge dedups on the (job_id, attempt) tuple. Absent (an OLD API/collector
    #: that doesn't emit it) → 0, so a legacy payload still flashes.
    attempt: int = 0
    previous_release_id: int | None = None
    previous_download_url: str | None = None
    previous_sha256: str | None = None
    previous_version: str | None = None


def parse_job(payload: bytes) -> JobPayload | None:
    """Decode the JSON job payload; return ``None`` on any structural error."""
    try:
        doc = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(doc, dict):
        return None
    try:
        previous = doc.get("previous") if isinstance(doc.get("previous"), dict) else None
        return JobPayload(
            job_id=int(doc["job_id"]),
            release_id=int(doc["release_id"]),
            target_board=str(doc["target_board"]),
            download_url=str(doc["download_url"]),
            sha256=str(doc["sha256"]).lower(),
            version=str(doc["version"]),
            # Optional (shared contract #1): a payload from an older API/collector
            # that predates the field has no "attempt" → default 0 (treated as a
            # fresh job, back-compat). Coerced via int() so a stringy "2" still
            # parses; a non-numeric value falls into the except below as a bad
            # payload (consistent with the other int() fields).
            attempt=int(doc.get("attempt", 0)),
            previous_release_id=(
                int(previous["release_id"])
                if previous and "release_id" in previous
                else None
            ),
            previous_download_url=(
                str(previous["download_url"])
                if previous and "download_url" in previous
                else None
            ),
            previous_sha256=(
                str(previous["sha256"]).lower()
                if previous and "sha256" in previous
                else None
            ),
            previous_version=(
                str(previous["version"])
                if previous and "version" in previous
                else None
            ),
        )
    except (KeyError, TypeError, ValueError):
        return None


def is_esp32_target(target_board: str) -> bool:
    """Heuristic: the V4 + future Heltec ESP32 envs name themselves
    ``heltec_v4_*`` / ``heltec_v3_*``; everything else (LilyGo, RAK,
    Wio, STM32, Heltec T114) stays on the nRF/STM path. Cheap
    classification — refine if we ever ship an ESP32-named env that
    should not use esptool."""
    tb = target_board.lower()
    return tb.startswith("heltec_v") or tb.startswith("esp32")


def is_h743_target(target_board: str) -> bool:
    """Heuristic: STM32H743 receiver envs name themselves
    ``stm32h743_*`` (mirrors the in-tree variant directory). These flash
    via the STM32 ROM USB-DFU bootloader (dfu-util) rather than the
    Adafruit nRF52 path used by T-Echo / T114."""
    tb = target_board.lower()
    return tb.startswith("stm32h743") or tb.startswith("h743")


def is_t114_target(target_board: str) -> bool:
    """Heuristic: Heltec T114 v2 receiver envs match ``heltec_t114_*``.

    The T114 v2 uses the Adafruit nRF52 bootloader, identical to T-Echo;
    classification here is purely for runtime-descriptor routing so the
    bridge picks the right per-chip USB glob (Heltec_T114_* vs
    Nordic_NRF52_DK_*). The actual flash code path is fwota_t114 →
    fwota_techo internally."""
    tb = target_board.lower()
    return tb.startswith("heltec_t114") or tb.startswith("t114")


def is_stm32wl_target(target_board: str) -> bool:
    """Heuristic: STM32WL (Wio-E5 mini / LoRa-E5) receiver envs match
    ``wio_e5_*`` / ``wio-e5-*`` / ``lora_e5_*`` / ``*stm32wl*``.

    These flash over serial via stm32flash → ST Open Bootloader (OpenBL),
    NOT the ROM bootloader: the WLE5 ROM bootloader's USART1 is on
    PA9/PA10 which the CP2102 (PB6/PB7) can't reach, and BOOT0 isn't
    bonded out. OpenBL — flashed once over SWD into a write-protected
    region, USART retargeted to PB6/PB7 — gives the AN3155 protocol on
    the CP2102 so stm32flash works. See fwota_stm32wl.flash_stm32wl."""
    tb = target_board.lower()
    return (
        tb.startswith("wio_e5")
        or tb.startswith("wio-e5")
        or tb.startswith("lora_e5")
        or "stm32wl" in tb
    )


def is_stm32wl_openbl_target(target_board: str) -> bool:
    """A STM32WL target that is the OpenBootloader-prepped build — the ONLY
    image safe to serial-flash on a Wio-E5.

    OpenBL writes the application at the app base (0x08008000). Only the
    ``*_openbl`` env is linked there (with VECT_TAB_OFFSET=0x8000); a normal
    0x08000000-based image written at 0x08008000 has the wrong vector table
    and absolute addresses and bricks the node. So the OTA path accepts the
    prepped build only. The matching firmware env is
    ``wio_e5_..._tdoa_rx_openbl``."""
    return is_stm32wl_target(target_board) and "_openbl" in target_board.lower()


def download_to_cache(
    url: str,
    expected_sha256: str,
    *,
    cache_dir: str = DEFAULT_FW_CACHE_DIR,
    opener: Callable[[str], object] = urllib.request.urlopen,
    github_token: str = "",
) -> str:
    """Download ``url`` into ``cache_dir`` keyed by ``expected_sha256``.

    Returns the local filesystem path. Verifies sha256 after download
    and raises ValueError on mismatch (caller marks the job
    ``failed_verify``). If the file already exists with the right hash
    we skip the download entirely.

    2026-05-31: when ``url`` matches the GitHub release-asset API form
    (``https://api.github.com/repos/<owner>/<repo>/releases/assets/<id>``)
    we attach ``Authorization: Bearer <github_token>`` + ``Accept:
    application/octet-stream``. This lets the bridge fetch firmware
    blobs directly from a private repo's Release without proxying
    through the prod host. Anonymous fallback still works for public
    repos / mirrors when ``github_token`` is empty.
    """
    os.makedirs(cache_dir, exist_ok=True)
    dest = os.path.join(cache_dir, expected_sha256)
    if os.path.exists(dest) and _file_sha256(dest) == expected_sha256:
        return dest

    # Build a Request when we need to attach headers (private-repo GH
    # API URL + a token to authenticate with). Anonymous public URLs
    # pass-through as bare strings — keeps the test stub (``opener``
    # default = ``urllib.request.urlopen``) working with both forms.
    is_gh_api_asset = url.startswith("https://api.github.com/repos/") and "/releases/assets/" in url
    if is_gh_api_asset and github_token:
        request: object = urllib.request.Request(
            url,
            headers={
                "Authorization": f"Bearer {github_token}",
                "Accept": "application/octet-stream",
                "User-Agent": "meshcore-bridge-fwota/1",
            },
        )
    else:
        request = url

    # urlopen is intentionally injected so tests can substitute.
    with opener(request) as resp:  # type: ignore[operator,arg-type]
        data = resp.read()  # type: ignore[attr-defined]
    actual = hashlib.sha256(data).hexdigest()
    if actual != expected_sha256:
        raise ValueError(
            f"sha256 mismatch: expected {expected_sha256}, got {actual}"
        )
    # Write atomically so a half-downloaded blob can't poison a future
    # cache hit.
    tmp = dest + ".part"
    with open(tmp, "wb") as f:
        f.write(data)
    os.replace(tmp, dest)
    return dest


def _map_flash_state(raw_state: str) -> str:
    """Translate a FlashResult.state literal into the API's state vocab.

    The flasher returns lower-case literals defined in fwota_v4.FlashState
    (e.g. "success", "rolled_back_to_previous", "failed_flash"); the API
    schema uses slightly different terminology ("done" instead of
    "success") and treats a rollback as a non-terminal outcome that the
    collector + frontend surface distinctly.
    """
    s = raw_state.lower()
    # Exact "success" only. The old ``s.endswith("success")`` was a trap: a
    # future state like ``partial_success`` would map to ``done`` and stamp the
    # firmware version on a partial flash. Add explicit success literals here if
    # a flasher ever introduces one.
    if s == "success":
        return "done"
    if "rolled_back" in s or "rollback" in s:
        return "rolled_back_to_previous"
    if "boot_loop" in s:
        return "failed_boot_loop"
    if "no_reenum" in s:
        return "failed_no_reenum"
    if "unsupported" in s:
        # Shared contract: collector side expects this exact literal.
        return "failed_unsupported"
    if "wrong_family" in s or "not_uf2_bootloader" in s:
        # 0.5.24 UF2 pre-flight gates (fwota_techo): a wrong-family .uf2 artifact
        # or a device whose MSC is NOT an Adafruit UF2 bootloader (e.g. a bare
        # Nordic nRF52-DK exposing a SEGGER J-Link OB / DAPLink drive). These are
        # TERMINAL — retrying re-drops the same artifact onto the same incompatible
        # device and will never succeed — so map to the non-retriable
        # ``failed_unsupported`` (same class as the h743/t114 gate) instead of the
        # retriable ``failed_flash`` default below.
        return "failed_unsupported"
    if "verify" in s:
        return "failed_verify"
    if "timeout" in s:
        return "failed_timeout"
    if "no_heartbeat" in s:
        # STEP 5 — the flash programmed but the device never came back at the
        # TARGET version within the probe window (stuck in DFU / boot-looping /
        # old firmware). RETRIABLE: map to ``failed_flash`` so the collector's
        # bounded 3-strike retry re-flashes it (the collector has no distinct
        # ``failed_post_flash_no_heartbeat`` literal — keep the wire vocab it
        # already understands; emitted by BOTH the techo and v4 probe paths).
        return "failed_flash"
    return "failed_flash"


#: Regex that extracts the hex chip-ID suffix from a runtime descriptor
#: slug. Two flavours show up in the field:
#:   - Heltec V4 ESP32-S3: 12-hex-digit MAC (``...PSRAM__441BF661E624-if00``)
#:   - LilyGo T-Echo nRF52: 16-hex-digit chip ID
#:     (``...Nordic_NRF52_DK_62444E784607AE64-if00``)
#: Used by find_jtag_recovery_port / find_techo_dfu_port to build the
#: matching bootloader descriptor when the supervisor (correctly)
#: doesn't track those ports as gateways.
_RUNTIME_MAC_RE = re.compile(r"_([0-9A-Fa-f]{12,16})-if")


def find_jtag_recovery_port(
    sanitized: str,
    *,
    glob_fn: Callable[[str], list[str]] | None = None,
) -> str | None:
    """Locate the JTAG-bootloader descriptor that pairs with ``sanitized``.

    When a Heltec V4 OTA fails, the chip drops into the ESP32-S3 ROM
    USB-JTAG bootloader. The supervisor's port sweep deliberately
    filters those descriptors out so the OTA dispatcher's retry doesn't
    race a SerialReader for the port — but the dispatcher then has to
    find the JTAG descriptor itself to recover the chip. The MAC suffix
    is the same on both descriptors (just colon-formatted on JTAG side).

    Returns the first matching JTAG path, or ``None`` if the sanitized
    slug doesn't carry a recognisable MAC or no JTAG descriptor exists.
    """
    import glob as _glob

    g = glob_fn or _glob.glob
    m = _RUNTIME_MAC_RE.search(sanitized)
    if m is None:
        return None
    mac = m.group(1)
    colon_mac = ":".join(mac[i : i + 2] for i in range(0, 12, 2))
    # ESP32-S3 — the descriptor format the bridge has seen on the V4.
    pattern = (
        f"/dev/serial/by-id/usb-Espressif_USB_JTAG_serial_debug_unit_"
        f"{colon_mac}-if00"
    )
    matches = sorted(g(pattern))
    return matches[0] if matches else None


def find_techo_dfu_port(
    sanitized: str,
    *,
    glob_fn: Callable[[str], list[str]] | None = None,
) -> str | None:
    """Locate the LilyGo T-Echo Adafruit-DFU descriptor for ``sanitized``.

    Adafruit nRF52 bootloader on T-Echo exposes a USB-CDC descriptor
    with a different product name (``LilyGo_T-Echo_v1_*``) than the
    runtime (``Nordic_NRF52_DK_*``). Same MAC suffix. When a previous
    OTA left the chip stuck in DFU, the dispatcher needs to find the
    DFU port so flash_techo can drop the .uf2 onto the bootloader's
    mass-storage device — same MAC-based lookup as V4's JTAG path.
    """
    import glob as _glob

    g = glob_fn or _glob.glob
    m = _RUNTIME_MAC_RE.search(sanitized)
    if m is None:
        return None
    mac = m.group(1)
    pattern = f"/dev/serial/by-id/usb-LilyGo_T-Echo_v1_{mac}-if00"
    matches = sorted(g(pattern))
    return matches[0] if matches else None


def find_port_by_serial(
    sanitized: str,
    *,
    glob_fn: Callable[[str], list[str]] | None = None,
) -> str | None:
    """Find the device for ``sanitized`` under ANY USB product descriptor,
    keyed only by its stable serial/MAC suffix.

    The board-specific finders above match a known bootloader product string.
    But a device's descriptor can differ between its APP and its BOOTLOADER in
    ways we don't enumerate — e.g. a RAK4631 runs the app as
    ``usb-RAKwireless_WisCore_RAK4631_Board_<serial>-if00`` but sits in its UF2
    bootloader as ``usb-RAKWireless_WisBlock_RAK4631_<serial>-if00`` (same
    serial ``<serial>``). When that happens (or the supervisor quarantined the
    port as "no frames" — exactly the device that NEEDS flashing), the exact-slug
    resolve + the board finders all miss, and the chip is stranded.

    This is the catch-all: extract the serial and glob for ANY
    ``/dev/serial/by-id/*<serial>*-if00*`` descriptor — app or bootloader. It
    reads the filesystem directly, so it works even when the supervisor isn't
    tracking the port (quarantined / never framed). Returns the first match, or
    ``None`` if no descriptor carries the serial.
    """
    import glob as _glob

    g = glob_fn or _glob.glob
    m = _RUNTIME_MAC_RE.search(sanitized)
    if m is None:
        return None
    serial = m.group(1)
    matches = sorted(g(f"/dev/serial/by-id/*{serial}*-if00*"))
    return matches[0] if matches else None


def find_jtag_port_by_serial(
    source: str,
    *,
    glob_fn: Callable[[str], list[str]] | None = None,
) -> str | None:
    """Resolve the ESP32-S3 USB-Serial-JTAG descriptor for ``source``.

    0.5.24 — esptool MUST be handed the USB-Serial-JTAG descriptor
    (``usb-Espressif_USB_JTAG_serial_debug_unit_<MAC>-if00``), not the V4's
    application CDC descriptor (``...heltec_wifi_lora_32_v4...``): the app CDC is
    a firmware TinyUSB endpoint with no ROM bootloader behind it, so esptool's
    sync gets "No serial data received" / errno-5. The JTAG controller is a
    fixed-function ROM peripheral the Heltec V4 app keeps enabled at runtime, so
    its descriptor is present even while the app runs — we can target it WITHOUT
    a separate reset-to-bootloader step, and ``discovery.is_bootloader_port``
    keeps the supervisor off it so the OTA owns it exclusively.

    Unlike :func:`find_jtag_recovery_port` (recovery-path only, slug-keyed), this
    accepts EITHER a sanitized slug OR a resolved port path — both carry the same
    ``_<MAC>-if`` suffix — so the NORMAL flash path can swap the app CDC port for
    the JTAG node before flashing. Returns the JTAG path, or ``None`` when no MAC
    is recognisable or no JTAG descriptor is present (caller keeps its port).
    """
    return find_jtag_recovery_port(source, glob_fn=glob_fn)


def _file_sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


#: tdoa-X.Y.Z firmware tag matcher. MUST stay in lock-step with the collector's
#: ``_TDOA_FW_TAG_RE`` / ``_fw_version_matches`` (shared contract #3): the bridge
#: post-flash probe and the collector validation use the SAME exact-tag rule, so
#: ``tdoa-1.12.4`` can never prefix-substring-match inside ``tdoa-1.12.45``.
_TDOA_FW_TAG_RE = re.compile(r"tdoa-\d+\.\d+\.\d+", re.IGNORECASE)


def _fw_version_matches(reported: str | None, target: str | None) -> bool:
    """True when ``reported`` confirms ``target`` by EXACT tdoa-X.Y.Z equality.

    Mirrors the collector's ``_fw_version_matches`` (shared contract #3):
      1. exact (case-insensitive) string equality; OR
      2. both sides carry a ``tdoa-X.Y.Z`` tag → those tags must be EQUAL
         (anchored token compare, never a prefix-substring).
    Either side empty / no tag on one side → NOT a match.
    """
    r = (reported or "").strip().lower()
    t = (target or "").strip().lower()
    if not r or not t:
        return False
    if r == t:
        return True
    rt = _TDOA_FW_TAG_RE.search(r)
    tt = _TDOA_FW_TAG_RE.search(t)
    if rt and tt:
        return rt.group(0) == tt.group(0)
    return False


def _resolve_stable_serial_port(
    sanitized: str,
    *,
    realpath: Callable[[str], str] = os.path.realpath,
    exists: Callable[[str], bool] = os.path.exists,
) -> str | None:
    """Re-find the device by its stable ``/dev/meshcore/serial-<HEX>-if00`` link.

    Shared contract #4: post-flash, the USB product descriptor changes
    (WisCore↔WisBlock, app↔JTAG), so the device must be re-found by the stable
    serial symlink the udev rule exposes — NOT by the descriptor. Extracts the
    bare-hex serial from ``sanitized``, builds the symlink path, and returns its
    resolved target (the live ``/dev/...`` node) when the symlink exists, else
    ``None``. ``realpath`` / ``exists`` are injected for unit tests.
    """
    from .discovery import extract_serial

    serial = extract_serial(sanitized)
    if serial is None:
        return None
    link = _STABLE_SERIAL_SYMLINK_TEMPLATE.format(serial=serial)
    if not exists(link):
        return None
    # Resolve to the live device node so the version lookup keys on the same
    # path the (resumed) serial reader publishes 0x94 frames under.
    return realpath(link)


def make_version_heartbeat_probe(
    target_version: str,
    version_lookup_by_serial: Callable[[str], str | None],
) -> HeartbeatProbe:
    """Build a version-aware post-flash :class:`HeartbeatProbe` (STEP 5).

    The returned async probe ``(port_or_slug, within_s) -> bool`` — the flasher
    calls it with whatever port it flashed (the resolved ``/dev/...`` path or the
    sanitized slug; both carry the ``_<HEX>-if00`` serial tail):
      1. extracts the device's STABLE bare-hex serial from that port/slug
         (contract #4) — the USB descriptor changes across the flash
         (WisCore↔WisBlock, app↔JTAG) so the serial is the only stable identity,
      2. reads the version most recently learned from a 0x94 GATEWAY_INFO frame
         on the device with that serial (``version_lookup_by_serial`` → the
         publisher's :meth:`tdoa_firmware_version_by_serial`, which scans the
         per-port cache by serial rather than by the moved/renamed port path),
      3. returns True ONLY when that reported version EXACTLY matches
         ``target_version`` (contract #3, via :func:`_fw_version_matches`).

    No serial, no cached version yet, or a NON-matching version → False, so the
    flasher's ``_await_heartbeat`` keeps polling until its budget elapses and
    then reports the retriable FAILED_POST_FLASH_NO_HEARTBEAT — never a false
    SUCCESS on the OLD firmware still emitting its old version. Presence is
    implied by a fresh 0x94 frame: the cache only carries a version once the
    (resumed) reader has actually heard the rebooted device.
    """
    from .discovery import extract_serial

    async def _probe(port_or_slug: str, _within_s: float) -> bool:
        serial = extract_serial(port_or_slug)
        if serial is None:
            return False
        reported = version_lookup_by_serial(serial)
        return _fw_version_matches(reported, target_version)

    return _probe


def _seen_key(job_id: int, attempt: int) -> str:
    """Stable string key for the (job_id, attempt) dedup tuple.

    JSON object keys must be strings, so the on-disk map keys on
    ``"<job_id>:<attempt>"`` — the same form the in-memory set keys on, so a
    restart that reloads the file is consistent with a live run.
    """
    return f"{job_id}:{attempt}"


def _load_seen_map(path: str, *, now: float, cooldown_s: float) -> dict[str, float]:
    """Load the persisted ``(job_id,attempt) -> wall-ts`` dedup map, pruned.

    Drops any entry older than ``cooldown_s`` so a stale file (e.g. after a long
    downtime) doesn't permanently suppress a job whose id is later reused, and
    so the file can't grow unbounded. Returns an empty map on a missing /
    corrupt file — a lost dedup state degrades to "may re-run a redelivery",
    never to a crash.
    """
    try:
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(raw, dict):
        return {}
    out: dict[str, float] = {}
    for k, v in raw.items():
        try:
            ts = float(v)
        except (TypeError, ValueError):
            continue
        if now - ts < cooldown_s:
            out[str(k)] = ts
    return out


class FwOtaDispatcher:
    """Subscribes to fw-upgrade commands and orchestrates per-port flashes.

    The dispatcher needs a way to resolve a sanitized-port back to a
    full ``/dev/serial/by-id/...`` path; ``port_resolver`` is injected
    so tests can stub it and the supervisor can pass the live mapping.

    ``pause_port`` is called BEFORE flashing (so the serial reader
    releases the USB-CDC port) and ``resume_port`` is called AFTER
    flashing succeeds / fails (so the reader reattaches and starts
    seeing the new firmware's heartbeats). Both are no-ops when the
    supervisor doesn't have the matching port.
    """

    def __init__(
        self,
        cfg: MQTTConfig,
        *,
        port_resolver: Callable[[str], str | None],
        pause_port: Callable[[str], None] | None = None,
        resume_port: Callable[[str], None] | None = None,
        mark_flashing: Callable[[str], None] | None = None,
        clear_flashing: Callable[[str], None] | None = None,
        update_health: Callable[[str, str, str], None] | None = None,
        cache_dir: str = DEFAULT_FW_CACHE_DIR,
        github_token: str = "",
        client_factory: Callable[[], mqtt.Client] | None = None,
        own_ports_provider: Callable[[], list[str]] | None = None,
        is_tdoa_fw_probe: Callable[[str], bool | None] | None = None,
        serial_locks: PortSerialLocks | None = None,
        heartbeat_probe_factory: (
            Callable[[str, str], HeartbeatProbe] | None
        ) = None,
        seen_path: str = DEFAULT_FWOTA_SEEN_PATH,
    ) -> None:
        self._cfg = cfg
        self._port_resolver = port_resolver
        # Per-port exclusive-serial-access lock, SHARED with the auth-token
        # minter (see __main__) so a flash and a token mint never open the same
        # port concurrently. Falls back to a private instance when not supplied
        # (tests / no minter) — still serializes this dispatcher's own flashes.
        from .serial_locks import PortSerialLocks
        self._serial_locks = serial_locks or PortSerialLocks()
        # Sanitized ports with a flash thread currently live, so a duplicate
        # MQTT delivery (qos=1) or a collector retry published while the first
        # attempt is still flashing doesn't spawn a second concurrent flash on
        # the same port. Guarded by ``_inflight_lock``.
        self._inflight: set[str] = set()
        self._inflight_lock = threading.Lock()
        # STEP 2 — per-(job_id,attempt) duplicate suppression (shared contract
        # #2), distinct from the per-PORT _inflight guard above. The seen map
        # keys on ``_seen_key(job_id, attempt)`` → wall-ts and is PERSISTED to
        # ``seen_path`` so a redelivered QoS=1 job (incl. one redelivered after a
        # bridge restart) for the SAME (job_id,attempt) is dropped, while a
        # legitimate collector retry — which carries a NEW attempt number — is
        # NOT deduped. Guarded by ``_seen_lock``.
        self._seen_path = seen_path
        self._seen_lock = threading.Lock()
        self._seen: dict[str, float] = _load_seen_map(
            seen_path, now=time.time(), cooldown_s=_FWOTA_SEEN_COOLDOWN_S
        )
        # Reports whether the CURRENT firmware on a sanitized port is a TDOA
        # build (i.e. exposes the companion CMD_ENTER_USB_DFU command). The
        # T-Echo/RAK flasher uses this to pick the DFU-enter method: magic frame
        # for TDOA fw, 1200-baud touch for stock fw. None → unknown (flasher
        # defaults to the magic frame; the fleet runs TDOA fw).
        self._is_tdoa_fw_probe = is_tdoa_fw_probe or (lambda _p: None)
        # STEP 5 — builds a version-aware post-flash heartbeat probe for a flash.
        # Called with ``(sanitized, target_version)`` and returns a
        # ``HeartbeatProbe`` (async ``(port, within_s) -> bool``) that re-finds
        # the device by its stable ``/dev/meshcore/serial-<HEX>-if00`` symlink,
        # reads the next 0x94 GATEWAY_INFO frame, and returns True ONLY when its
        # reported tdoa version EXACTLY matches ``target_version`` (contract #3).
        # None → no probe wired (tests / a publisher that predates the cached
        # version exposure); the flasher then falls back to its own check.
        self._heartbeat_probe_factory = heartbeat_probe_factory
        # Returns THIS Pi's sanitized port names so the dispatcher subscribes
        # only to its own ``gateway/<sanitized>/cmd/fw-upgrade`` topics. The
        # per-Pi MQTT ACL grants only the Pi's own port subtree, so the legacy
        # wildcard subscribe (gateway/+/...) is rejected as "Not authorized"
        # on a scoped broker. None / empty → fall back to the wildcard (dev /
        # god-user brokers, which DO allow it). See test_fwota_dispatcher_subscribe.
        self._own_ports_provider = own_ports_provider
        self._pause_port = pause_port or (lambda _p: None)
        self._resume_port = resume_port or (lambda _p: None)
        # Serial-keyed flash gate (supervisor.mark_flashing / clear_flashing).
        # Keyed on the device's STABLE bare-hex serial, NOT the sanitized slug,
        # so the supervisor's sweep stays off the device across the descriptor
        # swap a flash causes (RAK4631 WisCore↔WisBlock, ESP32-S3 app↔JTAG) —
        # exactly the case the slug-keyed pause_port misses. Bracketed around
        # the whole pause→flash→resume critical section. No-ops by default
        # (tests / a supervisor that predates the serial gate).
        self._mark_flashing = mark_flashing or (lambda _s: None)
        self._clear_flashing = clear_flashing or (lambda _s: None)
        # Set a port's status.json health (sanitized, kind, detail). Used to
        # mark a port "flashing" for the duration of an OTA so the portal shows
        # "fw update in progress" instead of the down/serial_error it would
        # otherwise read while the reader is paused. No-op by default.
        self._update_health = update_health or (lambda _p, _k, _d: None)
        self._cache_dir = cache_dir
        self._github_token = github_token
        if client_factory is None:
            # Honour MQTTConfig.transport so the dispatcher follows the
            # bridge's own broker connection model. A CF-fronted prod broker
            # is WSS+TLS on 443 — without `transport="websockets"` the
            # plain-TCP client connect against that port silently fails and
            # the dispatcher never subscribes
            # (zero `fwota.dispatcher.subscribed` log line, zero packets
            # routed). Was broken on every WSS bridge from the moment the
            # WSS migration shipped (no Layer-1 OTA ever succeeded on the
            # fleet until 2026-05-31).
            transport = (getattr(cfg, "transport", "tcp") or "tcp")
            client_factory = lambda: mqtt.Client(  # noqa: E731
                client_id=f"{cfg.client_id}-fwota",
                callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
                transport=transport,
            )
        self._client = client_factory()
        self._client.on_message = self._on_message
        self._client.on_connect = self._on_connect
        self._client.on_disconnect = self._on_disconnect
        self._log = log.bind(component="fwota-dispatcher")
        self._stop = threading.Event()

    def connect(self) -> None:
        """Open the connection + start the paho loop thread.

        Mirrors the bridge's main-publisher TLS handling — if
        ``cfg.tls_enabled`` is true we call ``client.tls_set()`` before
        ``connect()`` so paho negotiates a TLS handshake on the
        underlying socket (whether that socket carries raw MQTT or WSS,
        depending on transport). Without this the dispatcher was
        attempting plain-TCP on whatever port ``cfg.port`` advertised —
        works on port 1883, silently fails on the home-prod WSS:443
        endpoint.
        """
        if self._cfg.username:
            self._client.username_pw_set(self._cfg.username, self._cfg.password)
        if getattr(self._cfg, "tls_enabled", False):
            import ssl
            cert_reqs = (
                ssl.CERT_NONE
                if getattr(self._cfg, "tls_insecure", False)
                else ssl.CERT_REQUIRED
            )
            self._client.tls_set(cert_reqs=cert_reqs)
            if getattr(self._cfg, "tls_insecure", False):
                self._client.tls_insecure_set(True)
        self._client.connect(self._cfg.host, self._cfg.port, keepalive=60)
        self._client.loop_start()

    def stop(self) -> None:
        self._stop.set()
        try:
            self._client.loop_stop()
        finally:
            try:
                self._client.disconnect()
            except (OSError, RuntimeError):
                pass

    def _on_connect(
        self, _client: mqtt.Client, _ud: object, _flags: object,
        rc: int, _props: object | None = None,
    ) -> None:
        if rc != 0:
            self._log.warning("fwota.dispatcher.connect_fail", rc=rc)
            return
        # Subscribe to THIS Pi's own port topics so a scoped per-Pi ACL
        # doesn't reject us ("Not authorized" on the wildcard). Fall back to
        # the wildcard only when we don't know our ports (dev / god-user).
        own = []
        if self._own_ports_provider is not None:
            try:
                own = [p for p in (self._own_ports_provider() or []) if p]
            except Exception as exc:  # noqa: BLE001
                self._log.warning("fwota.dispatcher.own_ports_error", error=str(exc))
                own = []
        if own:
            topics = [f"gateway/{s}/cmd/fw-upgrade" for s in own]
        else:
            topics = [TOPIC_CMD_SUB]
        # paho drops subscriptions across reconnects (clean_session), so we MUST
        # re-subscribe on every connect — but only LOG at INFO when the topic set
        # actually CHANGES. A reconnect that re-subscribes the same set logs at
        # DEBUG, so a flapping broker connection no longer spams INFO every few
        # seconds (#4). Real connection FAILURES stay visible (connect_fail rc!=0
        # above, and _on_disconnect rc below).
        for topic in topics:
            self._client.subscribe(topic, qos=1)
        new = set(topics)
        if new != getattr(self, "_subscribed_topics", set()):
            self._log.info(
                "fwota.dispatcher.subscribed", topics=topics,
                scoped=bool(own), reconnect=hasattr(self, "_subscribed_topics"),
            )
            self._subscribed_topics = new
        else:
            self._log.debug("fwota.dispatcher.resubscribed", topics=topics)

    def _on_disconnect(
        self, _client: mqtt.Client, _ud: object, _flags: object,
        rc: int = 0, _props: object | None = None,
    ) -> None:
        # An UNEXPECTED disconnect (rc != 0) is the real churn cause — network
        # blip, broker eviction, or a client_id collision (another "-fwota"
        # client). Surface it at WARNING so a flapping connection is diagnosable
        # even though the per-connect subscribe log is now quiet (#4).
        if rc:
            self._log.warning("fwota.dispatcher.disconnected", rc=rc)
        else:
            self._log.debug("fwota.dispatcher.disconnected_clean")

    def _mark_seen_if_new(self, job_id: int, attempt: int) -> bool:
        """Record ``(job_id, attempt)`` as seen; return False if it ALREADY was.

        STEP 2 dedup primitive (shared contract #2). Prunes entries past the
        cooldown so a key whose id is later reused isn't suppressed forever, then
        checks-and-inserts under the lock so two redeliveries can't both win.
        Persists the map after a successful insert so the dedup survives a bridge
        restart (a redelivered QoS=1 job won't re-run). Returns True when this is
        a NEW (job_id,attempt) and the caller should proceed.
        """
        key = _seen_key(job_id, attempt)
        now = time.time()
        with self._seen_lock:
            # Prune expired entries (bounds the file + frees a reused id).
            self._seen = {
                k: ts for k, ts in self._seen.items()
                if now - ts < _FWOTA_SEEN_COOLDOWN_S
            }
            if key in self._seen:
                return False
            self._seen[key] = now
            self._persist_seen_locked()
        return True

    def _persist_seen_locked(self) -> None:
        """Atomically write the seen map to ``_seen_path``. Caller holds the lock.

        Best-effort: a write failure (read-only fs in a test, transient ENOSPC)
        is logged and swallowed — losing persistence degrades dedup to
        in-memory-only for this run, never crashes a flash. Written via a
        ``.part`` + ``os.replace`` so a crash mid-write can't truncate the file.
        """
        try:
            os.makedirs(os.path.dirname(self._seen_path) or ".", exist_ok=True)
            tmp = self._seen_path + ".part"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._seen, f)
            os.replace(tmp, self._seen_path)
        except OSError as exc:
            self._log.warning("fwota.dispatcher.seen_persist_failed", error=_safe_err(exc))

    def _on_message(self, _client: mqtt.Client, _ud: object, msg: mqtt.MQTTMessage) -> None:
        m = _TOPIC_PORT_RE.match(msg.topic)
        if not m:
            return
        sanitized = m.group(1)
        job = parse_job(msg.payload)
        if job is None:
            self._log.warning(
                "fwota.dispatcher.bad_payload",
                topic=msg.topic, bytes=len(msg.payload),
            )
            return
        # STEP 2 — per-(job_id,attempt) dedup (shared contract #2). Drop a job we
        # have already seen (in-flight OR completed within the cooldown). A QoS=1
        # redelivery — incl. one a broker redelivers after a bridge RESTART
        # mid-flash — carries the SAME (job_id,attempt) and is suppressed here,
        # because the seen map is reloaded from disk on startup. A legitimate
        # collector retry carries a NEW attempt number, so its key differs and it
        # is NOT deduped. Mark-and-persist atomically so two redeliveries racing
        # the paho loop can't both pass.
        if self._mark_seen_if_new(job.job_id, job.attempt) is False:
            self._log.warning(
                "fwota.dispatcher.duplicate_job_dropped",
                reason="already_seen",
                sanitized=sanitized, job_id=job.job_id, attempt=job.attempt,
            )
            return
        # Drop a duplicate/concurrent job for a port that's already flashing.
        # QoS=1 can redeliver, and the collector's retry policy may republish a
        # job while the first attempt is still live — without this guard each
        # would spawn a thread and two flashers would fight over the same port.
        # (This guards a DIFFERENT-attempt job for the same port; the seen-map
        # above already absorbed an exact (job_id,attempt) re-delivery.)
        with self._inflight_lock:
            if sanitized in self._inflight:
                self._log.warning(
                    "fwota.dispatcher.duplicate_job_dropped",
                    reason="port_inflight",
                    sanitized=sanitized, job_id=job.job_id, attempt=job.attempt,
                )
                return
            self._inflight.add(sanitized)
        # Run the flash in a worker thread so the paho loop stays
        # responsive (paho callbacks are NOT thread-pooled).
        threading.Thread(
            target=self._run_job,
            args=(sanitized, job),
            name=f"fwota-{sanitized}-{job.job_id}",
            daemon=True,
        ).start()

    def _publish_status(self, sanitized: str, job_id: int, state: str, log_chunk: str = "") -> None:
        payload = json.dumps({"job_id": job_id, "state": state, "log_chunk": log_chunk}).encode()
        self._client.publish(
            TOPIC_STATUS_TEMPLATE.format(sanitized=sanitized),
            payload=payload,
            qos=1,
            retain=False,
        )

    def _run_job(self, sanitized: str, job: JobPayload) -> None:
        """Run one flash attempt for a job.

        Hardening note: the entire body is wrapped in a try/except so
        that ANY exception (network blip during download, asyncio
        runner crash, subprocess oddity) still results in a final
        terminal status being published to MQTT. Without this safety
        net the collector would see the job stuck at ``flashing``
        forever and the 3-strike retry policy would never advance.
        """
        bound = self._log.bind(sanitized=sanitized, job_id=job.job_id, version=job.version)
        try:
            self._run_job_inner(sanitized, job, bound)
        except Exception as exc:  # noqa: BLE001
            bound.exception("fwota.dispatcher.job.crashed", error=_safe_err(exc))
            try:
                self._publish_status(
                    sanitized, job.job_id, "failed_flash",
                    # _safe_err: this catch-all also catches exceptions that
                    # AREN'T OSError/URLError (e.g. http.client.HTTPException),
                    # which bypass the typed handlers above and could carry the
                    # download's Authorization: Bearer <PAT> header to the MQTT
                    # broker. Redact before publishing.
                    f"dispatcher exception: {_safe_err(exc)}",
                )
            except Exception:  # noqa: BLE001 - never let cleanup crash
                pass
        finally:
            # Release the in-flight guard so a later (legitimate) job for this
            # port can run.
            with self._inflight_lock:
                self._inflight.discard(sanitized)
            # STEP 2 — re-stamp the seen entry at COMPLETION so the cooldown is
            # measured from when the flash finished, guaranteeing it spans
            # broker-redelivery + the post-flash verify window (a redelivery
            # arriving right after a long flash is still suppressed). Persisted so
            # the suppression survives a restart.
            with self._seen_lock:
                self._seen[_seen_key(job.job_id, job.attempt)] = time.time()
                self._persist_seen_locked()

    def _download_boot_uf2(self, zip_url: str) -> str | None:
        """Best-effort fetch of the ``.uf2`` sibling of an nRF DFU ``.zip``.

        Used only as a boot-nudge for a DFU-stuck nRF52 (see
        ``fwota_techo._post_flash_boot_nudge``). Returns the local path or
        ``None`` (no sibling, non-zip URL, or any download error — the nudge
        then simply doesn't run, leaving behaviour unchanged). No sha
        verification: it's the same release artifact as the verified ``.zip``
        and is only ever written to the bootloader when already stuck.
        """
        if not zip_url.endswith(".zip"):
            return None
        uf2_url = zip_url[:-4] + ".uf2"
        try:
            os.makedirs(self._cache_dir, exist_ok=True)
            dest = os.path.join(
                self._cache_dir, "bootnudge-" + os.path.basename(uf2_url)
            )
            request: object = uf2_url
            if (
                uf2_url.startswith("https://api.github.com/repos/")
                and "/releases/assets/" in uf2_url
                and self._github_token
            ):
                request = urllib.request.Request(
                    uf2_url,
                    headers={
                        "Authorization": f"Bearer {self._github_token}",
                        "Accept": "application/octet-stream",
                        "User-Agent": "meshcore-bridge-fwota/1",
                    },
                )
            with urllib.request.urlopen(request) as resp:  # type: ignore[arg-type]
                data = resp.read()  # type: ignore[attr-defined]
            if not data.startswith(b"UF2\n"):
                return None  # not a real UF2 — don't hand garbage to the nudge
            with open(dest, "wb") as f:
                f.write(data)
            return dest
        except (OSError, urllib.error.URLError, ValueError) as exc:  # type: ignore[attr-defined]
            self._log.info("fwota.dispatcher.boot_uf2_skip", error=_safe_err(exc))
            return None

    def _select_boot_nudge(self, download_url: str, local_path: str) -> str | None:
        """Pick the UF2 boot-nudge artifact for an nRF52 flash (STEP 4).

        Target-aware, NOT ``.zip``-suffix-gated:
          * ``.zip`` DFU package → fetch the sibling ``.uf2`` (the legacy path);
          * ``.uf2``-only release → the already-downloaded + sha-verified
            ``local_path`` IS the UF2, so reuse it directly (the old code
            returned None here, leaving the boot-nudge DEAD for .uf2 releases —
            a DFU-stuck nRF52 then never got nudged into the app);
          * anything else → no nudge (None), behaviour unchanged.
        """
        if download_url.endswith(".uf2"):
            return local_path
        return self._download_boot_uf2(download_url)

    def _run_job_inner(
        self, sanitized: str, job: JobPayload, bound: object
    ) -> None:
        bound.info("fwota.dispatcher.job.start", target_board=job.target_board)
        port = self._port_resolver(sanitized)
        if port is None:
            # Stuck-chip recovery. When the supervisor has no runtime
            # descriptor matching the slug, the chip is likely in a
            # bootloader after a previous failed flash. Look up the
            # matching bootloader descriptor by MAC suffix:
            #   - ESP32-S3 → USB_JTAG_serial_debug_unit_*
            #   - nRF52 (T-Echo) → LilyGo_T-Echo_v1_*
            # The supervisor filters both out so the dispatcher's
            # retry doesn't race a SerialReader; we find them here
            # and hand them to flash_v4 / flash_techo directly.
            jtag_port = find_jtag_recovery_port(sanitized)
            if jtag_port is not None:
                bound.warning(
                    "fwota.dispatcher.using_jtag_recovery_port",
                    jtag_port=jtag_port,
                )
                port = jtag_port
            else:
                techo_dfu_port = find_techo_dfu_port(sanitized)
                if techo_dfu_port is not None:
                    bound.warning(
                        "fwota.dispatcher.using_techo_dfu_port",
                        dfu_port=techo_dfu_port,
                    )
                    port = techo_dfu_port
            if port is None:
                # Catch-all: find the device under ANY descriptor by its serial
                # suffix (app OR bootloader, e.g. a RAK4631 sitting in its
                # WisBlock UF2 bootloader, or a port the supervisor quarantined
                # as "no frames" — the very device that needs flashing). Reads
                # /dev/serial/by-id directly so quarantine/descriptor changes
                # don't strand the chip.
                serial_port = find_port_by_serial(sanitized)
                if serial_port is not None:
                    bound.warning(
                        "fwota.dispatcher.using_serial_match_port",
                        resolved_port=serial_port,
                    )
                    port = serial_port
        if port is None:
            # Last-resort: the device is likely on the USB bus but its
            # /dev/serial/by-id symlink never appeared (a failed
            # SET_CONFIGURATION / error -110 during enumeration). Extract the
            # hex serial from the sanitized slug and toggle that device's sysfs
            # ``authorized`` flag to re-enumerate it — ONLY that one device, no
            # hub-wide reset. Then re-run the full finder chain ONCE.
            m_serial = _RUNTIME_MAC_RE.search(sanitized)
            if m_serial is not None:
                serial_hint = m_serial.group(1)
                did_reenum = reenumerate_by_serial(serial_hint)
                if did_reenum:
                    # Settle for the symlink to appear after re-enumeration.
                    import time as _time
                    _time.sleep(2.0)
                    # Re-run the full port-finder chain exactly once.
                    port = self._port_resolver(sanitized)
                    if port is None:
                        port = find_jtag_recovery_port(sanitized)
                    if port is None:
                        port = find_techo_dfu_port(sanitized)
                    if port is None:
                        port = find_port_by_serial(sanitized)
                    if port is not None:
                        bound.warning(
                            "fwota.dispatcher.port_unresolved.reenum_recovered",
                            resolved_port=port,
                        )
            if port is None:
                self._publish_status(
                    sanitized, job.job_id, "failed_flash",
                    f"port resolve failed for {sanitized}",
                )
                bound.warning("fwota.dispatcher.port_unresolved")
                return

        # 0.5.24 — ESP32-S3 (Heltec V4) MUST be flashed over the USB-Serial-JTAG
        # descriptor, NOT the application CDC descriptor: the app CDC is a
        # firmware TinyUSB endpoint with no ROM bootloader behind it, so esptool
        # gets "No serial data received" / errno-5. The supervisor's resolver
        # hands us the app CDC port (the open reader); swap it for the JTAG node
        # by serial BEFORE flashing. The JTAG controller is enabled at runtime on
        # the V4, so the descriptor is present without a reset-to-bootloader step.
        # Trigger when the board is an ESP32 target OR the resolved port is
        # already a native-USB descriptor (covers a slug-resolve that landed on
        # the app CDC). Only swap if a JTAG descriptor actually exists; otherwise
        # keep the resolved port (flash_v4 still has its failure-path JTAG retry).
        if is_esp32_target(job.target_board) or is_native_usb_descriptor(port):
            jtag_flash_port = find_jtag_port_by_serial(port) or find_jtag_port_by_serial(
                sanitized
            )
            if jtag_flash_port is not None and jtag_flash_port != port:
                bound.info(
                    "fwota.dispatcher.esp32_jtag_flash_port",
                    app_port=port,
                    jtag_port=jtag_flash_port,
                )
                port = jtag_flash_port

        self._publish_status(sanitized, job.job_id, "downloading")
        try:
            local_path = download_to_cache(
                job.download_url,
                job.sha256,
                cache_dir=self._cache_dir,
                github_token=self._github_token,
            )
        except ValueError as exc:
            self._publish_status(sanitized, job.job_id, "failed_verify", _safe_err(exc))
            bound.warning("fwota.dispatcher.verify_fail", error=_safe_err(exc))
            return
        except (OSError, urllib.error.URLError) as exc:  # type: ignore[attr-defined]
            self._publish_status(sanitized, job.job_id, "failed_download", _safe_err(exc))
            bound.warning("fwota.dispatcher.download_fail", error=_safe_err(exc))
            return

        # Pre-download the rollback firmware so it's available when we
        # need it. Failures here are non-fatal — the primary flash may
        # still succeed and never trigger the rollback path. If the
        # primary fails AND we have no rollback, the chip stays stuck
        # in JTAG mode (same as before this hardening); with one it
        # auto-recovers.
        rollback_path: str | None = None
        if job.previous_download_url and job.previous_sha256:
            try:
                rollback_path = download_to_cache(
                    job.previous_download_url,
                    job.previous_sha256,
                    cache_dir=self._cache_dir,
                    github_token=self._github_token,
                )
                bound.info(
                    "fwota.dispatcher.rollback_armed",
                    previous_version=job.previous_version,
                    previous_sha=job.previous_sha256,
                )
            except (ValueError, OSError, urllib.error.URLError) as exc:  # type: ignore[attr-defined]
                # Roll-forward without a rollback target — log loud so
                # the operator knows the safety net is missing for this
                # job, but don't fail the primary attempt over it.
                bound.warning(
                    "fwota.dispatcher.rollback_prepare_fail",
                    error=_safe_err(exc),
                    previous_version=job.previous_version,
                )

        # Stable device serial for the supervisor's serial-keyed flash gate.
        # Prefer the resolved port path (carries the colon-or-plain hex tail of
        # WHICHEVER descriptor we found — app or bootloader); fall back to the
        # sanitized slug. Normalized (uppercase, colons stripped) so it matches
        # the supervisor's own extract_serial key across the descriptor swap.
        from .discovery import extract_serial

        flash_serial = extract_serial(port) or extract_serial(sanitized)

        # Acquire the per-port serial lock (shared with the auth-token minter)
        # so a token-mint transaction can't open the same port mid-flash and
        # vice versa. Held across the whole pause→flash→resume critical section.
        port_lock = self._serial_locks.get(sanitized)
        port_lock.acquire()
        result = None

        # Reader-resume hook: the flasher calls this ONCE after the write +
        # before the version-verify probe, so the rebooted device's 0x94 frames
        # are read into the publisher version cache the probe reads. Resuming the
        # reader before the probe is what makes the version-verify confirm on the
        # FIRST attempt instead of churning retries while the reader is paused
        # for the whole probe window. Idempotent + also called in finally
        # (covers an early-failure path that never reaches the probe), so the
        # reader is resumed exactly once. Defined BEFORE the try so the finally
        # can always reference it even if pause/setup raises.
        _resumed = {"done": False}

        def on_programmed() -> None:
            if _resumed["done"]:
                return
            _resumed["done"] = True
            # Resume the specific paused reader FIRST, then lift the serial gate
            # (so the supervisor sweep can also re-open a reader for a renamed
            # post-flash descriptor) — resume-before-clear avoids a window where
            # the sweep spawns a duplicate reader before the resume.
            self._resume_port(sanitized)
            if flash_serial is not None:
                self._clear_flashing(flash_serial)

        try:
            # Register the device serial as flashing BEFORE pausing the reader,
            # so even if the chip re-enumerates under a different descriptor the
            # instant the reader releases, the supervisor's sweep refuses to
            # spawn a new reader for any port carrying this serial (the
            # slug-keyed pause_port alone misses the WisCore↔WisBlock /
            # app↔JTAG descriptor swap). No-op when the serial is unknown.
            if flash_serial is not None:
                self._mark_flashing(flash_serial)
            # Pause the serial reader so the flashing subprocess can take
            # the USB-CDC port; resume on the way out regardless of
            # success/failure. Inside the try so the lock can't leak if pause
            # itself raises.
            self._pause_port(sanitized)
            # Mark the port "flashing" so the portal shows "fw update in
            # progress" instead of the down/serial_error it would otherwise read
            # while the reader is paused for the flash. Set AFTER pause so the
            # (now-stopped) reader can't immediately overwrite it.
            self._update_health(sanitized, "flashing", "firmware update in progress")
            self._publish_status(sanitized, job.job_id, "flashing")
            log_lines: list[str] = []
            def on_progress(line: str) -> None:
                log_lines.append(line)
                self._publish_status(sanitized, job.job_id, "flashing", line)

            # STEP 5 — build the version-aware post-flash heartbeat probe. It
            # re-finds the device by the stable serial symlink (contract #4) and
            # confirms the device came back reporting EXACTLY job.version in a
            # 0x94 frame (contract #3). None when no factory is wired (tests /
            # older publisher) → the flasher keeps its prior behaviour.
            heartbeat_probe = (
                self._heartbeat_probe_factory(sanitized, job.version)
                if self._heartbeat_probe_factory is not None
                else None
            )

            # Async fwota_* functions are run synchronously here on the
            # worker thread via asyncio.run() — simpler than threading
            # in an asyncio.Runner. The flash takes 5-15s typically.
            import asyncio

            # WS2: h743 and t114 flash paths are gated behind env flags
            # because the hardware is not yet in production and the stubs
            # currently return "success", which would incorrectly stamp the
            # firmware version on the job row. Both gates MUST be checked
            # BEFORE routing so an un-enabled board type never falls through
            # to the T-Echo branch (which would silently "succeed" with the
            # wrong flash path).
            h743_disabled = not os.environ.get("FWOTA_ENABLE_H743", "").strip()
            t114_disabled = not os.environ.get("FWOTA_ENABLE_T114", "").strip()
            if is_h743_target(job.target_board) and h743_disabled:
                bound.warning(
                    "fwota.dispatcher.board_unsupported",
                    target_board=job.target_board,
                    gate="FWOTA_ENABLE_H743",
                    msg="Set FWOTA_ENABLE_H743=1 in the bridge environment to enable H743 OTA",
                )
                result = FlashResult(
                    state="failed_unsupported",
                    port=port,
                    fw_bin_path=local_path,
                    duration_seconds=0.0,
                    error=(
                        f"STM32H743 OTA is disabled on this bridge "
                        f"(set FWOTA_ENABLE_H743=1 to enable); "
                        f"target_board={job.target_board}"
                    ),
                )
            elif is_t114_target(job.target_board) and t114_disabled:
                bound.warning(
                    "fwota.dispatcher.board_unsupported",
                    target_board=job.target_board,
                    gate="FWOTA_ENABLE_T114",
                    msg="Set FWOTA_ENABLE_T114=1 in the bridge environment to enable T114 OTA",
                )
                result = FlashResult(
                    state="failed_unsupported",
                    port=port,
                    fw_bin_path=local_path,
                    duration_seconds=0.0,
                    error=(
                        f"Heltec T114 OTA is disabled on this bridge "
                        f"(set FWOTA_ENABLE_T114=1 to enable); "
                        f"target_board={job.target_board}"
                    ),
                )
            elif is_esp32_target(job.target_board):
                result = asyncio.run(
                    flash_v4(
                        port,
                        local_path,
                        on_progress=on_progress,
                        rollback_fw_bin_path=rollback_path,
                        # STEP 5 — gate SUCCESS on a target-version 0x94 frame.
                        heartbeat_probe=heartbeat_probe,
                        post_flash_heartbeat_seconds=_POST_FLASH_HEARTBEAT_S,
                        # Resume the reader after the write, before the probe.
                        on_programmed=on_programmed,
                    )
                )
            elif is_h743_target(job.target_board):
                # STM32H743 path uses dfu-util against the H7 ROM
                # bootloader at 0x1FF09800. The H7 family doesn't have
                # a separate JTAG bootloader, so the rollback path is
                # "retry against rollback binary while still in DFU"
                # rather than "retry on a different descriptor" — see
                # fwota_h743.flash_h743 for the details.
                result = asyncio.run(
                    flash_h743(
                        port,
                        local_path,
                        on_progress=on_progress,
                        rollback_fw_bin_path=rollback_path,
                    )
                )
            elif is_t114_target(job.target_board):
                # Heltec T114 v2 uses the Adafruit nRF52 bootloader,
                # identical to T-Echo at the flash-protocol level. The
                # wrapper exists so we can diverge later (e.g. if v3
                # ships with a different bootloader pin map) without
                # touching the T-Echo flash flow.
                result = asyncio.run(
                    flash_t114(port, local_path, on_progress=on_progress)
                )
            elif is_stm32wl_target(job.target_board):
                # SAFETY: only the OpenBootloader-prepped build (_openbl,
                # linked at 0x08008000) may be serial-flashed. OpenBL writes
                # the app at 0x08008000; a normal 0x08000000-based image lands
                # there with the wrong vector table + absolute addresses and
                # bricks the node. So refuse anything that isn't the prepped
                # TDOA build for the Wio. See is_stm32wl_openbl_target.
                if not is_stm32wl_openbl_target(job.target_board):
                    bound.warning(
                        "fwota.dispatcher.stm32wl.refused_non_openbl",
                        target_board=job.target_board,
                    )
                    result = FlashResult(
                        state="failed_bad_input",
                        port=port,
                        fw_bin_path=local_path,
                        duration_seconds=0.0,
                        error=(
                            "Wio-E5 serial OTA requires the OpenBL-prepped "
                            f"build (*_openbl); refusing {job.target_board} "
                            "to avoid a brick"
                        ),
                    )
                else:
                    # Wio-E5 mini / LoRa-E5 (STM32WLE5). Serial flash over the
                    # CP2102 (PB6/PB7) via stm32flash → ST Open Bootloader. The
                    # ROM bootloader is unreachable (PA9/PA10, BOOT0 not bonded)
                    # so OpenBL must already be resident (one-time SWD install,
                    # write-protected region) and the app must have self-jumped
                    # into it (startOTAUpdate sets the RTC backup flag + reset)
                    # before this runs. local_path is the raw firmware.bin; it's
                    # written at the app base past the OpenBL region. See
                    # fwota_stm32wl.flash_stm32wl.
                    result = asyncio.run(
                        flash_stm32wl(
                            port,
                            local_path,
                            on_progress=on_progress,
                            rollback_fw_bin_path=rollback_path,
                        )
                    )
            else:
                # T-Echo / RAK4631 / Wio fall-through path. Doesn't yet
                # support rollback; the DFU bootloader behaves
                # differently from ESP32-S3 and a generic rollback shim
                # risks bricking a healthy chip. Tracked separately.
                is_tdoa_fw = self._is_tdoa_fw_probe(sanitized)
                bound.info(
                    "fwota.dispatcher.techo.dfu_method",
                    is_tdoa_fw=is_tdoa_fw,
                    method="cmd_enter_usb_dfu" if is_tdoa_fw is not False else "1200_touch",
                )
                # Best-effort: pick the .uf2 so flash_techo can boot a DFU-stuck
                # nRF52 (Adafruit #174) without a Pi reboot. A .zip release has a
                # sibling .uf2; a .uf2-only release reuses the verified local
                # artifact directly (target-aware, not .zip-suffix-gated — the
                # old code left the nudge dead for .uf2 releases). Failure → no
                # nudge (no behaviour change).
                boot_uf2 = self._select_boot_nudge(job.download_url, local_path)
                result = asyncio.run(
                    flash_techo(
                        port,
                        local_path,
                        on_progress=on_progress,
                        is_tdoa_fw=is_tdoa_fw,
                        boot_nudge_uf2_path=boot_uf2,
                        # STEP 5 — gate SUCCESS on a target-version 0x94 frame.
                        heartbeat_probe=heartbeat_probe,
                        post_flash_heartbeat_seconds=_POST_FLASH_HEARTBEAT_S,
                        # Resume the reader after the write, before the probe.
                        on_programmed=on_programmed,
                    )
                )

            raw_state = str(getattr(result, "state", "failed_flash"))
            final_state = _map_flash_state(raw_state)
            self._publish_status(sanitized, job.job_id, final_state)
            bound.info("fwota.dispatcher.job.complete", final_state=final_state)
        finally:
            # Clear the transient "flashing" marker. On a successful flash the
            # device re-enumerates and the serial reader sets the real health
            # ("ok") from live frames once the port resumes; only force a
            # terminal "serial_error" when the flash clearly did NOT succeed so
            # a failed/aborted flash never stays stuck showing "flashing".
            _raw = str(getattr(result, "state", "")) if result is not None else ""
            if (not _raw) or any(
                t in _raw for t in ("fail", "timeout", "error", "refused", "bad_input")
            ):
                self._update_health(
                    sanitized, "serial_error", _raw or "firmware flash did not complete"
                )
            # Resume the reader + lift the serial-keyed flash gate. This is
            # IDEMPOTENT via on_programmed: on a healthy flash the flasher
            # already called it (after the write, before the probe — so the
            # reader was live during the version-verify); here it's a no-op. On
            # an early-failure path that never reached the probe, THIS is the
            # call that resumes. Either way the reader is resumed exactly once.
            on_programmed()
            # Release the per-port serial lock last, AFTER the reader has
            # resumed, so the minter can't grab the port before the reader is
            # back.
            try:
                port_lock.release()
            except RuntimeError:
                pass
