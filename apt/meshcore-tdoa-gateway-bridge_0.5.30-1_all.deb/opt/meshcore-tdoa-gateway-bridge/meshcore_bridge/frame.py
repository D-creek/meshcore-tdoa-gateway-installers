"""Wire-format extraction for companion-protocol TDOA frames.

The bridge does the bare minimum of parsing needed to:

1. Reliably frame TDOA records out of the companion-protocol byte
   stream (the firmware also emits log/contact frames that share the
   upper-bit range, so a naive "split on 0x90" is wrong).
2. Pull the typed fields out so we can shape ChirpStack-style envelopes
   on the way to MQTT — the collector then re-parses the raw bytes for
   itself.

Two frame families are extracted today:

**0x90 TDOA_RECEPTION** (one per LoRa packet heard):

    +0   1B   type = 0x90
    +1   6B   node_id (public-key prefix of the receiver)
    +7   4B   embedded packet_hash (SHA-256[:4] of the heard LoRa payload)
    +11  8B   gps_timestamp_us (int64 LE)
    +19  2B   rssi (int16 LE, dBm)
    +21  1B   snr  (int8, dB)
    +22  1B   flags (bit0=pps_locked, bit1=gps_3d_fix,
                    bits 2-7=sat_count 0..63 — firmware tdoa-1.5.3+;
                    pre-1.5.3 firmware emits 0 for the high six bits,
                    which the parser reads as ``sat_count=0``)
    -- KAN-137: optional length-prefixed transmitter-identity tail --
    +23  1B   ext_len  (0 = no extension; otherwise 33 + tx_name_len)
    +24  32B  tx_pubkey   (only present when ext_len > 0)
    +56  1B   tx_name_len (only present when ext_len > 0)
    +57  N    tx_name UTF-8 (N = tx_name_len; only present when ext_len > 0)

The extension is emitted by post-KAN-108 firmware whenever the receiver
has cached the transmitter's pubkey + display_name (typically after a
prior advert). Pre-KAN-108 firmware emits the legacy 23-byte form with
no trailing ext_len byte; the parser tolerates both shapes so a fleet
mid-rollout still flows cleanly.

**0x92 GATEWAY_POSITION** (every 60 s once GPS locks; matches firmware
side `examples/companion_radio/MyMesh.cpp::sendGatewayPosition`):

    +0   1B   type = 0x92
    +1   6B   node_id (matches the 0x90 frame's node_id field)
    +7   4B   lat_e7 (int32 LE, latitude  * 1e7)
    +11  4B   lon_e7 (int32 LE, longitude * 1e7)
    +15  2B   alt_m  (int16 LE; 0 = unknown)
    +17  1B   hdop_x10 (uint8; 0 = unknown)
    +18  1B   sat_count (uint8; 0 = unknown)
    +19  1B   flags (bit0=pps_locked, bit1=gps_3d_fix, bit2=position_valid)
    +20  3B   reserved (zero-padded — keeps both frame families at the
              same 23-byte length so the marker scanner is symmetric)

Both families are exactly 23 bytes; the FrameExtractor scans for either
marker byte and dispatches to the matching parser.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass

TDOA_TYPE_BYTE: int = 0x90
#: Length of the legacy (pre-KAN-108) 0x90 frame — header through the
#: ``flags`` byte. Post-KAN-108 firmware appends a 1-byte ``ext_len``
#: directly after this, plus an optional 33+N-byte identity tail.
TDOA_RECEPTION_LEN: int = 23

#: Maximum length the extension tail can occupy on the wire:
#: 1B ext_len + 32B tx_pubkey + 1B tx_name_len + 255B tx_name (UTF-8 cap).
#: Used to size the per-marker frame-length cap in ``_FRAME_LENGTHS``
#: so the extractor waits for a full extended frame before parsing
#: instead of dropping the marker mid-tail.
TDOA_RECEPTION_EXT_MAX_LEN: int = TDOA_RECEPTION_LEN + 1 + 32 + 1 + 255

#: Wire-level constant: ext_len for an extension that carries a pubkey
#: but a zero-length tx_name. Pubkey is 32 B + tx_name_len byte = 33 B.
#: Anything < 33 (and > 0) is malformed.
_TDOA_EXT_MIN_LEN: int = 33

#: Type byte for the 0x92 GATEWAY_POSITION frame; same 23-byte total
#: length as 0x90 by design.
GW_POS_TYPE_BYTE: int = 0x92
GW_POS_LEN: int = 23

#: Type byte for the 0x94 GATEWAY_INFO frame (board / firmware / chipset
#: metadata + GPS coordinates). 104 bytes total — carries TWO firmware
#: identifiers (MeshCore upstream + this fork's TDOA version) plus the
#: full string slots and the bundled coords so a single retained MQTT
#: message populates everything the Observer tab renders.
GW_INFO_TYPE_BYTE: int = 0x94
#: Legacy 0x94 frame size (104 B). tdoa-1.6.5+ ships a 112-byte variant
#: with an 8-byte radio-config tail (freq + BW + SF + CR). Both shapes
#: stay supported through the rollout window so a mixed fleet doesn't
#: drop gateways while old firmware is still in circulation.
GW_INFO_LEN: int = 104
#: tdoa-1.6.5: 0x94 with radio-config tail. The bridge accepts both
#: GW_INFO_LEN and GW_INFO_LEN_V165 in :func:`parse_gateway_info_frame`;
#: the extractor commits to GW_INFO_LEN_V165 (the larger of the two)
#: when buffering so neither variant is starved of bytes.
GW_INFO_LEN_V165: int = GW_INFO_LEN + 8  # = 112
#: tdoa 2026-05-29 PM: 0x94 with GPS-chip identity tail (probe-detected
#: family + model + sw_version + bootstrap_ack + enabled_gnss_mask).
#: Inner shape: V165 (112 B) followed by 35 B of chip-identity fields.
#: Parser accepts 104 / 112 / 147 transparently.
#:   +0..+111  V165 body (unchanged)
#:   +112      gps_chip_family (uint8: 0=unknown, 1=u-blox, 2=L76K)
#:   +113..128 gps_chip_model[16] (null-padded)
#:   +129..144 gps_chip_sw_version[16] (null-padded)
#:   +145      gps_bootstrap_ack (uint8 bitmap: bit0=NAV5/PCAS04,
#:                                              bit1=SBAS/PCAS02,
#:                                              bit2=GNSS/PMTK386,
#:                                              bit3=SAVE/PCAS00)
#:   +146      gps_enabled_gnss_mask (uint8 bitmap: bit0=GPS, bit1=GLONASS,
#:                                                  bit2=Galileo, bit3=BeiDou,
#:                                                  bit4=QZSS, bit5=SBAS,
#:                                                  bit7=sentinel "probe ran")
GW_INFO_GPS_TAIL_LEN: int = 1 + 16 + 16 + 1 + 1  # = 35
GW_INFO_LEN_V200: int = GW_INFO_LEN_V165 + GW_INFO_GPS_TAIL_LEN  # = 147
#: Pubkey-centric identity (docs/proto-pubkey-identity.md): 0x94 with the
#: receiver's full 32-byte MeshCore self-pubkey appended after the GPS tail.
#: This is the keystone that lets the bridge AUTO-LEARN the receiver pubkey —
#: the only frame field carrying it (the per-frame ``node_id`` is just the
#: 6-byte prefix). A pubkey-capable build emits the full 179-byte frame (GPS
#: tail zeroed when no GPS chip); older builds emit 104/112/147 and the pubkey
#: stays ``None``. An all-zero tail = "not yet known" and decodes to ``None``.
#:   +147..178  self_pubkey[32]
GW_INFO_PUBKEY_TAIL_LEN: int = 32
GW_INFO_LEN_V210: int = GW_INFO_LEN_V200 + GW_INFO_PUBKEY_TAIL_LEN  # = 179

#: tdoa-1.12.51: 0x94 with a firmware-authoritative HW capture-tick rate
#: (uint32 LE Hz, e.g. 40000000 ESP32-S3 MCPWM / 16000000 nRF52840 TIMER)
#: appended directly after the GPS tail. The shipped fleet does NOT emit the
#: self-pubkey tail (no firmware writes it — V210 is a forward-compat slot),
#: so cap_tick rides on the 147-byte V200 form → 151 bytes. The 151 cap-tick
#: tail and the 179 pubkey tail are MUTUALLY EXCLUSIVE (both start at +147).
#: The collector divides raw cc_* counts by this to get seconds without a
#: per-board rate map. Zero/absent on pre-1.12.51 builds.
#:   +147..150  cap_tick_hz (uint32 LE)
GW_INFO_CAP_TICK_TAIL_LEN: int = 4
GW_INFO_LEN_V220: int = GW_INFO_LEN_V200 + GW_INFO_CAP_TICK_TAIL_LEN  # = 151

#: Type byte for the 0x9A TDOA_ADVERT_AUX frame (tdoa-1.8.0). Variable
#: length: 7 B minimum (type + 4 B packet_hash + 1 B flags) up to
#: 7 + 8 (lat/lon) + 1 + 120 (raw_len + raw bytes) = 136 B max.
#: Emitted by ``logRxRaw`` immediately after the 0x90 frame and
#: correlated by the embedded packet_hash. Carries the advert-derived
#: transmitter coordinates and the (capped) raw LoRa packet bytes for
#: post-processing.
TDOA_ADVERT_AUX_TYPE_BYTE: int = 0x9A
TDOA_ADVERT_AUX_MIN_LEN: int = 1 + 4 + 1            # type+hash+flags
#: tdoa-1.8.5: raised 120 → 255 so the bridge can extract the FULL
#: on-air LoRa PHY payload from the 0x9A frame (the firmware-side
#: cap moved at the same time, and MAX_FRAME_SIZE grew to 320 to
#: accommodate). Pre-1.8.5 firmware still caps at 120; the bridge's
#: length-prefix parser handles either silently.
TDOA_ADVERT_AUX_MAX_RAW: int = 255
TDOA_ADVERT_AUX_MAX_LEN: int = (
    TDOA_ADVERT_AUX_MIN_LEN + 8 + 1 + TDOA_ADVERT_AUX_MAX_RAW
)
TDOA_ADVERT_AUX_FLAG_LATLON: int = 0x01
TDOA_ADVERT_AUX_FLAG_RAW: int = 0x02

#: Type byte for the 0x96 DEVICE_TELEMETRY frame (KAN-101). 29 bytes
#: total — carries periodic per-receiver health/timing metrics
#: (MCU temp, VBAT, GPS sat-count, PPS-jitter std-dev, etc.) so the
#: backend can correlate timing-residual quality with device state.
#:
#: NOTE: the original Jira description (KAN-101) listed "0x91 inside
#: 0x92" but those bytes are already taken upstream
#: (PUSH_CODE_TDOA_RECEPTION = 0x91, TDOA_GW_POS_INNER_TYPE_BYTE = 0x92).
#: Firmware allocates the next-available pair (outer 0x97, inner 0x96)
#: following the existing convention "outer = inner + 1" so the bridge
#: scanner keeps the same shape.
DEVICE_TELEMETRY_TYPE_BYTE: int = 0x96
DEVICE_TELEMETRY_LEN: int = 29

#: Sentinel values for fields the firmware can't reliably read on a
#: given build. Mirrors the wire spec in src/helpers/DeviceTelemetry.h.
DEVICE_TELEMETRY_MCU_TEMP_UNAVAILABLE: int = -32768  # INT16_MIN
DEVICE_TELEMETRY_RADIO_TEMP_UNAVAILABLE: int = -128  # INT8_MIN

#: Type byte for the 0x9F GPS_QUALITY frame (Phase-2 GPS housekeeping).
#: 23 bytes total — carries per-receiver GPS quality housekeeping
#: (multi-constellation sat counts, HDOP/PDOP/VDOP, fix quality,
#: geoid separation, SOG) so the timing pipeline can correlate per-
#: epoch sigma against the GPS state at the moment the packet was
#: heard.
#:
#: NOTE: the offset table in the spec (1 type byte + 22 body bytes →
#: 23 B total) is taken as the load-bearing definition. The plan's
#: prose statement of "24 B total inner frame" / calcsize==23 does not
#: arithmetically reconcile with the offset table or the listed struct
#: format ``<6sHHHBBBBBBhH`` (which calcsize=22). We follow the offset
#: table + format string (the most concrete spec) and record the
#: deviation here for the next reviewer.
GPS_QUALITY_TYPE_BYTE: int = 0x9F
GPS_QUALITY_LEN: int = 23

#: Sentinel values for the GPS-quality fields. ``int16`` for the
#: geoid separation honours the wire spec's INT16_MIN unavailable
#: marker; the SOG uses 0xFFFF as a sentinel (uint16).
GPS_QUALITY_GEOID_UNAVAILABLE: int = -32768  # INT16_MIN
GPS_QUALITY_SOG_UNAVAILABLE: int = 0xFFFF

#: Per-marker minimum frame length used by FrameExtractor to know how
#: many bytes it needs before it can attempt a parse for that marker.
#: 0x90 is variable-length (legacy 23 B or 24..312 B with extension);
#: the extractor only commits to a frame size once it has buffered the
#: ext_len byte at offset 23.
_FRAME_LENGTHS: dict[int, int] = {
    TDOA_TYPE_BYTE: TDOA_RECEPTION_LEN,
    GW_POS_TYPE_BYTE: GW_POS_LEN,
    # Largest of the 0x94 variants (104 / 112 / 147 / 179 B) so the
    # extractor buffers enough bytes for the GPS-chip tail; the
    # parser figures out which shape it actually got.
    GW_INFO_TYPE_BYTE: GW_INFO_LEN_V210,
    DEVICE_TELEMETRY_TYPE_BYTE: DEVICE_TELEMETRY_LEN,
    # tdoa-1.8.0: 0x9A is variable (6..136 B). Register the MIN length
    # (type + 4 B packet_hash + 1 B flags) so the extractor can read
    # the flags byte ASAP; a special dispatch in :class:`FrameExtractor`
    # then computes the full length from the flag bits + (optional)
    # raw_len byte before parsing.
    TDOA_ADVERT_AUX_TYPE_BYTE: TDOA_ADVERT_AUX_MIN_LEN,
    GPS_QUALITY_TYPE_BYTE: GPS_QUALITY_LEN,
}

#: All inner type bytes the FrameExtractor will scan for. Order is
#: irrelevant — the scanner looks for whichever marker comes first.
_KNOWN_INNER_TYPES = frozenset(_FRAME_LENGTHS.keys())

#: Largest frame the extractor needs to buffer before it can attempt a
#: parse. Used by the "marker found but body not yet buffered" guard.
_MAX_FRAME_LEN = max(_FRAME_LENGTHS.values())

#: ============================================================================
#: COMPANION-PROTOCOL FRAMING (2026-05-24)
#: ============================================================================
#:
#: The firmware's ``ArduinoSerialInterface::writeFrame`` wraps every
#: emitted frame in a 3-byte header: ``'>'`` (0x3E) + LE16 length +
#: payload. That framing is what the bridge SHOULD honour to be immune
#: to non-frame bytes on the USB-CDC line (MESH_DEBUG / BRIDGE_DEBUG /
#: CLI Rescue printfs, line-discipline noise, etc.).
#:
#: Before 2026-05-24 the extractor ignored the framing and scanned for
#: the inner type bytes (0x90 / 0x92 / 0x94 / 0x96 / 0x9A) at any byte
#: offset. That works on a clean stream but is **fundamentally
#: vulnerable to text contamination**: any 0x9X byte appearing inside a
#: MESH_DEBUG ``printf`` line gets mis-extracted as a frame.
#:
#: The new design: walk the buffer, find ``>`` (0x3E), validate the
#: LE16 length, validate the payload's first byte is a known OUTER push
#: code, then dispatch to the right inner parser. A stray 0x3E in
#: debug text would need the NEXT 3 bytes to all line up — vanishingly
#: low probability, and the inner parsers' plausibility checks catch
#: the rare false positive.

#: Firmware-to-host frame start byte. From ArduinoSerialInterface.cpp:
#:   hdr[0] = '>';
#:   hdr[1] = (len & 0xFF);  // LSB
#:   hdr[2] = (len >> 8);    // MSB
FRAME_START_BYTE: int = 0x3E

#: Outer companion-protocol push codes the firmware uses for TDOA
#: families. Each wraps an inner-type-prefixed payload. The same outer
#: code 0x93 is reused for two inner types (0x92 GATEWAY_POSITION and
#: 0x9A TDOA_ADVERT_AUX) — disambiguated by reading payload[1].
_PUSH_CODE_TDOA_RECEPTION         = 0x91
_PUSH_CODE_TDOA_ADVERT_OR_POS     = 0x93  # disambiguated by inner type
_PUSH_CODE_TDOA_GATEWAY_INFO      = 0x95
_PUSH_CODE_TDOA_DEVICE_TELEMETRY  = 0x97
_PUSH_CODE_TDOA_GPS_QUALITY       = 0xA0

#: All outer push codes we accept inside the framing layer. A frame
#: whose payload starts with a byte outside this set is dropped (it
#: was a false `>` match in non-frame bytes).
_VALID_OUTER_PUSH_CODES = frozenset({
    _PUSH_CODE_TDOA_RECEPTION,
    _PUSH_CODE_TDOA_ADVERT_OR_POS,
    _PUSH_CODE_TDOA_GATEWAY_INFO,
    _PUSH_CODE_TDOA_DEVICE_TELEMETRY,
    _PUSH_CODE_TDOA_GPS_QUALITY,
})

#: Sanity ceiling on the LE16 length in the framing header. Real frames
#: top out around 320 bytes (GW_INFO_LEN_V165 + ext tail + radio tail);
#: 2048 keeps the door open for future-larger frames while rejecting
#: random LE16 reads of debug text (which produce values in the
#: thousands or tens-of-thousands routinely).
_MAX_FRAMED_LEN = 2048

FLAG_PPS_LOCKED = 1 << 0
FLAG_GPS_3D_FIX = 1 << 1
FLAG_POSITION_VALID = 1 << 2

#: Capability flags carried in the 0x94 GATEWAY_INFO ``flags`` byte.
GW_INFO_FLAG_HAS_GPS = 1 << 0
GW_INFO_FLAG_HAS_DISPLAY = 1 << 1
GW_INFO_FLAG_IS_TDOA_RX = 1 << 2
GW_INFO_FLAG_HAS_PPS = 1 << 3
#: Set on the wire when the lat_e7/lon_e7 fields carry a real coordinate
#: (firmware bumped this on first GPS lock). Cleared while the receiver
#: is still indoors / pre-lock; collector then leaves gateways.location
#: untouched rather than persisting (0,0).
GW_INFO_FLAG_POSITION_VALID = 1 << 4
#: Set by the firmware (KAN-125) when the receiver has had a stable GPS
#: 3D fix AND the PPS line has been disciplining the µs counter for at
#: least the configured warm-up window. Distinct from
#: ``GW_INFO_FLAG_HAS_PPS``: that one is a *capability* (the board is
#: wired for PPS), this one is a *runtime quality* (the GPS has actually
#: locked the µs counter to wall-clock time). The downstream TDOA
#: solver gates on this bit before joining a gateway into a
#: multilateration epoch.
GW_INFO_FLAG_GPS_TIME_SYNC_CONFIRMED = 1 << 5
#: tdoa-1.6.0: hardware path for IRQ-based packet timestamping is wired
#: in this firmware build. Compile-time on the receiver side — set
#: whenever the platform routes DIO1 through a hardware capture
#: register (today: nRF52840 GPIOTE→PPI→TIMER1). Distinct from the
#: PROVEN flag below: HAS_IRQ_TIMESTAMPING claims the path exists,
#: PROVEN claims it's been measured to actually work on this build.
GW_INFO_FLAG_HAS_IRQ_TIMESTAMPING = 1 << 6
#: tdoa-1.6.0: runtime self-test passed — the 100-sample DIO1 capture
#: std-dev is within bound. Sticky once set so a stray latency spike
#: from a future ISR storm doesn't flip the operator UI badge.
GW_INFO_FLAG_IRQ_TIMESTAMPING_PROVEN = 1 << 7
_GW_INFO_VALID_FLAG_MASK = (
    GW_INFO_FLAG_HAS_GPS
    | GW_INFO_FLAG_HAS_DISPLAY
    | GW_INFO_FLAG_IS_TDOA_RX
    | GW_INFO_FLAG_HAS_PPS
    | GW_INFO_FLAG_POSITION_VALID
    | GW_INFO_FLAG_GPS_TIME_SYNC_CONFIRMED
    | GW_INFO_FLAG_HAS_IRQ_TIMESTAMPING
    | GW_INFO_FLAG_IRQ_TIMESTAMPING_PROVEN
)

# Mask of *defined* flag bits. Any bit outside this mask in the flags byte
# means the 23-byte window is almost certainly not a real 0x90 frame —
# typically a 0x90 byte that appears mid-payload of a different frame
# family (log/contact/advert) which the naive marker-based extractor
# happened to land on.
#
# Firmware tdoa-1.5.3+ packs the GPS sat_count (0..63) into bits 2-7 of
# the flags byte, so the misalignment-rejection mask now covers the full
# byte. The low two bits are still pps_locked / gps_3d_fix; bits 2-7
# carry the satellite count and are extracted separately by
# :func:`parse_tdoa_frame`.
_VALID_FLAG_MASK = 0xFF

# Plausible LoRa receive characteristics. Values outside these bounds
# are physically impossible and signal that we're decoding garbage:
#   * RSSI in dBm: SX1262 reports as low as ~-148 (sensitivity floor) and
#     practical near-field max is ~+10. Allow a generous window.
#   * SNR in dB: SX1262 effective range ~-20..+15. Allow a small margin.
_RSSI_MIN_DBM = -150
_RSSI_MAX_DBM = 30
_SNR_MIN_DB = -25
_SNR_MAX_DB = 25

#: ``struct`` body format (the 22 bytes after the 1-byte type prefix).
_TDOA_BODY_FMT = "<6s4sqhbB"
assert struct.calcsize(_TDOA_BODY_FMT) == TDOA_RECEPTION_LEN - 1

#: Body format for the 0x94 GATEWAY_INFO frame (103 bytes after the
#: 1-byte type prefix). Layout matches firmware
#: examples/companion_radio/MyMesh.cpp::sendGatewayInfo:
#:   6s = node_id,
#:   32s = board_name,
#:   16s = fw_version       (upstream MeshCore release),
#:   16s = tdoa_fw_version  (THIS fork's version),
#:   12s = mcu_chip,
#:   8s = lora_chip,
#:   4s = build_date_first_4_bytes,
#:   B = flags,
#:   i = lat_e7, i = lon_e7
_GW_INFO_BODY_FMT = "<6s32s16s16s12s8s4sBii"
assert struct.calcsize(_GW_INFO_BODY_FMT) == GW_INFO_LEN - 1

#: tdoa-1.6.5 radio-config tail (8 bytes appended after lon_e7).
#:   I = freq_hz (uint32 LE, full Hz precision; 869618000 for 869.618 MHz)
#:   H = bw_x10_khz (uint16 LE, BW in 0.1 kHz units; 625 = 62.5 kHz)
#:   B = sf (SF6..SF12)
#:   B = cr (LoRa coding-rate denominator, 5..8 for 4/5..4/8)
_GW_INFO_RADIO_TAIL_FMT = "<IHBB"
assert struct.calcsize(_GW_INFO_RADIO_TAIL_FMT) == GW_INFO_LEN_V165 - GW_INFO_LEN

#: Body format for the 0x92 GATEWAY_POSITION frame (22 bytes after the
#: 1-byte type prefix). Layout matches the firmware-side wire spec.
#:   6s = node_id, i = lat_e7, i = lon_e7, h = alt_m,
#:   B = hdop_x10, B = sat_count, B = flags, 3s = reserved
_GW_POS_BODY_FMT = "<6siihBBB3s"
assert struct.calcsize(_GW_POS_BODY_FMT) == GW_POS_LEN - 1

#: Body format for the 0x96 DEVICE_TELEMETRY frame (28 bytes after the
#: 1-byte type prefix). Layout matches firmware
#: src/helpers/DeviceTelemetry.h:
#:   6s = node_id,
#:   I = uptime_s, H = boot_count, B = reset_reason,
#:   h = mcu_temp_q4 (Q12.4, INT16_MIN if unavailable),
#:   b = radio_temp_c (INT8_MIN if unavailable),
#:   H = vbat_mv,
#:   B = gps_sats, H = gps_hdop_x10,
#:   H = pps_jitter_us,
#:   B = ble_active,
#:   I = free_heap
_DEVICE_TELEMETRY_BODY_FMT = "<6sIHBhbHBHHBI"
assert struct.calcsize(_DEVICE_TELEMETRY_BODY_FMT) == DEVICE_TELEMETRY_LEN - 1

#: Body format for the 0x9F GPS_QUALITY frame (22 bytes after the
#: 1-byte type prefix). Layout matches the Phase-2 wire spec:
#:   6s = node_id,
#:   H = hdop_x100, H = pdop_x100, H = vdop_x100,
#:   B = gps_sats, B = glonass_sats, B = beidou_sats,
#:   B = galileo_sats, B = qzss_sats, B = fix_quality,
#:   h = geoid_sep_x10 (INT16_MIN unavailable),
#:   H = sog_x100 (0xFFFF unavailable)
_GPS_QUALITY_BODY_FMT = "<6sHHHBBBBBBhH"
assert struct.calcsize(_GPS_QUALITY_BODY_FMT) == GPS_QUALITY_LEN - 1


@dataclass(frozen=True)
class TDOAFrame:
    """Decoded 0x90 frame.

    ``raw`` is the on-wire bytes preserved verbatim — 23 bytes for the
    legacy (pre-KAN-108) shape, 24+ for the post-KAN-108 shape with the
    optional length-prefixed identity tail.

    ``tx_pubkey`` (32 B) and ``tx_display_name`` (str) are populated only
    when the firmware emitted a non-zero ``ext_len`` (i.e. the receiver
    had cached the transmitter's identity from a prior advert). Both
    are ``None`` for legacy frames *and* for new-format frames whose
    ``ext_len`` is 0, so downstream code can treat presence as the only
    signal.
    """

    raw: bytes
    node_id: bytes
    embedded_packet_hash: bytes
    timestamp_us: int
    rssi: int
    snr: int
    flags: int
    tx_pubkey: bytes | None = None
    tx_display_name: str | None = None
    #: Satellite count locked by the receiver's GPS at the moment the
    #: packet was heard, extracted from bits 2-7 of the flags byte
    #: (firmware tdoa-1.5.3+). ``None`` is reserved for paths that don't
    #: carry the field at all; the wire encoding always produces an int
    #: in [0, 63], where ``0`` legitimately means "no sats locked" on
    #: post-1.5.3 firmware AND is what pre-1.5.3 firmware emits in the
    #: unused high bits — those two cases are indistinguishable, which
    #: is the conservative-correct read.
    sat_count: int | None = None
    #: tdoa-1.6.6 route trailer fields. Populated only when the firmware
    #: appends the fixed 6-byte route trailer (post-1.6.6 builds).
    #: All three are ``None`` for pre-1.6.6 firmware whose 0x90 frame
    #: ends after the KAN-108 identity tail — the bridge surfaces the
    #: absence honestly so the collector doesn't fabricate values.
    #:
    #: ``original_header`` is the LoRa packet's first byte; bits 0-1
    #: are the route_type that the Packet Reception tab renders as
    #: Direct / Flood / Direct+TC / Flood+TC.
    #:
    #: ``path_len_byte`` is the firmware-emitted path_len byte. High
    #: 2 bits encode path_hash_size-1 (so 0 → 1-byte path hashes,
    #: which is the MeshCore default); low 6 bits encode hop count.
    #: A 1-hop direct broadcast has path_len_byte = 0; an advert
    #: flood-routed through 2 repeaters typically has path_len_byte = 2
    #: (count=2, size=1).
    #:
    #: ``last_hop_hash`` is the LAST 4 bytes of the path field, zero-
    #: padded on the LEFT when the path is shorter than 4 bytes and
    #: all-zero when path_len_byte = 0 (no hops yet — packet's first
    #: airtime since being emitted).
    original_header: int | None = None
    path_len_byte: int | None = None
    last_hop_hash: bytes | None = None

    #: tdoa-1.7.0 PPS-counts trailer fields (SpaceTeam/TDoA_Analysis
    #: strategy). Populated only when the firmware appends the fixed
    #: 8-byte trailer after the route trailer.
    #:
    #: ``counts_since_pps`` is the firmware's measured ``micros() -
    #: pps_micros`` at packet RX. Expressed in raw micros() ticks (not
    #: pre-divided by 1e6) so the collector can compute
    #: ``fractional_second = counts_since_pps / pps_interval_us`` with
    #: full precision regardless of the locally-observed tick rate.
    #:
    #: ``pps_interval_us`` is the number of micros() ticks the firmware
    #: counted between the two most recent PPS edges — i.e. the
    #: locally-measured tick rate per real second. Zero until the
    #: second PPS edge has fired; collector treats zero as "not yet
    #: calibrated" and skips TDOA correlation for that reception.
    #:
    #: Both fields are unsigned 32-bit. Modular arithmetic in the
    #: firmware ISR handles micros() rollover (every ~71 min) without
    #: needing wider integers.
    counts_since_pps: int | None = None
    pps_interval_us: int | None = None

    #: tdoa-1.8.1 debug timing trailer (three LE uint32 fields, appended
    #: AFTER the PPS-counts trailer). All three are NULL on pre-1.8.1
    #: firmware. Lets post-processing decompose the per-subsystem timing
    #: noise:
    #:
    #: * ``rx_irq_micros`` — value of ``g_radio_irq_micros`` at the
    #:   moment the firmware's main loop entered ``logRxRaw``. Captures
    #:   the software-only path from the DIO1 ISR to the main loop.
    #: * ``cc_packet`` — TIMER4 CC[0] at packet RX (hardware capture
    #:   via GPIOTE→PPI). 0 on platforms without HW capture (V4 SW path).
    #: * ``cc_pps`` — TIMER4 CC[1] at the most-recent PPS edge.
    #:   0 on platforms without HW capture.
    #:
    #: ``rx_irq_micros - cc_packet`` gives the ISR-entry latency on
    #: T-Echo; ``cc_packet - cc_pps`` equals ``counts_since_pps`` on
    #: HW-capable platforms (cross-check).
    rx_irq_micros: int | None = None
    cc_packet: int | None = None
    cc_pps: int | None = None

    #: SX126x LoRa demodulator frequency-error estimate at RX_DONE (signed Hz,
    #: read from FREQ_ERROR register 0x076B-0x076D). Firmware tdoa-1.8.16+
    #: only — older firmware leaves this as None. The collector applies the
    #: time-frequency coupling correction Δt = freq_error_hz / chirp_rate,
    #: chirp_rate = BW²/2^SF, to test whether removing demodulator offset
    #: bias shrinks the cross-receiver σ.
    freq_error_hz: int | None = None

    #: tdoa-1.12.51 numeric firmware-version stamp (uint32 LE,
    #: MAJOR*1e6+MINOR*1e3+PATCH e.g. 1012051) appended to the debug trailer
    #: after ``freq_error_hz``. For server-side version-gating + per-packet
    #: debug. ``None`` on firmware predating the stamp (12/16/21B trailers).
    tdoa_fw_version_num: int | None = None

    #: tdoa-1.12.0 dual-anchor experiment. Firmware emits TWO MCPWM
    #: capture-register values per RX:
    #:
    #: * ``cc_packet`` (above) — captured at RX_DONE (the end-of-payload
    #:   edge). Existing field, same semantics; what the firmware has
    #:   always emitted as the timestamp anchor.
    #: * ``cc_packet_preamble`` — captured at PREAMBLE_DETECTED (the
    #:   ~beginning-of-airtime edge). Earlier in the packet by exactly the
    #:   on-air payload duration, so the collector can validate the pair
    #:   against radiolib's getTimeOnAir() prediction and reject corrupt
    #:   readings before they pollute the σ math.
    #:
    #: Zero / None means the firmware build doesn't carry the preamble
    #: anchor (pre-1.12.0 or TDOA_PREAMBLE_ANCHOR=0). The collector treats
    #: NULL on this column as "RX_DONE-anchor only, use cc_packet for the
    #: timestamp offset" — same behaviour the fleet has had since 1.6.0.
    cc_packet_preamble: int | None = None

    #: tdoa-1.12.0. How many DIO1 edges fired in the window between
    #: ``startRecv()`` and the moment ``logRxRaw()`` ran. Expected values:
    #:
    #: * 2 — the clean case: PREAMBLE_DETECTED + RX_DONE fired exactly
    #:   once each. Both ``cc_packet_preamble`` and ``cc_packet`` are
    #:   valid; collector can pick either anchor.
    #: * 1 — only RX_DONE fired (preamble was missed, e.g. weak signal
    #:   on the preamble that didn't pass the demodulator threshold).
    #:   ``cc_packet_preamble`` is 0; fall back to RX_DONE anchor.
    #: * 0 — radio reported a packet ready without DIO1 firing; should
    #:   never happen and means the ISR machinery is broken.
    #: * 3+ — spurious DIO1 transition (stray RF, TX_DONE on repeater
    #:   builds, GPIO glitch). Treat the entire row as suspect; the
    #:   collector should set ``drift_valid=false`` for it.
    anchor_edges_seen: int | None = None

    # Convenience accessors mirroring GatewayPositionFrame so the
    # bridge's frame callbacks (mqtt_publisher + __main__) can read the
    # 0x90 per-packet PPS / 3D-fix flags without re-masking. Originally
    # part of TDOAFrame; reinstated 2026-05-11 after a refactor
    # accidentally dropped them and broke uplink publishing.
    @property
    def pps_locked(self) -> bool:
        return bool(self.flags & FLAG_PPS_LOCKED)

    @property
    def gps_3d_fix(self) -> bool:
        return bool(self.flags & FLAG_GPS_3D_FIX)


@dataclass(frozen=True)
class GatewayPositionFrame:
    """Decoded 0x92 frame. ``raw`` is the 23-byte source preserved verbatim.

    ``lat`` and ``lon`` are exposed as floats in degrees (already divided
    out from the int32 *1e7 wire form) for convenience — the canonical
    integer representation lives in ``lat_e7`` / ``lon_e7`` for callers
    that need exact equality.
    """

    raw: bytes
    node_id: bytes
    lat_e7: int
    lon_e7: int
    alt_m: int
    hdop_x10: int
    sat_count: int
    flags: int

    @property
    def lat(self) -> float:
        return self.lat_e7 / 10_000_000.0

    @property
    def lon(self) -> float:
        return self.lon_e7 / 10_000_000.0

    @property
    def hdop(self) -> float | None:
        return self.hdop_x10 / 10.0 if self.hdop_x10 else None

    @property
    def pps_locked(self) -> bool:
        return bool(self.flags & FLAG_PPS_LOCKED)

    @property
    def gps_3d_fix(self) -> bool:
        return bool(self.flags & FLAG_GPS_3D_FIX)

    @property
    def position_valid(self) -> bool:
        return bool(self.flags & FLAG_POSITION_VALID)


def _resolve_tdoa_extended_length(
    buf: bytearray, needed_short: int
) -> int | None:
    """Pick the consumed-byte length for a 0x90 frame with extension tails.

    Three firmware generations are possible:

    * **pre-1.6.6** — no trailer at all. Body ends at ``needed_short``.
    * **1.6.6..1.6.x** — 6-byte route trailer only. Body is
      ``needed_short + 6``.
    * **1.7.0+** — 6-byte route trailer + 8-byte PPS-counts trailer
      (SpaceTeam/TDoA_Analysis strategy). Body is ``needed_short + 14``.

    The dispatch peeks at the byte AFTER each tentative end. If it's
    a known inner-frame marker (0x90/0x92/0x94/0x96/0x97) we treat that
    as the next frame's start; otherwise it's a LoRa packet header byte
    and the trailer is present.

    The route trailer's first byte IS a LoRa packet header (route_type
    in low bits, payload_type in bits 2-5, version in bits 6-7). The
    PPS-counts trailer's first byte is the LSB of ``counts_since_pps``,
    a free-running 32-bit counter — uniformly distributed, only
    collides with marker bytes ~5/256 of the time. Both ambiguities
    are resolved by re-running the same peek logic recursively.

    Returns ``None`` when the buffer doesn't yet have enough bytes to
    make the call — caller should ``return out`` and wait for more.
    """
    if len(buf) < needed_short:
        return None
    if len(buf) == needed_short:
        return needed_short
    next_byte = buf[needed_short]
    if next_byte in _KNOWN_INNER_TYPES:
        # Unambiguously the next frame's marker — pre-1.6.6 firmware.
        return needed_short
    # Looks like a LoRa packet header → route trailer is present.
    if len(buf) < needed_short + 6:
        return None
    # tdoa-1.7.0: PPS-counts trailer may follow the route trailer.
    # Same disambiguation: peek beyond the route trailer.
    needed_with_route = needed_short + 6
    if len(buf) == needed_with_route:
        return needed_with_route
    next_byte_pps = buf[needed_with_route]
    if next_byte_pps in _KNOWN_INNER_TYPES:
        return needed_with_route
    if len(buf) < needed_with_route + 8:
        return None
    needed_with_pps = needed_with_route + 8
    # tdoa-1.8.1: debug timing trailer (12 bytes) may follow the
    # PPS-counts trailer. Same peek-and-disambiguate pattern.
    # tdoa-1.8.16: trailer extended to 16 bytes (+4B int32 freq_error_hz).
    # Disambiguate both lengths via the same peek pattern:
    #   * No debug trailer → byte at +0 is a known marker (next frame start)
    #   * 12B trailer (1.8.1..1.8.15) → byte at +12 is a known marker
    #   * 16B trailer (1.8.16+)       → byte at +16 is a known marker
    # If the byte at +12 is a marker we COULD also coincidentally have a
    # 16B trailer whose 13th byte happens to land on a marker value (5/256).
    # Prefer the shorter trailer in that case — old firmware will be in the
    # fleet during OTA flash and false-cutting a 16B frame into a 12B frame
    # only mis-classifies freq_error_hz; false-extending a 12B frame into
    # 16B steals 4 bytes from the next outer frame and breaks resync.
    if len(buf) == needed_with_pps:
        return needed_with_pps
    next_byte_dbg = buf[needed_with_pps]
    if next_byte_dbg in _KNOWN_INNER_TYPES:
        return needed_with_pps
    if len(buf) < needed_with_pps + 12:
        return None
    if len(buf) == needed_with_pps + 12:
        return needed_with_pps + 12
    next_byte_dbg12 = buf[needed_with_pps + 12]
    if next_byte_dbg12 in _KNOWN_INNER_TYPES:
        return needed_with_pps + 12
    if len(buf) < needed_with_pps + 16:
        return None
    # tdoa-1.12.0: 21-byte debug trailer (+5B: cc_packet_preamble u32 +
    # anchor_edges_seen u8). tdoa-1.12.51: a uint32 fw-version stamp is
    # inserted after freq_error_hz, making the 16B form 20B and the 21B form
    # 25B. Peek past each candidate end at a known inner-marker, preferring
    # the SHORTER form on ambiguity (same "false-extend steals from the next
    # frame" reasoning as the 12B-vs-16B case above).
    #   +16 marker → 16B trailer (pre-fw-version 1.8.16..1.11.x)
    #   +20 marker → 20B trailer (16B + fw_version)
    #   +21 marker → 21B trailer (old dual-anchor, no fw_version)
    #   else       → 25B trailer (20B + dual-anchor)
    if len(buf) == needed_with_pps + 16:
        return needed_with_pps + 16
    next_byte_dbg16 = buf[needed_with_pps + 16]
    if next_byte_dbg16 in _KNOWN_INNER_TYPES:
        return needed_with_pps + 16
    if len(buf) < needed_with_pps + 20:
        return None
    if len(buf) == needed_with_pps + 20:
        return needed_with_pps + 20
    next_byte_dbg20 = buf[needed_with_pps + 20]
    if next_byte_dbg20 in _KNOWN_INNER_TYPES:
        return needed_with_pps + 20
    if len(buf) < needed_with_pps + 21:
        return None
    if len(buf) == needed_with_pps + 21:
        return needed_with_pps + 21
    next_byte_dbg21 = buf[needed_with_pps + 21]
    if next_byte_dbg21 in _KNOWN_INNER_TYPES:
        return needed_with_pps + 21
    if len(buf) < needed_with_pps + 25:
        return None
    return needed_with_pps + 25


def _decode_tdoa_route_trailer(
    raw: bytes, consumed: int
) -> tuple[int | None, int | None, bytes | None]:
    """Decode the tdoa-1.6.6 6-byte route trailer if present.

    Accepts both possible trailing shapes: route trailer alone
    (``len(raw) == consumed + 6``) or route trailer + tdoa-1.7.0
    PPS-counts trailer (``len(raw) == consumed + 14``). A triple of
    ``None`` means either pre-1.6.6 firmware (no trailer at all) or a
    window with an unexpected number of trailing bytes (skip rather
    than misinterpret).

    Caller advances ``consumed`` when this returns a non-None first
    element.
    """
    trailing = len(raw) - consumed
    # 6  = route trailer only (pre-1.7.0).
    # 14 = route trailer (6) + PPS-counts trailer (8) (tdoa-1.7.0..1.8.0).
    # 26 = route trailer (6) + PPS-counts trailer (8) + debug trailer (12) (tdoa-1.8.1..1.8.15).
    # 30 = route trailer (6) + PPS-counts trailer (8) + debug trailer (16) (tdoa-1.8.16+).
    # 35 = route trailer (6) + PPS-counts trailer (8) + debug trailer (21)
    #      (tdoa-1.12.0+ dual-anchor).
    # 34 = route(6)+pps(8)+debug(20); 39 = route(6)+pps(8)+debug(25)
    #      (tdoa-1.12.51+ per-packet fw-version stamp).
    if trailing not in (6, 14, 26, 30, 34, 35, 39):
        return None, None, None
    return raw[consumed], raw[consumed + 1], bytes(raw[consumed + 2:consumed + 6])


def _decode_tdoa_pps_trailer(
    raw: bytes, consumed: int
) -> tuple[int | None, int | None]:
    """Decode the tdoa-1.7.0 8-byte PPS-counts trailer if present.

    Returns ``(counts_since_pps, pps_interval_us)`` when the speculative
    window has AT LEAST 8 unconsumed bytes after ``consumed`` — that's
    what tdoa-1.7.0+ firmware emits AFTER the 6-byte route trailer.
    A tuple of ``None`` means pre-1.7.0 firmware (no PPS trailer) or
    an unexpected number of trailing bytes. The extractor's
    :func:`_resolve_tdoa_extended_length` already commits to exactly
    8 OR 8+12 trailing bytes; this decoder accepts either by reading
    just the 8 PPS bytes regardless of what follows.

    Both values are unsigned 32-bit little-endian — the firmware emits
    them via ``buf[p++] = (uint8_t)(x >> (8 * k))`` in :func:`logRxRaw`.
    """
    trailing = len(raw) - consumed
    if trailing not in (8, 20, 24, 28, 29, 33):
        # 8  = PPS-counts trailer only (pre-1.8.1).
        # 20 = PPS-counts trailer (8) + debug trailer (12) (tdoa-1.8.1..1.8.15).
        # 24 = PPS-counts trailer (8) + debug trailer (16) (tdoa-1.8.16+).
        # 28 = PPS-counts trailer (8) + debug trailer (20) (tdoa-1.12.51+ fw-version).
        # 29 = PPS-counts trailer (8) + debug trailer (21) (tdoa-1.12.0+ dual-anchor).
        # 33 = PPS-counts trailer (8) + debug trailer (25) (tdoa-1.12.51+ fw-version + dual-anchor).
        return None, None
    counts_since_pps = (
        raw[consumed]
        | (raw[consumed + 1] << 8)
        | (raw[consumed + 2] << 16)
        | (raw[consumed + 3] << 24)
    )
    pps_interval_us = (
        raw[consumed + 4]
        | (raw[consumed + 5] << 8)
        | (raw[consumed + 6] << 16)
        | (raw[consumed + 7] << 24)
    )
    return counts_since_pps, pps_interval_us


def _decode_tdoa_debug_trailer(
    raw: bytes, consumed: int
) -> tuple[
    int | None, int | None, int | None, int | None,
    int | None, int | None, int | None
]:
    """Decode the tdoa-1.8.1+ debug trailer (12, 16, 20, 21, or 25 bytes).

    tdoa-1.12.51 inserts a uint32 LE ``tdoa_fw_version_num`` after
    ``freq_error_hz``: the 16B form becomes 20B, the 21B dual-anchor form
    becomes 25B (preamble/anchor fields shift +4). The 21B form (old
    dual-anchor, no fw-version) stays supported for rollover.

    Returns ``(rx_irq_micros, cc_packet, cc_pps, freq_error_hz,
    cc_packet_preamble, anchor_edges_seen)`` based on trailer length:

    * 12-byte (tdoa-1.8.1..1.8.15): three LE uint32 fields. Both
      ``freq_error_hz`` and the two 1.12.0 fields are None.
    * 16-byte (tdoa-1.8.16..1.11.x): the same three fields plus a 4th
      LE int32 ``freq_error_hz`` (SX126x FREQ_ERROR register, Hz).
    * 21-byte (tdoa-1.12.0+): the 16-byte form plus a 5th LE uint32
      ``cc_packet_preamble`` (MCPWM capture latched at
      PREAMBLE_DETECTED, complementing the existing ``cc_packet``
      latched at RX_DONE) and a 1-byte ``anchor_edges_seen`` counter
      (how many DIO1 edges fired between startRecv and logRxRaw).

    A 6-tuple of ``None`` means pre-1.8.1 firmware (no debug trailer)
    or an unrecognised trailer size.

    The cc_* and rx_irq_micros fields are unsigned 32-bit little-endian;
    ``freq_error_hz`` is signed; ``anchor_edges_seen`` is unsigned 8-bit.
    """
    trailing = len(raw) - consumed
    if trailing not in (12, 16, 20, 21, 25):
        return None, None, None, None, None, None, None
    rx_irq_micros = (
        raw[consumed]
        | (raw[consumed + 1] << 8)
        | (raw[consumed + 2] << 16)
        | (raw[consumed + 3] << 24)
    )
    cc_packet = (
        raw[consumed + 4]
        | (raw[consumed + 5] << 8)
        | (raw[consumed + 6] << 16)
        | (raw[consumed + 7] << 24)
    )
    cc_pps = (
        raw[consumed + 8]
        | (raw[consumed + 9] << 8)
        | (raw[consumed + 10] << 16)
        | (raw[consumed + 11] << 24)
    )
    freq_error_hz: int | None = None
    tdoa_fw_version_num: int | None = None
    cc_packet_preamble: int | None = None
    anchor_edges_seen: int | None = None
    if trailing >= 16:
        # int32 little-endian → signed two's complement
        u32 = (
            raw[consumed + 12]
            | (raw[consumed + 13] << 8)
            | (raw[consumed + 14] << 16)
            | (raw[consumed + 15] << 24)
        )
        freq_error_hz = u32 - 0x1_0000_0000 if u32 & 0x8000_0000 else u32
    # tdoa-1.12.51 fw-version stamp: present ONLY on the 20B and 25B forms.
    # NOT on the old 21B dual-anchor form (where +16..+19 is cc_packet_preamble).
    if trailing in (20, 25):
        tdoa_fw_version_num = (
            raw[consumed + 16]
            | (raw[consumed + 17] << 8)
            | (raw[consumed + 18] << 16)
            | (raw[consumed + 19] << 24)
        )
    if trailing == 21:
        # OLD dual-anchor (no fw-version): preamble/anchor at +16/+20.
        cc_packet_preamble = (
            raw[consumed + 16]
            | (raw[consumed + 17] << 8)
            | (raw[consumed + 18] << 16)
            | (raw[consumed + 19] << 24)
        )
        anchor_edges_seen = raw[consumed + 20]
    if trailing == 25:
        # NEW dual-anchor + fw-version: preamble/anchor shift +4 (after stamp).
        cc_packet_preamble = (
            raw[consumed + 20]
            | (raw[consumed + 21] << 8)
            | (raw[consumed + 22] << 16)
            | (raw[consumed + 23] << 24)
        )
        anchor_edges_seen = raw[consumed + 24]
    return (
        rx_irq_micros,
        cc_packet,
        cc_pps,
        freq_error_hz,
        tdoa_fw_version_num,
        cc_packet_preamble,
        anchor_edges_seen,
    )


def parse_tdoa_frame(raw: bytes) -> TDOAFrame | None:
    """Best-effort decode of a 0x90 candidate window.

    Accepts both wire shapes:

    * **Legacy (23 B)** — pre-KAN-108 firmware, no extension tail.
    * **Extended (24+ B)** — post-KAN-108 firmware. Byte 23 is
      ``ext_len``; when 0 the frame ends there, when 33+N a full
      ``tx_pubkey`` + ``tx_name_len`` + ``tx_name`` tail follows.

    Returns ``None`` on any structural problem (wrong length, wrong type
    byte, ext_len present but tail truncated, ext_len < 33 but > 0).
    Never raises — the framing layer hands us speculative windows and
    an "is this real?" answer is what it needs.
    """
    if len(raw) < TDOA_RECEPTION_LEN:
        return None
    if raw[0] != TDOA_TYPE_BYTE:
        return None
    try:
        node_id, ehash, ts_us, rssi, snr, flags = struct.unpack(
            _TDOA_BODY_FMT, raw[1:TDOA_RECEPTION_LEN]
        )
    except struct.error:
        return None
    # Reject implausible values — a 0x90 byte mid-stream in a non-TDOA
    # frame will satisfy the magic-byte check but the unpacked fields
    # come out as random noise (RSSI in the thousands, undefined flag
    # bits, etc.). The collector dedup index would otherwise persist
    # those rows. See KAN: spurious-frames-bug.
    if flags & ~_VALID_FLAG_MASK:
        return None
    if rssi < _RSSI_MIN_DBM or rssi > _RSSI_MAX_DBM:
        return None
    if snr < _SNR_MIN_DB or snr > _SNR_MAX_DB:
        return None
    # 2026-05-24 — companion_radio's PUSH_CODE_ADVERT (0x80) emits the
    # full 32-byte contact pubkey verbatim, and PUSH_CODE_TDOA_ADVERT_AUX
    # (0x93) emits arbitrary raw-LoRa-packet bytes. Both can carry a
    # 0x90 byte mid-stream, and the bytes that follow often have long
    # zero stretches that look like (rssi=0, snr=0, flags=0, ts_us=0) —
    # passing all of the range checks above. The TDOA firmware emits
    # rssi=0 only on a "we received this packet at exactly 0 dBm AND
    # the radio reported snr=0 AND we have no PPS lock AND timestamp
    # is exactly 0 µs" — which doesn't happen on a real reception
    # (rssi is always non-zero, ts_us is always non-zero post-boot).
    # Drop the frame when all four are zero; the false-negative rate
    # on real frames is effectively zero.
    if rssi == 0 and snr == 0 and flags == 0 and ts_us == 0:
        return None

    # Firmware tdoa-1.5.3+: bits 2-7 of the flags byte carry the
    # GPS sat_count (0..63). Pre-1.5.3 firmware leaves those bits
    # at 0, which is read here as ``sat_count=0`` — that's
    # indistinguishable from "0 sats locked" but is the
    # conservative-correct read. The low two bits keep their
    # original pps_locked / gps_3d_fix meaning and are exposed
    # via the dataclass properties.
    sat_count = (flags >> 2) & 0x3F

    # KAN-137: optional length-prefixed identity tail.
    tx_pubkey: bytes | None = None
    tx_name: str | None = None
    consumed = TDOA_RECEPTION_LEN

    if len(raw) == TDOA_RECEPTION_LEN:
        # Legacy 23-byte frame — pre-KAN-108 firmware. No tail.
        pass
    else:
        ext_len = raw[TDOA_RECEPTION_LEN]
        consumed = TDOA_RECEPTION_LEN + 1
        if ext_len == 0:
            # New firmware emitted the ext_len byte with no payload;
            # nothing else to parse but the byte itself is consumed.
            pass
        elif ext_len < _TDOA_EXT_MIN_LEN:
            # Extension byte present but smaller than the mandatory
            # 32B pubkey + 1B name_len it must carry. Either firmware
            # bug or stream misalignment — refuse rather than guess.
            return None
        else:
            # Need the full tail buffered; otherwise the speculative
            # window is truncated and the extractor needs to buffer
            # more bytes before re-attempting the parse.
            if len(raw) < TDOA_RECEPTION_LEN + 1 + ext_len:
                return None
            pubkey_start = TDOA_RECEPTION_LEN + 1
            tx_pubkey = bytes(raw[pubkey_start:pubkey_start + 32])
            name_len = raw[pubkey_start + 32]
            # ext_len carries the *total* tail size including pubkey
            # (32) + name_len byte (1) + name. Cross-check against the
            # name_len byte; mismatch means corruption.
            if 33 + name_len != ext_len:
                return None
            name_start = pubkey_start + 32 + 1
            name_bytes = bytes(raw[name_start:name_start + name_len])
            # UTF-8 best-effort: surface a malformed byte as U+FFFD
            # rather than rejecting the whole frame. The TDOA timing
            # data is still valid even if the name slot is corrupt.
            tx_name = name_bytes.decode("utf-8", errors="replace")
            consumed = TDOA_RECEPTION_LEN + 1 + ext_len

    # tdoa-1.6.6+: optional 6-byte route trailer parsed by helper to
    # keep parse_tdoa_frame's cognitive complexity in check.
    original_header, path_len_byte, last_hop_hash = (
        _decode_tdoa_route_trailer(raw, consumed)
    )
    if original_header is not None:
        consumed += 6

    # tdoa-1.7.0+: optional 8-byte PPS-counts trailer following the
    # route trailer. Only attempt the decode when the route trailer
    # WAS present — pre-1.6.6 firmware emits neither, so a window with
    # extra trailing bytes after the legacy/KAN-108 body but no route
    # trailer is corruption.
    counts_since_pps: int | None = None
    pps_interval_us: int | None = None
    if original_header is not None:
        counts_since_pps, pps_interval_us = _decode_tdoa_pps_trailer(
            raw, consumed
        )
        if counts_since_pps is not None:
            consumed += 8

    # tdoa-1.8.1+: optional 12-byte debug timing trailer after PPS-counts.
    # tdoa-1.8.16+: optional 16-byte form (adds freq_error_hz).
    # Only attempt the decode when the PPS-counts trailer WAS present
    # (debug trailer cannot exist without it).
    rx_irq_micros: int | None = None
    cc_packet: int | None = None
    cc_pps: int | None = None
    freq_error_hz: int | None = None
    tdoa_fw_version_num: int | None = None
    cc_packet_preamble: int | None = None
    anchor_edges_seen: int | None = None
    if counts_since_pps is not None:
        trailing = len(raw) - consumed
        (
            rx_irq_micros,
            cc_packet,
            cc_pps,
            freq_error_hz,
            tdoa_fw_version_num,
            cc_packet_preamble,
            anchor_edges_seen,
        ) = _decode_tdoa_debug_trailer(raw, consumed)
        if rx_irq_micros is not None:
            # 12 (legacy), 16 (+freq_error), 20 (+fw_version), 21 (old
            # dual-anchor), or 25 (+fw_version +dual-anchor, tdoa-1.12.51+)
            consumed += trailing

    return TDOAFrame(
        raw=bytes(raw[:consumed]),
        node_id=node_id,
        embedded_packet_hash=ehash,
        timestamp_us=ts_us,
        rssi=rssi,
        snr=snr,
        flags=flags,
        tx_pubkey=tx_pubkey,
        tx_display_name=tx_name,
        original_header=original_header,
        path_len_byte=path_len_byte,
        last_hop_hash=last_hop_hash,
        counts_since_pps=counts_since_pps,
        pps_interval_us=pps_interval_us,
        sat_count=sat_count,
        rx_irq_micros=rx_irq_micros,
        cc_packet=cc_packet,
        cc_pps=cc_pps,
        freq_error_hz=freq_error_hz,
        tdoa_fw_version_num=tdoa_fw_version_num,
        cc_packet_preamble=cc_packet_preamble,
        anchor_edges_seen=anchor_edges_seen,
    )


def parse_gateway_position_frame(raw: bytes) -> GatewayPositionFrame | None:
    """Best-effort decode of a 23-byte 0x92 candidate window.

    Returns ``None`` on any structural problem or implausible-value
    rejection. Mirrors the sanity-check policy from parse_tdoa_frame:
    flags must have only defined bits set, and a bit2=position_valid
    of 0 means the receiver hasn't locked GPS yet — we drop those
    rather than emit a (0,0) coordinate.
    """
    if len(raw) != GW_POS_LEN:
        return None
    if raw[0] != GW_POS_TYPE_BYTE:
        return None
    try:
        node_id, lat_e7, lon_e7, alt_m, hdop, sats, flags, _reserved = struct.unpack(
            _GW_POS_BODY_FMT, raw[1:GW_POS_LEN]
        )
    except struct.error:
        return None
    valid_mask = FLAG_PPS_LOCKED | FLAG_GPS_3D_FIX | FLAG_POSITION_VALID
    if flags & ~valid_mask:
        return None
    if not (flags & FLAG_POSITION_VALID):
        return None
    # int32 lat * 1e7 range: ±900_000_000 (covers ±90°). Anything wider
    # is corruption.
    if not (-900_000_000 <= lat_e7 <= 900_000_000):
        return None
    if not (-1_800_000_000 <= lon_e7 <= 1_800_000_000):
        return None
    # Misalignment guard. The marker scanner can land on a 0x92 byte
    # mid-payload of an unrelated frame (e.g. LOG_RX_DATA carries raw
    # LoRa bytes that often contain 0x92). A random 23-byte window
    # passes the flags + lat/lon checks ~5 % of the time. The reserved
    # 3-byte slot in the firmware is always (0, 0, 0); requiring that
    # cuts the false-positive rate by 16 M× (1 / 2^24).
    # Per-axis plausibility on the auxiliary fields catches the tiny
    # remainder: alt_m within −1 km..30 km (Mt Everest is 8.85 km),
    # hdop_x10 ≤ 999 (HDOP > 99.9 is impossible), sat_count ≤ 64
    # (multi-constellation receivers cap around 32; allow margin).
    if _reserved != b"\x00\x00\x00":
        return None
    if not (-1000 <= alt_m <= 30000):
        return None
    if not (0 <= hdop <= 250):
        return None
    if not (0 <= sats <= 64):
        return None
    return GatewayPositionFrame(
        raw=bytes(raw),
        node_id=node_id,
        lat_e7=lat_e7,
        lon_e7=lon_e7,
        alt_m=alt_m,
        hdop_x10=hdop,
        sat_count=sats,
        flags=flags,
    )


@dataclass(frozen=True)
class GatewayInfoFrame:
    """Decoded 0x94 frame. ``raw`` is the 104-byte source preserved verbatim.

    Strings on the wire are null-padded fixed-length slots; the parser
    strips the padding and returns plain Python strings — UTF-8
    decoding is best-effort with ``errors="replace"`` so a malformed
    byte never crashes the bridge.

    ``fw_version`` is the upstream MeshCore release this build is based
    on (FIRMWARE_VERSION macro). ``tdoa_fw_version`` is THIS fork's
    version (TDOA_FIRMWARE_VERSION macro) — the Observer tab renders
    the two as separate columns so an operator can tell at a glance
    whether a fork update is rolled out without parsing combined
    strings.

    ``lat`` / ``lon`` are exposed as floats in degrees (the canonical
    integer representation lives in ``lat_e7`` / ``lon_e7``). When
    ``position_valid`` is False the firmware sends 0,0 and the
    ``lat`` / ``lon`` properties return ``None`` so the backend never
    persists a synthetic origin coordinate.
    """

    raw: bytes
    node_id: bytes
    board_name: str
    fw_version: str
    tdoa_fw_version: str
    mcu_chip: str
    lora_chip: str
    build_date_prefix: str
    flags: int
    lat_e7: int
    lon_e7: int
    # tdoa-1.6.5 radio-config tail. ``None`` on a legacy 104-byte frame
    # so old fleet entries don't poison the column with synthetic
    # zeros. The collector only upserts these when non-null, leaving
    # the gateways row's radio_* columns untouched for pre-1.6.5
    # receivers until they're updated.
    radio_freq_hz: int | None = None
    radio_bw_x10_khz: int | None = None
    radio_sf: int | None = None
    radio_cr: int | None = None
    # tdoa 2026-05-29 PM GPS-chip identity tail (147-byte 0x94 variant).
    # ``None`` on legacy frames; collector only upserts non-null values
    # so a fleet rolling through the upgrade doesn't lose chip data.
    gps_chip_family: int | None = None      # 0=unknown, 1=u-blox, 2=L76K
    gps_chip_model: str | None = None       # e.g. "L76K", "ZOE-M8Q"
    gps_chip_sw_version: str | None = None  # raw chip-reported version
    gps_bootstrap_ack: int | None = None    # bitmap, see GW_INFO_LEN_V200 doc
    gps_enabled_gnss_mask: int | None = None  # bitmap, see GW_INFO_LEN_V200 doc
    # Pubkey-centric identity (docs/proto-pubkey-identity.md): the receiver's
    # full 32-byte self-pubkey, present only on the 179-byte V210 frame. ``None``
    # on legacy frames or an all-zero (not-yet-known) tail. The bridge caches it
    # per port and stamps ``meta.pubkey_hex`` from it — auto-learning the pubkey
    # without operator declaration.
    self_pubkey: bytes | None = None
    # tdoa-1.12.51 firmware-authoritative HW capture-tick rate (Hz): 40000000
    # ESP32-S3 (MCPWM), 16000000 nRF52840 (TIMER3). ``None`` on pre-1.12.51
    # frames (104/112/147/179 B) or a 0 placeholder, so the collector never
    # overwrites a known rate with a synthetic value.
    cap_tick_hz: int | None = None

    @property
    def has_gps(self) -> bool:
        return bool(self.flags & GW_INFO_FLAG_HAS_GPS)

    @property
    def has_display(self) -> bool:
        return bool(self.flags & GW_INFO_FLAG_HAS_DISPLAY)

    @property
    def is_tdoa_rx(self) -> bool:
        return bool(self.flags & GW_INFO_FLAG_IS_TDOA_RX)

    @property
    def has_pps(self) -> bool:
        return bool(self.flags & GW_INFO_FLAG_HAS_PPS)

    @property
    def position_valid(self) -> bool:
        return bool(self.flags & GW_INFO_FLAG_POSITION_VALID)

    @property
    def gps_time_sync_confirmed(self) -> bool:
        """Runtime quality bit — firmware (KAN-125) sets this only after
        a stable 3D fix AND PPS-disciplined µs counter. Distinct from
        :attr:`has_pps`, which is a build-time capability indicator. The
        TDOA solver drops a gateway from a multilateration epoch when
        this is False at the time of the packet.
        """
        return bool(self.flags & GW_INFO_FLAG_GPS_TIME_SYNC_CONFIRMED)

    @property
    def has_irq_timestamping(self) -> bool:
        """Compile-time capability bit (tdoa-1.6.0): this firmware build
        wires DIO1 through a hardware capture register so the per-packet
        arrival timestamp is latched with zero CPU latency. Today only
        nRF52840 builds set this; everywhere else the bit stays clear
        even on platforms where it could theoretically be implemented.
        """
        return bool(self.flags & GW_INFO_FLAG_HAS_IRQ_TIMESTAMPING)

    @property
    def irq_timestamping_proven(self) -> bool:
        """Runtime quality bit (tdoa-1.6.0): the firmware's boot self-test
        collected 100 DIO1 captures during normal RX and confirmed the
        (sw - hw) latency std-dev is within bound, so the hardware path
        is demonstrably working on this particular build. Sticky once
        set. ``False`` means either the self-test is still in progress
        / failed, or this build doesn't have the hardware path at all
        (cross-reference :attr:`has_irq_timestamping` to disambiguate).
        """
        return bool(self.flags & GW_INFO_FLAG_IRQ_TIMESTAMPING_PROVEN)

    @property
    def lat(self) -> float | None:
        return self.lat_e7 / 10_000_000.0 if self.position_valid else None

    @property
    def lon(self) -> float | None:
        return self.lon_e7 / 10_000_000.0 if self.position_valid else None


def _resolve_gw_info_length(buf: bytearray, default_len: int) -> int:
    """Pick 104 vs 112 for a 0x94 frame in the extractor buffer.

    tdoa-1.6.5 introduced an 8-byte radio-config tail so 0x94 is now
    variable-length: legacy 104 B or 112 B. ``_FRAME_LENGTHS`` holds
    the larger of the two (so the buffer waits for either shape) and
    this helper decides which size to actually consume.

    The byte at offset 104 disambiguates: legacy firmware places the
    next frame's marker there (one of 0x90/0x92/0x94/0x96); 1.6.5
    firmware places the freq_hz low byte, which for 869.618 MHz is
    ``0x10`` — not a known marker. So when byte 104 IS a known marker
    AND the 104-byte parse succeeds, commit to 104; otherwise stick
    with the default 112.
    """
    if len(buf) <= GW_INFO_LEN:
        return default_len
    next_byte = buf[GW_INFO_LEN]
    if next_byte not in _KNOWN_INNER_TYPES:
        return default_len
    if parse_gateway_info_frame(bytes(buf[:GW_INFO_LEN])) is None:
        return default_len
    return GW_INFO_LEN


def _decode_gw_info_radio_tail(
    raw: bytes,
) -> tuple[int | None, int | None, int | None, int | None]:
    """Decode the tdoa-1.6.5 8-byte radio-config tail on a 112-byte 0x94 frame.

    Returns ``(freq_hz, bw_x10_khz, sf, cr)`` on success, or a 4-tuple
    of ``None`` if the tail bytes are structurally malformed. Caller
    guarantees ``len(raw) >= GW_INFO_LEN_V165`` so the slice is safe.
    Splitting this out keeps :func:`parse_gateway_info_frame` below the
    cognitive-complexity gate.
    """
    try:
        return struct.unpack(
            _GW_INFO_RADIO_TAIL_FMT, raw[GW_INFO_LEN:GW_INFO_LEN_V165]
        )
    except struct.error:
        return None, None, None, None


# tdoa 2026-05-29 PM: GPS-chip identity tail layout.
#   B (family) + 16s (model) + 16s (sw_version) + B (ack) + B (gnss_mask)
_GW_INFO_GPS_TAIL_FMT: str = "<B 16s 16s B B"

#: GPS chip family code → human-readable label exposed in MQTT events.
GW_INFO_GPS_FAMILY_NAMES: dict[int, str] = {
    0: "unknown",
    1: "u-blox",
    2: "L76K",
    # 2026-06-07: a GPS that streams valid NMEA but answers neither the u-blox
    # nor L76K version probe (e.g. the GP-02 BDS+GPS module on a Heltec V4).
    # The firmware's GpsChipProbe reports family=3 + model "GP-02"; positioning
    # already works via the generic NMEA provider.
    3: "GP-02 (generic NMEA)",
}


def _correct_gp02_misdetect(
    family: int | None, model: str | None, sw_version: str | None
) -> tuple[int | None, str | None]:
    """Trust the firmware's GPS-chip family — no bridge-side relabel.

    HISTORY (2026-06-10 fix): this used to force any chip whose ``sw_version``
    contained ``URANUS`` to GP-02 (family 3), on the assumption that the URANUS
    signature was unique to the GP-02 and never appeared on a real L76K. That
    assumption was WRONG — the LilyGo T-Echo's genuine Quectel L76K answers
    ``$PQVERNO`` with ``SW=URANUS5`` (see GpsChipProbe.h's own comment). So the
    heuristic mislabeled real L76Ks as GP-02, which broke the chip identity, the
    L76K bootstrap expectations, and the reported constellations on the fleet's
    T-Echos/V4s. The firmware's GpsChipProbe already distinguishes the chips from
    the actual PCAS/PQVERNO exchange (it has the serial line); the bridge must
    not second-guess it on an ambiguous version string. Pass-through now —
    deployed call site unchanged so this lands via the deb auto-update.
    """
    return family, model


def _decode_gw_info_gps_tail(
    raw: bytes,
) -> tuple[int | None, str | None, str | None, int | None, int | None]:
    """Decode the 35-byte GPS-chip identity tail on a 147-byte 0x94 frame.

    Returns a 5-tuple ``(family, model, sw_version, ack_bits, gnss_mask)``
    on success, or all-``None`` on a structural failure. Caller
    guarantees ``len(raw) == GW_INFO_LEN_V200``. Strings are stripped
    of trailing nulls and any non-printable garbage.
    """
    try:
        (family, model_b, sw_b, ack, gnss_mask) = struct.unpack(
            _GW_INFO_GPS_TAIL_FMT, raw[GW_INFO_LEN_V165:GW_INFO_LEN_V200]
        )
    except struct.error:
        return None, None, None, None, None
    return family, _strip_padded(model_b), _strip_padded(sw_b), ack, gnss_mask


def parse_gateway_info_frame(raw: bytes) -> GatewayInfoFrame | None:
    """Best-effort decode of a 0x94 candidate window.

    Accepts both the legacy 104-byte shape and the tdoa-1.6.5 112-byte
    shape that appends a radio-config tail (freq + BW + SF + CR). The
    extra fields decode into the matching ``radio_*`` attributes on the
    returned frame; on a legacy 104-byte input they stay ``None`` and
    the collector leaves the gateways row's radio columns alone.

    Returns ``None`` on any structural problem, on a flags byte with
    bits outside the defined mask, or on lat/lon outside the WGS84
    range when the position_valid bit is set. (When position_valid is
    cleared the firmware sends 0,0 — those are ignored, not range-
    checked.)
    """
    has_cap_tick_tail = len(raw) == GW_INFO_LEN_V220
    has_pubkey_tail = len(raw) == GW_INFO_LEN_V210
    # 151 (cap-tick) and 179 (pubkey) are mutually exclusive — both append at
    # +147; both still carry the GPS tail at [112:147].
    has_gps_tail = (
        has_pubkey_tail or has_cap_tick_tail or len(raw) == GW_INFO_LEN_V200
    )
    has_radio_tail = has_gps_tail or len(raw) == GW_INFO_LEN_V165
    if len(raw) != GW_INFO_LEN and not has_radio_tail:
        return None
    if raw[0] != GW_INFO_TYPE_BYTE:
        return None
    try:
        (
            node_id,
            board,
            fw,
            tdoa_fw,
            mcu,
            lora,
            build,
            flags,
            lat_e7,
            lon_e7,
        ) = struct.unpack(_GW_INFO_BODY_FMT, raw[1:GW_INFO_LEN])
    except struct.error:
        return None
    radio_freq_hz, radio_bw_x10_khz, radio_sf, radio_cr = (
        _decode_gw_info_radio_tail(raw) if has_radio_tail else (None, None, None, None)
    )
    (gps_chip_family, gps_chip_model, gps_chip_sw_version,
     gps_bootstrap_ack, gps_enabled_gnss_mask) = (
        _decode_gw_info_gps_tail(raw) if has_gps_tail
        else (None, None, None, None, None)
    )
    gps_chip_family, gps_chip_model = _correct_gp02_misdetect(
        gps_chip_family, gps_chip_model, gps_chip_sw_version
    )
    self_pubkey: bytes | None = None
    if has_pubkey_tail:
        tail = bytes(raw[GW_INFO_LEN_V200:GW_INFO_LEN_V200 + GW_INFO_PUBKEY_TAIL_LEN])
        # An all-zero tail means the firmware hasn't populated its self-pubkey
        # yet (or a zeroed placeholder) — treat as "not known" so it never
        # becomes a bogus identity / ACL key.
        if tail != b"\x00" * GW_INFO_PUBKEY_TAIL_LEN:
            self_pubkey = tail
    # tdoa-1.12.51: firmware-authoritative HW capture-tick rate (uint32 LE
    # Hz) on the 151-byte V220 form (V200 GPS tail + 4 B), mutually exclusive
    # with the 179-byte pubkey tail. 0 placeholder → None so the collector's
    # COALESCE preserves a prior known value.
    cap_tick_hz: int | None = None
    if has_cap_tick_tail:
        (cap_tick_hz,) = struct.unpack(
            "<I",
            raw[GW_INFO_LEN_V200:GW_INFO_LEN_V200 + GW_INFO_CAP_TICK_TAIL_LEN],
        )
        cap_tick_hz = cap_tick_hz or None
    if flags & ~_GW_INFO_VALID_FLAG_MASK:
        return None
    if flags & GW_INFO_FLAG_POSITION_VALID:
        # int32 lat * 1e7 range: ±900_000_000 (covers ±90°). Outside
        # that means the wire data is corrupt, not just "no fix".
        if not (-900_000_000 <= lat_e7 <= 900_000_000):
            return None
        if not (-1_800_000_000 <= lon_e7 <= 1_800_000_000):
            return None
    # NOTE: misalignment / contamination guarding is no longer needed
    # here — the framed-only extractor (2026-05-25 / PR #160) only ever
    # invokes this parser on bytes that survived the `> + LE16 length +
    # outer_push` envelope. Inter-frame noise (debug printf, etc.)
    # never reaches this function. Unit tests can drive crafted edge-
    # case slots and get a valid frame back; production traffic cannot
    # carry contamination because of the envelope validation upstream.
    return GatewayInfoFrame(
        raw=bytes(raw),
        node_id=node_id,
        board_name=_strip_padded(board),
        fw_version=_strip_padded(fw),
        tdoa_fw_version=_strip_padded(tdoa_fw),
        mcu_chip=_strip_padded(mcu),
        lora_chip=_strip_padded(lora),
        build_date_prefix=_strip_padded(build),
        flags=flags,
        lat_e7=lat_e7,
        lon_e7=lon_e7,
        radio_freq_hz=radio_freq_hz,
        radio_bw_x10_khz=radio_bw_x10_khz,
        radio_sf=radio_sf,
        radio_cr=radio_cr,
        gps_chip_family=gps_chip_family,
        gps_chip_model=gps_chip_model,
        gps_chip_sw_version=gps_chip_sw_version,
        gps_bootstrap_ack=gps_bootstrap_ack,
        gps_enabled_gnss_mask=gps_enabled_gnss_mask,
        self_pubkey=self_pubkey,
        cap_tick_hz=cap_tick_hz,
    )


@dataclass(frozen=True)
class DeviceTelemetryFrame:
    """Decoded 0x96 DEVICE_TELEMETRY frame (KAN-101).

    ``raw`` is the 29-byte source preserved verbatim. All numeric
    fields are exposed as plain ints; helpers below decode the
    fixed-point + sentinel fields into Pythonic optionals so consumers
    don't have to repeat the `INT16_MIN` / `INT8_MIN` / `0` checks.
    """

    raw: bytes
    node_id: bytes
    uptime_s: int
    boot_count: int
    reset_reason: int
    mcu_temp_q4: int       # 0.0625 °C units, INT16_MIN = unavailable
    radio_temp_c: int      # °C, INT8_MIN = unavailable
    vbat_mv: int
    gps_sats: int
    gps_hdop_x10: int
    pps_jitter_us: int
    ble_active: int
    free_heap: int

    @property
    def mcu_temp_c(self) -> float | None:
        """nRF52840 die temp in °C, or ``None`` when the firmware
        marked the field unavailable (INT16_MIN sentinel)."""
        if self.mcu_temp_q4 == DEVICE_TELEMETRY_MCU_TEMP_UNAVAILABLE:
            return None
        # Q12.4 fixed-point — divide by 16.
        return self.mcu_temp_q4 / 16.0

    @property
    def radio_temp_c_or_none(self) -> int | None:
        """SX1262 die temp in °C, or ``None`` when the firmware marked
        the field unavailable (INT8_MIN sentinel). The firmware
        currently always emits the sentinel — see KAN-101 PR notes
        for the deferred opcode-0x1C work."""
        if self.radio_temp_c == DEVICE_TELEMETRY_RADIO_TEMP_UNAVAILABLE:
            return None
        return self.radio_temp_c

    @property
    def gps_hdop(self) -> float | None:
        """HDOP as a float, or ``None`` when the firmware reports
        the ``unknown`` sentinel (0)."""
        return self.gps_hdop_x10 / 10.0 if self.gps_hdop_x10 else None

    @property
    def gps_fix(self) -> bool:
        """Best-effort fix indicator: any sat-count > 0 implies the
        GPS module currently has a fix when this telemetry frame was
        emitted. Distinct from GPS_TIME_SYNC_CONFIRMED (carried in
        the 0x94 GATEWAY_INFO frame), which gates a stricter PPS-
        stability test as well."""
        return self.gps_sats > 0


def parse_device_telemetry_frame(raw: bytes) -> DeviceTelemetryFrame | None:
    """Best-effort decode of a 29-byte 0x96 candidate window (KAN-101).

    Returns ``None`` on any structural problem or implausible-value
    rejection. Misalignment guards mirror the 0x90 parser: any
    obviously-out-of-range field (e.g. boot_count > 16k, reset_reason
    > 255 — masked by struct, but VBAT > 6000 mV is impossible on a
    LiPo) means the 29-byte window almost certainly landed in the
    middle of an unrelated companion-protocol frame.
    """
    if len(raw) != DEVICE_TELEMETRY_LEN:
        return None
    if raw[0] != DEVICE_TELEMETRY_TYPE_BYTE:
        return None
    try:
        (
            node_id,
            uptime_s,
            boot_count,
            reset_reason,
            mcu_temp_q4,
            radio_temp_c,
            vbat_mv,
            gps_sats,
            gps_hdop_x10,
            pps_jitter_us,
            ble_active,
            free_heap,
        ) = struct.unpack(_DEVICE_TELEMETRY_BODY_FMT, raw[1:DEVICE_TELEMETRY_LEN])
    except struct.error:
        return None

    # Plausibility / misalignment guards. These are tuned to be very
    # generous — the telemetry frame is the WIDEST 0x9X frame the bridge
    # parses (28 bytes after the magic), so the false-positive rate from
    # noise is already negligible. We only reject values that are
    # physically impossible:
    #   * VBAT in mV: realistic 0..6000 (LiPo 3.0–4.4 V; 6000 covers
    #     a hypothetical USB-VBUS 5.0 V rail with margin).
    #   * GPS sats: 0..64 (multi-constellation receivers cap ~32).
    #   * HDOP × 10: 0..999 (HDOP > 99.9 is impossible).
    #   * MCU temp q4: -5000..+5000 (≈ -312 °C..+312 °C — the chip
    #     itself rates -40..+85 °C, so the bound is intentionally
    #     loose to allow INT16_MIN as a documented sentinel without
    #     a separate branch — INT16_MIN < -5000 would fail this
    #     range check, so we explicitly allow it).
    #   * BLE active: 0 or 1.
    #   * Reset reason: byte-bounded by struct, no further check.
    if vbat_mv > 6000:
        return None
    if gps_sats > 64:
        return None
    if gps_hdop_x10 > 999:
        return None
    if not (0 <= ble_active <= 1):
        return None
    if mcu_temp_q4 != DEVICE_TELEMETRY_MCU_TEMP_UNAVAILABLE and not (
        -5000 <= mcu_temp_q4 <= 5000
    ):
        return None

    return DeviceTelemetryFrame(
        raw=bytes(raw),
        node_id=node_id,
        uptime_s=uptime_s,
        boot_count=boot_count,
        reset_reason=reset_reason,
        mcu_temp_q4=mcu_temp_q4,
        radio_temp_c=radio_temp_c,
        vbat_mv=vbat_mv,
        gps_sats=gps_sats,
        gps_hdop_x10=gps_hdop_x10,
        pps_jitter_us=pps_jitter_us,
        ble_active=ble_active,
        free_heap=free_heap,
    )


@dataclass(frozen=True)
class GpsQualityFrame:
    """Decoded 0x9F GPS_QUALITY frame (Phase-2 GPS housekeeping).

    ``raw`` is the 23-byte source preserved verbatim. Convenience
    properties translate the fixed-point + sentinel fields into Python
    optionals so consumers don't have to repeat the unavailability
    checks (HDOP/PDOP/VDOP zero, geoid INT16_MIN, SOG 0xFFFF).
    """

    raw: bytes
    node_id: bytes
    hdop_x100: int
    pdop_x100: int
    vdop_x100: int
    gps_sats: int
    glonass_sats: int
    beidou_sats: int
    galileo_sats: int
    qzss_sats: int
    fix_quality: int
    geoid_sep_x10: int
    sog_x100: int

    @property
    def hdop(self) -> float | None:
        """Horizontal dilution of precision, or ``None`` when the
        firmware reports the ``unknown`` sentinel (0)."""
        return self.hdop_x100 / 100.0 if self.hdop_x100 else None

    @property
    def pdop(self) -> float | None:
        """Positional dilution of precision, or ``None`` (sentinel 0)."""
        return self.pdop_x100 / 100.0 if self.pdop_x100 else None

    @property
    def vdop(self) -> float | None:
        """Vertical dilution of precision, or ``None`` (sentinel 0)."""
        return self.vdop_x100 / 100.0 if self.vdop_x100 else None

    @property
    def geoid_sep_m(self) -> float | None:
        """Geoid separation in metres, or ``None`` when the firmware
        marked the field unavailable (INT16_MIN sentinel)."""
        if self.geoid_sep_x10 == GPS_QUALITY_GEOID_UNAVAILABLE:
            return None
        return self.geoid_sep_x10 / 10.0

    @property
    def speed_mps(self) -> float | None:
        """Speed-over-ground in m/s, or ``None`` when the firmware
        marked the field unavailable (0xFFFF sentinel)."""
        if self.sog_x100 == GPS_QUALITY_SOG_UNAVAILABLE:
            return None
        return self.sog_x100 / 100.0

    @property
    def sat_total(self) -> int:
        """Total satellites locked across all 5 constellations."""
        return (
            self.gps_sats
            + self.glonass_sats
            + self.beidou_sats
            + self.galileo_sats
            + self.qzss_sats
        )


def parse_gps_quality_frame(raw: bytes) -> GpsQualityFrame | None:
    """Best-effort decode of a 23-byte 0x9F candidate window.

    Returns ``None`` on any structural problem or implausible-value
    rejection. Plausibility bounds mirror the Phase-2 wire spec:

    * DOP_x100 each <= 9999 (DOP > 99.99 is impossible)
    * per-constellation sat counts each <= 32
    * sum of constellation sats <= 64
    * fix_quality in {0..6} ($GPGGA codes; 7+ rejected)
    * geoid_sep_x10 in [-3000, +3000] OR == INT16_MIN sentinel
    * sog_x100 <= 35000 OR == 0xFFFF sentinel
    """
    if len(raw) != GPS_QUALITY_LEN:
        return None
    if raw[0] != GPS_QUALITY_TYPE_BYTE:
        return None
    try:
        (
            node_id,
            hdop_x100,
            pdop_x100,
            vdop_x100,
            gps_sats,
            glonass_sats,
            beidou_sats,
            galileo_sats,
            qzss_sats,
            fix_quality,
            geoid_sep_x10,
            sog_x100,
        ) = struct.unpack(_GPS_QUALITY_BODY_FMT, raw[1:GPS_QUALITY_LEN])
    except struct.error:
        return None

    # Plausibility / misalignment guards. Mirror the bounds in the
    # plan exactly so a future wire-format change is the only place
    # these need updating.
    if hdop_x100 > 9999:
        return None
    if pdop_x100 > 9999:
        return None
    if vdop_x100 > 9999:
        return None
    if gps_sats > 32:
        return None
    if glonass_sats > 32:
        return None
    if beidou_sats > 32:
        return None
    if galileo_sats > 32:
        return None
    if qzss_sats > 32:
        return None
    sat_sum = (
        gps_sats + glonass_sats + beidou_sats + galileo_sats + qzss_sats
    )
    if sat_sum > 64:
        return None
    if fix_quality > 6:
        return None
    if geoid_sep_x10 != GPS_QUALITY_GEOID_UNAVAILABLE and not (
        -3000 <= geoid_sep_x10 <= 3000
    ):
        return None
    if sog_x100 != GPS_QUALITY_SOG_UNAVAILABLE and sog_x100 > 35000:
        return None

    return GpsQualityFrame(
        raw=bytes(raw),
        node_id=node_id,
        hdop_x100=hdop_x100,
        pdop_x100=pdop_x100,
        vdop_x100=vdop_x100,
        gps_sats=gps_sats,
        glonass_sats=glonass_sats,
        beidou_sats=beidou_sats,
        galileo_sats=galileo_sats,
        qzss_sats=qzss_sats,
        fix_quality=fix_quality,
        geoid_sep_x10=geoid_sep_x10,
        sog_x100=sog_x100,
    )


def _strip_padded(b: bytes) -> str:
    """Decode a null-padded UTF-8 byte slot as a clean Python string."""
    # Stop at the first NUL — everything after is filler, not data.
    end = b.find(b"\x00")
    if end >= 0:
        b = b[:end]
    return b.decode("utf-8", errors="replace").strip()


@dataclass(frozen=True)
class TdoaAdvertAuxFrame:
    """Decoded 0x9A TDOA_ADVERT_AUX frame (tdoa-1.8.0).

    Emitted by the firmware immediately after the 0x90 frame; the
    embedded ``packet_hash`` matches the 0x90 frame's hash so the
    bridge can correlate without an additional key. Carries
    advert-derived transmitter coordinates and the (capped) raw
    LoRa packet bytes — both optional, signaled by the flag bits.
    """

    raw: bytes
    packet_hash: bytes  # 4 B; same SHA-256[:4] as the matching 0x90
    tx_lat_e6: int | None
    tx_lon_e6: int | None
    raw_packet: bytes | None


def parse_tdoa_advert_aux_frame(raw: bytes) -> TdoaAdvertAuxFrame | None:
    """Best-effort decode of a 0x9A candidate window.

    Returns ``None`` on any structural problem. The caller's
    speculative window may include either:

    * The full frame the firmware actually emitted (correct case).
    * MORE bytes from the next frame (the FrameExtractor's
      ``_resolve_tdoa_advert_aux_length`` already trimmed this, but
      defensive checks here guard against a buggy upstream).

    Sanity checks on lat/lon bounds (±90/±180 e6) mirror the
    firmware-side validation.
    """
    if len(raw) < TDOA_ADVERT_AUX_MIN_LEN:
        return None
    if raw[0] != TDOA_ADVERT_AUX_TYPE_BYTE:
        return None
    packet_hash = bytes(raw[1:5])
    flags = raw[5]
    cursor = 6
    tx_lat_e6: int | None = None
    tx_lon_e6: int | None = None
    raw_packet: bytes | None = None
    if flags & TDOA_ADVERT_AUX_FLAG_LATLON:
        if cursor + 8 > len(raw):
            return None
        lat_e6, lon_e6 = struct.unpack_from("<ii", raw, cursor)
        cursor += 8
        if not (-90_000_000 <= lat_e6 <= 90_000_000):
            return None
        if not (-180_000_000 <= lon_e6 <= 180_000_000):
            return None
        tx_lat_e6, tx_lon_e6 = lat_e6, lon_e6
    if flags & TDOA_ADVERT_AUX_FLAG_RAW:
        if cursor + 1 > len(raw):
            return None
        raw_len = raw[cursor]
        cursor += 1
        if raw_len > TDOA_ADVERT_AUX_MAX_RAW:
            return None
        if cursor + raw_len > len(raw):
            return None
        raw_packet = bytes(raw[cursor:cursor + raw_len])
        cursor += raw_len
    # Truncate ``raw`` to the bytes we actually consumed so the
    # extractor knows exactly how many bytes to discard.
    return TdoaAdvertAuxFrame(
        raw=bytes(raw[:cursor]),
        packet_hash=packet_hash,
        tx_lat_e6=tx_lat_e6,
        tx_lon_e6=tx_lon_e6,
        raw_packet=raw_packet,
    )


def _resolve_tdoa_advert_aux_length(buf: bytearray) -> int | None:
    """Compute the full byte length of a 0x9A frame from the flags byte.

    Returns ``None`` when not enough bytes are buffered yet to make
    the call. The MIN frame length (6 B) gets us through the flag
    byte; from there we add 8 B for LATLON and read the raw_len byte
    (when set) to learn the raw-packet tail length.
    """
    if len(buf) < TDOA_ADVERT_AUX_MIN_LEN:
        return None
    flags = buf[5]
    needed = TDOA_ADVERT_AUX_MIN_LEN
    if flags & TDOA_ADVERT_AUX_FLAG_LATLON:
        needed += 8
    if flags & TDOA_ADVERT_AUX_FLAG_RAW:
        # raw_len byte follows
        if len(buf) < needed + 1:
            return None
        raw_len = buf[needed]
        if raw_len > TDOA_ADVERT_AUX_MAX_RAW:
            # Implausible — caller should drop one byte and resync.
            return needed  # parser will reject; extractor advances
        needed += 1 + raw_len
    return needed


#: Type alias for any frame the extractor emits.
AnyFrame = (
    TDOAFrame
    | GatewayPositionFrame
    | GatewayInfoFrame
    | DeviceTelemetryFrame
    | TdoaAdvertAuxFrame
    | GpsQualityFrame
)


class FrameExtractor:
    """Stateful frame extractor over a streaming byte buffer.

    Recognises four frame families:

    * 0x90 ``TDOA_RECEPTION`` (23 B) — one per LoRa packet heard by the
      receiver. Outer wrapper 0x91 ``PUSH_CODE_TDOA_RECEPTION``.
    * 0x92 ``GATEWAY_POSITION`` (23 B) — receiver's own GPS position,
      every 60 s. Outer wrapper 0x93 ``PUSH_CODE_TDOA_GATEWAY_POSITION``.
    * 0x94 ``GATEWAY_INFO`` (104 B) — receiver's board / firmware /
      chipset metadata, every ~60 min. Outer 0x95
      ``PUSH_CODE_TDOA_GATEWAY_INFO``.
    * 0x96 ``DEVICE_TELEMETRY`` (29 B) — periodic per-receiver health
      / timing metrics (MCU temp, VBAT, GPS sats, PPS jitter), every
      5 s by firmware default (KAN-101). Outer 0x97
      ``PUSH_CODE_TDOA_DEVICE_TELEMETRY``.
    * 0x9A ``TDOA_ADVERT_AUX`` (variable) — pre-0x90 aux frame carrying
      tx_lat/tx_lon + raw LoRa bytes. Outer wrapper 0x93
      ``PUSH_CODE_TDOA_ADVERT_AUX`` (same as 0x92 — disambiguated by
      the inner type byte).

    ARCHITECTURE (2026-05-24, framing-aware redesign):

    The extractor honours the firmware-side companion-protocol framing
    that ``ArduinoSerialInterface::writeFrame`` (and the BLE / WiFi
    equivalents) all produce:

        > (0x3E)  + LE16 length + <length bytes of payload>

    Algorithm:

    1. Walk the buffer for the next ``>`` (FRAME_START_BYTE).
    2. Read the LE16 length at offsets +1, +2. Validate length
       in [2, _MAX_FRAMED_LEN].
    3. Read the next ``length`` bytes as the payload. Validate
       payload[0] is a known outer push code.
    4. Dispatch to the right inner parser (using payload[1:] as the
       inner-type-prefixed frame body).
    5. On any validation failure: discard ONE byte (the ``>`` was noise
       or non-frame) and resume from step 1.

    This is immune to MESH_DEBUG / BRIDGE_DEBUG / CLI Rescue printf
    text appearing on the USB-CDC line: those bytes don't carry the
    ``>`` + LE16 + push-code header, so they're discarded silently.
    The probability of stray printf text producing a byte stream that
    passes header + push-code + inner-type + plausibility validation
    is vanishingly small (cumulative ~1e-9 per debug line).

    Memory bound: an internal cap drops the oldest bytes if no parseable
    frame appears in the trailing ``max_buffer_size`` bytes (default
    64 KiB). Keeps the bridge from OOM'ing on a stuck firmware.
    """

    def __init__(self, *, max_buffer_size: int = 64 * 1024) -> None:
        self._buf = bytearray()
        self._max = max_buffer_size

    def feed(self, chunk: bytes) -> list[AnyFrame]:
        """Append bytes and return every fully-parseable framed frame.

        Single-path framed extractor: consumes companion-protocol
        envelopes (``> + LE16 length + payload``) where the payload's
        first byte is a known outer push code (0x91/0x93/0x95/0x97)
        and the remainder is dispatched to the matching inner parser.

        2026-05-25: the marker-scan fallback was REMOVED entirely
        after the fleet migrated to framed emit
        (tdoa-1.12.15+ for simple_repeater_tdoa_rx,
        companion_radio was always framed). See PR #160 (and the
        D_Creek incident notes) for why marker-scan was a structural
        contamination surface: it ran on bytes between successive
        framed frames — debug printf, CDC idle noise, MESH_DEBUG
        dumps — and a sufficiently lucky byte alignment in that
        noise could pass the structural parse + plausibility gates
        and land as a fake GATEWAY_INFO row in the DB.

        Non-framed bytes never satisfy header validation, so
        contamination from inter-frame noise is impossible by design.
        If a future firmware variant emits raw (un-framed) frames,
        the extractor here will silently drop those bytes — the right
        fix is to add framing to the firmware, not to re-introduce
        marker-scan.
        """
        if not chunk:
            return []
        self._buf.extend(chunk)
        if len(self._buf) > self._max:
            drop = len(self._buf) - self._max
            del self._buf[:drop]

        out: list[AnyFrame] = []
        while True:
            result = self._next_framed_payload()
            if result is None:
                break
            consumed, outer_push, inner_payload = result
            frame = self._dispatch_inner(outer_push, inner_payload)
            del self._buf[:consumed]
            if frame is not None:
                out.append(frame)
        return out

    # ------------------------------------------------------------------
    # framing helpers
    # ------------------------------------------------------------------

    def _next_framed_payload(self) -> tuple[int, int, bytes] | None:
        """Scan ``self._buf`` for the next valid framed message.

        Returns ``(consumed_bytes, outer_push_code, inner_payload)`` or
        ``None`` when the buffer doesn't yet hold a complete frame.

        Mutates ``self._buf`` by discarding leading non-frame bytes
        (debug text, partial frames whose header didn't validate).
        Per-candidate validation lives in :meth:`_try_frame_at`.
        """
        buf = self._buf
        i = 0
        while i < len(buf):
            if buf[i] != FRAME_START_BYTE:
                i += 1
                continue
            verdict = self._try_frame_at(i)
            if verdict == "wait":
                # Real-looking frame, just incomplete in the buffer.
                # Discard any junk before the candidate and ask the
                # caller to feed us more bytes.
                if i > 0:
                    del buf[:i]
                return None
            if verdict == "skip":
                # `>` byte was noise — advance one byte and continue.
                i += 1
                continue
            # ``verdict`` is the result tuple.
            return verdict  # type: ignore[return-value]
        # No `>` found at all — leave the buffer intact so the marker-
        # scan fallback (pass 2 in feed()) can salvage bare 0x90/0x92/
        # 0x94/0x96/0x9A frames from firmwares that emit without the
        # companion-protocol envelope. Unbounded growth is prevented
        # by the max_buffer_size trim in feed().
        return None

    def _try_frame_at(
        self, i: int,
    ) -> tuple[int, int, bytes] | str:
        """Validate a single ``>``-anchored candidate at offset ``i``.

        Returns one of:
          * ``"wait"`` — header sane but payload not fully buffered.
          * ``"skip"`` — header invalid; caller advances past this byte.
          * ``(consumed, outer_push, inner_payload)`` — accepted frame.
        """
        buf = self._buf
        # Need at least 4 bytes (`>` + LE16 + at least 1 byte payload).
        if i + 4 > len(buf):
            return "wait"
        frame_len = buf[i + 1] | (buf[i + 2] << 8)
        # Length must be sane: at least 2 (outer push + inner type)
        # and within the firmware's MAX_FRAME_SIZE-ish ceiling.
        if frame_len < 2 or frame_len > _MAX_FRAMED_LEN:
            return "skip"
        payload_end = i + 3 + frame_len
        if payload_end > len(buf):
            return "wait"
        # Validate outer push code BEFORE returning. A real `>` in
        # debug text would need the NEXT 3 bytes to ALSO collude
        # (plausible length + known push code) for a false positive
        # to survive — vanishingly unlikely.
        outer = buf[i + 3]
        if outer not in _VALID_OUTER_PUSH_CODES:
            return "skip"
        inner_payload = bytes(buf[i + 4:payload_end])
        # ``consumed`` is measured from the START of the buffer so it
        # includes any junk that preceded the `>`.
        return (payload_end, outer, inner_payload)

    def _dispatch_inner(
        self, outer_push: int, inner_payload: bytes,
    ) -> AnyFrame | None:
        """Route ``inner_payload`` (starting with the inner type byte)
        to the right parse_*_frame helper based on outer push code.

        Returns ``None`` for an unknown / malformed inner type — the
        framing layer already validated the outer push code, so this
        only fires on a length mismatch or plausibility rejection
        inside the parser.
        """
        if not inner_payload:
            return None
        inner_type = inner_payload[0]
        if outer_push == _PUSH_CODE_TDOA_RECEPTION and inner_type == TDOA_TYPE_BYTE:
            return parse_tdoa_frame(inner_payload)
        if outer_push == _PUSH_CODE_TDOA_ADVERT_OR_POS:
            # Same outer push code carries TWO inner types — disambiguate.
            if inner_type == GW_POS_TYPE_BYTE:
                return parse_gateway_position_frame(inner_payload)
            if inner_type == TDOA_ADVERT_AUX_TYPE_BYTE:
                return parse_tdoa_advert_aux_frame(inner_payload)
        if outer_push == _PUSH_CODE_TDOA_GATEWAY_INFO and inner_type == GW_INFO_TYPE_BYTE:
            return parse_gateway_info_frame(inner_payload)
        if (outer_push == _PUSH_CODE_TDOA_DEVICE_TELEMETRY
                and inner_type == DEVICE_TELEMETRY_TYPE_BYTE):
            return parse_device_telemetry_frame(inner_payload)
        if (outer_push == _PUSH_CODE_TDOA_GPS_QUALITY
                and inner_type == GPS_QUALITY_TYPE_BYTE):
            return parse_gps_quality_frame(inner_payload)
        return None

    @property
    def buffered_bytes(self) -> int:
        """Inspectable for tests; not part of the public protocol."""
        return len(self._buf)
