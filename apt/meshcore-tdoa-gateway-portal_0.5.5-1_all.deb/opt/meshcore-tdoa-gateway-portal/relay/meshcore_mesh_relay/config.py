"""Load and validate the per-device mctomqtt-style config.toml.

The portal (D-creek/meshcore-tdoa-gateway repo) writes this exact file at
``/etc/meshcore-tdoa-gateway/devices/<slug>/config.toml``; reusing it as the
sole source of truth so the operator only edits brokers in one place. We
deliberately do NOT define a separate config schema.

Format reference: same as the legacy `mctomqtt` (TOML with [[broker]]
array of tables, each carrying name/server/port/transport/auth/topics).
We accept whatever the portal emits and only validate the fields we need
to publish (server, port, auth.method, custom_topic or topics.packets).
"""
from __future__ import annotations

import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib  # type: ignore[import-not-found]


logger = logging.getLogger(__name__)


@dataclass
class BrokerConfig:
    """A single [[broker]] entry from config.toml, normalised."""

    name: str
    enabled: bool
    server: str
    port: int
    transport: str  # "tcp" | "websockets"
    keepalive: int
    qos: int
    retain: bool
    tls_enabled: bool
    tls_verify: bool
    auth_method: str  # "none" | "password" | "token"
    auth_username: str | None
    auth_password: str | None
    auth_token_audience: str | None
    auth_token_owner: str | None
    auth_token_email: str | None
    custom_topic: str | None
    topics: dict[str, str]  # broker-level topic templates
    # Per-broker payload protocol override (set by the gateway portal's
    # PUT /api/devices/{slug}/brokers/{name}/protocol). "tdoa" = our own
    # TDOA-extended JSON envelope; "mctomqtt" = legacy Cisien/meshcoretomqtt-
    # shaped on8ar payload; None = no override, fall back to the auto-
    # classify default in `broker_kind`.
    protocol_override: str | None
    raw: dict[str, Any]  # the original block, for diagnostic logging

    @property
    def broker_kind(self) -> str:
        """Classify the broker by its server address — used by the router to skip the TDOA broker.

        Mirrors `app/main.py::_classify` in the portal repo (must stay in
        sync — server-substring match is the only signal we have).
        """
        s = self.server.lower()
        if "tdoa" in s:
            return "meshcore-tdoa"
        if "letsmesh" in s:
            return "letsmesh"
        if "meshrank" in s:
            return "meshrank"
        if "on8ar" in s or "emqx" in s:
            return "emqx-public"
        return "generic-mqtt"

    @property
    def effective_protocol(self) -> str:
        """The wire format the dispatcher should use for this broker.

        Resolution order:
          1. Operator override via the portal (TOML ``protocol = "tdoa" |
             "mctomqtt"``) wins outright.
          2. **Topic-marker auto-detect**: any topic template (custom_topic
             or topics.*) containing ``tdoa_gateway`` flags this broker
             as TDOA. The collector also publishes a ``tdoa_gateway``
             status topic on first connect; an MQTT subscriber that
             sees it can call back to the portal to flip the broker.
             Works on first-time nodes — no pubkey needed (vs. the
             earlier ``{PUBLIC_KEY}``-templated approach).
          3. broker_kind == "meshcore-tdoa" → "tdoa" by default
             (legacy match on plain "tdoa" substring, e.g.
             ``tdoa.dahllie.nl``).
          4. Everything else → "mctomqtt" (the legacy on8ar shape).
        """
        if self.protocol_override in ("tdoa", "mctomqtt"):
            return self.protocol_override
        all_topics: list[str] = list(self.topics.values())
        if self.custom_topic:
            all_topics.append(self.custom_topic)
        for t in all_topics:
            if "tdoa_gateway" in str(t).lower():
                return "tdoa"
        # #1B (2026-06-09): NO server-substring fallback. A broker is TDOA only if
        # it SAYS so (protocol="tdoa") or carries a tdoa_gateway topic — not because
        # its hostname happens to contain "tdoa". homeprod (mqtt.dahllie.nl) sets
        # protocol explicitly, so it still classes correctly; a generic broker no
        # longer mis-classes on a host substring (broker_kind stays for diagnostics).
        return "mctomqtt"


@dataclass
class RelayConfig:
    """Top-level relay config — IATA + brokers + global topic templates."""

    iata: str
    repeater_pub_key: str
    repeater_name: str
    brokers: list[BrokerConfig]
    global_topics: dict[str, str] = field(default_factory=dict)


def load(path: Path) -> RelayConfig:
    """Parse the TOML at ``path`` and return a normalised RelayConfig.

    Raises ``FileNotFoundError`` on missing path, ``ValueError`` on
    structural problems (missing iata, missing brokers, etc.). Logs a
    warning + skips any broker missing required fields so a single bad
    entry doesn't blow up the entire fan-out.
    """
    if not path.is_file():
        raise FileNotFoundError(f"config not found: {path}")

    with path.open("rb") as fh:
        doc = tomllib.load(fh)

    general = doc.get("general", {})
    iata = str(general.get("iata", "")).strip()
    if not iata:
        # Not fatal — topic templates that use {IATA} will end up with an
        # empty substitution. mctomqtt does the same.
        logger.warning("config.iata.missing path=%s — {IATA} substitutions will be empty", path)

    repeater = doc.get("repeater", {})
    repeater_name = str(repeater.get("name", "unknown-repeater"))

    # The pubkey isn't in [repeater] in the portal-written config. Try
    # to recover it from any broker that has a token-auth `owner` field
    # (mctomqtt's letsmesh blocks carry the full pubkey here for the
    # JWT minting flow). Falls back to "UNKNOWN" only when neither
    # source has it — at which point {PUBLIC_KEY}-templated topics will
    # carry the literal "UNKNOWN" until the operator fixes the config.
    repeater_pub_key = str(repeater.get("pub_key") or "").upper()
    if not repeater_pub_key:
        for raw in doc.get("broker", []) or []:
            owner = (raw.get("auth") or {}).get("owner")
            if owner:
                repeater_pub_key = str(owner).upper()
                logger.info(
                    "repeater.pub_key.recovered_from_broker_owner broker=%s",
                    raw.get("name", "?"),
                )
                break
    if not repeater_pub_key:
        repeater_pub_key = "UNKNOWN"
        logger.warning(
            "repeater.pub_key.missing — {PUBLIC_KEY} topics will render as 'UNKNOWN'",
        )

    brokers: list[BrokerConfig] = []
    for raw in doc.get("broker", []) or []:
        try:
            brokers.append(_normalise_broker(raw))
        except KeyError as exc:
            logger.warning(
                "config.broker.skipped name=%s reason=missing-field field=%s",
                raw.get("name", "?"),
                exc.args[0],
            )

    if not brokers:
        raise ValueError(f"no [[broker]] entries found in {path}")

    global_topics = doc.get("topics", {}) or {}

    return RelayConfig(
        iata=iata,
        repeater_pub_key=repeater_pub_key,
        repeater_name=repeater_name,
        brokers=brokers,
        global_topics=global_topics,
    )


def _normalise_broker(raw: dict[str, Any]) -> BrokerConfig:
    """Lift the TOML block into a typed BrokerConfig, raising on missing keys."""
    name = str(raw["name"])
    server = str(raw["server"])
    # Port can land as int or quoted str in TOML — coerce.
    port = int(str(raw.get("port", 1883)))
    transport = str(raw.get("transport", "tcp")).lower()
    enabled = bool(raw.get("enabled", False))
    keepalive = int(raw.get("keepalive", 60))
    qos = int(raw.get("qos", 0))
    # 2026-05-27: letsmesh's reference exporter (Cisien/meshcoretomqtt)
    # publishes with retain=True so the analyzer's last-known-state view
    # survives observer reconnects. Other brokers default retain=False
    # (the MQTT default); operators can still override per-broker in TOML.
    retain_default = "letsmesh" in server.lower()
    retain = bool(raw.get("retain", retain_default))

    tls = raw.get("tls", {}) or {}
    tls_enabled = bool(tls.get("enabled", False))
    tls_verify = bool(tls.get("verify", True))

    auth = raw.get("auth", {}) or {}
    auth_method = str(auth.get("method", "none")).lower()
    auth_username = auth.get("username")
    auth_password = auth.get("password")
    auth_token_audience = auth.get("audience")
    auth_token_owner = auth.get("owner")
    auth_token_email = auth.get("email")

    custom_topic = raw.get("custom_topic")
    topics = raw.get("topics", {}) or {}

    # Per-broker protocol override; only honor "tdoa" / "mctomqtt".
    raw_proto = str(raw.get("protocol") or "").lower().strip()
    protocol_override = raw_proto if raw_proto in ("tdoa", "mctomqtt") else None

    return BrokerConfig(
        name=name,
        enabled=enabled,
        server=server,
        port=port,
        transport=transport,
        keepalive=keepalive,
        qos=qos,
        retain=retain,
        tls_enabled=tls_enabled,
        tls_verify=tls_verify,
        auth_method=auth_method,
        auth_username=str(auth_username) if auth_username else None,
        auth_password=str(auth_password) if auth_password else None,
        auth_token_audience=str(auth_token_audience) if auth_token_audience else None,
        auth_token_owner=str(auth_token_owner) if auth_token_owner else None,
        auth_token_email=str(auth_token_email) if auth_token_email else None,
        custom_topic=str(custom_topic) if custom_topic else None,
        topics={str(k): str(v) for k, v in topics.items()},
        protocol_override=protocol_override,
        raw=raw,
    )


def resolve_topic(template: str, iata: str, pub_key: str) -> str:
    """Apply {IATA} and {PUBLIC_KEY} substitutions exactly as mctomqtt does."""
    return template.replace("{IATA}", iata).replace("{PUBLIC_KEY}", pub_key)


def load_all_devices(devices_root: Path) -> dict[str, RelayConfig]:
    """Scan ``<devices_root>/<slug>/config.toml`` and return ``{slug: RelayConfig}``.

    Used by the relay to attach per-device identity (repeater_name +
    repeater_pub_key) to outbound packets — so on8ar / letsmesh / etc.
    see each USB-attached receiver on the Pi as its own node instead of
    all RX being attributed to the single config the relay was started
    against.

    Each ``slug`` is the device directory name, which the bridge also
    uses as the MQTT ``gateway/<slug>/uplink`` topic — so the slug
    extracted from the inbound topic in input_mqtt.py directly indexes
    this dict.

    Broken / unparseable per-device configs are skipped with a warning;
    the relay keeps running with whatever did load. Missing root dir
    returns an empty dict (caller falls back to its primary config).
    """
    out: dict[str, RelayConfig] = {}
    if not devices_root.is_dir():
        return out
    for entry in sorted(devices_root.iterdir()):
        if not entry.is_dir():
            continue
        cfg_path = entry / "config.toml"
        if not cfg_path.is_file():
            continue
        try:
            out[entry.name] = load(cfg_path)
        except (FileNotFoundError, ValueError) as exc:
            logger.warning(
                "device_config.skipped slug=%s reason=%s", entry.name, exc,
            )
    return out
