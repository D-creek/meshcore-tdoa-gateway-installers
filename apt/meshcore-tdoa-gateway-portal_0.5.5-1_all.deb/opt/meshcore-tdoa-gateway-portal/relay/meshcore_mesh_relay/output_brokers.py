"""Per-broker MQTT publishers — one paho client per enabled broker.

The router (`__main__.py`) calls `publish_to_all(payload_bytes, topic_per_broker)`
which dispatches to every broker's queue. Each broker runs its own paho
client + thread so a slow/dead broker doesn't block the others.

We deliberately do NOT implement letsmesh-us JWT minting in this MVP —
the token must be pre-provisioned by the operator (mctomqtt-style
``[broker.auth] method="token" audience=... owner=... email=...`` block).
Token refresh, if needed later, is a follow-up.
"""
from __future__ import annotations

import logging
import socket
import ssl
import threading
from typing import Any

import paho.mqtt.client as mqtt

from . import auth_token
from .config import BrokerConfig, resolve_topic


logger = logging.getLogger(__name__)


def _build_client_id(broker_name: str, scope_suffix: str = "") -> str:
    """MQTT client_id that won't collide across Pis or across devices on one Pi.

    Segments:
      - broker name (operator-meaningful in broker logs)
      - local hostname (scopes to this Pi — without it two Pis would
        share one client_id and kick each other off the same broker)
      - optional ``scope_suffix`` (added 2026-05-30) — scopes the
        client_id to a specific RECEIVER on the Pi. Multi-device Pis
        (e.g. SkyPi4 = FeedCafe + D_Creek) now publish through one
        connection per receiver, mctomqtt-style; without the suffix
        the two devices' clients would share one id and rc=7-flap.

    MQTT spec allows 23 ASCII chars in some implementations; mosquitto
    + emqx accept longer, so we don't truncate.
    """
    base = f"meshcore-mesh-relay-{broker_name}-{socket.gethostname()}"
    return f"{base}-{scope_suffix}" if scope_suffix else base


#: Identifies OUR homeprod TDOA exporter — the ONE broker the relay must skip
#: (the bridge publishes our TDOA envelope there directly). Hardcoded per the
#: 2026-06-08 operator directive: no protocol/topic/URL classification, just the
#: homeprod broker name / our cloud host. Everything else is a legacy mctomqtt
#: fan-out target.
_HOMEPROD_BROKER_NAMES = frozenset({"homeprod", "home-prod", "home-prod-wss"})
_HOMEPROD_HOST_MARKERS = ("mqtt.dahllie", "homeprod.dahllie")


def _is_homeprod_exporter(cfg: BrokerConfig) -> bool:
    """True for our homeprod TDOA exporter (skipped); everything else fans out."""
    name = (cfg.name or "").strip().lower()
    server = (cfg.server or "").lower()
    if name in _HOMEPROD_BROKER_NAMES or "homeprod" in name:
        return True
    return any(marker in server for marker in _HOMEPROD_HOST_MARKERS)


class BrokerClient:
    """Wraps one paho client + its connection state + a publish helper."""

    def __init__(
        self,
        cfg: BrokerConfig,
        *,
        iata: str,
        pub_key: str,
        priv_key: str | None = None,
        scope_suffix: str = "",
    ) -> None:
        self.cfg = cfg
        self._iata = iata
        self._pub_key = pub_key
        self._priv_key = priv_key
        self._client = mqtt.Client(
            client_id=_build_client_id(cfg.name, scope_suffix),
            clean_session=True,
            transport="websockets" if cfg.transport == "websockets" else "tcp",
        )
        if cfg.auth_method == "password" and cfg.auth_username:
            self._client.username_pw_set(cfg.auth_username, cfg.auth_password or "")
        elif cfg.auth_method == "token":
            # Token-auth brokers (letsmesh) want a fresh MeshCore-signed
            # JWT as the MQTT password. Username MUST be ``v1_<PUBKEY>``
            # — letsmesh rejects with rc=5 otherwise (see mctomqtt's
            # mqtt_manager.py:_compute_username_password). Token TTL = 1 h;
            # auto-refresh in start() if needed.
            token = self._mint_jwt()
            self._client.username_pw_set(f"v1_{pub_key.upper()}", token)
        if cfg.tls_enabled:
            self._client.tls_set(cert_reqs=ssl.CERT_REQUIRED if cfg.tls_verify else ssl.CERT_NONE)
            if not cfg.tls_verify:
                self._client.tls_insecure_set(True)
        self._client.on_connect = self._on_connect
        self._client.on_disconnect = self._on_disconnect
        self._client.on_message = self._on_message
        self._connected_evt = threading.Event()
        self._lock = threading.Lock()
        # Status counters surface via `snapshot()` for the systemd /
        # portal status file.
        self._last_publish_ok_at: float | None = None
        self._publish_ok = 0
        self._publish_fail = 0
        self._last_error: str | None = None
        # 2026-05-25 — MQTT-native TDOA detection. Every output broker
        # subscribes to ``tdoa_gateway/_meta/protocol`` (retained).
        # Whoever publishes data in TDOA format (the bridge, this
        # relay's own _announce, etc.) drops a retained meta there on
        # connect. If we ever receive that retained message on this
        # broker, we know this broker carries TDOA-format traffic and
        # surface ``observed_protocol = "tdoa"`` to the portal.
        # ``mctomqtt`` stays the default until/unless we see the marker.
        self._observed_protocol: str | None = None
        self._observed_protocol_at: float | None = None

    def start(self) -> None:
        logger.info(
            "broker.connecting name=%s server=%s port=%s transport=%s tls=%s auth=%s",
            self.cfg.name, self.cfg.server, self.cfg.port,
            self.cfg.transport, self.cfg.tls_enabled, self.cfg.auth_method,
        )
        try:
            self._client.connect_async(self.cfg.server, self.cfg.port, keepalive=self.cfg.keepalive)
            self._client.loop_start()
        except Exception as exc:  # noqa: BLE001
            # connect_async should not raise on DNS errors (it queues for
            # the loop), but be defensive — never let one broker's init
            # take down the relay.
            self._last_error = f"connect_async: {exc}"
            logger.exception("broker.connect_async_failed name=%s", self.cfg.name)

    def stop(self) -> None:
        try:
            self._client.loop_stop()
            self._client.disconnect()
        except Exception:  # noqa: BLE001
            pass

    def publish(self, payload: bytes) -> bool:
        """Resolve the /packets topic + send. Returns True on enqueue."""
        return self._publish_to(self._resolve_topic(), payload)

    def publish_status(self, payload: bytes) -> bool:
        """Resolve the /status topic + send (on8ar canonical path).

        Used only for ``broker_kind == "emqx-public"``. Other brokers
        also reach this method when iterated, but their resolved topic
        is the /status sibling of their /packets template — harmless
        when nobody subscribes to it.
        """
        return self._publish_to(self._resolve_status_topic(), payload)

    def _publish_to(self, topic: str, payload: bytes) -> bool:
        if not topic:
            self._last_error = "no topic template"
            self._publish_fail += 1
            return False
        with self._lock:
            try:
                # QoS 1 in mctomqtt's code was downgraded to 0 to avoid
                # retry storms — preserve that behaviour exactly.
                qos = 0 if self.cfg.qos == 1 else self.cfg.qos
                info = self._client.publish(topic, payload, qos=qos, retain=self.cfg.retain)
                if info.rc != mqtt.MQTT_ERR_SUCCESS:
                    self._publish_fail += 1
                    self._last_error = f"paho rc={info.rc}"
                    return False
                self._publish_ok += 1
                import time
                self._last_publish_ok_at = time.time()
                return True
            except Exception as exc:  # noqa: BLE001
                self._publish_fail += 1
                self._last_error = f"publish: {exc}"
                logger.exception("broker.publish_failed name=%s", self.cfg.name)
                return False

    def snapshot(self) -> dict[str, Any]:
        """Connection + counters for the status file (portal consumes this)."""
        return {
            "name": self.cfg.name,
            "server": self.cfg.server,
            "port": self.cfg.port,
            "transport": self.cfg.transport,
            "auth": self.cfg.auth_method,
            "kind": self.cfg.broker_kind,
            "enabled": self.cfg.enabled,
            "connected": self._connected_evt.is_set(),
            "publish_ok": self._publish_ok,
            "publish_fail": self._publish_fail,
            "last_publish_ok_at": self._last_publish_ok_at,
            "last_error": self._last_error,
            # 2026-05-25 — MQTT-native protocol detection. Goes from
            # null to "tdoa" the moment the retained
            # ``tdoa_gateway/_meta/protocol`` message lands on this
            # broker. Stays null on brokers that never carry that
            # marker (letsmesh / on8ar / generic mosquitto). The
            # portal classifies brokers from this field — strictly an
            # MQTT signal, no hostname / IP / username strategy.
            "observed_protocol": self._observed_protocol,
            "observed_protocol_at": self._observed_protocol_at,
        }

    # ------- internals -------

    def _resolve_topic(self) -> str:
        # Per-broker custom_topic wins (meshrank uses this pattern).
        if self.cfg.custom_topic:
            return resolve_topic(self.cfg.custom_topic, self._iata, self._pub_key)
        # Otherwise per-broker [topics] table, then nothing.
        broker_packets = self.cfg.topics.get("packets")
        if broker_packets:
            return resolve_topic(broker_packets, self._iata, self._pub_key)
        # Sensible default — mctomqtt's typical "meshcore/{IATA}/{PUBLIC_KEY}/packets".
        return resolve_topic("meshcore/{IATA}/{PUBLIC_KEY}/packets", self._iata, self._pub_key)

    def _resolve_status_topic(self) -> str:
        """Sibling /status topic of the /packets template.

        Resolution order matches `_resolve_topic`:
          1. Per-broker [topics].status (when the operator declares one)
          2. Sibling of custom_topic — replace `/packets` → `/status`
          3. Sibling of [topics].packets — same replace
          4. Default ``meshcore/{IATA}/{PUBLIC_KEY}/status``
        """
        broker_status = self.cfg.topics.get("status")
        if broker_status:
            return resolve_topic(broker_status, self._iata, self._pub_key)
        # Derive from /packets by swapping the trailing segment so
        # operators don't have to manage two topic strings per broker.
        if self.cfg.custom_topic:
            derived = self.cfg.custom_topic.replace("/packets", "/status")
            if derived != self.cfg.custom_topic:
                return resolve_topic(derived, self._iata, self._pub_key)
        broker_packets = self.cfg.topics.get("packets")
        if broker_packets:
            derived = broker_packets.replace("/packets", "/status")
            if derived != broker_packets:
                return resolve_topic(derived, self._iata, self._pub_key)
        return resolve_topic("meshcore/{IATA}/{PUBLIC_KEY}/status",
                             self._iata, self._pub_key)

    def _mint_jwt(self) -> str:
        """Generate a fresh letsmesh JWT — claims come straight from the
        broker config (audience / sub / etc). Falls back to a static
        cfg.auth_password if minting fails so the operator can still
        ship a pre-baked token if `meshcore-decoder` is unavailable.
        """
        if not self._priv_key:
            if self.cfg.auth_password:
                logger.warning(
                    "broker.jwt.no_priv_key name=%s falling_back_to_static_password",
                    self.cfg.name,
                )
                return self.cfg.auth_password
            raise RuntimeError(
                f"broker {self.cfg.name} needs token auth but no priv_key supplied "
                "(set BRIDGE_REPEATER_PRIV_KEY in /etc/default/meshcore-mesh-relay)"
            )
        # Claim key names match mctomqtt's mqtt_manager.py exactly
        # (letsmesh's verifier expects ``aud`` + ``owner`` + lower-case
        # ``email`` — using ``audience`` or ``sub`` returns rc=5).
        #
        # 2026-05-27: ``publicKey`` (UPPER hex) added — Cisien/meshcoretomqtt
        # injects it via the meshcore-decoder CLI and letsmesh's verifier
        # requires it in the payload. Setting it explicitly here is
        # idempotent (CLI overrides match): safer than depending on the
        # CLI's auto-injection behaviour, which may differ by version.
        claims: dict[str, Any] = {
            "client": "meshcore-mesh-relay/0.1.0",
            "publicKey": self._pub_key.upper(),
        }
        if self.cfg.auth_token_audience:
            claims["aud"] = self.cfg.auth_token_audience
        # Owner + email are only sent when TLS verify is on (letsmesh
        # treats them as PII and refuses to accept over a non-verified
        # channel — same gate as mctomqtt).
        if self.cfg.tls_enabled and self.cfg.tls_verify:
            if self.cfg.auth_token_owner:
                claims["owner"] = self.cfg.auth_token_owner
            if self.cfg.auth_token_email:
                claims["email"] = self.cfg.auth_token_email.lower()
        try:
            return auth_token.mint(self._pub_key, self._priv_key, **claims)
        except (FileNotFoundError, RuntimeError) as exc:
            self._last_error = f"jwt mint: {exc}"
            logger.exception("broker.jwt.mint_failed name=%s", self.cfg.name)
            if self.cfg.auth_password:
                logger.warning(
                    "broker.jwt.fallback_to_static_password name=%s",
                    self.cfg.name,
                )
                return self.cfg.auth_password
            raise

    # Canonical retained-meta topic that announces a broker is part of
    # the TDOA-format ecosystem. Whoever produces data in TDOA format
    # (today: the bridge) publishes ``{"format":"tdoa","version":1}``
    # here retained on connect. The portal classifies brokers by
    # whether ``observed_protocol`` flipped to "tdoa" — strictly via
    # MQTT, no hostname / IP / username fingerprints.
    _TDOA_META_TOPIC = "tdoa_gateway/_meta/protocol"

    def _on_connect(self, _c: mqtt.Client, _u: Any, _f: Any, rc: int) -> None:
        if rc == 0:
            self._connected_evt.set()
            self._last_error = None
            logger.info("broker.connected name=%s", self.cfg.name)
            # Subscribe to the TDOA-protocol meta topic so a retained
            # marker on this broker reaches us within the next packet.
            # QoS 0 — best-effort; the marker is retained so a missed
            # delivery just means we re-fetch on next reconnect.
            try:
                _c.subscribe(self._TDOA_META_TOPIC, qos=0)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "broker.meta_subscribe_failed name=%s err=%s",
                    self.cfg.name, exc,
                )
            # If this broker IS already classified as TDOA (the relay's
            # own effective_protocol resolved to "tdoa" — typically
            # because the operator set ``protocol = "tdoa"`` in the
            # broker TOML, or because the topic template contains
            # ``tdoa_gateway``), advertise that fact to peers by
            # publishing the retained meta. From this point any other
            # subscriber on this broker (this Pi's portal, another
            # Pi's relay) auto-detects TDOA via pure MQTT — no
            # hostname guess needed.
            try:
                if self.cfg.effective_protocol == "tdoa":
                    import json as _json
                    marker = _json.dumps({
                        "format": "tdoa", "version": 1,
                        "source": "meshcore-mesh-relay",
                        "broker_name": self.cfg.name,
                    }, separators=(",", ":")).encode("utf-8")
                    _c.publish(self._TDOA_META_TOPIC, marker, qos=1, retain=True)
                    logger.info(
                        "broker.meta_published name=%s topic=%s",
                        self.cfg.name, self._TDOA_META_TOPIC,
                    )
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "broker.meta_publish_failed name=%s err=%s",
                    self.cfg.name, exc,
                )
            return
        self._last_error = f"connack rc={rc}"
        logger.warning("broker.connack_fail name=%s rc=%s", self.cfg.name, rc)
        # Token-auth brokers (letsmesh) re-mint the JWT on auth-class
        # failures. rc=4 = "Bad username or password" (3.1.1 / 5),
        # rc=16 = "ACL denied" in 3.1.1 OR "session taken over" in
        # MQTT 5 — observed live on letsmesh-us 2026-05-25 cycling
        # every ~2 min, which suggests broker-side token rejection
        # rather than a true ACL fault. Treating both as JWT-stale
        # closes the reconnect loop with a fresh signature.
        if rc in (4, 16) and self.cfg.auth_method == "token":
            self._refresh_jwt()

    def _on_message(self, _c: mqtt.Client, _u: Any, msg: mqtt.MQTTMessage) -> None:
        """Receive callback — used only for the TDOA-protocol meta topic.

        Output brokers don't subscribe to anything else by default, so
        any message arriving here SHOULD be the retained meta. We're
        defensive about parse failures: a bad payload still flips us
        to ``observed_protocol="tdoa"`` because the topic itself is
        the signal — the payload is just version metadata.
        """
        try:
            topic = msg.topic
        except Exception:  # noqa: BLE001
            return
        if topic != self._TDOA_META_TOPIC:
            return
        import time
        prev = self._observed_protocol
        self._observed_protocol = "tdoa"
        self._observed_protocol_at = time.time()
        if prev != "tdoa":
            logger.info(
                "broker.observed_protocol name=%s -> tdoa "
                "(retained meta seen, payload=%r)",
                self.cfg.name, msg.payload[:120],
            )

    def _on_disconnect(self, _c: mqtt.Client, _u: Any, rc: int) -> None:
        self._connected_evt.clear()
        if rc == 0:
            return
        self._last_error = f"disconnected rc={rc}"
        logger.warning("broker.disconnected name=%s rc=%s (auto-reconnect)", self.cfg.name, rc)
        # Same JWT-refresh logic on every disconnect for token brokers —
        # paho auto-reconnect re-uses the stored username/password unless
        # we update them. The cost is one CLI invocation per disconnect
        # (~50 ms), negligible vs. a stuck-rc=4 reconnect loop. rc=16
        # added 2026-05-25 after letsmesh-us was observed flapping every
        # 2 min with rc=16 — same broker-side-token-rejection symptom
        # as rc=4, so refresh aggressively rather than wait for the
        # next periodic reconnect.
        if self.cfg.auth_method == "token":
            self._refresh_jwt()

    def _refresh_jwt(self) -> None:
        """Mint a fresh JWT + push it into paho's stored credentials.

        Idempotent; on any minter failure logs + leaves the previous
        credentials in place (the next disconnect will retry). Used by
        the rc=4 path in :meth:`_on_connect` and the every-disconnect
        path in :meth:`_on_disconnect`.
        """
        if not self._priv_key:
            return
        try:
            token = self._mint_jwt()
        except Exception as exc:  # noqa: BLE001
            self._last_error = f"jwt refresh: {exc}"
            logger.warning("broker.jwt.refresh_failed name=%s error=%s",
                           self.cfg.name, exc)
            return
        self._client.username_pw_set(f"v1_{self._pub_key.upper()}", token)
        logger.info("broker.jwt.refreshed name=%s", self.cfg.name)


class BrokerPool:
    """Owns one BrokerClient per enabled, non-TDOA broker."""

    def __init__(
        self,
        brokers: list[BrokerConfig],
        *,
        iata: str,
        pub_key: str,
        priv_key: str | None = None,
        scope_suffix: str = "",
    ) -> None:
        self._clients: list[BrokerClient] = []
        for cfg in brokers:
            if not cfg.enabled:
                logger.info("broker.skipped name=%s reason=disabled", cfg.name)
                continue
            if _is_homeprod_exporter(cfg):
                # HARDCODED (operator directive 2026-06-08): our homeprod
                # exporter is the ONE TDOA broker and the BRIDGE publishes our
                # TDOA envelope there directly — the relay must never also
                # publish there (double fan-out + "homeprod not authorised" auth
                # failures + bogus UI status). Every OTHER broker is a legacy
                # mctomqtt fan-out target. Identified by the homeprod broker name
                # / our cloud host — deliberately NOT by any protocol/topic/URL
                # classification (that machinery was removed).
                logger.info(
                    "broker.skipped name=%s reason=homeprod_handled_by_bridge",
                    cfg.name,
                )
                continue
            try:
                self._clients.append(
                    BrokerClient(
                        cfg, iata=iata, pub_key=pub_key, priv_key=priv_key,
                        scope_suffix=scope_suffix,
                    ),
                )
            except RuntimeError as exc:
                # Constructor only raises when a broker needs token auth
                # but no priv_key was supplied. Skip with a warning so
                # the other brokers stay up.
                logger.warning(
                    "broker.skipped name=%s reason=%s",
                    cfg.name, exc,
                )

    def start(self) -> None:
        for c in self._clients:
            c.start()

    def stop(self) -> None:
        for c in self._clients:
            c.stop()

    def publish_all(self, payload: bytes) -> dict[str, bool]:
        """Fan out to every client. Returns name → ok-bool."""
        return {c.cfg.name: c.publish(payload) for c in self._clients}

    def publish_per_broker(
        self,
        payload_by_kind: dict[str, bytes],
        default_payload: bytes,
        *,
        tdoa_payload: bytes | None = None,
    ) -> dict[str, bool]:
        """Fan out distinct payloads per broker.

        Resolution order per broker:
          1. ``effective_protocol == "tdoa"`` (operator override OR
             special-topic auto-detect from config.py) AND ``tdoa_payload``
             provided → send the TDOA-extended envelope.
          2. Else look up ``broker_kind`` in ``payload_by_kind`` (legacy
             behaviour — letsmesh / meshrank / emqx-public formatters).
          3. Fall back to ``default_payload``.

        ``payload_by_kind`` maps broker_kind strings (e.g.
        ``"emqx-public"``, ``"letsmesh"``) to per-kind payload bytes.
        """
        out: dict[str, bool] = {}
        for c in self._clients:
            if (
                tdoa_payload is not None
                and c.cfg.effective_protocol == "tdoa"
            ):
                payload = tdoa_payload
            else:
                payload = payload_by_kind.get(c.cfg.broker_kind, default_payload)
            out[c.cfg.name] = c.publish(payload)
        return out

    def publish_status_to_kind(self, kind: str, payload: bytes) -> dict[str, bool]:
        """Publish a /status payload to every broker matching ``kind``.

        Used by the periodic on8ar /status backstop in __main__.py.
        Brokers of other kinds get NO publish — we don't pollute
        letsmesh / meshrank with status frames they don't expect.
        """
        out: dict[str, bool] = {}
        for c in self._clients:
            if c.cfg.broker_kind != kind:
                continue
            out[c.cfg.name] = c.publish_status(payload)
        return out

    def snapshot(self) -> list[dict[str, Any]]:
        return [c.snapshot() for c in self._clients]

    @property
    def client_count(self) -> int:
        return len(self._clients)
